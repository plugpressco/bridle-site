/*
 * Who the visitor talks to (#163): the assistant's name ("Blake" unless the
 * owner renamed it) and face (one of the built-in faces, or the owner's own
 * picture), always labelled as an AI. A person from the team gets their
 * initials instead, so a reply from a human never looks like the AI's.
 */
import { el } from './dom';
import { faceSvg } from './faces';

export function agentOf( config ) {
	const agent = config.agent || {};
	return {
		name: String( agent.name || 'Blake' ),
		face: String( agent.face || '' ),
		image: String( agent.image || '' ),
	};
}

/* The assistant's face, `size` in px. */
export function assistantFace( config, size ) {
	const agent = agentOf( config );
	const node = el( 'span', { class: 'ava', 'aria-hidden': 'true' } );
	node.style.setProperty( '--size', size + 'px' );
	const svg = agent.image ? '' : faceSvg( agent.face );
	if ( agent.image ) {
		node.append( el( 'img', { src: agent.image, alt: '' } ) );
	} else if ( svg ) {
		node.innerHTML = svg;
	} else if ( config.logo ) {
		node.append( el( 'img', { src: config.logo, alt: '' } ) );
	} else {
		node.classList.add( 'letter' );
		node.textContent = agent.name.charAt( 0 ).toUpperCase();
	}
	return node;
}

/* A team member's initials, `size` in px. */
export function personFace( name, size ) {
	const node = el( 'span', {
		class: 'ava letter team',
		'aria-hidden': 'true',
	} );
	node.style.setProperty( '--size', size + 'px' );
	const words = String( name || '?' )
		.trim()
		.split( /\s+/ )
		.filter( Boolean );
	node.textContent = (
		( words[ 0 ] || '?' ).charAt( 0 ) +
		( words.length > 1 ? words[ words.length - 1 ].charAt( 0 ) : '' )
	).toUpperCase();
	return node;
}
