/*
 * Bridle Chat's element (#114, polish #163). Config and every word come
 * from PHP (Services\ChatWidget::config()) as window.bridleChat. The chat
 * survives page loads (store.js); while it's with a person the bubble checks
 * for the team's replies (#120): every 15 seconds open, every minute closed,
 * with a badge and a soft chime for unread ones.
 *
 * Live (#131, only with `config.live`, which Bridle Pro sets): when a person
 * is here, a handoff stays in the bubble without an email, the checks speed
 * up to what the server asks (`poll`), and "Typing…" shows both ways.
 */
import { dots, edgeFailed, el, post, wait } from './dom';
import { chime, peekCard } from './peek';
import { solve } from './pow';
import * as store from './store';
import { STYLES } from './styles';
import * as view from './view';

export class BridleChat extends window.HTMLElement {
	connectedCallback() {
		if ( this.shadowRoot ) {
			return;
		}
		this.config = window.bridleChat;
		this.s = this.config.strings;
		this.state = store.load() || store.fresh();
		this.turnstileToken = '';
		this.render();
		this.listen();
		this.confirmFromLink();
		this.schedulePeek();
	}

	render() {
		const { config } = this;
		const root = this.attachShadow( { mode: 'open' } );
		root.innerHTML = `<style>${ STYLES }</style>`;

		this.wrap = el( 'div', {
			class: [
				'bc',
				config.position === 'left' ? 'left' : '',
				config.size === 'compact' ? 'compact' : '',
				config.theme || 'light',
			]
				.filter( Boolean )
				.join( ' ' ),
		} );
		this.wrap.style.setProperty( '--bc-accent', config.color );

		this.panel = el( 'section', {
			class: 'panel',
			role: 'dialog',
			'aria-label': [ this.agentName(), this.s.role, config.title ]
				.filter( Boolean )
				.join( ', ' ),
			hidden: true,
		} );
		this.log = el( 'div', {
			class: 'log',
			role: 'log',
			'aria-live': 'polite',
		} );
		this.form = view.handoffForm( this );
		this.composer = view.composer( this );
		this.typingNode = dots( this.s.typing || '…' );

		// Turnstile can't draw inside a shadow root: it renders into a light
		// DOM child slotted into the panel.
		this.panel.append(
			view.header( this ),
			this.log,
			el( 'slot', { name: 'turnstile' } ),
			this.form,
			this.composer,
			view.footer( this )
		);

		this.peek = peekCard(
			config,
			this.s,
			() => this.toggle( true ),
			() => this.hidePeek( 'dismissed' )
		);
		this.launcher = view.launcher( this );
		this.wrap.append( this.panel, this.peek, this.launcher );
		root.append( this.wrap );

		this.wrap.addEventListener( 'keydown', ( event ) => {
			if ( event.key !== 'Escape' ) {
				return;
			}
			if ( ! this.peek.hidden ) {
				this.hidePeek( 'dismissed' );
			} else if ( this.panel.hidden ) {
				// Nothing open to close.
			} else if ( ! this.menu.hidden ) {
				this.openMenu( false );
				this.menuButton.focus();
			} else {
				this.toggle( false );
			}
		} );
		this.panel.addEventListener( 'click', ( event ) => {
			if ( ! this.menu.hidden && ! this.menu.contains( event.target ) ) {
				this.openMenu( false );
			}
		} );

		this.paint();
	}

	agentName() {
		return ( this.config.agent && this.config.agent.name ) || 'Blake';
	}

	/*
	 * The greeting peek (#163): after the owner's delay on a page, once a
	 * day, only while the page is in view and the chat isn't going.
	 */
	schedulePeek() {
		const delay = Number( this.config.peek ) || 0;
		const may = () =>
			store.mayPeek( {
				delay,
				seen: store.marks(),
				state: this.state,
				open: ! this.panel.hidden,
				now: Date.now(),
			} );
		if ( ! may() ) {
			return;
		}
		const show = () => {
			if ( document.visibilityState !== 'visible' ) {
				document.addEventListener( 'visibilitychange', show, {
					once: true,
				} );
				return;
			}
			if ( ! may() ) {
				return;
			}
			store.mark( 'peeked' );
			this.peek.hidden = false;
			this.wrap.classList.add( 'peeking' );
			if ( this.config.sound ) {
				chime();
			}
		};
		this.peekTimer = window.setTimeout( show, delay * 1000 );
	}

	hidePeek( why ) {
		window.clearTimeout( this.peekTimer );
		if ( why ) {
			store.mark( why );
		}
		if ( ! this.peek.hidden ) {
			this.peek.hidden = true;
			this.wrap.classList.remove( 'peeking' );
		}
	}

	/*
	 * The proof of work a new chat needs without Turnstile (#165): fetched and
	 * solved as soon as the visitor opens the chat or starts typing, so it is
	 * ready by the time they send. One challenge, one chat.
	 */
	prepare() {
		const bits = Number( this.config.pow ) || 0;
		if ( ! bits || this.state.id ) {
			return Promise.resolve( '' );
		}
		if ( ! this.powPromise ) {
			this.powPromise = ( async () => {
				const task = await this.post( '/challenge', null );
				const n = await solve(
					String( task.challenge ),
					Number( task.bits ) || bits,
					5000,
					() => !! this.state.id
				);
				return n >= 0 ? `${ task.challenge }:${ n }` : '';
			} )().catch( () => {
				this.powPromise = null;
				return '';
			} );
		}
		return this.powPromise;
	}

	/*
	 * The link in the chat's confirmation email (#150) opens the site with
	 * ?bridle_confirm=ID.KEY. One tap confirms the email is the visitor's;
	 * a mail scanner that opens links never taps.
	 */
	confirmFromLink() {
		let value = '';
		try {
			const url = new URL( window.location.href );
			value = url.searchParams.get( 'bridle_confirm' ) || '';
			if ( value ) {
				url.searchParams.delete( 'bridle_confirm' );
				window.history.replaceState( null, '', url.toString() );
			}
		} catch {}
		const match = /^(\d+)\.([a-f0-9]{32})$/.exec( value );
		if ( ! match ) {
			return;
		}
		const node = el( 'div', { class: 'msg bot' } );
		const yes = el(
			'button',
			{ class: 'btn', type: 'button' },
			this.s.confirmYes
		);
		node.append( el( 'p', {}, this.s.confirmAsk ), yes );
		const ask = view.turn( this, node, 'bot' );
		this.log.append( ask );
		yes.addEventListener( 'click', async () => {
			yes.disabled = true;
			try {
				await this.post( '/confirm', {
					id: Number( match[ 1 ] ),
					key: match[ 2 ],
				} );
				ask.remove();
				this.add( { who: 'note', text: this.s.confirmed } );
			} catch ( error ) {
				ask.remove();
				this.add( { who: 'note', text: error.message } );
			}
		} );
		this.toggle( true );
	}

	/*
	 * The team's replies: checked while the chat is with a person, every 15
	 * seconds open (or as fast as a live chat asks) and every minute closed.
	 */
	listen() {
		window.clearTimeout( this.timer );
		if ( ! this.state.id || ! ( this.state.email || this.state.live ) ) {
			return;
		}
		const next = () => {
			window.clearTimeout( this.timer );
			const delay = this.panel.hidden ? 60000 : this.fast || 15000;
			this.timer = window.setTimeout(
				() => this.poll( ! this.panel.hidden ).then( next ),
				delay
			);
		};
		this.poll( ! this.panel.hidden ).then( next );
	}

	typing() {
		return (
			Date.now() - ( this.typedAt || 0 ) < 5000 &&
			this.input.value.trim() !== ''
		);
	}

	/* The visitor typed in the composer. */
	typed() {
		this.grow();
		this.sendButton.disabled = this.busy || ! this.input.value.trim();
		this.typedAt = Date.now();
		// Live: tell the person at once rather than at the next check.
		if (
			this.state.live &&
			! this.panel.hidden &&
			Date.now() - ( this.polledAt || 0 ) > 2500
		) {
			this.poll( true );
		}
	}

	showTyping( on ) {
		if ( on && ! this.typingNode.isConnected ) {
			this.log.append( this.typingNode );
			this.scroll();
		} else if ( ! on ) {
			this.typingNode.remove();
		}
	}

	async poll( open ) {
		if ( this.polling || ! this.state.id ) {
			return;
		}
		this.polling = true;
		this.polledAt = Date.now();
		try {
			const data = await this.post( '/messages', {
				id: this.state.id,
				token: this.state.token,
				after: this.state.lastTeam || 0,
				open,
				typing: open && this.typing(),
			} );
			this.fast = data.poll ? Math.max( 2000, Number( data.poll ) ) : 0;
			if ( data.live ) {
				this.state.live = true;
			}
			this.showTyping( !! data.typing );
			let fresh = 0;
			( data.messages || [] ).forEach( ( message ) => {
				this.state.lastTeam = Math.max(
					this.state.lastTeam || 0,
					message.id
				);
				// The agent's chat answers come too; skip the ones shown already.
				if (
					message.bot &&
					( this.state.answered || [] ).includes( message.id )
				) {
					return;
				}
				this.add( {
					who: message.bot ? 'bot' : 'team',
					name: message.name,
					html: message.html,
				} );
				if ( ! open ) {
					this.state.unread = ( this.state.unread || 0 ) + 1;
					fresh++;
				}
			} );
			if ( fresh && this.config.sound ) {
				chime();
			}
			this.badge();
			this.save();
		} catch ( error ) {
			if ( error.code === 'bridle_chat_gone' ) {
				window.clearTimeout( this.timer );
			}
		} finally {
			this.polling = false;
		}
	}

	badge() {
		const count = this.state.unread || 0;
		this.badgeNode.hidden = ! count;
		this.badgeNode.textContent = count > 9 ? '9+' : String( count );
	}

	save() {
		store.save( this.state );
	}

	openMenu( open ) {
		this.menu.hidden = ! open;
		this.menuButton.setAttribute( 'aria-expanded', String( open ) );
		if ( open ) {
			this.menu.querySelector( 'button:not([hidden]), a' )?.focus();
		}
	}

	toggle( open = this.panel.hidden ) {
		this.panel.hidden = ! open;
		this.wrap.classList.toggle( 'open', open );
		this.launcher.setAttribute( 'aria-expanded', String( open ) );
		this.launcher.setAttribute(
			'aria-label',
			open ? this.s.close : this.s.open
		);
		if ( open ) {
			this.hidePeek( 'opened' );
			if ( this.state.unread ) {
				// Opened to read them: they count as seen, so they aren't emailed.
				this.state.unread = 0;
				this.badge();
				this.save();
			}
			// Check now, and at the open pace rather than the closed one.
			this.listen();
			this.prepare();
			this.loadTurnstile();
			this.scroll();
			( this.state.mode === 'form' ? this.email : this.input ).focus();
		} else {
			this.launcher.focus();
		}
	}

	grow() {
		this.input.style.height = 'auto';
		this.input.style.height =
			Math.min( this.input.scrollHeight, 120 ) + 'px';
	}

	scroll() {
		this.log.scrollTop = this.log.scrollHeight;
	}

	paint() {
		this.log.replaceChildren(
			view.bubble( this, { who: 'bot', text: this.config.greeting } ),
			...this.state.messages.map( ( message ) =>
				view.bubble( this, message )
			)
		);
		this.setMode( this.state.mode );
		this.scroll();
	}

	setMode( mode ) {
		this.state.mode = mode;
		this.form.hidden = mode !== 'form';
		// The form replaces the composer while it's open.
		this.composer.hidden = mode === 'form';
		// Live, the button offers to leave an email too.
		this.personButton.textContent =
			this.state.live && ! this.state.email
				? this.s.email
				: this.s.person;
		this.personButton.hidden =
			! this.state.id ||
			mode !== 'chat' ||
			( this.state.live && !! this.state.email );
		this.restartButton.hidden = ! this.state.id || mode === 'form';
		this.menuButton.hidden =
			this.personButton.hidden &&
			this.restartButton.hidden &&
			! this.config.privacy;
		this.save();
	}

	add( message ) {
		this.state.messages.push( message );
		this.log.insertBefore(
			view.bubble( this, message ),
			this.typingNode.isConnected ? this.typingNode : null
		);
		this.save();
		this.scroll();
	}

	showForm( text ) {
		// After the agent's own handoff line the form needs no words of its own.
		this.formText.textContent = text;
		this.formText.hidden = ! text;
		this.setMode( 'form' );
		this.email.focus();
		window.requestAnimationFrame( () => this.scroll() );
	}

	restart() {
		this.powPromise = null;
		this.state = store.fresh();
		this.save();
		this.paint();
		this.input.focus();
	}

	post( path, body ) {
		return post( this.config.rest, path, body, this.s.error );
	}

	/*
	 * A message: through Bridle AI's edge when the site has one (#172), so
	 * the site never waits on the AI. If the edge itself fails, the same
	 * message (same cid) goes to the site, which answers it once.
	 */
	async ask( body ) {
		if ( this.config.edge ) {
			try {
				return await post( this.config.edge, '', body, this.s.error );
			} catch ( error ) {
				if ( ! edgeFailed( error ) ) {
					throw error;
				}
			}
		}
		return this.post( '', body );
	}

	async send() {
		const text = this.input.value.trim();
		if ( ! text || this.busy ) {
			return;
		}
		this.busy = true;
		this.sendButton.disabled = true;
		this.input.value = '';
		this.grow();
		this.add( { who: 'visitor', text } );

		const thinking = dots( this.s.thinking );
		this.log.append( thinking );
		this.scroll();

		const body = {
			message: text,
			id: this.state.id,
			token: this.state.token,
			hp: this.hp.value,
			turnstile: this.state.id ? '' : this.turnstileToken,
			// Where a new chat started; the team sees it beside the chat.
			page: this.state.id ? '' : window.location.href,
			cid: store.messageId(),
		};
		try {
			if ( ! this.state.id && Number( this.config.pow ) ) {
				body.pow = await this.prepare();
			}
			let data;
			try {
				data = await this.ask( body );
			} catch ( error ) {
				if ( error.code === 'bridle_chat_pow' ) {
					// Used or too old: a fresh one, once, for the same message.
					this.powPromise = null;
					body.pow = await this.prepare();
					data = await this.ask( body );
				} else if ( error.code ) {
					throw error;
				} else {
					// No answer at all (the network, or a proxy gave up): ask
					// once more. The server knows this message by its cid.
					await wait( 3000 );
					data = await this.ask( body );
				}
			}
			// The challenge is spent once a chat starts.
			this.powPromise = null;
			// Still being answered: ask again, for the same message, a bit later.
			for ( let i = 0; data.pending && i < 3; i++ ) {
				await wait( 8000 );
				data = await this.ask( body );
			}
			thinking.remove();
			this.state.id = data.id;
			this.state.token = data.token;
			const wasLive = this.state.live;
			if ( data.live ) {
				this.state.live = true;
			}
			this.answered( data );
			this.setMode( this.state.mode );
			if ( this.state.live && ! wasLive ) {
				this.listen();
			}
		} catch ( error ) {
			thinking.remove();
			if ( error.code === 'bridle_chat_gone' ) {
				this.state = store.fresh();
				this.paint();
			}
			this.add( { who: 'note', text: error.message } );
		} finally {
			this.busy = false;
			this.sendButton.disabled = ! this.input.value.trim();
			this.resetTurnstile();
		}
	}

	/* What the server said to a message: an answer, a wait, or a handoff. */
	answered( data ) {
		if ( data.answer ) {
			if ( data.answer.id ) {
				this.state.answered = [
					...( this.state.answered || [] ),
					data.answer.id,
				].slice( -50 );
			}
			this.add( {
				who: 'bot',
				html: data.answer.html,
				sources: data.answer.sources,
			} );
		} else if ( data.pending ) {
			// Still not there: it turns up when the bubble checks for replies.
			[ 15000, 45000 ].forEach( ( ms ) =>
				window.setTimeout( () => this.poll( ! this.panel.hidden ), ms )
			);
		} else if ( data.waiting ) {
			// Live, the person reads along; no note on every message.
			if ( ! data.live ) {
				this.add( { who: 'note', text: this.s.waiting } );
			}
		} else if ( data.handoff && data.live ) {
			this.add( { who: 'bot', text: this.s.live } );
		} else if ( data.handoff === 'unsure' ) {
			// Not sure (#169): offer a person and keep chatting, no form.
			this.add( { who: 'bot', text: this.s.unsure, offer: true } );
		} else if ( data.handoff ) {
			const words =
				this.s[
					data.handoff === 'person' ? 'handoff' : data.handoff
				] || this.s.unsure;
			this.add( {
				who: 'bot',
				text: data.promise ? words + ' ' + data.promise : words,
			} );
			this.showForm( this.s.replyTo );
		}
	}

	/*
	 * "Talk to a person": live when a person is here (config.live and the
	 * server agrees), else the email form. Live already, it asks for an
	 * email in case the visitor leaves.
	 */
	async askPerson() {
		if ( ! this.config.live || this.state.live ) {
			this.showForm( this.state.live ? this.s.leaveEmail : this.s.ask );
			return;
		}
		if ( this.busy ) {
			return;
		}
		this.busy = true;
		try {
			const data = await this.post( '/handoff', {
				id: this.state.id,
				token: this.state.token,
				live: true,
				turnstile: this.turnstileToken,
			} );
			if ( ! data.live ) {
				throw new Error( 'offline' );
			}
			this.state.live = true;
			this.add( { who: 'bot', text: this.s.live } );
			this.setMode( 'chat' );
			this.listen();
			this.input.focus();
		} catch {
			this.showForm( this.s.ask );
		} finally {
			this.busy = false;
			this.resetTurnstile();
		}
	}

	async handoff() {
		if ( this.busy ) {
			return;
		}
		this.busy = true;
		this.submitButton.disabled = true;
		try {
			const data = await this.post( '/handoff', {
				id: this.state.id,
				token: this.state.token,
				email: this.email.value.trim(),
				name: this.name.value.trim(),
				message: this.noteInput.value.trim(),
				turnstile: this.turnstileToken,
			} );
			this.state.email = data.email;
			this.noteInput.value = '';
			this.setMode( 'done' );
			this.add( {
				who: 'note',
				text: this.s.sent
					.replace( '%1$s', data.promise || '' )
					.replace( '%2$s', data.email ),
			} );
			this.listen();
		} catch ( error ) {
			this.formText.textContent = error.message;
			this.formText.hidden = false;
		} finally {
			this.busy = false;
			this.submitButton.disabled = false;
			this.resetTurnstile();
		}
	}

	loadTurnstile() {
		if ( ! this.config.turnstile || this.turnstileLoaded ) {
			return;
		}
		this.turnstileLoaded = true;
		const box = el( 'div', { slot: 'turnstile' } );
		this.append( box );
		window.bridleChatTurnstile = () => {
			this.turnstileId = window.turnstile.render( box, {
				sitekey: this.config.turnstile,
				appearance: 'interaction-only',
				callback: ( token ) => ( this.turnstileToken = token ),
			} );
		};
		const script = el( 'script', {
			src: 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit&onload=bridleChatTurnstile',
			async: true,
			defer: true,
		} );
		document.head.append( script );
	}

	resetTurnstile() {
		if ( window.turnstile && this.turnstileId !== undefined ) {
			this.turnstileToken = '';
			window.turnstile.reset( this.turnstileId );
		}
	}
}
