/* Small DOM helpers for the bubble: no framework, nothing else to load. */

export function el( tag, attrs = {}, text ) {
	const node = document.createElement( tag );
	Object.entries( attrs ).forEach( ( [ name, value ] ) => {
		if ( value !== false && value !== null && value !== undefined ) {
			node.setAttribute( name, value === true ? '' : value );
		}
	} );
	if ( text ) {
		node.textContent = text;
	}
	return node;
}

/* Three dots: the agent looking it up, or a person typing. */
export function dots( label ) {
	const node = el( 'div', {
		class: 'msg bot dots',
		role: 'status',
		'aria-label': label,
	} );
	node.append( el( 'i' ), el( 'i' ), el( 'i' ) );
	return node;
}

export const wait = ( ms ) =>
	new Promise( ( done ) => window.setTimeout( done, ms ) );

/*
 * Whether a message sent through Bridle AI's edge should go to the site
 * instead (#172): no answer at all, the edge's own error, or a server error.
 * The site's own refusals (limits, checks, an ended chat) stand.
 */
export function edgeFailed( error ) {
	return (
		! error.code ||
		String( error.code ).startsWith( 'bridle_chat_edge' ) ||
		Number( error.status ) >= 500
	);
}

/* POST (or, with no body, GET) to the chat's REST route; a non-2xx throws with the server's words and code. */
export async function post( rest, path, body, fallback ) {
	const response = await window.fetch(
		rest + path,
		body === null
			? { credentials: 'omit' }
			: {
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					credentials: 'omit',
					body: JSON.stringify( body ),
			  }
	);
	const data = await response.json().catch( () => ( {} ) );
	if ( ! response.ok ) {
		const error = new Error( data.message || fallback );
		error.code = data.code;
		error.status = response.status;
		throw error;
	}
	return data;
}
