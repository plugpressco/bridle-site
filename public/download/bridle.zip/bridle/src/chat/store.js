/*
 * What the bubble remembers in the visitor's browser (localStorage): the chat
 * (its id, token and what was said) for a day, or for 30 days once it's with a
 * person; and, apart from it, the day the visitor last opened, dismissed or
 * was shown the greeting peek (#163), so the peek comes at most once a day.
 */

export const KEY = 'bridle-chat-v1';
export const MARKS_KEY = 'bridle-chat-marks';
export const DAY = 24 * 60 * 60 * 1000;

/* A chat that hasn't started. */
export function fresh() {
	return {
		id: 0,
		token: '',
		messages: [],
		mode: 'chat',
		email: '',
		live: false,
		lastTeam: 0,
		answered: [],
		unread: 0,
		at: 0,
	};
}

/* A saved chat, if it is still fresh enough to show. Pure. */
export function keep( saved, now ) {
	if ( ! saved || typeof saved !== 'object' || ! saved.at ) {
		return null;
	}
	return now - saved.at < ( saved.email ? 30 : 1 ) * DAY ? saved : null;
}

function read( key ) {
	try {
		return JSON.parse( window.localStorage.getItem( key ) || 'null' );
	} catch {
		return null;
	}
}

function write( key, value ) {
	try {
		window.localStorage.setItem( key, JSON.stringify( value ) );
	} catch {}
}

export function load() {
	return keep( read( KEY ), Date.now() );
}

export function save( state ) {
	state.at = Date.now();
	write( KEY, state );
}

/* The visitor's local day, YYYY-MM-DD. Pure. */
export function dayOf( time ) {
	const date = new Date( time );
	const pad = ( n ) => String( n ).padStart( 2, '0' );
	return `${ date.getFullYear() }-${ pad( date.getMonth() + 1 ) }-${ pad(
		date.getDate()
	) }`;
}

/**
 * Whether the greeting peek may show now. Pure.
 *
 * @param {Object}  args
 * @param {number}  args.delay Seconds the owner chose (0: never).
 * @param {Object}  args.seen  { opened, dismissed, peeked }: days, YYYY-MM-DD.
 * @param {Object}  args.state The chat as remembered.
 * @param {boolean} args.open  The window is open now.
 * @param {number}  args.now   Time.
 * @return {boolean} Show it.
 */
export function mayPeek( { delay, seen, state, open, now } ) {
	if ( ! delay || open ) {
		return false;
	}
	// A visitor already chatting knows where the chat is.
	if ( state && ( state.id || ( state.messages || [] ).length ) ) {
		return false;
	}
	const today = dayOf( now );
	const days = seen || {};
	return ! [ days.opened, days.dismissed, days.peeked ].includes( today );
}

export function marks() {
	return read( MARKS_KEY ) || {};
}

/* Note that the visitor opened the chat, dismissed or was shown the peek, today. */
export function mark( what ) {
	write( MARKS_KEY, { ...marks(), [ what ]: dayOf( Date.now() ) } );
}

/* A message's own id, so a retry is never answered (or charged) twice (#151). */
export function messageId() {
	const bytes = new Uint8Array( 12 );
	window.crypto.getRandomValues( bytes );
	return Array.from( bytes, ( b ) =>
		b.toString( 16 ).padStart( 2, '0' )
	).join( '' );
}
