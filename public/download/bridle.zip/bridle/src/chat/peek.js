/*
 * The greeting peek (#163): after the visitor has spent the owner's chosen
 * time on a page (30 s unless changed), a small card beside the launcher
 * with the assistant's face and greeting, and a soft chime. Once a day at
 * most (store.mayPeek), never while the chat is open or already going.
 */
import { el } from './dom';
import { assistantFace, agentOf } from './persona';

/*
 * A soft two-note chime, made on the spot (no sound file). Only after the
 * visitor has clicked or typed on the page: browsers block sound before,
 * and a page that never had a gesture stays quiet.
 */
export function chime() {
	const Ctx = window.AudioContext || window.webkitAudioContext;
	if ( ! Ctx || ! window.navigator.userActivation?.hasBeenActive ) {
		return;
	}
	try {
		const ctx = new Ctx();
		const start = ctx.currentTime + 0.02;
		[
			[ 880, 0 ],
			[ 1318.5, 0.11 ],
		].forEach( ( [ freq, offset ] ) => {
			const osc = ctx.createOscillator();
			const gain = ctx.createGain();
			osc.type = 'sine';
			osc.frequency.value = freq;
			gain.gain.setValueAtTime( 0, start + offset );
			gain.gain.linearRampToValueAtTime( 0.07, start + offset + 0.015 );
			gain.gain.exponentialRampToValueAtTime(
				0.0001,
				start + offset + 0.42
			);
			osc.connect( gain ).connect( ctx.destination );
			osc.start( start + offset );
			osc.stop( start + offset + 0.45 );
		} );
		window.setTimeout( () => ctx.close(), 900 );
	} catch {}
}

/*
 * The peek card. `onOpen` runs when the visitor clicks it, `onDismiss` on ×.
 */
export function peekCard( config, strings, onOpen, onDismiss ) {
	const agent = agentOf( config );
	const card = el( 'div', { class: 'peek', role: 'status', hidden: true } );
	const body = el( 'button', {
		class: 'peek-body',
		type: 'button',
		'aria-label': strings.open,
	} );
	const text = el( 'span', { class: 'peek-text' } );
	text.append(
		el( 'strong', {}, agent.name ),
		el( 'span', {}, config.greeting )
	);
	body.append( assistantFace( config, 32 ), text );
	body.addEventListener( 'click', onOpen );
	const close = el(
		'button',
		{
			class: 'peek-close',
			type: 'button',
			'aria-label': strings.dismiss,
		},
		'×'
	);
	close.addEventListener( 'click', ( event ) => {
		event.stopPropagation();
		onDismiss();
	} );
	card.append( body, close );
	return card;
}
