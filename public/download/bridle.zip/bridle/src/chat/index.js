/*
 * Bridle Chat (#114): the bubble on the site's front end, and on other sites
 * through Bridle Pro's embed. No dependencies; it draws itself in a shadow
 * root (widget.js). The parts (#163): store.js (what the browser remembers),
 * view.js (header, composer, messages), persona.js and faces.js (the
 * assistant's name and face), peek.js (the greeting after a while, and the
 * chime), dom.js, styles.js, icons.js.
 */
import { el } from './dom';
import { BridleChat } from './widget';

if ( window.bridleChat && ! window.customElements.get( 'bridle-chat' ) ) {
	window.customElements.define( 'bridle-chat', BridleChat );
	const mount = () => document.body.append( el( 'bridle-chat' ) );
	if ( document.body ) {
		mount();
	} else {
		document.addEventListener( 'DOMContentLoaded', mount );
	}
}
