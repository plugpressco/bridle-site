/*
 * The bubble's parts (#163), built once by the widget: header, menu,
 * conversation, handoff form, composer, footer and launcher, plus one
 * message. Each part wires its events back to the widget (`chat`).
 */
import { el } from './dom';
import {
	ICON_CLOSE,
	ICON_DOWN,
	ICON_MENU,
	ICON_OUT,
	ICON_SEND,
	LAUNCHER_ICONS,
} from './icons';
import { agentOf, assistantFace, personFace } from './persona';

/* The assistant's face, name, and that it's an AI, with the chat's actions. */
export function header( chat ) {
	const { config, s } = chat;
	const agent = agentOf( config );
	const node = el( 'header' );

	const face = el( 'span', { class: 'who-face' } );
	face.append( assistantFace( config, 38 ), el( 'span', { class: 'on' } ) );

	const who = el( 'div', { class: 'who' } );
	const role = el( 'p' );
	role.append( el( 'span', {}, s.role ) );
	if ( config.title ) {
		role.append( el( 'span', { class: 'at' }, config.title ) );
	}
	who.append( el( 'h2', {}, agent.name ), role );

	chat.menuButton = el( 'button', {
		class: 'hbtn',
		type: 'button',
		'aria-label': s.menu || 'More',
		'aria-haspopup': 'menu',
		'aria-expanded': 'false',
	} );
	chat.menuButton.innerHTML = ICON_MENU;
	chat.menuButton.addEventListener( 'click', ( event ) => {
		event.stopPropagation();
		chat.openMenu( chat.menu.hidden );
	} );

	const close = el( 'button', {
		class: 'hbtn',
		type: 'button',
		'aria-label': s.close,
	} );
	close.innerHTML = ICON_CLOSE;
	close.addEventListener( 'click', () => chat.toggle( false ) );

	node.append( face, who, chat.menuButton, close, menu( chat ) );
	return node;
}

/* The actions live in a small menu, so the window stays calm (#142). */
function menu( chat ) {
	const { config, s } = chat;
	chat.menu = el( 'div', { class: 'menu', role: 'menu', hidden: true } );
	chat.personButton = el(
		'button',
		{ type: 'button', role: 'menuitem' },
		s.person
	);
	chat.personButton.addEventListener( 'click', () => {
		chat.openMenu( false );
		chat.askPerson();
	} );
	chat.restartButton = el(
		'button',
		{ type: 'button', role: 'menuitem' },
		s.restart
	);
	chat.restartButton.addEventListener( 'click', () => {
		chat.openMenu( false );
		chat.restart();
	} );
	chat.menu.append( chat.personButton, chat.restartButton );
	if ( config.privacy ) {
		const privacy = el(
			'a',
			{
				href: config.privacy,
				target: '_blank',
				rel: 'noopener',
				role: 'menuitem',
			},
			s.privacy
		);
		privacy.insertAdjacentHTML( 'beforeend', ICON_OUT );
		chat.menu.append( privacy );
	}
	return chat.menu;
}

/* One rounded field with the send button inside. */
export function composer( chat ) {
	const { s } = chat;
	const form = el( 'form', { class: 'composer' } );
	chat.input = el( 'textarea', {
		rows: 1,
		placeholder: s.placeholder,
		'aria-label': s.placeholder,
		maxlength: 1000,
	} );
	chat.hp = el( 'input', {
		class: 'hp',
		name: 'website',
		tabindex: '-1',
		autocomplete: 'off',
		'aria-hidden': 'true',
	} );
	chat.sendButton = el( 'button', {
		class: 'send',
		type: 'submit',
		'aria-label': s.send,
	} );
	chat.sendButton.innerHTML = ICON_SEND;
	chat.sendButton.disabled = true;
	form.append( chat.input, chat.hp, chat.sendButton );
	form.addEventListener( 'submit', ( event ) => {
		event.preventDefault();
		chat.send();
	} );
	chat.input.addEventListener( 'keydown', ( event ) => {
		if ( event.key === 'Enter' && ! event.shiftKey ) {
			event.preventDefault();
			chat.send();
		}
	} );
	chat.input.addEventListener( 'input', () => chat.typed() );
	// A new chat's proof of work starts while they type (#165).
	chat.input.addEventListener( 'focus', () => chat.prepare() );
	return form;
}

/* Leaving an email for a person. */
export function handoffForm( chat ) {
	const { s } = chat;
	const form = el( 'form', { class: 'handoff', hidden: true } );
	chat.formText = el( 'p', { class: 'note' } );
	chat.email = el( 'input', {
		type: 'email',
		required: true,
		placeholder: s.email,
		'aria-label': s.email,
		autocomplete: 'email',
	} );
	chat.name = el( 'input', {
		type: 'text',
		placeholder: s.name,
		'aria-label': s.name,
		autocomplete: 'name',
	} );
	chat.noteInput = el( 'textarea', {
		rows: 2,
		placeholder: s.note,
		'aria-label': s.note,
		maxlength: 1000,
	} );
	const row = el( 'div', { class: 'row' } );
	const cancel = el(
		'button',
		{ class: 'btn quiet', type: 'button' },
		s.cancel
	);
	cancel.addEventListener( 'click', () => chat.setMode( 'chat' ) );
	chat.submitButton = el(
		'button',
		{ class: 'btn', type: 'submit' },
		s.submit
	);
	row.append( cancel, chat.submitButton );
	form.append( chat.formText, chat.email, chat.name, chat.noteInput, row );
	form.addEventListener( 'submit', ( event ) => {
		event.preventDefault();
		chat.handoff();
	} );
	return form;
}

/* "Powered by Bridle", only when the owner said yes (Settings → Chat). */
export function footer( chat ) {
	const { config, s } = chat;
	const node = el( 'footer', { hidden: ! config.powered } );
	if ( config.powered ) {
		node.append(
			el(
				'a',
				{ href: config.powered, target: '_blank', rel: 'noopener' },
				s.powered
			)
		);
	}
	return node;
}

/* The owner's icon, a chevron while open, and the unread badge. */
export function launcher( chat ) {
	const { config, s } = chat;
	const node = el( 'button', {
		class: 'launcher',
		type: 'button',
		'aria-label': s.open,
		'aria-expanded': 'false',
	} );
	node.innerHTML = `<span class="face icon-face">${
		LAUNCHER_ICONS[ config.icon ] || LAUNCHER_ICONS.bubble
	}</span><span class="face down">${ ICON_DOWN }</span>`;
	chat.badgeNode = el( 'span', {
		class: 'badge',
		'aria-hidden': 'true',
		hidden: true,
	} );
	node.append( chat.badgeNode );
	node.addEventListener( 'click', () => chat.toggle() );
	return node;
}

/* An answer or a person's reply, beside its face. */
export function turn( chat, content, who, name ) {
	const node = el( 'div', { class: 'turn' } );
	node.append(
		who === 'team'
			? personFace( name || chat.s.team, 28 )
			: assistantFace( chat.config, 28 ),
		content
	);
	return node;
}

/* One message of the conversation. */
export function bubble( chat, message ) {
	const { s } = chat;
	if ( message.who === 'visitor' ) {
		return el( 'div', { class: 'msg visitor' }, message.text );
	}
	if ( message.who === 'note' ) {
		return el( 'p', { class: 'msg note' }, message.text );
	}
	const node = el( 'div', { class: 'msg bot' } );
	if ( message.who === 'team' ) {
		node.classList.add( 'team' );
		node.append( el( 'p', { class: 'from' }, message.name || s.team ) );
	}
	if ( message.html ) {
		// Sanitized on the server (wp_kses, AgentService::REPLY_TAGS).
		const body = el( 'div' );
		body.innerHTML = message.html;
		node.append( body );
		node.querySelectorAll( 'a' ).forEach( ( a ) => {
			a.target = '_blank';
			a.rel = 'noopener';
		} );
	} else {
		node.append( el( 'p', {}, message.text ) );
	}
	// Not sure (#169): a person is offered, never pushed; the chat goes on.
	if ( message.offer ) {
		const offer = el(
			'button',
			{ class: 'offer', type: 'button' },
			s.person
		);
		offer.addEventListener( 'click', () => chat.askPerson() );
		node.append( offer );
	}
	if ( message.sources && message.sources.length ) {
		const list = el( 'div', { class: 'sources' } );
		list.append( el( 'p', { class: 'src-label' }, s.sources ) );
		message.sources.forEach( ( source, i ) => {
			const link = el( 'a', {
				href: source.url,
				target: '_blank',
				rel: 'noopener',
			} );
			link.append(
				el( 'span', { class: 'n' }, String( i + 1 ) ),
				el( 'span', {}, source.title || source.url )
			);
			list.append( link );
		} );
		node.append( list );
	}
	return turn( chat, node, message.who, message.name );
}
