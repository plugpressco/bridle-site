/*
 * The chat assistant's built-in faces (#163): six original illustrations,
 * drawn from a few numbers each so the visitor bundle stays small. Pastel
 * discs from Bridle's palette, varied skin tones and hair. Shared by the
 * bubble and Settings → Chat → Look (ChatWidget::FACES has the same keys).
 */

const INK = '#2a2522';

// Hair shapes on a 48px grid. `back` is drawn behind the head, `front` over it.
const HAIR = {
	side: {
		front: 'M15 20c0-6.5 4.2-10.5 9.4-10.5 5.6 0 9 3.8 9 9.6-2.2-2.6-6-4.2-10.6-4.4-2.7 2-5.2 3.6-7.8 5.3Z',
	},
	curls: {
		front: 'M13.6 21.4c-2-3.4-.7-7.6 2.6-9.2.8-3.7 4.7-5.7 8.1-4.4 3.1-2 7.5-.6 8.7 2.9 3.2 1.3 4.4 5.1 2.8 8.1-.4 1.3-.9 2.2-1.5 2.8-.7-4.3-3.5-7.2-10-7.2-6.4 0-9.6 2.9-10 7.2Z',
	},
	long: {
		back: 'M14 22c0-7.6 4.4-12.5 10-12.5S34 14.4 34 22v13h-4.5V25h-11v10H14Z',
		front: 'M15 20.6c1.8-5 5.2-7.6 9.4-7.6 4.4 0 7.8 2.6 8.8 7.1-3.4-1-7.4-3.2-9.8-5.6-2 2.8-4.8 4.6-8.4 6.1Z',
	},
	bun: {
		back: 'M20 9.6a4 4 0 1 0 8 0 4 4 0 1 0-8 0',
		front: 'M15 21c0-6 4-10 9-10s9 4 9 10c-2-3-5.4-5-9-5s-7 2-9 5Z',
	},
	short: {
		front: 'M15.2 19.6c.6-5.6 4.2-8.7 8.8-8.7s8.2 3.1 8.8 8.7c-2.6-2.2-5.6-3.3-8.8-3.3s-6.2 1.1-8.8 3.3Z',
	},
	wave: {
		back: 'M14.6 23c-.8-8 3.6-13.4 9.4-13.4 6.2 0 10.2 5 9.4 13.4l-1.4 5.4-2-7.4H18l-2 7.4Z',
		front: 'M15.2 20.4c1-4.8 4.6-7.6 8.8-7.6 3.4 0 6 1.4 7.6 3.8-2.6.2-4.8-.6-6.6-2-1.8 3-5 4.8-9.8 5.8Z',
	},
};

/* The six faces: disc, shirt, skin, hair colour and shape, glasses. */
export const FACES = {
	sky: {
		bg: '#dbe8fb',
		shirt: '#679eee',
		skin: '#f2c7a5',
		hair: '#5a3a26',
		cut: 'side',
	},
	sun: {
		bg: '#fbe7c2',
		shirt: '#e8973a',
		skin: '#8d5a3b',
		hair: '#1f1a17',
		cut: 'curls',
	},
	mint: {
		bg: '#d6efe2',
		shirt: '#3fa37a',
		skin: '#f6d7bf',
		hair: '#c27a3a',
		cut: 'long',
	},
	rose: {
		bg: '#f8dde3',
		shirt: '#e06c8a',
		skin: '#c58b62',
		hair: '#2b2220',
		cut: 'bun',
	},
	lilac: {
		bg: '#e6defa',
		shirt: '#8a6fe0',
		skin: '#e5b48d',
		hair: '#3a2c25',
		cut: 'short',
		glasses: true,
	},
	sand: {
		bg: '#efe7da',
		shirt: '#2d6fcd',
		skin: '#6e4530',
		hair: '#1d1714',
		cut: 'wave',
	},
};

export const FACE_KEYS = Object.keys( FACES );

/* A built-in face as SVG markup, or '' for an unknown key. */
export function faceSvg( key ) {
	const face = FACES[ key ];
	if ( ! face ) {
		return '';
	}
	const hair = HAIR[ face.cut ];
	const path = ( d, fill ) => `<path d="${ d }" fill="${ fill }"/>`;
	return (
		'<svg viewBox="0 0 48 48" aria-hidden="true">' +
		`<circle cx="24" cy="24" r="24" fill="${ face.bg }"/>` +
		// The figure a little larger than drawn, so the face reads at 28px.
		'<g transform="translate(24 30) scale(1.16) translate(-24 -30)">' +
		( hair.back ? path( hair.back, face.hair ) : '' ) +
		path( 'M8 48c1.5-9 8-13.6 16-13.6S38.5 39 40 48Z', face.shirt ) +
		`<rect x="20.5" y="28.5" width="7" height="8" rx="3.5" fill="${ face.skin }"/>` +
		`<ellipse cx="24" cy="21.6" rx="9" ry="10" fill="${ face.skin }"/>` +
		path( hair.front, face.hair ) +
		`<circle cx="20.6" cy="22" r="1.15" fill="${ INK }"/><circle cx="27.4" cy="22" r="1.15" fill="${ INK }"/>` +
		( face.glasses
			? `<g fill="none" stroke="${ INK }" stroke-width="1.1"><circle cx="20.6" cy="22" r="2.7"/><circle cx="27.4" cy="22" r="2.7"/><path d="M23.3 21.8h1.4"/></g>`
			: '' ) +
		`<path d="M21.3 25.9c1.6 1.4 3.8 1.4 5.4 0" fill="none" stroke="${ INK }" stroke-width="1.2" stroke-linecap="round"/>` +
		'<circle cx="18.8" cy="25.2" r="1.4" fill="#ef8f8f" opacity=".3"/><circle cx="29.2" cy="25.2" r="1.4" fill="#ef8f8f" opacity=".3"/>' +
		'</g></svg>'
	);
}
