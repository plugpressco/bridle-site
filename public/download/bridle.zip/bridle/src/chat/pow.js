/*
 * A small proof of work before a new chat starts (#165), so a bot can't
 * open chats by the thousand and spend the owner's AI answers. The server
 * hands out a challenge (GET /chat/challenge → { challenge, bits }); the
 * bubble finds the smallest n where SHA-256 of "challenge:n" starts with
 * `bits` zero bits, and sends "challenge:n" with the first message. A
 * person never notices: it runs while they type. Without Turnstile only.
 *
 * SHA-256 is written out here, synchronous, because WebCrypto's digest is
 * async per call and far too slow for a few hundred thousand tries.
 */
/* eslint-disable no-bitwise -- a hash is bit arithmetic. */

const K = new Uint32Array( [
	0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1,
	0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
	0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786,
	0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
	0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
	0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
	0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b,
	0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
	0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a,
	0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
	0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
] );
const W = new Uint32Array( 64 );
const ror = ( x, n ) => ( x >>> n ) | ( x << ( 32 - n ) );

/* SHA-256 of some bytes, as 32 bytes. */
export function sha256( bytes ) {
	const length = bytes.length;
	const size = ( ( length + 9 + 63 ) >> 6 ) << 6;
	const m = new Uint8Array( size );
	m.set( bytes );
	m[ length ] = 0x80;
	const view = new DataView( m.buffer );
	view.setUint32( size - 8, Math.floor( length / 0x20000000 ) );
	view.setUint32( size - 4, ( length * 8 ) >>> 0 );
	const h = [
		0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c,
		0x1f83d9ab, 0x5be0cd19,
	];
	for ( let off = 0; off < size; off += 64 ) {
		for ( let i = 0; i < 16; i++ ) {
			W[ i ] = view.getUint32( off + i * 4 );
		}
		for ( let i = 16; i < 64; i++ ) {
			const x = W[ i - 15 ];
			const y = W[ i - 2 ];
			W[ i ] =
				W[ i - 16 ] +
				( ror( x, 7 ) ^ ror( x, 18 ) ^ ( x >>> 3 ) ) +
				W[ i - 7 ] +
				( ror( y, 17 ) ^ ror( y, 19 ) ^ ( y >>> 10 ) );
		}
		let [ a, b, c, d, e, f, g, k ] = h;
		for ( let i = 0; i < 64; i++ ) {
			const t1 =
				( k +
					( ror( e, 6 ) ^ ror( e, 11 ) ^ ror( e, 25 ) ) +
					( ( e & f ) ^ ( ~e & g ) ) +
					K[ i ] +
					W[ i ] ) |
				0;
			const t2 =
				( ( ror( a, 2 ) ^ ror( a, 13 ) ^ ror( a, 22 ) ) +
					( ( a & b ) ^ ( a & c ) ^ ( b & c ) ) ) |
				0;
			k = g;
			g = f;
			f = e;
			e = ( d + t1 ) | 0;
			d = c;
			c = b;
			b = a;
			a = ( t1 + t2 ) | 0;
		}
		h[ 0 ] = ( h[ 0 ] + a ) | 0;
		h[ 1 ] = ( h[ 1 ] + b ) | 0;
		h[ 2 ] = ( h[ 2 ] + c ) | 0;
		h[ 3 ] = ( h[ 3 ] + d ) | 0;
		h[ 4 ] = ( h[ 4 ] + e ) | 0;
		h[ 5 ] = ( h[ 5 ] + f ) | 0;
		h[ 6 ] = ( h[ 6 ] + g ) | 0;
		h[ 7 ] = ( h[ 7 ] + k ) | 0;
	}
	const out = new Uint8Array( 32 );
	const outView = new DataView( out.buffer );
	h.forEach( ( word, i ) => outView.setUint32( i * 4, word >>> 0 ) );
	return out;
}

/* How many zero bits a hash starts with. */
export function zeroBits( hash ) {
	let count = 0;
	for ( const byte of hash ) {
		if ( byte === 0 ) {
			count += 8;
			continue;
		}
		return count + Math.clz32( byte ) - 24;
	}
	return count;
}

/* The bytes of "challenge:n" (the challenge once, the digits each try). */
function attempt( prefix, n ) {
	const digits = String( n );
	const bytes = new Uint8Array( prefix.length + digits.length );
	bytes.set( prefix );
	for ( let i = 0; i < digits.length; i++ ) {
		bytes[ prefix.length + i ] = digits.charCodeAt( i );
	}
	return bytes;
}

/*
 * The smallest n for the challenge, giving the page a breath every `chunk`
 * tries so typing and scrolling stay smooth. `stop()` can end it early.
 */
export async function solve(
	challenge,
	bits,
	chunk = 5000,
	stop = () => false
) {
	const prefix = new TextEncoder().encode( challenge + ':' );
	for ( let n = 0; ; n++ ) {
		if ( zeroBits( sha256( attempt( prefix, n ) ) ) >= bits ) {
			return n;
		}
		if ( n % chunk === chunk - 1 ) {
			await new Promise( ( done ) => setTimeout( done, 0 ) );
			if ( stop() ) {
				return -1;
			}
		}
	}
}
