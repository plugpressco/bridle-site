// Bridle Chat's styles, inside its shadow root: the theme's CSS never reaches
// them and they never reach the theme. --bc-accent is the owner's colour.
// The look (#142, calmer #163): a quiet header with the assistant's face,
// name and "AI Assistant"; the owner's colour on the launcher, the visitor's
// bubbles and the send button; round bubbles beside the assistant's face; a
// greeting peek beside the launcher; actions in a small menu.
export const STYLES = `
:host { all: initial; }
* { box-sizing: border-box; }
.bc { --bc-ink: #1b1b19; --bc-muted: #6b6b66; --bc-line: #ebebe7; --bc-soft: #f3f3f0; --bc-bg: #fff; --bc-on: #fff;
	--bc-w: 400px; --bc-h: 680px; --bc-ease: cubic-bezier(.2,.8,.2,1);
	font: 15px/1.5 system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; color: var(--bc-ink);
	position: fixed; right: 20px; bottom: 20px; z-index: 2147483000; -webkit-font-smoothing: antialiased; }
.bc.left { right: auto; left: 20px; }
.bc.compact { --bc-w: 340px; --bc-h: 540px; }
.bc.dark { --bc-ink: #f2f2ee; --bc-muted: #a3a39d; --bc-line: #2e2e2b; --bc-soft: #262624; --bc-bg: #1b1b1a; }
@media (prefers-color-scheme: dark) {
	.bc.auto { --bc-ink: #f2f2ee; --bc-muted: #a3a39d; --bc-line: #2e2e2b; --bc-soft: #262624; --bc-bg: #1b1b1a; }
}
button, input, textarea { font: inherit; color: inherit; }
svg { display: block; }
[hidden] { display: none !important; }

/* Faces: the assistant's (a built-in face, the owner's picture or a letter) and a person's initials. */
.ava { --size: 28px; flex: none; width: var(--size); height: var(--size); border-radius: 50%; overflow: hidden;
	display: grid; place-items: center; background: var(--bc-soft); }
.ava svg, .ava img { width: 100%; height: 100%; object-fit: cover; }
.ava.letter { background: var(--bc-accent); color: var(--bc-on); font-weight: 650; font-size: calc(var(--size) * .42); letter-spacing: .01em; }
.ava.team { background: var(--bc-ink); color: var(--bc-bg); }

/* The launcher: the owner's icon, a chevron while open. */
.launcher { position: relative; width: 56px; height: 56px; border-radius: 50%; border: 0; cursor: pointer; padding: 0;
	background: var(--bc-accent); color: var(--bc-on); display: grid; place-items: center;
	box-shadow: 0 6px 20px rgb(0 0 0 / .16), 0 1px 3px rgb(0 0 0 / .12);
	transition: transform .2s var(--bc-ease), box-shadow .2s; }
.launcher:hover { transform: scale(1.05); box-shadow: 0 8px 26px rgb(0 0 0 / .2), 0 1px 3px rgb(0 0 0 / .12); }
.launcher:active { transform: scale(.95); }
.launcher .face { grid-area: 1 / 1; width: 27px; height: 27px; transition: transform .25s var(--bc-ease), opacity .2s; }
.launcher .face svg { width: 100%; height: 100%; }
.launcher .down { opacity: 0; transform: rotate(-90deg) scale(.6); }
.launcher[aria-expanded="true"] .icon-face { opacity: 0; transform: rotate(90deg) scale(.6); }
.launcher[aria-expanded="true"] .down { opacity: 1; transform: none; }
.badge { position: absolute; top: -2px; right: -2px; min-width: 20px; height: 20px; padding: 0 5px; border-radius: 10px;
	background: #e5484d; color: #fff; font-size: 12px; font-weight: 700; line-height: 16px; border: 2px solid #fff; text-align: center; }

/* The greeting peek beside the launcher. */
.peek { position: absolute; right: 0; bottom: 70px; width: max-content; max-width: min(300px, calc(100vw - 40px));
	display: flex; align-items: flex-start; background: var(--bc-bg); color: var(--bc-ink); border-radius: 18px;
	box-shadow: 0 14px 40px rgb(0 0 0 / .16), 0 2px 6px rgb(0 0 0 / .06), 0 0 0 1px rgb(0 0 0 / .04);
	transform-origin: bottom right; animation: bc-peek .32s var(--bc-ease); }
.bc.left .peek { right: auto; left: 0; transform-origin: bottom left; }
@keyframes bc-peek { from { opacity: 0; transform: translateY(10px) scale(.94); } }
.peek-body { display: flex; align-items: flex-start; gap: 10px; padding: 14px 6px 14px 14px; border: 0; background: none; cursor: pointer; text-align: left; border-radius: 18px; }
.peek-text { display: grid; gap: 2px; font-size: 14px; line-height: 1.4; }
.peek-text strong { font-size: 13px; font-weight: 650; }
.peek-text span { color: var(--bc-ink); display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }
.peek-close { flex: none; margin: 6px 6px 0 0; width: 26px; height: 26px; border-radius: 8px; border: 0; background: none; cursor: pointer;
	color: var(--bc-muted); font-size: 18px; line-height: 1; display: grid; place-items: center; }
.peek-close:hover { background: var(--bc-soft); color: var(--bc-ink); }

/* The window. */
.panel { position: absolute; right: 0; bottom: 72px; width: var(--bc-w); height: min(var(--bc-h), calc(100vh - 104px));
	background: var(--bc-bg); border-radius: 22px; overflow: hidden;
	box-shadow: 0 24px 64px rgb(0 0 0 / .18), 0 2px 8px rgb(0 0 0 / .06), 0 0 0 1px rgb(0 0 0 / .05);
	display: flex; flex-direction: column; transform-origin: bottom right; animation: bc-in .24s var(--bc-ease); }
.bc.left .panel { right: auto; left: 0; transform-origin: bottom left; }
@keyframes bc-in { from { opacity: 0; transform: translateY(12px) scale(.97); } }

/* A quiet header: who you're talking to, and that it's an AI. */
header { position: relative; display: flex; align-items: center; gap: 12px; padding: 14px 10px 14px 16px;
	background: var(--bc-bg); border-bottom: 1px solid var(--bc-line); }
.who-face { position: relative; flex: none; display: grid; }
.who-face .on { position: absolute; right: 0; bottom: 0; width: 11px; height: 11px; border-radius: 50%; background: #22c55e; border: 2px solid var(--bc-bg); }
header .who { flex: 1; min-width: 0; }
header h2 { margin: 0; font-size: 15.5px; font-weight: 650; letter-spacing: -.01em; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
header p { margin: 1px 0 0; font-size: 12.5px; color: var(--bc-muted); display: flex; gap: 5px; white-space: nowrap; overflow: hidden; }
header p .at { overflow: hidden; text-overflow: ellipsis; }
header p .at::before { content: "·"; margin-right: 5px; }
.hbtn { width: 34px; height: 34px; border-radius: 10px; border: 0; background: transparent; cursor: pointer; color: var(--bc-muted);
	display: grid; place-items: center; }
.hbtn svg { width: 19px; height: 19px; }
.hbtn:hover { background: var(--bc-soft); color: var(--bc-ink); }
.menu { position: absolute; top: 56px; right: 10px; min-width: 190px; padding: 6px; border-radius: 14px; z-index: 2;
	background: var(--bc-bg); color: var(--bc-ink); box-shadow: 0 12px 32px rgb(0 0 0 / .16), 0 0 0 1px var(--bc-line); }
.menu button, .menu a { display: flex; align-items: center; justify-content: space-between; width: 100%; padding: 9px 10px; border: 0; border-radius: 9px;
	background: none; cursor: pointer; text-align: left; font-size: 14px; color: var(--bc-ink); text-decoration: none; }
.menu button:hover, .menu a:hover { background: var(--bc-soft); }
.menu svg { width: 15px; height: 15px; color: var(--bc-muted); }

/* The conversation. */
.log { flex: 1; overflow-y: auto; padding: 20px 16px 12px; display: flex; flex-direction: column; gap: 6px; background: var(--bc-bg); scroll-behavior: smooth; }
.turn { align-self: flex-start; display: flex; align-items: flex-end; gap: 8px; max-width: 88%; animation: bc-msg .2s var(--bc-ease); }
/* One face per run of answers, beside the last one. */
.turn:has(+ .turn) .ava { visibility: hidden; }
.turn + .turn, .visitor + .visitor { margin-top: -2px; }
.log > .dots { align-self: flex-start; margin-left: 36px; }
.msg { padding: 10px 14px; border-radius: 18px; overflow-wrap: anywhere; min-width: 0; }
.msg p { margin: 0 0 8px; } .msg p:last-child { margin: 0; }
.msg ul, .msg ol { margin: 0 0 8px; padding-left: 20px; }
.msg a { color: var(--bc-accent); text-underline-offset: 2px; }
.msg code { font-size: 13px; background: rgb(0 0 0 / .06); padding: 1px 4px; border-radius: 4px; }
.bot { background: var(--bc-soft); border-bottom-left-radius: 6px; }
.visitor { align-self: flex-end; max-width: 82%; background: var(--bc-accent); color: var(--bc-on); border-bottom-right-radius: 6px; white-space: pre-wrap; animation: bc-msg .2s var(--bc-ease); }
@keyframes bc-msg { from { opacity: 0; transform: translateY(6px); } }
.from { margin: 0 0 3px !important; font-size: 12px; font-weight: 650; color: var(--bc-muted); }
.offer { display: inline-flex; margin-top: 8px; padding: 6px 12px; border: 1px solid var(--bc-line); border-radius: 999px; background: var(--bc-bg); font-size: 13px; font-weight: 600; color: var(--bc-ink); cursor: pointer; }
.offer:hover { border-color: var(--bc-muted); }
.offer:focus-visible { outline: 2px solid var(--bc-accent); outline-offset: 2px; }
.note { align-self: center; max-width: 100%; margin: 6px 0; font-size: 12.5px; color: var(--bc-muted); text-align: center; }
.sources { display: grid; gap: 4px; margin-top: 10px; padding-top: 10px; border-top: 1px solid var(--bc-line); }
.src-label { margin: 0 0 2px !important; font-size: 11.5px; font-weight: 600; color: var(--bc-muted); }
.sources a { display: flex; align-items: center; gap: 8px; font-size: 13px; color: var(--bc-ink); text-decoration: none; min-width: 0; padding: 2px 0; }
.sources a span:last-child { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.sources a:hover span:last-child { text-decoration: underline; }
.sources .n { flex: none; width: 18px; height: 18px; border-radius: 6px; display: grid; place-items: center; font-size: 11px; font-weight: 650;
	background: var(--bc-bg); color: var(--bc-muted); border: 1px solid var(--bc-line); }
.dots { display: inline-flex; gap: 4px; padding: 14px 16px; }
.dots i { width: 6px; height: 6px; border-radius: 50%; background: var(--bc-muted); opacity: .4; animation: bc-dot 1.2s infinite ease-in-out; }
.dots i:nth-child(2) { animation-delay: .15s; } .dots i:nth-child(3) { animation-delay: .3s; }
@keyframes bc-dot { 0%, 60%, 100% { opacity: .35; transform: none; } 30% { opacity: .9; transform: translateY(-3px); } }

/* Leaving an email for a person. */
form.handoff { display: grid; gap: 8px; padding: 14px 16px; border-top: 1px solid var(--bc-line); background: var(--bc-bg); }
input, textarea { width: 100%; border: 1px solid var(--bc-line); border-radius: 12px; padding: 10px 12px; background: var(--bc-bg); outline: none; }
input:focus, textarea:focus { border-color: var(--bc-accent); box-shadow: 0 0 0 3px color-mix(in srgb, var(--bc-accent) 18%, transparent); }
.row { display: flex; gap: 8px; justify-content: flex-end; }
.btn { border: 0; border-radius: 12px; padding: 9px 16px; cursor: pointer; background: var(--bc-accent); color: var(--bc-on); font-weight: 550; }
.msg .btn { margin-top: 8px; }
.btn.quiet { background: transparent; color: var(--bc-muted); }
.btn.quiet:hover { color: var(--bc-ink); }
.btn:disabled { opacity: .5; cursor: default; }

/* The composer: one rounded field with the send button inside. */
.composer { margin: 4px 12px 12px; display: flex; align-items: flex-end; gap: 6px; padding: 6px 6px 6px 14px;
	border: 1px solid var(--bc-line); border-radius: 22px; background: var(--bc-bg); transition: border-color .15s, box-shadow .15s; }
.composer:focus-within { border-color: color-mix(in srgb, var(--bc-accent) 60%, var(--bc-line)); box-shadow: 0 0 0 3px color-mix(in srgb, var(--bc-accent) 14%, transparent); }
.composer textarea { flex: 1; border: 0; padding: 7px 0; resize: none; max-height: 120px; line-height: 1.4; background: transparent; box-shadow: none; }
.composer textarea:focus, .composer textarea:focus-visible { box-shadow: none; outline: none; }
.send { flex: none; width: 34px; height: 34px; border-radius: 50%; border: 0; background: var(--bc-accent); color: var(--bc-on); cursor: pointer; display: grid; place-items: center; transition: opacity .15s, transform .15s; }
.send svg { width: 18px; height: 18px; }
.send:disabled { opacity: .35; cursor: default; }
.send:not(:disabled):active { transform: scale(.92); }
footer { padding: 0 16px 10px; text-align: center; font-size: 11.5px; }
footer a { color: var(--bc-muted); text-decoration: none; }
footer a:hover { text-decoration: underline; }
.hp { position: absolute; left: -9999px; width: 1px; height: 1px; opacity: 0; }
:focus-visible { outline: 2px solid var(--bc-accent); outline-offset: 2px; }
.launcher:focus-visible { outline-color: var(--bc-on); outline-offset: -4px; }
@media (max-width: 480px) {
	.bc, .bc.left { right: 16px; left: auto; bottom: 16px; }
	.bc.left { left: 16px; right: auto; }
	.panel, .bc.left .panel { position: fixed; inset: 0; width: auto; height: auto; border-radius: 0; }
	/* Full screen: the header's close takes over from the launcher. */
	.bc.open .launcher { display: none; }
	.peek { max-width: calc(100vw - 32px); }
}
@media (prefers-reduced-motion: reduce) {
	.panel, .peek, .turn, .visitor, .dots i { animation: none; }
	.launcher, .launcher .face { transition: none; }
	.log { scroll-behavior: auto; }
}
`;
