import { useState } from 'react';
import { __, sprintf } from '@wordpress/i18n';
import { TriangleAlert } from 'lucide-react';

import { ForwardingBlock } from '@/components/settings/forwarding';
import { INBOX_COLORS, InboxFields } from '@/components/settings/inbox-form';
import { useShell } from '@/components/shell/shell-context';
import { Button } from '@/components/ui/button';
import {
	Dialog,
	DialogContent,
	DialogDescription,
	DialogFooter,
	DialogHeader,
	DialogTitle,
} from '@/components/ui/dialog';
import { inboxes as inboxesApi } from '@/lib/api';
import { navigate } from '@/lib/router';
import { GuideLink } from '@/components/settings/guide-link';

/* "Connect an inbox": create it, then show the forwarding address. */
export function ConnectInboxDialog( { open, onOpenChange, onCreated } ) {
	const { setInboxScope } = useShell();
	const [ form, setForm ] = useState( {
		display_name: '',
		email_address: '',
		color: INBOX_COLORS[ 0 ],
	} );
	const [ busy, setBusy ] = useState( false );
	const [ error, setError ] = useState( null );
	const [ atLimit, setAtLimit ] = useState( false );
	const [ created, setCreated ] = useState( null );

	const submit = async ( event ) => {
		event.preventDefault();
		setBusy( true );
		setError( null );
		setAtLimit( false );
		try {
			const inbox = await inboxesApi.create( form );
			setCreated( inbox );
			onCreated?.( inbox );
		} catch ( err ) {
			setAtLimit( err?.code === 'bridle_inbox_limit' );
			setError(
				err?.message || __( 'Could not create the inbox.', 'bridle' )
			);
		} finally {
			setBusy( false );
		}
	};

	const close = () => {
		onOpenChange( false );
		setCreated( null );
		setForm( {
			display_name: '',
			email_address: '',
			color: INBOX_COLORS[ 0 ],
		} );
	};

	return (
		<Dialog
			open={ open }
			onOpenChange={ ( next ) =>
				next ? onOpenChange( true ) : close()
			}
		>
			<DialogContent className="sm:max-w-lg">
				{ ! created ? (
					<form onSubmit={ submit } className="space-y-5">
						<DialogHeader>
							<DialogTitle>
								{ __( 'Connect an inbox', 'bridle' ) }
							</DialogTitle>
							<DialogDescription>
								{ __(
									'One inbox per support address. You’ll forward that address to Bridle in the next step.',
									'bridle'
								) }
							</DialogDescription>
						</DialogHeader>
						<InboxFields value={ form } onChange={ setForm } />
						{ error && (
							<p className="text-sm text-destructive">
								{ error }
							</p>
						) }
						{ atLimit && (
							<GuideLink
								topic="more-inboxes"
								screen="connect-inbox"
								className="-mt-2 text-sm"
							/>
						) }
						<DialogFooter>
							<Button
								type="button"
								variant="ghost"
								onClick={ close }
							>
								{ __( 'Cancel', 'bridle' ) }
							</Button>
							<Button
								type="submit"
								disabled={
									busy ||
									! form.display_name ||
									! form.email_address
								}
							>
								{ busy
									? __( 'Connecting…', 'bridle' )
									: __( 'Continue', 'bridle' ) }
							</Button>
						</DialogFooter>
					</form>
				) : (
					<div className="space-y-5">
						<DialogHeader>
							<DialogTitle>
								{ __( 'Now forward your mail', 'bridle' ) }
							</DialogTitle>
							<DialogDescription>
								{ sprintf(
									/* translators: %s: the inbox name */
									__(
										'%s is ready. Point its address at Bridle and send yourself a test email.',
										'bridle'
									),
									created.display_name
								) }
							</DialogDescription>
						</DialogHeader>
						{ created.registration_warning && (
							<p className="flex items-start gap-2 rounded-md bg-note px-3 py-2 text-sm text-note-foreground">
								<TriangleAlert className="mt-0.5 size-4 shrink-0" />
								{ created.registration_warning }
							</p>
						) }
						<ForwardingBlock
							inbox={ created }
							onInboxChange={ setCreated }
						/>
						<DialogFooter>
							<Button
								type="button"
								onClick={ () => {
									close();
									setInboxScope?.( created.id );
									navigate( '/settings/inboxes' );
								} }
							>
								{ __( 'Done', 'bridle' ) }
							</Button>
						</DialogFooter>
					</div>
				) }
			</DialogContent>
		</Dialog>
	);
}
