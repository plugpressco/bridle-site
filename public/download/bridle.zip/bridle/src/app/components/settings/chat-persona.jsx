import { useRef, useState } from 'react';
import apiFetch from '@wordpress/api-fetch';
import { __, sprintf } from '@wordpress/i18n';
import { ImagePlus } from 'lucide-react';
import { cn } from 'cn';

import { Field, Row, Segmented } from '@/components/settings/field';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';

import { FACE_KEYS, faceSvg } from '../../../chat/faces';

const RING =
	'ring-2 ring-foreground ring-offset-2 ring-offset-card opacity-100';

/*
 * The assistant's face (#163): six built-in faces, or the owner's own
 * picture, uploaded to the Media Library.
 */
function FacePicker( { value, image, onChoose, onUpload } ) {
	const file = useRef( null );
	const [ busy, setBusy ] = useState( false );
	const [ failed, setFailed ] = useState( false );

	const upload = async ( event ) => {
		const picked = event.target.files?.[ 0 ];
		event.target.value = '';
		if ( ! picked ) {
			return;
		}
		setBusy( true );
		setFailed( false );
		try {
			const body = new window.FormData();
			body.append( 'file', picked, picked.name );
			const media = await apiFetch( {
				path: '/wp/v2/media',
				method: 'POST',
				body,
			} );
			await onUpload( media.source_url );
		} catch {
			setFailed( true );
		} finally {
			setBusy( false );
		}
	};

	return (
		<>
			<div
				role="radiogroup"
				aria-label={ __( 'Face', 'bridle' ) }
				className="flex flex-wrap items-center gap-3"
			>
				{ FACE_KEYS.map( ( key, i ) => (
					<button
						key={ key }
						type="button"
						role="radio"
						aria-checked={ value === key }
						aria-label={ sprintf(
							/* translators: %d: 1 to 6 */
							__( 'Face %d', 'bridle' ),
							i + 1
						) }
						onClick={ () => onChoose( key ) }
						className={ cn(
							'size-11 cursor-pointer overflow-hidden rounded-full outline-none transition focus-visible:ring-[3px] focus-visible:ring-ring/50 [&_svg]:size-full',
							value === key
								? RING
								: 'opacity-75 hover:opacity-100'
						) }
						// Static SVG from src/chat/faces.js.
						dangerouslySetInnerHTML={ { __html: faceSvg( key ) } }
					/>
				) ) }
				{ image && (
					<button
						type="button"
						role="radio"
						aria-checked={ value === 'custom' }
						aria-label={ __( 'Your picture', 'bridle' ) }
						onClick={ () => onChoose( 'custom' ) }
						className={ cn(
							'size-11 cursor-pointer overflow-hidden rounded-full outline-none transition focus-visible:ring-[3px] focus-visible:ring-ring/50',
							value === 'custom'
								? RING
								: 'opacity-75 hover:opacity-100'
						) }
					>
						<img
							src={ image }
							alt=""
							className="size-full object-cover"
						/>
					</button>
				) }
				<button
					type="button"
					onClick={ () => file.current?.click() }
					disabled={ busy }
					className="inline-flex h-9 cursor-pointer items-center gap-1.5 rounded-full border border-input bg-card px-3 text-sm text-foreground outline-none transition hover:bg-accent focus-visible:ring-[3px] focus-visible:ring-ring/50 disabled:opacity-60"
				>
					<ImagePlus aria-hidden="true" className="size-4" />
					{ busy
						? __( 'Uploading…', 'bridle' )
						: __( 'Your picture', 'bridle' ) }
				</button>
				<input
					ref={ file }
					type="file"
					accept="image/png,image/jpeg,image/webp,image/gif"
					className="hidden"
					onChange={ upload }
				/>
			</div>
			{ failed && (
				<p className="mt-2 text-sm text-destructive">
					{ __( 'That picture couldn’t be uploaded.', 'bridle' ) }
				</p>
			) }
		</>
	);
}

/*
 * Settings → Chat → Look (#163): who visitors talk to, and the greeting that
 * pops up after a while.
 */
export function ChatPersona( { values, edit, choose, chooseMany, run } ) {
	const face = values.chat_face || 'sky';
	return (
		<>
			<div className="grid gap-5 sm:grid-cols-2">
				<Field
					label={ __( 'Assistant name', 'bridle' ) }
					help={ __(
						'The name in the chat window. The chat always says it’s an AI assistant.',
						'bridle'
					) }
					htmlFor="chat-agent-name"
				>
					<Input
						id="chat-agent-name"
						maxLength={ 40 }
						placeholder="Blake"
						value={ values.chat_agent_name ?? '' }
						onChange={ edit( 'chat_agent_name' ) }
					/>
				</Field>
			</div>
			<Field label={ __( 'Face', 'bridle' ) }>
				<FacePicker
					value={ face }
					image={ values.chat_face_url || '' }
					onChoose={ ( next ) =>
						run( () => choose( 'chat_face', next ) )
					}
					onUpload={ ( url ) =>
						chooseMany( {
							chat_face_url: url,
							chat_face: 'custom',
						} )
					}
				/>
			</Field>
			<div className="grid gap-5 sm:grid-cols-2">
				<Field
					label={ __( 'Open by itself', 'bridle' ) }
					help={ __(
						'After a visitor spends this long on a page, a short hello pops up next to the chat button. Once a day at most.',
						'bridle'
					) }
				>
					<Segmented
						label={ __( 'Open by itself', 'bridle' ) }
						size="sm"
						value={ String( values.chat_peek || '30' ) }
						options={ [
							[ 'off', __( 'Off', 'bridle' ) ],
							[ '15', __( '15 s', 'bridle' ) ],
							[ '30', __( '30 s', 'bridle' ) ],
							[ '60', __( '60 s', 'bridle' ) ],
						] }
						onChange={ ( next ) =>
							run( () => choose( 'chat_peek', next ) )
						}
					/>
				</Field>
			</div>
			<Row
				label={ __( 'Sound', 'bridle' ) }
				help={ __(
					'A soft chime when the hello pops up or a reply comes in. Only after the visitor has clicked or typed on the page.',
					'bridle'
				) }
			>
				<Switch
					aria-label={ __( 'Sound', 'bridle' ) }
					checked={ values.chat_sound !== false }
					onCheckedChange={ ( next ) =>
						run( () => choose( 'chat_sound', !! next ) )
					}
				/>
			</Row>
		</>
	);
}
