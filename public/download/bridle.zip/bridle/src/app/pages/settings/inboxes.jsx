import { useEffect, useState } from 'react';
import { __, sprintf } from '@wordpress/i18n';
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react';
import { cn } from 'cn';

import { Field, InlineError, Row } from '@/components/settings/field';
import { ForwardingBlock } from '@/components/settings/forwarding';
import { ForwardingDrift } from '@/components/settings/forwarding-drift';
import { GuideLink } from '@/components/settings/guide-link';
import { ColorPicker } from '@/components/settings/inbox-form';
import {
	SettingsPanel,
	SettingsSection,
} from '@/components/settings/settings-frame';
import {
	truthy,
	useInboxSettings,
	useInstant,
} from '@/components/settings/use-draft';
import { InboxDot } from '@/components/shell/inbox-scope';
import { useShell } from '@/components/shell/shell-context';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { inboxes as inboxesApi } from '@/lib/api';
import { Link, navigate } from '@/lib/router';

/* Deactivate, behind one confirm in place. */
function Deactivate( { inbox } ) {
	const { refreshInboxes } = useShell();
	const [ busy, setBusy ] = useState( false );
	const [ confirming, setConfirming ] = useState( false );
	const [ error, setError ] = useState( null );

	const deactivate = async () => {
		setBusy( true );
		setError( null );
		try {
			await inboxesApi.deactivate( inbox.id );
			await refreshInboxes().catch( () => {} );
			navigate( '/settings/inboxes' );
		} catch {
			setError( __( 'Couldn’t deactivate. Try again.', 'bridle' ) );
		} finally {
			setBusy( false );
			setConfirming( false );
		}
	};

	return (
		<>
			<Row
				label={ __( 'Deactivate', 'bridle' ) }
				help={ __(
					'Stops mail arriving and hides the inbox. Its conversations stay.',
					'bridle'
				) }
			>
				{ confirming ? (
					<div className="flex items-center gap-2">
						<Button
							variant="ghost"
							size="sm"
							onClick={ () => setConfirming( false ) }
						>
							{ __( 'Cancel', 'bridle' ) }
						</Button>
						<Button
							variant="destructive"
							size="sm"
							disabled={ busy }
							onClick={ deactivate }
						>
							{ busy
								? __( 'Deactivating…', 'bridle' )
								: __( 'Yes, deactivate', 'bridle' ) }
						</Button>
					</div>
				) : (
					<Button
						variant="outline"
						size="sm"
						onClick={ () => setConfirming( true ) }
					>
						{ __( 'Deactivate', 'bridle' ) }
					</Button>
				) }
			</Row>
			<InlineError>{ error }</InlineError>
		</>
	);
}

/* One inbox: forwarding, sender, acknowledgement, colour, deactivate. */
function InboxDetail( { inbox, single, onConnect } ) {
	const { refreshInboxes } = useShell();
	const { values, edit, choose } = useInboxSettings( inbox );
	const [ ackError, runAck ] = useInstant();
	const [ colorError, runColor ] = useInstant(
		__( 'Couldn’t save the colour. Try again.', 'bridle' )
	);

	return (
		<SettingsPanel
			back={
				! single && (
					<Link
						to="/settings/inboxes"
						className="mb-2 inline-flex items-center gap-1 rounded-md text-sm text-muted-foreground outline-none hover:text-foreground focus-visible:ring-[3px] focus-visible:ring-ring/50"
					>
						<ChevronLeft className="size-4" />
						{ __( 'Inboxes', 'bridle' ) }
					</Link>
				)
			}
			title={
				<>
					{ ! single && <InboxDot inbox={ inbox } /> }
					<span className="truncate">
						{ single
							? __( 'Inbox', 'bridle' )
							: inbox.display_name }
					</span>
				</>
			}
			actions={
				single && (
					<Button
						size="sm"
						variant="ghost"
						className="text-muted-foreground"
						onClick={ onConnect }
					>
						<Plus />
						{ __( 'Connect another', 'bridle' ) }
					</Button>
				)
			}
		>
			<SettingsSection
				title={ __( 'Forwarding', 'bridle' ) }
				help={ sprintf(
					/* translators: %s: the support address customers write to */
					__(
						'Forward %s to this address. Every message becomes a conversation.',
						'bridle'
					),
					inbox.email_address
				) }
			>
				<ForwardingBlock
					key={ inbox.id }
					inbox={ inbox }
					onInboxChange={ () => refreshInboxes() }
				/>
			</SettingsSection>

			<SettingsSection
				title={ __( 'Sender', 'bridle' ) }
				help={ __( 'Who customers see on your replies.', 'bridle' ) }
			>
				<div className="grid gap-5 sm:grid-cols-2">
					<Field
						label={ __( 'Name', 'bridle' ) }
						htmlFor="sender-name"
					>
						<Input
							id="sender-name"
							value={ values.display_name ?? '' }
							onChange={ edit( 'display_name' ) }
						/>
					</Field>
					<Field
						label={ __( 'Email', 'bridle' ) }
						help={ __( 'Replies go out from here.', 'bridle' ) }
						htmlFor="sender-email"
					>
						<Input
							id="sender-email"
							type="email"
							value={ values.email_address ?? '' }
							onChange={ edit( 'email_address' ) }
						/>
					</Field>
					<Field
						label={ __( 'Signature', 'bridle' ) }
						help={ __(
							'Under every reply. Plain text or simple HTML.',
							'bridle'
						) }
						htmlFor="sender-signature"
						className="sm:col-span-2"
					>
						<Textarea
							id="sender-signature"
							rows={ 3 }
							value={ values.signature ?? '' }
							onChange={ edit( 'signature' ) }
						/>
					</Field>
				</div>
			</SettingsSection>

			<SettingsSection>
				<Row
					label={ __( 'Confirm new conversations', 'bridle' ) }
					help={ __(
						'The “we got your message” email. With the agent on, it goes out only when a person takes over.',
						'bridle'
					) }
				>
					<Switch
						aria-label={ __(
							'Confirm new conversations',
							'bridle'
						) }
						checked={ truthy( values.auto_reply_enabled ) }
						onCheckedChange={ ( on ) =>
							runAck( () =>
								choose( { auto_reply_enabled: on ? 1 : 0 } )
							)
						}
					/>
				</Row>
				<InlineError>{ ackError }</InlineError>
				{ truthy( values.auto_reply_enabled ) && (
					<div className="grid gap-5">
						<Field
							label={ __( 'Subject', 'bridle' ) }
							htmlFor="ack-subject"
						>
							<Input
								id="ack-subject"
								value={ values.auto_reply_subject ?? '' }
								onChange={ edit( 'auto_reply_subject' ) }
							/>
						</Field>
						<Field
							label={ __( 'Message', 'bridle' ) }
							htmlFor="ack-body"
						>
							<Textarea
								id="ack-body"
								rows={ 3 }
								value={ values.auto_reply_body ?? '' }
								onChange={ edit( 'auto_reply_body' ) }
							/>
						</Field>
					</div>
				) }
			</SettingsSection>

			<SettingsSection>
				{ ! single && (
					<>
						<Row
							label={ __( 'Colour', 'bridle' ) }
							help={ __(
								'Marks its rows when you look across several inboxes.',
								'bridle'
							) }
						>
							<ColorPicker
								value={ values.color }
								onChange={ ( color ) =>
									runColor( () => choose( { color } ) )
								}
							/>
						</Row>
						<InlineError>{ colorError }</InlineError>
					</>
				) }
				<Deactivate key={ inbox.id } inbox={ inbox } />
			</SettingsSection>
		</SettingsPanel>
	);
}

/* Every inbox as a row; each opens its own page. */
function InboxList( { inboxes, onConnect } ) {
	return (
		<SettingsPanel
			title={ __( 'Inboxes', 'bridle' ) }
			actions={
				<Button size="sm" variant="outline" onClick={ onConnect }>
					<Plus />
					{ __( 'Connect an inbox', 'bridle' ) }
				</Button>
			}
		>
			<ul className="-mx-3 py-2">
				{ inboxes.map( ( inbox ) => {
					const arriving = !! inbox.last_received_at;
					return (
						<li key={ inbox.id }>
							<Link
								to={ `/settings/inboxes/${ inbox.id }` }
								className="group flex items-center gap-3 rounded-lg px-3 py-3 outline-none transition-colors hover:bg-accent focus-visible:ring-[3px] focus-visible:ring-ring/50"
							>
								<InboxDot inbox={ inbox } />
								<span className="min-w-0 flex-1">
									<span className="block truncate text-sm font-medium">
										{ inbox.display_name }
									</span>
									<span className="block truncate font-mono text-xs text-muted-foreground">
										{ inbox.email_address }
									</span>
								</span>
								<span
									className={ cn(
										'hidden items-center gap-1.5 text-xs sm:inline-flex',
										arriving
											? 'text-brand-ink'
											: 'text-muted-foreground'
									) }
								>
									<span
										className={ cn(
											'size-1.5 rounded-full',
											arriving
												? 'bg-brand'
												: 'bg-muted-foreground/50'
										) }
									/>
									{ arriving
										? __( 'Mail arriving', 'bridle' )
										: __(
												'Waiting for first email',
												'bridle'
										  ) }
								</span>
								<ChevronRight className="size-4 text-muted-foreground transition-transform group-hover:translate-x-0.5" />
							</Link>
						</li>
					);
				} ) }
			</ul>
		</SettingsPanel>
	);
}

/*
 * How many inboxes this site has on the Bridle mail service (#174), only
 * while the service has a limit: "2 of 3 inboxes", and at the limit a
 * guide link to more with Pro (gone once Pro is active).
 */
function InboxUsage( { count } ) {
	const [ usage, setUsage ] = useState( null );
	useEffect( () => {
		inboxesApi
			.usage()
			.then( setUsage )
			.catch( () => setUsage( null ) );
	}, [ count ] );
	if ( ! usage?.cap || null === usage.limit || null === usage.used ) {
		return null;
	}
	return (
		<div className="px-1 text-sm text-muted-foreground">
			<p>
				{ sprintf(
					/* translators: 1: inboxes in use, 2: the limit. */
					__(
						'%1$d of %2$d inboxes on the Bridle mail service',
						'bridle'
					),
					usage.used,
					usage.limit
				) }
			</p>
			{ usage.used >= usage.limit && (
				<GuideLink
					topic="more-inboxes"
					screen="settings-inboxes"
					className="pt-1"
				/>
			) }
		</div>
	);
}

/*
 * Settings → Inboxes. One inbox opens straight to its page (solo-first);
 * several are a list, and each has its own page (#/settings/inboxes/3).
 */
export function InboxesSettings( { inboxId, onConnect } ) {
	const { inboxes } = useShell();
	const single = inboxes.length === 1;
	const open = inboxId
		? inboxes.find( ( row ) => Number( row.id ) === Number( inboxId ) )
		: null;
	const inbox = open || ( single ? inboxes[ 0 ] : null );

	let body;
	if ( ! inboxes.length ) {
		body = (
			<SettingsPanel title={ __( 'Inboxes', 'bridle' ) }>
				<SettingsSection>
					<div className="flex items-center justify-between gap-4">
						<p className="text-sm text-muted-foreground">
							{ __( 'No inbox yet.', 'bridle' ) }
						</p>
						<Button size="sm" onClick={ onConnect }>
							<Plus />
							{ __( 'Connect an inbox', 'bridle' ) }
						</Button>
					</div>
				</SettingsSection>
			</SettingsPanel>
		);
	} else if ( inbox ) {
		body = (
			<InboxDetail
				key={ inbox.id }
				inbox={ inbox }
				single={ single }
				onConnect={ onConnect }
			/>
		);
	} else {
		body = <InboxList inboxes={ inboxes } onConnect={ onConnect } />;
	}

	return (
		<div className="space-y-4">
			<ForwardingDrift />
			{ body }
			{ ! open && <InboxUsage count={ inboxes.length } /> }
		</div>
	);
}
