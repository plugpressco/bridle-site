import { __ } from '@wordpress/i18n';
import {
	Clock,
	ExternalLink,
	Globe,
	Hand,
	Package,
	SearchCheck,
	Workflow,
} from 'lucide-react';

import {
	SettingsPanel,
	SettingsSection,
} from '@/components/settings/settings-frame';
import { Button } from '@/components/ui/button';

const PRO_URL =
	'https://bridle.to/pro/?utm_source=plugin&utm_medium=settings&utm_campaign=pro';

const FEATURES = [
	{
		icon: Globe,
		title: __( 'Your other sites', 'bridle' ),
		text: __( 'Put this chat on them too.', 'bridle' ),
	},
	{
		icon: Hand,
		title: __( 'Live chat', 'bridle' ),
		text: __( 'Jump in and chat while you’re online.', 'bridle' ),
	},
	{
		icon: Package,
		title: __( 'Orders and licences', 'bridle' ),
		text: __( 'Replies that know what they bought.', 'bridle' ),
	},
	{
		icon: SearchCheck,
		title: __( 'Missing answers', 'bridle' ),
		text: __( 'See what it couldn’t answer. Write the doc.', 'bridle' ),
	},
	{
		icon: Clock,
		title: __( 'Business hours', 'bridle' ),
		text: __( 'Tell visitors when you’re back.', 'bridle' ),
	},
	{
		icon: Workflow,
		title: __( 'Workflows', 'bridle' ),
		text: __( 'Late reply nudges. Auto close. Auto assign.', 'bridle' ),
	},
];

/*
 * Settings → Bridle Pro (#118): what Pro adds, and where to get it. One of
 * Pro's three quiet places (with the Plugins row link and the readme); no
 * notices, badges or locked buttons anywhere else. With Pro active, Pro's
 * licence screen replaces this page.
 */
export function ProSettings() {
	return (
		<SettingsPanel title={ __( 'Bridle Pro', 'bridle' ) }>
			<SettingsSection>
				<ul className="grid gap-3 sm:grid-cols-2">
					{ FEATURES.map( ( { icon: Icon, title, text } ) => (
						<li
							key={ title }
							className="flex gap-3 rounded-xl border border-border/80 p-4"
						>
							<span className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-brand-soft text-brand-ink">
								<Icon aria-hidden="true" className="size-4" />
							</span>
							<span className="grid gap-0.5">
								<span className="text-sm font-semibold">
									{ title }
								</span>
								<span className="text-sm text-muted-foreground">
									{ text }
								</span>
							</span>
						</li>
					) ) }
				</ul>
				<div className="mt-5 flex flex-wrap items-center gap-3">
					<Button asChild>
						<a href={ PRO_URL } target="_blank" rel="noreferrer">
							{ __( 'Get Bridle Pro', 'bridle' ) }
							<ExternalLink
								aria-hidden="true"
								className="size-3.5"
							/>
						</a>
					</Button>
					<span className="text-sm text-muted-foreground">
						{ __(
							'Comes with Bridle AI answers. Bridle stays free.',
							'bridle'
						) }
					</span>
				</div>
			</SettingsSection>
		</SettingsPanel>
	);
}
