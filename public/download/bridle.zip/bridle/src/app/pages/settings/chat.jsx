import { useEffect, useState } from 'react';
import { __, sprintf } from '@wordpress/i18n';
import { ExternalLink } from 'lucide-react';
import { cn } from 'cn';

import {
	Field,
	InlineError,
	Row,
	Segmented,
	SELECT,
} from '@/components/settings/field';
import {
	SettingsPanel,
	SettingsSection,
} from '@/components/settings/settings-frame';
import { ChatPersona } from '@/components/settings/chat-persona';
import { GuideLink } from '@/components/settings/guide-link';
import { useAiStatus } from '@/components/settings/use-ai-status';
import { useInstant, useSiteSettings } from '@/components/settings/use-draft';
import { useShell } from '@/components/shell/shell-context';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { chat } from '@/lib/api';
import { appData } from '@/lib/app-data';
import { Link } from '@/lib/router';

import { LAUNCHER_ICONS } from '../../../chat/icons';

const ICON_LABELS = {
	bubble: __( 'Chat bubble', 'bridle' ),
	message: __( 'Message', 'bridle' ),
	sparkle: __( 'Sparkle', 'bridle' ),
	question: __( 'Question', 'bridle' ),
	headset: __( 'Headset', 'bridle' ),
};

/* The launcher's icon (#142), drawn the way visitors will see it. */
function IconPicker( { value, color, onChange } ) {
	return (
		<div
			role="radiogroup"
			aria-label={ __( 'Icon', 'bridle' ) }
			className="flex flex-wrap gap-3"
		>
			{ Object.entries( LAUNCHER_ICONS ).map( ( [ key, svg ] ) => (
				<button
					key={ key }
					type="button"
					role="radio"
					aria-checked={ value === key }
					aria-label={ ICON_LABELS[ key ] }
					title={ ICON_LABELS[ key ] }
					onClick={ () => onChange( key ) }
					style={ { background: color } }
					className={ cn(
						'grid size-11 cursor-pointer place-items-center rounded-full text-white outline-none transition focus-visible:ring-[3px] focus-visible:ring-ring/50 [&_svg]:size-5',
						value === key
							? 'ring-2 ring-foreground ring-offset-2 ring-offset-card'
							: 'opacity-60 hover:opacity-100'
					) }
					// Static SVG from src/chat/icons.js.
					dangerouslySetInnerHTML={ { __html: svg } }
				/>
			) ) }
		</div>
	);
}

/* Optional Cloudflare Turnstile keys. The secret is write-only. */
function Turnstile() {
	const [ config, setConfig ] = useState( null );
	const [ siteKey, setSiteKey ] = useState( '' );
	const [ secret, setSecret ] = useState( '' );
	const [ error, run ] = useInstant();
	const [ saved, setSaved ] = useState( false );

	useEffect( () => {
		chat.turnstile()
			.then( ( next ) => {
				setConfig( next );
				setSiteKey( next.site_key || '' );
			} )
			.catch( () => setConfig( {} ) );
	}, [] );

	const save = () =>
		run( async () => {
			const next = await chat.saveTurnstile( {
				site_key: siteKey.trim(),
				secret: secret.trim(),
			} );
			setConfig( next );
			setSecret( '' );
			setSaved( true );
		} );

	return (
		<>
			<div className="grid gap-5 sm:grid-cols-2">
				<Field label={ __( 'Site key', 'bridle' ) } htmlFor="ts-site">
					<Input
						id="ts-site"
						value={ siteKey }
						onChange={ ( event ) => {
							setSiteKey( event.target.value );
							setSaved( false );
						} }
					/>
				</Field>
				<Field
					label={ __( 'Secret key', 'bridle' ) }
					htmlFor="ts-secret"
					hint={
						config?.has_secret
							? sprintf(
									/* translators: %s: last four characters of the saved key */
									__( 'Saved, ending %s', 'bridle' ),
									config.secret_hint
							  )
							: null
					}
				>
					<Input
						id="ts-secret"
						type="password"
						autoComplete="off"
						value={ secret }
						onChange={ ( event ) => {
							setSecret( event.target.value );
							setSaved( false );
						} }
					/>
				</Field>
			</div>
			<div className="mt-4 flex items-center gap-3">
				<Button
					variant="outline"
					size="sm"
					onClick={ save }
					disabled={ ! siteKey.trim() && ! config?.site_key }
				>
					{ ! siteKey.trim() && config?.site_key
						? __( 'Turn off', 'bridle' )
						: __( 'Save keys', 'bridle' ) }
				</Button>
				{ saved && (
					<span className="text-sm text-muted-foreground">
						{ __( 'Saved', 'bridle' ) }
					</span>
				) }
			</div>
			<InlineError>{ error }</InlineError>
		</>
	);
}

/*
 * Settings → Chat (#114): the bubble on your site. It answers from the same
 * knowledge as email drafts and hands the rest to the Inbox.
 */
export function ChatSettings() {
	const { values, edit, choose, chooseMany } = useSiteSettings();
	const { inboxes } = useShell();
	const [ status ] = useAiStatus();
	const [ error, run ] = useInstant();

	if ( ! values ) {
		return (
			<p className="text-sm text-muted-foreground">
				{ __( 'Loading…', 'bridle' ) }
			</p>
		);
	}

	const label = __( 'Chat on your site', 'bridle' );
	const on = !! values.chat_enabled;
	let blocked = null;
	if ( ! inboxes.length ) {
		blocked = (
			<Link
				to="/settings/inboxes"
				className="text-brand-ink hover:underline"
			>
				{ __( 'Connect an inbox first', 'bridle' ) }
			</Link>
		);
	} else if ( status && ! status.can_use_ai ) {
		blocked = (
			<Link
				to="/settings/replies"
				className="text-brand-ink hover:underline"
			>
				{ __( 'Choose how the agent writes first', 'bridle' ) }
			</Link>
		);
	}

	return (
		<SettingsPanel title={ __( 'Chat', 'bridle' ) }>
			<SettingsSection>
				<Row
					label={ label }
					help={ __(
						'A chat bubble on every page. It answers from your docs, pages, products and past replies, checks each fact, and hands anything else to a person by email.',
						'bridle'
					) }
					hint={ blocked }
				>
					<Switch
						aria-label={ label }
						checked={ on }
						disabled={ !! blocked && ! on }
						onCheckedChange={ ( next ) =>
							run( () => choose( 'chat_enabled', !! next ) )
						}
					/>
				</Row>
				{ on && ! blocked && appData.siteUrl && (
					<a
						href={ appData.siteUrl }
						target="_blank"
						rel="noreferrer"
						className="inline-flex items-center gap-1.5 text-sm text-brand-ink hover:underline"
					>
						{ __( 'See it on your site', 'bridle' ) }
						<ExternalLink aria-hidden="true" className="size-3.5" />
					</a>
				) }
				<Row
					label={ __(
						'Email me when a chat needs a person',
						'bridle'
					) }
					hint={ values.notification_email || null }
				>
					<Switch
						aria-label={ __(
							'Email me when a chat needs a person',
							'bridle'
						) }
						checked={ values.chat_alerts !== false }
						onCheckedChange={ ( next ) =>
							run( () => choose( 'chat_alerts', !! next ) )
						}
					/>
				</Row>
				<Row
					label={ __( 'Show “Powered by Bridle”', 'bridle' ) }
					help={ __(
						'A small link to bridle.to under the chat, so visitors can find Bridle. Off unless you turn it on.',
						'bridle'
					) }
				>
					<Switch
						aria-label={ __(
							'Show “Powered by Bridle”',
							'bridle'
						) }
						checked={ !! values.chat_credit_enabled }
						onCheckedChange={ ( next ) =>
							run( () =>
								choose( 'chat_credit_enabled', !! next )
							)
						}
					/>
				</Row>
				<InlineError>{ error }</InlineError>
			</SettingsSection>
			<SettingsSection>
				<div className="grid gap-5 sm:grid-cols-2">
					<Field
						label={ __( 'Greeting', 'bridle' ) }
						htmlFor="chat-greeting"
						className="sm:col-span-2"
					>
						<Input
							id="chat-greeting"
							placeholder={ __(
								'Hi! Ask me anything. I answer from this site’s help pages, and a person can take over.',
								'bridle'
							) }
							value={ values.chat_greeting ?? '' }
							onChange={ edit( 'chat_greeting' ) }
						/>
					</Field>
					{ inboxes.length > 1 && (
						<Field
							label={ __( 'Chats go to', 'bridle' ) }
							help={ __(
								'Handed-off chats land in this inbox and are answered from its address.',
								'bridle'
							) }
							htmlFor="chat-inbox"
						>
							<select
								id="chat-inbox"
								className={ SELECT }
								value={ String( values.chat_inbox_id || '' ) }
								onChange={ edit( 'chat_inbox_id' ) }
							>
								<option value="">
									{ __( 'First inbox', 'bridle' ) }
								</option>
								{ inboxes.map( ( inbox ) => (
									<option
										key={ inbox.id }
										value={ String( inbox.id ) }
									>
										{ inbox.display_name ||
											inbox.email_address }
									</option>
								) ) }
							</select>
						</Field>
					) }
					<Field
						label={ __( 'Colour', 'bridle' ) }
						htmlFor="chat-color"
					>
						<div className="flex items-center gap-2">
							<input
								id="chat-color"
								type="color"
								className="h-9 w-12 cursor-pointer rounded-md border border-input bg-card p-1"
								value={ values.chat_color || '#2d6fcd' }
								onChange={ edit( 'chat_color' ) }
							/>
							<span className="font-mono text-xs text-muted-foreground">
								{ values.chat_color || '#2d6fcd' }
							</span>
						</div>
					</Field>
				</div>
			</SettingsSection>
			<SettingsSection
				title={ __( 'Look', 'bridle' ) }
				help={ __(
					'Who visitors talk to, and how the chat button and window look. Changes show on the next page load.',
					'bridle'
				) }
			>
				<ChatPersona
					values={ values }
					edit={ edit }
					choose={ choose }
					chooseMany={ chooseMany }
					run={ run }
				/>
				<Field label={ __( 'Icon', 'bridle' ) }>
					<IconPicker
						value={ values.chat_icon || 'bubble' }
						color={ values.chat_color || '#2d6fcd' }
						onChange={ ( next ) =>
							run( () => choose( 'chat_icon', next ) )
						}
					/>
				</Field>
				<div className="grid gap-5 sm:grid-cols-3">
					<Field label={ __( 'Corner', 'bridle' ) }>
						<Segmented
							label={ __( 'Corner', 'bridle' ) }
							size="sm"
							value={ values.chat_position || 'right' }
							options={ [
								[ 'right', __( 'Right', 'bridle' ) ],
								[ 'left', __( 'Left', 'bridle' ) ],
							] }
							onChange={ ( next ) =>
								run( () => choose( 'chat_position', next ) )
							}
						/>
					</Field>
					<Field label={ __( 'Size', 'bridle' ) }>
						<Segmented
							label={ __( 'Size', 'bridle' ) }
							size="sm"
							value={ values.chat_size || 'large' }
							options={ [
								[ 'large', __( 'Large', 'bridle' ) ],
								[ 'compact', __( 'Compact', 'bridle' ) ],
							] }
							onChange={ ( next ) =>
								run( () => choose( 'chat_size', next ) )
							}
						/>
					</Field>
					<Field label={ __( 'Theme', 'bridle' ) }>
						<Segmented
							label={ __( 'Theme', 'bridle' ) }
							size="sm"
							value={ values.chat_theme || 'light' }
							options={ [
								[ 'light', __( 'Light', 'bridle' ) ],
								[ 'dark', __( 'Dark', 'bridle' ) ],
								[ 'auto', __( 'Auto', 'bridle' ) ],
							] }
							onChange={ ( next ) =>
								run( () => choose( 'chat_theme', next ) )
							}
						/>
					</Field>
				</div>
			</SettingsSection>
			<SettingsSection
				title={ __( 'Turnstile (optional)', 'bridle' ) }
				help={ __(
					'Chat already limits how much one visitor can send. Add free Cloudflare Turnstile keys to also check that a new chat comes from a person.',
					'bridle'
				) }
			>
				<Turnstile />
			</SettingsSection>
			<GuideLink topic="chat-on-other-sites" screen="settings-chat" />
		</SettingsPanel>
	);
}
