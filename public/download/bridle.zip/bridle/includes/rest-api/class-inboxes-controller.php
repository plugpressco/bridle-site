<?php

namespace Bridle\RestApi;

use Bridle\Models\Inbox;
use Bridle\Services\InboxAiSettings;
use Bridle\Services\MailHost;
use Bridle\Services\WorkerSyncService;
use WP_Error;
use WP_REST_Controller;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class InboxesController extends WP_REST_Controller {

	protected $namespace = BRIDLE_REST_NAMESPACE;
	protected $rest_base = 'inboxes';

	const WORKER_URL   = 'https://bridle-email-worker.plugpress.workers.dev';
	const EMAIL_DOMAIN = 'bridle.to';

	public function register_routes(): void {
		register_rest_route( $this->namespace, '/' . $this->rest_base, [
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_items' ],
				'permission_callback' => [ $this, 'read_check' ],
			],
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'create_item' ],
				'permission_callback' => [ $this, 'manage_check' ],
			],
		] );

		register_rest_route( $this->namespace, '/' . $this->rest_base . '/(?P<id>[\d]+)', [
			[
				'methods'             => 'PATCH',
				'callback'            => [ $this, 'update_item' ],
				'permission_callback' => [ $this, 'manage_check' ],
			],
			[
				'methods'             => WP_REST_Server::DELETABLE,
				'callback'            => [ $this, 'delete_item' ],
				'permission_callback' => [ $this, 'manage_check' ],
			],
		] );

		// Re-register every inbox with the email worker — the "Fix
		// forwarding" button. Used after a site URL change (or any state
		// where the worker's stored webhook URL no longer matches).
		register_rest_route( $this->namespace, '/' . $this->rest_base . '/fix-forwarding', [
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'fix_forwarding' ],
				'permission_callback' => [ $this, 'manage_check' ],
			],
		] );

		// How many inboxes this site has on the mail service, and its
		// limit (#174).
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/usage',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_usage' ],
					'permission_callback' => [ $this, 'manage_check' ],
				],
			]
		);

		// Who hosts a mailbox (Gmail, Microsoft 365…), so onboarding can
		// show the right forwarding steps without asking.
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/mail-host',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_mail_host' ],
					'permission_callback' => [ $this, 'manage_check' ],
					'args'                => [
						'email' => [
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_email',
						],
					],
				],
			]
		);

		// Per-inbox AI settings.
		register_rest_route( $this->namespace, '/' . $this->rest_base . '/(?P<id>[\d]+)/ai', [
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_ai_settings' ],
				'permission_callback' => [ $this, 'manage_check' ],
			],
			[
				'methods'             => 'PATCH',
				'callback'            => [ $this, 'update_ai_settings' ],
				'permission_callback' => [ $this, 'manage_check' ],
			],
		] );
	}

	public function read_check( $request ) {
		return current_user_can( 'bridle_manage_conversations' ) || current_user_can( 'manage_options' );
	}

	public function manage_check( $request ) {
		return current_user_can( 'bridle_manage_settings' ) || current_user_can( 'manage_options' );
	}

	public function get_items( $request ) {
		$model = new Inbox();
		$rows  = array_map( [ self::class, 'without_secret' ], $model->list( [ 'is_active' => 1 ] ) );
		return new WP_REST_Response( $rows );
	}

	public function create_item( $request ) {
		$params = $request->get_json_params();

		if ( empty( $params['display_name'] ) || empty( $params['email_address'] ) ) {
			return new WP_Error( 'bridle_missing_fields', __( 'Name and email are required.', 'bridle' ), [ 'status' => 400 ] );
		}

		// Slug stays constant across retries — only the hash changes.
		$slug = self::slugify_for_address( $params['display_name'] );

		$webhook_secret = Inbox::default_webhook_secret();

		$webhook_url = rest_url( BRIDLE_REST_NAMESPACE . '/inbound-email' );

		// Register with the worker, retrying with a fresh hash on 409 Conflict.
		// The 4-char hex hash has 65,536 combos per slug; collisions happen
		// in practice when many sites share the same inbox name ("support").
		// Five attempts give an effective collision rate so low it's not
		// worth modelling — the loop bails with an error after that.
		$max_attempts = 5;
		$inbox_hash   = null;
		$forwarding   = null;
		$register_err = null;

		for ( $attempt = 1; $attempt <= $max_attempts; $attempt++ ) {
			$hash       = substr( bin2hex( random_bytes( 2 ) ), 0, 4 );
			$candidate  = $slug . '-' . $hash;
			$fallback   = $candidate . '@' . self::EMAIL_DOMAIN;

			$response = wp_remote_post( self::WORKER_URL . '/register', [
				'body'    => wp_json_encode(
					WorkerSyncService::body(
						[
							'site_url'       => home_url(),
							'inbox_hash'     => $candidate,
							'webhook_url'    => $webhook_url,
							'webhook_secret' => $webhook_secret,
						],
						'register'
					)
				),
				'headers' => [ 'Content-Type' => 'application/json' ],
				'timeout' => 15,
			] );

			$status = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );

			if ( 409 === $status ) {
				// Hash collided with another site's address — try again.
				continue;
			}

			if ( 402 === $status ) {
				// The site is at its inbox limit on the mail service (#174):
				// nothing is saved, the app says why.
				$body = json_decode( wp_remote_retrieve_body( $response ), true );
				WorkerSyncService::forget_usage();
				return WorkerSyncService::limit_error( is_array( $body ) ? $body : [] );
			}

			if ( is_wp_error( $response ) || $status >= 400 ) {
				// Worker is unreachable or returned a non-409 error. We still
				// fall through to saving the inbox with the fallback address;
				// the worker can be re-registered later via the same endpoint.
				$register_err = $response;
			}

			$inbox_hash = $candidate;
			$forwarding = $fallback;
			if ( ! is_wp_error( $response ) ) {
				$body     = json_decode( wp_remote_retrieve_body( $response ), true );
				$returned = sanitize_email( (string) ( $body['forwarding_address'] ?? '' ) );
				if ( is_email( $returned ) ) {
					$forwarding = $returned;
				}
			}
			break;
		}

		if ( null === $inbox_hash ) {
			return new WP_Error(
				'bridle_register_failed',
				__( 'Could not provision a unique forwarding address after several attempts. Please try a different inbox name.', 'bridle' ),
				[ 'status' => 503 ]
			);
		}

		// Save to DB.
		$model = new Inbox();
		$id    = $model->create( [
			'email_address'      => sanitize_email( $params['email_address'] ),
			'display_name'       => sanitize_text_field( $params['display_name'] ),
			'icon'               => $params['icon'] ?? null,
			'color'              => $params['color'] ?? null,
			'inbox_hash'         => $inbox_hash,
			'forwarding_address' => $forwarding,
			'webhook_secret'     => $webhook_secret,
		] );

		if ( ! $id ) {
			return new WP_Error( 'bridle_create_error', __( 'Could not save inbox.', 'bridle' ), [ 'status' => 500 ] );
		}

		if ( null === $register_err ) {
			// Remember what we registered so WorkerSyncService can detect
			// drift when the site URL later changes.
			$model->update( $id, [ 'registered_webhook_url' => $webhook_url ] );
		}

		WorkerSyncService::forget_usage();
		$data = (array) self::without_secret( $model->get_by_id( $id ) );

		if ( null !== $register_err ) {
			// The row is saved but the worker never stored the mapping — the
			// address won't receive mail until a sync succeeds (daily cron,
			// or the Fix forwarding button). Tell the UI instead of
			// pretending everything worked.
			$data['registration_warning'] = __(
				'The forwarding address could not be registered with the email service. Mail to it will not arrive yet — use "Fix forwarding" in a few minutes or contact support.',
				'bridle'
			);
			WorkerSyncService::schedule_register();
		}

		return new WP_REST_Response( $data, 201 );
	}

	/**
	 * Re-register all active inboxes with the email worker ("Fix
	 * forwarding"). Safe to run any time — registration is idempotent.
	 * This is the one place in the app that re-points a registered inbox
	 * at this site (#104).
	 */
	public function fix_forwarding( $request ) {
		$summary = WorkerSyncService::sync_all( 'all' );
		$summary['drift'] = WorkerSyncService::get_drift();

		return new WP_REST_Response( $summary );
	}

	/**
	 * `GET /inboxes/usage`: `{ used, limit, cap }`, or nulls when the mail
	 * service can't say. `?fresh=1` skips the kept answer.
	 */
	public function get_usage( $request ) {
		$usage = WorkerSyncService::usage( (bool) $request->get_param( 'fresh' ) );
		$none = [
			'used'  => null,
			'limit' => null,
			'cap'   => false,
		];
		return new WP_REST_Response( $usage ?? $none );
	}

	public function get_mail_host( $request ) {
		return new WP_REST_Response( MailHost::detect( (string) $request->get_param( 'email' ) ) );
	}

	public function update_item( $request ) {
		$model = new Inbox();
		$inbox = $model->get_by_id( absint( $request['id'] ) );

		if ( ! $inbox ) {
			return new WP_Error( 'bridle_not_found', __( 'Inbox not found.', 'bridle' ), [ 'status' => 404 ] );
		}

		// The model sanitizes each field. The forwarding address, registered
		// webhook URL and last-received time are ours to set, not a client's.
		$params = array_diff_key(
			(array) $request->get_json_params(),
			array_flip( [ 'forwarding_address', 'registered_webhook_url', 'last_received_at' ] )
		);

		// Replies go out From this address; never blank it with a typo.
		if ( array_key_exists( 'email_address', $params ) && ! is_email( sanitize_email( (string) $params['email_address'] ) ) ) {
			return new WP_Error( 'bridle_invalid_email', __( 'That is not a valid email address.', 'bridle' ), [ 'status' => 400 ] );
		}

		$model->update( $inbox->id, $params );

		// Switching an inbox off stops its mail at the worker (and forgets
		// the registration); switching it back on registers it again in the
		// background.
		if ( array_key_exists( 'is_active', $params ) ) {
			if ( empty( $params['is_active'] ) && ! empty( $inbox->is_active ) ) {
				WorkerSyncService::deregister_inbox( $inbox );
			} elseif ( ! empty( $params['is_active'] ) && empty( $inbox->is_active ) ) {
				WorkerSyncService::schedule_register();
			}
		}

		return new WP_REST_Response( self::without_secret( $model->get_by_id( $inbox->id ) ) );
	}

	public function get_ai_settings( $request ) {
		$inbox_id = absint( $request['id'] );
		return new WP_REST_Response( InboxAiSettings::get( $inbox_id ) );
	}

	public function update_ai_settings( $request ) {
		$inbox_id = absint( $request['id'] );
		$params   = $request->get_json_params();
		$updated  = InboxAiSettings::update( $inbox_id, $params );
		return new WP_REST_Response( $updated );
	}

	public function delete_item( $request ) {
		$model = new Inbox();
		$inbox = $model->get_by_id( absint( $request['id'] ) );

		if ( ! $inbox ) {
			return new WP_Error( 'bridle_not_found', __( 'Inbox not found.', 'bridle' ), [ 'status' => 404 ] );
		}

		// Deregister from Worker — stop inbound email delivery.
		WorkerSyncService::deregister_inbox( $inbox );

		// Soft-delete: deactivate instead of removing the row. Conversations
		// keep their inbox_id and remain accessible. The inbox disappears
		// from the sidebar (queries filter by is_active = 1) but can be
		// reactivated later if needed.
		$model->update( $inbox->id, [ 'is_active' => 0 ] );

		return new WP_REST_Response( [ 'deactivated' => true ] );
	}

	/**
	 * An inbox row as clients see it: everything but the webhook secret,
	 * which only the email worker and the inbound webhook need.
	 */
	private static function without_secret( ?object $inbox ): ?object {
		if ( null === $inbox ) {
			return null;
		}

		$inbox = clone $inbox;
		unset( $inbox->webhook_secret );

		return $inbox;
	}

	/**
	 * Turn a user-supplied inbox name into a safe email-local-part slug.
	 *
	 * - sanitize_title() handles unicode, transliteration, lowercasing.
	 * - We then strip any character that isn't a-z, 0-9 or hyphen, collapse
	 *   runs of hyphens, and trim. Empty result falls back to "inbox".
	 * - Truncated to 24 chars so the full address stays under ~30 chars.
	 */
	private static function slugify_for_address( string $name ): string {
		$slug = sanitize_title( $name );
		$slug = preg_replace( '/[^a-z0-9-]/', '', $slug );
		$slug = preg_replace( '/-+/', '-', (string) $slug );
		$slug = trim( (string) $slug, '-' );
		if ( strlen( $slug ) > 24 ) {
			$slug = trim( substr( $slug, 0, 24 ), '-' );
		}
		if ( '' === $slug ) {
			$slug = 'inbox';
		}
		return $slug;
	}
}
