<?php
/**
 * Bridle Chat's routes (#114): two public ones for the visitor's browser and
 * one for the owner's Turnstile keys.
 *
 * @package Bridle
 */

namespace Bridle\RestApi;

use Bridle\Services\BridleAi;
use Bridle\Services\ChatFollowUp;
use Bridle\Services\ChatPolicy;
use Bridle\Services\ChatService;
use WP_Error;
use WP_REST_Controller;
use WP_REST_Response;
use WP_REST_Server;

defined( 'ABSPATH' ) || exit;

/**
 * POST /chat and POST /chat/handoff are public: their permission check is
 * that Chat is switched on and, to continue a chat, that the visitor holds
 * its token. Limits and Turnstile are checked in ChatService.
 */
class ChatController extends WP_REST_Controller {

	protected $namespace = BRIDLE_REST_NAMESPACE;
	protected $rest_base = 'chat';

	public function register_routes(): void {
		$text = [
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_textarea_field',
		];
		$line = [
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_text_field',
		];

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'send' ],
					'permission_callback' => [ $this, 'visitor_check' ],
					'args'                => [
						'message'   => [ 'required' => true ] + $text,
						'id'        => [
							'type'    => 'integer',
							'default' => 0,
						],
						'token'     => $line,
						'hp'        => $line,
						'turnstile' => $line,
						'pow'       => $line,
						'cid'       => $line,
						'page'      => [
							'type'              => 'string',
							'sanitize_callback' => 'esc_url_raw',
						],
					],
				],
			]
		);

		// The invisible check's challenge, before a new chat (#165).
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/challenge',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'challenge' ],
					'permission_callback' => [ $this, 'visitor_check' ],
				],
			]
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/handoff',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'handoff' ],
					'permission_callback' => [ $this, 'visitor_check' ],
					'args'                => [
						'id'        => [
							'type'     => 'integer',
							'required' => true,
						],
						'token'     => [ 'required' => true ] + $line,
						'email'     => [
							'type'              => 'string',
							'default'           => '',
							'sanitize_callback' => 'sanitize_email',
						],
						'name'      => $line,
						'message'   => $text,
						'turnstile' => $line,
						'live'      => [
							'type'    => 'boolean',
							'default' => false,
						],
					],
				],
			]
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/messages',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'messages' ],
					'permission_callback' => [ $this, 'visitor_check' ],
					'args'                => [
						'id'     => [
							'type'     => 'integer',
							'required' => true,
						],
						'token'  => [ 'required' => true ] + $line,
						'after'  => [
							'type'    => 'integer',
							'default' => 0,
						],
						'open'   => [
							'type'    => 'boolean',
							'default' => false,
						],
						'typing' => [
							'type'    => 'boolean',
							'default' => false,
						],
					],
				],
			]
		);

		// Bridle AI's edge (#172): it asks the model, this site does the rest.
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/edge',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'edge' ],
					'permission_callback' => [ $this, 'edge_check' ],
				],
			]
		);

		// The one-time link in a chat's confirmation email (#150): the bubble
		// asks the visitor to tap, then posts here.
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/confirm',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'confirm' ],
					'permission_callback' => [ $this, 'confirm_check' ],
					'args'                => [
						'id'  => [
							'type'     => 'integer',
							'required' => true,
						],
						'key' => [ 'required' => true ] + $line,
					],
				],
			]
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/turnstile',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_turnstile' ],
					'permission_callback' => [ $this, 'settings_check' ],
				],
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'save_turnstile' ],
					'permission_callback' => [ $this, 'settings_check' ],
					'args'                => [
						'site_key' => $line,
						'secret'   => $line,
					],
				],
			]
		);
	}

	/**
	 * GET /chat/challenge: a fresh challenge for the invisible check.
	 *
	 * @return \WP_REST_Response
	 */
	public function challenge() {
		$response = new \WP_REST_Response( ChatService::challenge() );
		$response->header( 'Cache-Control', 'no-store' );
		return $response;
	}

	/**
	 * Chat must be on, for a browser on this site (or one an add-on allows);
	 * continuing a chat (or leaving an email) needs its token.
	 *
	 * @param \WP_REST_Request $request The request.
	 * @return true|WP_Error
	 */
	public function visitor_check( $request ) {
		if ( ! ChatService::ready() ) {
			return new WP_Error( 'bridle_chat_off', __( 'Chat is not available.', 'bridle' ), [ 'status' => 403 ] );
		}
		if ( ! ChatService::origin_allowed( ChatService::origin() ) ) {
			return new WP_Error( 'bridle_chat_origin', __( 'Chat is not available on this site.', 'bridle' ), [ 'status' => 403 ] );
		}
		$id = absint( $request->get_param( 'id' ) );
		if ( $id && ! ChatService::find( $id, (string) $request->get_param( 'token' ) ) ) {
			return new WP_Error( 'bridle_chat_gone', __( 'This chat has ended. Start a new one.', 'bridle' ), [ 'status' => 403 ] );
		}
		return true;
	}

	/**
	 * Confirming needs Chat on and a browser on this site (or one an add-on
	 * allows); the key in the link is checked by the callback.
	 *
	 * @param \WP_REST_Request $request The request.
	 * @return true|WP_Error
	 */
	public function confirm_check( $request ) {
		if ( ! ChatService::ready() ) {
			return new WP_Error( 'bridle_chat_off', __( 'Chat is not available.', 'bridle' ), [ 'status' => 403 ] );
		}
		if ( ! ChatService::origin_allowed( ChatService::origin() ) ) {
			return new WP_Error( 'bridle_chat_origin', __( 'Chat is not available on this site.', 'bridle' ), [ 'status' => 403 ] );
		}
		return true;
	}

	public function confirm( $request ) {
		$result = ChatService::confirm_email( absint( $request->get_param( 'id' ) ), (string) $request->get_param( 'key' ) );
		return is_wp_error( $result ) ? $result : $this->no_cache( new WP_REST_Response( $result ) );
	}

	/**
	 * Only Bridle AI's edge, by its signature over the raw body, and only
	 * while Chat is on.
	 *
	 * @param \WP_REST_Request $request The request.
	 * @return true|WP_Error
	 */
	public function edge_check( $request ) {
		$secret = (string) ( BridleAi::edge()['secret'] ?? '' );
		if ( ! ChatPolicy::edge_valid( $secret, (string) $request->get_header( 'x_bridle_edge_time' ), (string) $request->get_body(), (string) $request->get_header( 'x_bridle_edge_sign' ), time() ) ) {
			return new WP_Error( 'bridle_chat_edge_auth', __( 'Not signed by Bridle AI.', 'bridle' ), [ 'status' => 401 ] );
		}
		if ( ! ChatService::ready() ) {
			return new WP_Error( 'bridle_chat_off', __( 'Chat is not available.', 'bridle' ), [ 'status' => 403 ] );
		}
		return true;
	}

	/**
	 * POST /chat/edge: prepare (everything up to the model call) or finish
	 * (with the model's answer), for Bridle AI's edge.
	 *
	 * @param \WP_REST_Request $request The request.
	 */
	public function edge( $request ) {
		$data = (array) $request->get_json_params();
		if ( 'finish' === ( $data['step'] ?? '' ) ) {
			$result = ChatService::edge_finish(
				sanitize_text_field( (string) ( $data['ticket'] ?? '' ) ),
				(string) ( $data['raw'] ?? '' ),
				sanitize_key( (string) ( $data['error'] ?? '' ) )
			);
			return is_wp_error( $result ) ? $result : $this->no_cache( new WP_REST_Response( $result ) );
		}

		$input  = (array) ( $data['input'] ?? [] );
		$origin = esc_url_raw( (string) ( $data['origin'] ?? '' ) );
		if ( ! ChatService::origin_allowed( $origin ) ) {
			return new WP_Error( 'bridle_chat_origin', __( 'Chat is not available on this site.', 'bridle' ), [ 'status' => 403 ] );
		}
		$id = absint( $input['id'] ?? 0 );
		if ( $id && ! ChatService::find( $id, sanitize_text_field( (string) ( $input['token'] ?? '' ) ) ) ) {
			return new WP_Error( 'bridle_chat_gone', __( 'This chat has ended. Start a new one.', 'bridle' ), [ 'status' => 403 ] );
		}
		$result = ChatService::edge_prepare(
			[
				'message'   => sanitize_textarea_field( (string) ( $input['message'] ?? '' ) ),
				'id'        => $id,
				'token'     => sanitize_text_field( (string) ( $input['token'] ?? '' ) ),
				'hp'        => sanitize_text_field( (string) ( $input['hp'] ?? '' ) ),
				'turnstile' => sanitize_text_field( (string) ( $input['turnstile'] ?? '' ) ),
				'page'      => esc_url_raw( (string) ( $input['page'] ?? '' ) ),
				'cid'       => sanitize_text_field( (string) ( $input['cid'] ?? '' ) ),
				'pow'       => sanitize_text_field( (string) ( $input['pow'] ?? '' ) ),
			],
			sanitize_text_field( (string) ( $data['visitor'] ?? '' ) ),
			$origin
		);
		return is_wp_error( $result ) ? $result : $this->no_cache( new WP_REST_Response( $result ) );
	}

	public function settings_check( $request ) {
		return current_user_can( 'bridle_manage_settings' );
	}

	public function send( $request ) {
		$result = ChatService::send(
			[
				'message'   => (string) $request->get_param( 'message' ),
				'id'        => absint( $request->get_param( 'id' ) ),
				'token'     => (string) $request->get_param( 'token' ),
				'hp'        => (string) $request->get_param( 'hp' ),
				'turnstile' => (string) $request->get_param( 'turnstile' ),
				'page'      => (string) $request->get_param( 'page' ),
				'cid'       => (string) $request->get_param( 'cid' ),
				'pow'       => (string) $request->get_param( 'pow' ),
			]
		);
		return is_wp_error( $result ) ? $result : $this->no_cache( new WP_REST_Response( $result ) );
	}

	public function handoff( $request ) {
		$conversation = ChatService::find( absint( $request->get_param( 'id' ) ), (string) $request->get_param( 'token' ) );
		if ( ! $conversation ) {
			return new WP_Error( 'bridle_chat_gone', __( 'This chat has ended. Start a new one.', 'bridle' ), [ 'status' => 403 ] );
		}
		$result = ChatService::handoff(
			$conversation,
			[
				'email'     => (string) $request->get_param( 'email' ),
				'name'      => (string) $request->get_param( 'name' ),
				'message'   => (string) $request->get_param( 'message' ),
				'live'      => (bool) $request->get_param( 'live' ),
				'turnstile' => (string) $request->get_param( 'turnstile' ),
			]
		);
		return is_wp_error( $result ) ? $result : $this->no_cache( new WP_REST_Response( $result ) );
	}

	/**
	 * The team's replies the bubble hasn't shown yet (#120). Polled while the
	 * visitor is on the site; `open` means they are looking, so the replies
	 * count as read and are not emailed.
	 */
	public function messages( $request ) {
		$conversation = ChatService::find( absint( $request->get_param( 'id' ) ), (string) $request->get_param( 'token' ) );
		if ( ! $conversation ) {
			return new WP_Error( 'bridle_chat_gone', __( 'This chat has ended. Start a new one.', 'bridle' ), [ 'status' => 403 ] );
		}
		$open = (bool) $request->get_param( 'open' );
		$data = [
			'messages' => ChatFollowUp::messages( $conversation, absint( $request->get_param( 'after' ) ), $open ),
		];
		/**
		 * Filters what the visitor's bubble gets on each check for replies.
		 * Bridle Pro adds `live` (a person has the chat open), `typing` (a
		 * person is typing) and `poll` (milliseconds to the next check).
		 *
		 * @param array  $data         { messages }.
		 * @param object $conversation The chat.
		 * @param array  $visitor      { open: the bubble is open, typing: the visitor is typing }.
		 */
		$data = (array) apply_filters(
			'bridle_chat_poll',
			$data,
			$conversation,
			[
				'open'   => $open,
				'typing' => (bool) $request->get_param( 'typing' ),
			]
		);
		return $this->no_cache( new WP_REST_Response( $data ) );
	}

	public function get_turnstile( $request ) {
		return new WP_REST_Response( ChatService::turnstile_config() );
	}

	public function save_turnstile( $request ) {
		return new WP_REST_Response(
			ChatService::save_turnstile(
				[
					'site_key' => (string) $request->get_param( 'site_key' ),
					'secret'   => (string) $request->get_param( 'secret' ),
				]
			)
		);
	}

	/** A visitor's chat must never be cached by a page cache or CDN. */
	private function no_cache( WP_REST_Response $response ): WP_REST_Response {
		$response->header( 'Cache-Control', 'no-store, private' );
		return $response;
	}
}
