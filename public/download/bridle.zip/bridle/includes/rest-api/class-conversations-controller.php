<?php

namespace Bridle\RestApi;

use Bridle\Models\Conversation;
use Bridle\Models\Customer;
use Bridle\Models\Inbox;
use Bridle\Models\Read;
use WP_Error;
use WP_REST_Controller;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ConversationsController extends WP_REST_Controller {

	protected $namespace = BRIDLE_REST_NAMESPACE;
	protected $rest_base = 'conversations';

	public function register_routes(): void {
		register_rest_route( $this->namespace, '/' . $this->rest_base, [
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_items' ],
				'permission_callback' => [ $this, 'get_items_permissions_check' ],
				'args'                => $this->get_collection_params(),
			],
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'create_item' ],
				'permission_callback' => [ $this, 'create_item_permissions_check' ],
			],
		] );

		register_rest_route( $this->namespace, '/' . $this->rest_base . '/counts', [
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_counts' ],
				'permission_callback' => [ $this, 'get_items_permissions_check' ],
			],
		] );

		// The Feed, grouped one row per sender.
		register_rest_route( $this->namespace, '/' . $this->rest_base . '/feed-senders', [
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_feed_senders' ],
				'permission_callback' => [ $this, 'get_items_permissions_check' ],
			],
		] );

		register_rest_route( $this->namespace, '/' . $this->rest_base . '/(?P<id>[\d]+)', [
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_item' ],
				'permission_callback' => [ $this, 'get_items_permissions_check' ],
			],
			[
				'methods'             => 'PATCH',
				'callback'            => [ $this, 'update_item' ],
				'permission_callback' => [ $this, 'create_item_permissions_check' ],
			],
			[
				'methods'             => WP_REST_Server::DELETABLE,
				'callback'            => [ $this, 'delete_item' ],
				'permission_callback' => [ $this, 'create_item_permissions_check' ],
			],
		] );

		// Read/unread for the current teammate: POST marks read, DELETE unread.
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/(?P<id>[\d]+)/read',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'mark_read' ],
					'permission_callback' => [ $this, 'get_items_permissions_check' ],
				],
				[
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => [ $this, 'mark_unread' ],
					'permission_callback' => [ $this, 'get_items_permissions_check' ],
				],
			]
		);

		// Every id a list view matches, for "select all N conversations".
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/ids',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_ids' ],
					'permission_callback' => [ $this, 'get_items_permissions_check' ],
					'args'                => $this->get_collection_params(),
				],
			]
		);

		// One status for many conversations (Resolve, Spam, Reopen, Not spam).
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/bulk-status',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'bulk_status' ],
					'permission_callback' => [ $this, 'create_item_permissions_check' ],
				],
			]
		);

		// Read or unread for many conversations, for the current teammate.
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/bulk-read',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'bulk_read' ],
					'permission_callback' => [ $this, 'get_items_permissions_check' ],
				],
			]
		);

		// Bulk delete (soft by default; pass force=true to hard-delete trashed items).
		register_rest_route( $this->namespace, '/' . $this->rest_base . '/bulk-delete', [
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'bulk_delete' ],
				'permission_callback' => [ $this, 'create_item_permissions_check' ],
			],
		] );

		// Bulk restore (trash → active).
		register_rest_route( $this->namespace, '/' . $this->rest_base . '/bulk-restore', [
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'bulk_restore' ],
				'permission_callback' => [ $this, 'create_item_permissions_check' ],
			],
		] );

		// Empty trash (permanently delete everything with status=trash).
		register_rest_route( $this->namespace, '/' . $this->rest_base . '/empty-trash', [
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'empty_trash' ],
				'permission_callback' => [ $this, 'create_item_permissions_check' ],
			],
		] );

		// Merge conversations.
		register_rest_route( $this->namespace, '/' . $this->rest_base . '/merge', [
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'merge_conversations' ],
				'permission_callback' => [ $this, 'create_item_permissions_check' ],
			],
		] );
	}

	public function get_items_permissions_check( $request ) {
		return current_user_can( 'bridle_manage_conversations' ) || current_user_can( 'bridle_reply_conversations' );
	}

	public function create_item_permissions_check( $request ) {
		return current_user_can( 'bridle_manage_conversations' );
	}

	public function get_counts( $request ) {
		global $wpdb;

		$conv_table  = $wpdb->prefix . 'bridle_conversations';
		$inbox_table = $wpdb->prefix . 'bridle_inboxes';
		$user_id     = get_current_user_id();
		$inbox_id    = $request->get_param( 'inbox_id' ) ? absint( $request->get_param( 'inbox_id' ) ) : 0;

		// When scoped to an inbox, filter by that inbox.
		// When global (dashboard), only count conversations that belong to an
		// active inbox — orphaned rows with NULL or deleted inbox_id are excluded
		// so dashboard numbers stay consistent with what inboxes actually show.
		if ( $inbox_id ) {
			$inbox_where = ' AND c.inbox_id = %d';
			$inbox_args  = [ $inbox_id ];
		} else {
			$inbox_where = ' AND c.inbox_id IN ( SELECT id FROM %i WHERE is_active = %d )';
			$inbox_args  = [ $inbox_table, 1 ];
		}

		// One pass for every box. Feed mail stays status "active" but is
		// never part of the Inbox, its views or its counts.
		$joins    = Conversation::box_joins();
		$inbox    = Conversation::box_sql( 'inbox' );
		$feed     = Conversation::box_sql( 'feed' );
		$feed_sql = Conversation::FEED_SQL;

		// The box SQL, FEED_SQL and the joins are constant fragments and the
		// inbox filter is placeholders; every table and value below is bound.
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT
				SUM( {$inbox} ) AS inbox,
				SUM( {$inbox} AND lt.author_type = 'customer' ) AS needs_reply,
				SUM( {$inbox} AND c.assigned_to IS NULL ) AS unassigned,
				SUM( {$inbox} AND c.assigned_to = %d ) AS mine,
				SUM( {$feed} ) AS feed,
				SUM( c.status = 'closed' ) AS closed,
				SUM( c.status = 'spam' ) AS spam,
				SUM( c.status = 'trash' ) AS trash
			FROM %i c {$joins}
			WHERE 1 = 1{$inbox_where}",
			array_merge( [ $user_id, $conv_table ], Conversation::box_join_tables(), $inbox_args )
		) );

		$all_open    = (int) ( $row->inbox ?? 0 );
		$needs_reply = (int) ( $row->needs_reply ?? 0 );
		$unassigned  = (int) ( $row->unassigned ?? 0 );
		$mine        = (int) ( $row->mine ?? 0 );
		$feed_count  = (int) ( $row->feed ?? 0 );
		$closed      = (int) ( $row->closed ?? 0 );
		$spam        = (int) ( $row->spam ?? 0 );
		$trash       = (int) ( $row->trash ?? 0 );

		$threads_table = $wpdb->prefix . 'bridle_threads';
		$sent          = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(DISTINCT c.id) FROM %i c
			 INNER JOIN %i t ON t.conversation_id = c.id
			 WHERE t.author_type = 'teammate' AND t.author_id = %d AND t.thread_type = 'reply'
			 AND c.status NOT IN (%s, %s, %s){$inbox_where}",
			array_merge( [ $conv_table, $threads_table, $user_id, 'closed', 'spam', 'trash' ], $inbox_args )
		) );

		// Per-inbox counts — open, unassigned, mine for each active inbox,
		// Feed excluded.
		$inbox_rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT i.id AS inbox_id, i.display_name,
				SUM( CASE WHEN c.status = 'active' AND NOT ( {$feed_sql} ) THEN 1 ELSE 0 END ) AS open_count,
				SUM( CASE WHEN c.status = 'active' AND NOT ( {$feed_sql} ) AND c.assigned_to IS NULL THEN 1 ELSE 0 END ) AS unassigned_count,
				SUM( CASE WHEN c.status = 'active' AND NOT ( {$feed_sql} ) AND c.assigned_to = %d THEN 1 ELSE 0 END ) AS mine_count
			FROM %i i
			LEFT JOIN %i c ON c.inbox_id = i.id
			LEFT JOIN %i cu ON c.customer_id = cu.id
			WHERE i.is_active = 1
			GROUP BY i.id, i.display_name",
			$user_id,
			$inbox_table,
			$conv_table,
			$wpdb->prefix . 'bridle_customers'
		) );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery

		$by_inbox = [];
		if ( $inbox_rows ) {
			foreach ( $inbox_rows as $row ) {
				$by_inbox[] = [
					'id'         => (int) $row->inbox_id,
					'name'       => $row->display_name,
					'open'       => (int) $row->open_count,
					'unassigned' => (int) $row->unassigned_count,
					'mine'       => (int) $row->mine_count,
				];
			}
		}

		$drafts_table = $wpdb->prefix . 'bridle_drafts';
		if ( $inbox_id ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$drafts = (int) $wpdb->get_var( $wpdb->prepare(
				'SELECT COUNT(*) FROM %i WHERE user_id = %d AND conversation_id IN (SELECT id FROM %i WHERE inbox_id = %d)',
				$drafts_table,
				$user_id,
				$conv_table,
				$inbox_id
			) );
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$drafts = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE user_id = %d', $drafts_table, $user_id ) );
		}

		return new WP_REST_Response( [
			'unassigned'  => $unassigned,
			'mine'        => $mine,
			'inbox'       => $all_open,
			'all_open'    => $all_open,
			'needs_reply' => $needs_reply,
			'waiting'     => $all_open - $needs_reply,
			'feed'        => $feed_count,
			'sent'        => $sent,
			'drafts'      => $drafts,
			'closed'      => $closed,
			'spam'        => $spam,
			'trash'       => $trash,
			'by_inbox'    => $by_inbox,
		] );
	}

	public function get_items( $request ) {
		$model = new Conversation();

		$assigned_to = $request->get_param( 'assigned_to' );
		if ( 'me' === $assigned_to ) {
			$assigned_to = get_current_user_id();
		}

		$sent_by = $request->get_param( 'sent_by' );
		if ( 'me' === $sent_by ) {
			$sent_by = get_current_user_id();
		}

		$has_draft_by = $request->get_param( 'has_draft_by' );
		if ( 'me' === $has_draft_by ) {
			$has_draft_by = get_current_user_id();
		}

		$result = $model->list( [
			'status'        => $request->get_param( 'status' ),
			'box'          => $request->get_param( 'box' ),
			'inbox_id'      => $request->get_param( 'inbox_id' ),
			'customer_id'   => $request->get_param( 'customer_id' ),
			'assigned_to'   => $assigned_to,
			'sent_by'       => $sent_by ? absint( $sent_by ) : null,
			'has_draft_by'  => $has_draft_by ? absint( $has_draft_by ) : null,
			'search'        => $request->get_param( 'search' ),
			'reader_id'    => get_current_user_id(),
			'page'        => $request->get_param( 'page' ) ?: 1,
			'per_page'    => $request->get_param( 'per_page' ) ?: 20,
		] );

		// Attach a gravatar URL per row (d=404 so rows without a real
		// gravatar fall back to coloured initials client-side).
		foreach ( $result['items'] as $item ) {
			$item->customer_avatar = \Bridle\Services\Avatars::url( $item->customer_email ?? '', 64 );
		}

		$response = new WP_REST_Response( $result['items'] );
		$response->header( 'X-WP-Total', $result['total'] );
		$response->header( 'X-WP-TotalPages', ceil( $result['total'] / $result['per_page'] ) );

		return $response;
	}

	/**
	 * The ids behind a list view (same filters as get_items), capped at
	 * Conversation::IDS_LIMIT. `capped` says the view holds more than that.
	 */
	public function get_ids( $request ) {
		$filters = [
			'status'   => $request->get_param( 'status' ),
			'box'      => $request->get_param( 'box' ),
			'inbox_id' => $request->get_param( 'inbox_id' ),
			'search'   => $request->get_param( 'search' ),
		];
		$result  = ( new Conversation() )->ids( $filters );
		$body    = [
			'ids'    => $result['ids'],
			'total'  => $result['total'],
			'capped' => $result['total'] > count( $result['ids'] ),
		];

		return new WP_REST_Response( $body );
	}

	/**
	 * Set one status on many conversations, through the same model update
	 * and `bridle_conversation_updated` action as a single PATCH. Trash has
	 * its own routes (bulk-delete, bulk-restore).
	 */
	public function bulk_status( $request ) {
		$params = (array) $request->get_json_params();
		$ids    = $this->ids_param( $params );
		$status = sanitize_key( (string) ( $params['status'] ?? '' ) );

		if ( ! $ids ) {
			return new WP_Error( 'bridle_missing_ids', __( 'No conversation IDs provided.', 'bridle' ), [ 'status' => 400 ] );
		}
		if ( ! in_array( $status, [ 'active', 'closed', 'spam' ], true ) ) {
			return new WP_Error( 'bridle_invalid_fields', __( 'Invalid value for: status.', 'bridle' ), [ 'status' => 400 ] );
		}

		$model   = new Conversation();
		$updated = 0;
		foreach ( $ids as $id ) {
			$previous = $model->get_by_id( $id );
			if ( ! $previous || $status === $previous->status ) {
				continue;
			}
			$model->update( $id, [ 'status' => $status ] );
			/** This action is documented in update_item(). */
			do_action( 'bridle_conversation_updated', $id, $model->get_by_id( $id ), $previous, [ 'status' => $status ] );
			++$updated;
		}

		return new WP_REST_Response( [ 'updated' => $updated ] );
	}

	/**
	 * Mark many conversations read (`read: true`) or unread for the current
	 * teammate.
	 */
	public function bulk_read( $request ) {
		$params = (array) $request->get_json_params();
		$ids    = $this->ids_param( $params );
		$read   = ! empty( $params['read'] );

		if ( ! $ids ) {
			return new WP_Error( 'bridle_missing_ids', __( 'No conversation IDs provided.', 'bridle' ), [ 'status' => 400 ] );
		}

		$reads = new Read();
		$user  = get_current_user_id();
		foreach ( $ids as $id ) {
			if ( $read ) {
				$reads->mark_read( $id, $user );
			} else {
				$reads->mark_unread( $id, $user );
			}
		}

		$body = [
			'updated' => count( $ids ),
			'unread'  => ! $read,
		];

		return new WP_REST_Response( $body );
	}

	/**
	 * The `ids` of a bulk request: positive integers, de-duplicated, at most
	 * Conversation::IDS_LIMIT.
	 *
	 * @return int[]
	 */
	private function ids_param( array $params ): array {
		$ids = array_values( array_unique( array_filter( array_map( 'absint', (array) ( $params['ids'] ?? [] ) ) ) ) );

		return array_slice( $ids, 0, Conversation::IDS_LIMIT );
	}

	public function mark_read( $request ) {
		return $this->set_read( $request, true );
	}

	public function mark_unread( $request ) {
		return $this->set_read( $request, false );
	}

	private function set_read( $request, bool $read ) {
		$id = absint( $request['id'] );
		if ( ! ( new Conversation() )->get_by_id( $id ) ) {
			return new WP_Error( 'bridle_not_found', __( 'Conversation not found.', 'bridle' ), [ 'status' => 404 ] );
		}

		$reads = new Read();
		$saved = $read
			? $reads->mark_read( $id, get_current_user_id() )
			: $reads->mark_unread( $id, get_current_user_id() );
		if ( ! $saved ) {
			return new WP_Error( 'bridle_read_failed', __( 'Could not save that. Try again.', 'bridle' ), [ 'status' => 500 ] );
		}

		return new WP_REST_Response( [ 'unread' => ! $read ] );
	}

	public function get_feed_senders( $request ) {
		$result = ( new Conversation() )->feed_senders( [
			'inbox_id' => $request->get_param( 'inbox_id' ),
			'page'     => $request->get_param( 'page' ),
			'per_page' => $request->get_param( 'per_page' ),
		] );

		foreach ( $result['items'] as $item ) {
			$item->avatar_url    = \Bridle\Services\Avatars::url( $item->email ?? '', 64 );
			$item->conversations = (int) $item->conversations;
		}

		$response = new WP_REST_Response( $result['items'] );
		$response->header( 'X-WP-Total', $result['total'] );

		return $response;
	}

	public function get_item( $request ) {
		$model        = new Conversation();
		$conversation = $model->get_with_threads( absint( $request['id'] ) );

		if ( ! $conversation ) {
			return new WP_Error( 'bridle_not_found', __( 'Conversation not found.', 'bridle' ), [ 'status' => 404 ] );
		}

		// A chat's email is only the visitor's word until they confirm it (#150).
		if ( 'chat' === $conversation->channel && (int) $conversation->customer_id > 0 ) {
			$conversation->email_confirmed = \Bridle\Services\ChatService::email_confirmed( $conversation );
		}

		return new WP_REST_Response( $conversation );
	}

	public function create_item( $request ) {
		$params = $request->get_json_params();

		if ( empty( $params['subject'] ) || empty( $params['customer_email'] ) ) {
			return new WP_Error( 'bridle_missing_fields', __( 'Subject and contact email are required.', 'bridle' ), [ 'status' => 400 ] );
		}

		// Validate the address up front: an invalid string survives the empty
		// check above but sanitize_email() collapses it to '', which then trips
		// the customers.email NOT NULL UNIQUE constraint as a confusing 500.
		$params['customer_email'] = sanitize_email( $params['customer_email'] );
		if ( ! is_email( $params['customer_email'] ) ) {
			return new WP_Error( 'bridle_invalid_email', __( 'A valid contact email is required.', 'bridle' ), [ 'status' => 400 ] );
		}

		// inbox_id is required — without it the conversation is invisible
		// to every folder filter (folders are scoped to a specific inbox).
		// Fall back to the first active inbox so older clients that don't
		// send inbox_id still produce a visible row.
		$inbox_id = isset( $params['inbox_id'] ) ? absint( $params['inbox_id'] ) : 0;
		if ( ! $inbox_id ) {
			$first = ( new Inbox() )->list();
			$inbox_id = ! empty( $first ) ? (int) $first[0]->id : 0;
		}
		if ( ! $inbox_id ) {
			return new WP_Error( 'bridle_no_inbox', __( 'Create an inbox before adding conversations.', 'bridle' ), [ 'status' => 400 ] );
		}
		$params['inbox_id'] = $inbox_id;

		$customer_model = new Customer();
		$customer       = $customer_model->find_by_email( $params['customer_email'] );

		if ( ! $customer ) {
			$customer_id = $customer_model->create( [
				'email' => $params['customer_email'],
				'name'  => $params['customer_name'] ?? null,
			] );

			if ( ! $customer_id ) {
				return new WP_Error( 'bridle_customer_error', __( 'Could not create contact.', 'bridle' ), [ 'status' => 500 ] );
			}

			/**
			 * Fires after a new customer is created via REST.
			 *
			 * @param int    $customer_id The new customer ID.
			 * @param object $customer    The customer row (freshly fetched).
			 */
			do_action( 'bridle_customer_created', (int) $customer_id, $customer_model->get_by_id( $customer_id ) );
		} else {
			$customer_id = $customer->id;
		}

		// Thread prefix from inbox hash.
		$thread_prefix = null;
		$inbox         = null;
		if ( ! empty( $params['inbox_id'] ) ) {
			$inbox = ( new Inbox() )->get_by_id( absint( $params['inbox_id'] ) );
			if ( $inbox ) {
				$thread_prefix = strtoupper( substr( $inbox->inbox_hash, 0, 2 ) );
			}
		}

		/**
		 * Filter the conversation subject before the conversation is created.
		 *
		 * @param string   $subject  The subject from the API request.
		 * @param int      $inbox_id The target inbox ID.
		 */
		$subject = (string) apply_filters( 'bridle_conversation_subject', sanitize_text_field( $params['subject'] ), (int) $params['inbox_id'] );

		$model           = new Conversation();
		$conversation_id = $model->create( [
			'subject'        => $subject ?: $params['subject'],
			'customer_id'    => $customer_id,
			'inbox_id'     => $params['inbox_id'] ?? null,
			'channel'        => $params['channel'] ?? 'email',
			'urgency'        => $params['urgency'] ?? 'normal',
			'assigned_to'    => $params['assigned_to'] ?? null,
			'thread_prefix'  => $thread_prefix,
		] );

		if ( ! $conversation_id ) {
			return new WP_Error( 'bridle_create_error', __( 'Could not create conversation.', 'bridle' ), [ 'status' => 500 ] );
		}

		if ( ! empty( $params['message'] ) ) {
			$thread_model = new \Bridle\Models\Thread();
			$thread_model->create( [
				'conversation_id' => $conversation_id,
				'author_type'     => 'customer',
				'author_id'       => $customer_id,
				'content'         => $params['message'],
				'content_html'    => $params['message_html'] ?? null,
			] );
		}

		// Increment customer conversations count.
		$customer_model->increment_conversations( $customer_id );

		$conversation = $model->get_with_threads( $conversation_id );

		/**
		 * Fires after a new conversation is created.
		 *
		 * @param int    $conversation_id The conversation ID.
		 * @param object $conversation    The conversation object.
		 */
		do_action( 'bridle_conversation_created', $conversation_id, $conversation );

		return new WP_REST_Response( $conversation, 201 );
	}

	public function update_item( $request ) {
		$model        = new Conversation();
		$conversation = $model->get_by_id( absint( $request['id'] ) );

		if ( ! $conversation ) {
			return new WP_Error( 'bridle_not_found', __( 'Conversation not found.', 'bridle' ), [ 'status' => 404 ] );
		}

		$params = (array) $request->get_json_params();
		[ $fields, $invalid ] = Conversation::editable_fields( $params );

		if ( ! empty( $fields['inbox_id'] ) ) {
			$inbox = ( new \Bridle\Models\Inbox() )->get_by_id( $fields['inbox_id'] );
			if ( ! $inbox || ! $inbox->is_active ) {
				$invalid[] = 'inbox_id';
			}
		}

		if ( $invalid ) {
			return new WP_Error(
				'bridle_invalid_fields',
				/* translators: %s: comma-separated field names. */
				sprintf( __( 'Invalid value for: %s.', 'bridle' ), implode( ', ', $invalid ) ),
				[ 'status' => 400 ]
			);
		}

		$model->update( $conversation->id, $fields );

		$updated = $model->get_by_id( $conversation->id );

		/**
		 * Fires after a conversation is updated via REST.
		 *
		 * @param int    $conversation_id The conversation ID.
		 * @param object $updated         The updated conversation row.
		 * @param object $previous        The conversation row prior to update.
		 * @param array  $params          The validated fields that were applied.
		 */
		do_action( 'bridle_conversation_updated', (int) $conversation->id, $updated, $conversation, $fields );

		return new WP_REST_Response( $updated );
	}

	public function delete_item( $request ) {
		$model        = new Conversation();
		$conversation = $model->get_by_id( absint( $request['id'] ) );

		if ( ! $conversation ) {
			return new WP_Error( 'bridle_not_found', __( 'Conversation not found.', 'bridle' ), [ 'status' => 404 ] );
		}

		// Permanent delete: allowed ONLY if already in trash, or when force=true is explicit.
		$force = $this->is_force( $request );

		if ( $force ) {
			if ( 'trash' !== $conversation->status ) {
				return new WP_Error( 'bridle_not_trashed', __( 'Conversation must be in trash before permanent deletion.', 'bridle' ), [ 'status' => 400 ] );
			}
			$model->hard_delete( [ (int) $conversation->id ] );
			return new WP_REST_Response( [ 'deleted' => true, 'permanent' => true ] );
		}

		// Soft delete: move to trash.
		$model->update( (int) $conversation->id, [ 'status' => 'trash' ] );
		return new WP_REST_Response( [ 'deleted' => true, 'permanent' => false ] );
	}

	public function bulk_delete( $request ) {
		$params = $request->get_json_params();
		$ids    = array_map( 'absint', $params['ids'] ?? [] );
		$ids    = array_filter( $ids );

		if ( empty( $ids ) ) {
			return new WP_Error( 'bridle_missing_ids', __( 'No conversation IDs provided.', 'bridle' ), [ 'status' => 400 ] );
		}

		$force = ! empty( $params['force'] ) || $this->is_force( $request );

		if ( $force ) {
			// Only hard-delete conversations that are already in trash.
			global $wpdb;
			$conv_table   = $wpdb->prefix . 'bridle_conversations';
			$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- a list of %d placeholders.
			$trashed_ids = $wpdb->get_col( $wpdb->prepare(
				"SELECT id FROM %i WHERE status = %s AND id IN ({$placeholders})",
				array_merge( [ $conv_table, 'trash' ], $ids )
			) );
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
			$trashed_ids = array_map( 'intval', $trashed_ids );

			if ( empty( $trashed_ids ) ) {
				return new WP_Error( 'bridle_not_trashed', __( 'Selected conversations are not in trash.', 'bridle' ), [ 'status' => 400 ] );
			}

			( new Conversation() )->hard_delete( $trashed_ids );
			return new WP_REST_Response( [ 'deleted' => count( $trashed_ids ), 'permanent' => true ] );
		}

		// Soft delete: set status=trash.
		$model = new Conversation();
		foreach ( $ids as $id ) {
			$model->update( (int) $id, [ 'status' => 'trash' ] );
		}

		return new WP_REST_Response( [ 'deleted' => count( $ids ), 'permanent' => false ] );
	}

	public function bulk_restore( $request ) {
		$params = $request->get_json_params();
		$ids    = array_filter( array_map( 'absint', $params['ids'] ?? [] ) );

		if ( empty( $ids ) ) {
			return new WP_Error( 'bridle_missing_ids', __( 'No conversation IDs provided.', 'bridle' ), [ 'status' => 400 ] );
		}

		$model = new Conversation();
		foreach ( $ids as $id ) {
			$row = $model->get_by_id( (int) $id );
			if ( $row && 'trash' === $row->status ) {
				$model->update( (int) $id, [ 'status' => 'active' ] );
			}
		}

		return new WP_REST_Response( [ 'restored' => count( $ids ) ] );
	}

	public function empty_trash( $request ) {
		global $wpdb;
		$conv_table = $wpdb->prefix . 'bridle_conversations';

		$trashed_ids = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare(
			'SELECT id FROM %i WHERE status = %s',
			$conv_table,
			'trash'
		) ) );

		if ( empty( $trashed_ids ) ) {
			return new WP_REST_Response( [ 'deleted' => 0 ] );
		}

		( new Conversation() )->hard_delete( $trashed_ids );

		return new WP_REST_Response( [ 'deleted' => count( $trashed_ids ) ] );
	}

	private function is_force( $request ): bool {
		$force = $request->get_param( 'force' );
		return ! empty( $force ) && 'false' !== $force && '0' !== $force;
	}

	public function merge_conversations( $request ) {
		$params    = $request->get_json_params();
		$target_id = absint( $params['target_id'] ?? 0 );
		$source_id = absint( $params['source_id'] ?? 0 );

		if ( ! $target_id || ! $source_id || $target_id === $source_id ) {
			return new WP_Error( 'bridle_invalid', __( 'Two different conversation IDs required.', 'bridle' ), [ 'status' => 400 ] );
		}

		$model  = new Conversation();
		$target = $model->get_by_id( $target_id );
		$source = $model->get_by_id( $source_id );

		if ( ! $target || ! $source ) {
			return new WP_Error( 'bridle_not_found', __( 'Conversation not found.', 'bridle' ), [ 'status' => 404 ] );
		}

		global $wpdb;
		$threads_table = $wpdb->prefix . 'bridle_threads';

		// Move all threads from source to target.
		$wpdb->update( $threads_table, [ 'conversation_id' => $target_id ], [ 'conversation_id' => $source_id ] );

		$model->update( $target_id, [ 'last_activity_at' => current_time( 'mysql', true ) ] );

		// Delete source conversation.
		$model->delete( $source_id );

		return new WP_REST_Response( [
			'merged'       => true,
			'conversation' => $model->get_with_threads( $target_id ),
		] );
	}

	public function get_collection_params(): array {
		return [
			'status'      => [
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			],
			'inbox_id'  => [
				'type'              => 'integer',
				'sanitize_callback' => 'absint',
			],
			'customer_id' => [
				'type'              => 'integer',
				'sanitize_callback' => 'absint',
			],
			'assigned_to' => [
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			],
			'search'      => [
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			],
			'page'        => [
				'type'    => 'integer',
				'default' => 1,
			],
			'per_page'    => [
				'type'    => 'integer',
				'default' => 20,
			],
		];
	}
}
