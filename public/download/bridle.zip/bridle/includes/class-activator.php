<?php

namespace Bridle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Activator {

	const DB_VERSION = '1.8.0';

	/** Every cron event the plugin schedules; cleared on deactivation and by the Danger Zone. */
	const CRON_HOOKS = [
		'bridle_worker_sync',
		'bridle_worker_register',
		'bridle_worker_sync_daily',
		'bridle_purge_orphan_attachments',
		'bridle_purge_trash',
		'bridle_agent_draft',
		'bridle_agent_send',
	];

	public static function activate(): void {
		self::create_tables();
		self::create_roles();
		// Read/unread starts here: mail that arrived before it counts as read
		// for everyone (Models\Read::is_unread()). Set once, never moved.
		add_option( 'bridle_unread_since', current_time( 'mysql', true ), '', false );
		update_option( 'bridle_db_version', self::DB_VERSION );
	}

	/**
	 * Bring the schema up to DB_VERSION when the stored version is older.
	 * A single get_option on every load once current.
	 */
	public static function maybe_upgrade(): void {
		$stored = get_option( 'bridle_db_version', '0.0.0' );
		if ( version_compare( $stored, self::DB_VERSION, '>=' ) ) {
			return;
		}
		self::activate();
	}

	/**
	 * The full list of custom tables the plugin owns (suffixes only).
	 *
	 * The authoritative inventory of plugin data, used by the Danger Zone
	 * teardown. Keep it in step with create_tables().
	 *
	 * @return string[]
	 */
	private static function table_suffixes(): array {
		return [
			'customers',
			'inboxes',
			'conversations',
			'threads',
			'drafts',
			'attachments',
			'ratings',
			'reads',
		];
	}

	/**
	 * DANGER ZONE — erase ALL plugin data, then recreate a clean install.
	 *
	 * User-triggered only (never on uninstall). Drops every bridle_* table,
	 * deletes every option the plugin owns (never Bridle KB's bridle_kb_*),
	 * strips the role and caps, clears cron, then re-runs the install routine
	 * so the plugin is left in a working, freshly-installed state (empty data)
	 * rather than broken.
	 */
	public static function delete_all_data(): void {
		global $wpdb;

		// 0. Stop the email worker delivering mail for every inbox. Best
		//    effort with a short timeout: an unreachable worker never blocks
		//    the erase (its mappings then simply go stale).
		foreach ( ( new Models\Inbox() )->list() as $inbox ) {
			Services\WorkerSyncService::deregister_inbox( $inbox, 3 );
		}

		// 1. Drop every custom table.
		foreach ( self::table_suffixes() as $suffix ) {
			$table = $wpdb->prefix . 'bridle_' . $suffix;
			$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $table ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- dropping our own tables.
		}

		// 2. Delete every plugin option (never Bridle KB's or Pro's, see owns_option()).
		self::delete_options();

		// 3. Remove the support-agent role and strip caps from admin + editor.
		remove_role( 'bridle_support_agent' );

		foreach ( [ 'administrator', 'editor' ] as $role_name ) {
			$role = get_role( $role_name );
			if ( ! $role ) {
				continue;
			}
			foreach ( [
				'bridle_manage_conversations',
				'bridle_reply_conversations',
				'bridle_manage_settings',
			] as $cap ) {
				$role->remove_cap( $cap );
			}
		}

		// The send permission is granted per user (Settings → Agent), not per role.
		foreach ( get_users( [ 'capability' => 'bridle_agent_send' ] ) as $user ) {
			$user->remove_cap( 'bridle_agent_send' );
		}

		// 4. Clear every plugin cron event.
		foreach ( self::CRON_HOOKS as $hook ) {
			wp_clear_scheduled_hook( $hook );
		}

		// 5. Recreate empty tables + roles so the plugin is left clean and
		//    working — a fresh-install state, not a broken one.
		self::activate();
	}

	/**
	 * Whether an option belongs to this plugin: `bridle_*`, except the
	 * `bridle_kb_*` options of the sibling plugin Bridle KB and the
	 * `bridle_pro_*` ones of Bridle Pro (its licence key among them), which
	 * can run on the same site and must survive Bridle's teardown.
	 */
	public static function owns_option( string $name ): bool {
		return str_starts_with( $name, 'bridle_' ) && ! str_starts_with( $name, 'bridle_kb_' ) && ! str_starts_with( $name, 'bridle_pro_' );
	}

	/**
	 * Delete every option this plugin owns. Names come from a prefix scan
	 * (some are per inbox, e.g. bridle_inbox_ai_{id}); delete_option() keeps
	 * the options cache in step, so the reinstall that follows really writes.
	 */
	private static function delete_options(): void {
		global $wpdb;

		// The underscore is escaped so LIKE treats it literally.
		$names = $wpdb->get_col( $wpdb->prepare( 'SELECT option_name FROM %i WHERE option_name LIKE %s', $wpdb->options, $wpdb->esc_like( 'bridle_' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		foreach ( (array) $names as $name ) {
			if ( self::owns_option( (string) $name ) ) {
				delete_option( $name );
			}
		}
	}

	private static function create_tables(): void {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();
		$p               = $wpdb->prefix . 'bridle_';

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		// dbDelta requires:
		// - Each field on its own line
		// - TWO spaces between PRIMARY KEY and (id)
		// - Column names must match exactly
		// - No IF NOT EXISTS

		dbDelta( "CREATE TABLE {$p}customers (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			email varchar(255) NOT NULL,
			name varchar(255) DEFAULT NULL,
			wp_user_id bigint(20) unsigned DEFAULT NULL,
			total_conversations int unsigned NOT NULL DEFAULT 0,
			box_override varchar(8) DEFAULT NULL,
			created_at datetime DEFAULT NULL,
			updated_at datetime DEFAULT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY email (email)
		) {$charset_collate};" );

		dbDelta( "CREATE TABLE {$p}inboxes (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			email_address varchar(255) NOT NULL,
			display_name varchar(255) NOT NULL,
			icon varchar(16) DEFAULT NULL,
			icon_url varchar(1024) DEFAULT NULL,
			color varchar(16) DEFAULT NULL,
			inbox_hash varchar(32) NOT NULL,
			forwarding_address varchar(255) DEFAULT NULL,
			webhook_secret varchar(255) DEFAULT NULL,
			registered_webhook_url varchar(255) DEFAULT NULL,
			is_active tinyint(1) NOT NULL DEFAULT 1,
			auto_reply_enabled tinyint(1) NOT NULL DEFAULT 1,
			auto_reply_subject varchar(255) DEFAULT NULL,
			auto_reply_body longtext DEFAULT NULL,
			signature longtext DEFAULT NULL,
			satisfaction_enabled tinyint(1) NOT NULL DEFAULT 0,
			satisfaction_text varchar(255) DEFAULT NULL,
			restricted_access tinyint(1) NOT NULL DEFAULT 0,
			last_received_at datetime DEFAULT NULL,
			created_at datetime DEFAULT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY inbox_hash (inbox_hash)
		) {$charset_collate};" );

		dbDelta( "CREATE TABLE {$p}conversations (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			thread_id varchar(16) NOT NULL,
			inbox_id bigint(20) unsigned DEFAULT NULL,
			subject text NOT NULL,
			status varchar(20) NOT NULL DEFAULT 'active',
			urgency varchar(20) NOT NULL DEFAULT 'normal',
			channel varchar(20) NOT NULL DEFAULT 'email',
			source_url varchar(500) DEFAULT NULL,
			customer_id bigint(20) unsigned NOT NULL,
			assigned_to bigint(20) unsigned DEFAULT NULL,
			ai_classification longtext DEFAULT NULL,
			last_activity_at datetime DEFAULT NULL,
			first_responded_at datetime DEFAULT NULL,
			closed_at datetime DEFAULT NULL,
			trashed_at datetime DEFAULT NULL,
			automation_handled tinyint(1) NOT NULL DEFAULT 0,
			is_automated tinyint(1) NOT NULL DEFAULT 0,
			created_at datetime DEFAULT NULL,
			updated_at datetime DEFAULT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY thread_id (thread_id),
			KEY status (status),
			KEY status_automated (status, is_automated),
			KEY inbox_id (inbox_id),
			KEY customer_id (customer_id),
			KEY assigned_to (assigned_to),
			KEY closed_at (closed_at),
			KEY first_responded_at (first_responded_at),
			KEY status_trashed (status, trashed_at)
		) {$charset_collate};" );

		dbDelta( "CREATE TABLE {$p}threads (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			conversation_id bigint(20) unsigned NOT NULL,
			author_type varchar(20) NOT NULL DEFAULT 'customer',
			author_id bigint(20) unsigned DEFAULT NULL,
			thread_type varchar(20) NOT NULL DEFAULT 'reply',
			content longtext NOT NULL,
			content_html longtext DEFAULT NULL,
			ai_generated tinyint(1) NOT NULL DEFAULT 0,
			ai_sources longtext DEFAULT NULL,
			email_message_id varchar(255) DEFAULT NULL,
			is_private tinyint(1) NOT NULL DEFAULT 0,
			created_at datetime DEFAULT NULL,
			PRIMARY KEY  (id),
			KEY conversation_id (conversation_id),
			KEY email_message_id (email_message_id)
		) {$charset_collate};" );

		dbDelta( "CREATE TABLE {$p}drafts (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			conversation_id bigint(20) unsigned NOT NULL,
			user_id bigint(20) unsigned NOT NULL,
			content longtext NOT NULL,
			thread_type varchar(20) NOT NULL DEFAULT 'reply',
			meta longtext DEFAULT NULL,
			updated_at datetime DEFAULT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY conv_user (conversation_id, user_id)
		) {$charset_collate};" );

		dbDelta( "CREATE TABLE {$p}attachments (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			thread_id bigint(20) unsigned NOT NULL,
			wp_attachment_id bigint(20) unsigned DEFAULT NULL,
			filename varchar(255) NOT NULL,
			mime_type varchar(100) NOT NULL,
			size_bytes int unsigned NOT NULL DEFAULT 0,
			is_inline tinyint(1) NOT NULL DEFAULT 0,
			content_id varchar(255) DEFAULT NULL,
			created_at datetime DEFAULT NULL,
			PRIMARY KEY  (id),
			KEY thread_id (thread_id),
			KEY content_id (content_id)
		) {$charset_collate};" );

		// Customer satisfaction ratings, one per conversation (latest wins
		// on conflict). Rating 1–4 corresponds to Great / Good / Okay / Bad.
		dbDelta( "CREATE TABLE {$p}ratings (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			conversation_id bigint(20) unsigned NOT NULL,
			rating tinyint unsigned NOT NULL,
			comment text DEFAULT NULL,
			created_at datetime DEFAULT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY conversation_id (conversation_id),
			KEY rating (rating),
			KEY created_at (created_at)
		) {$charset_collate};" );

		// When each teammate last opened each conversation (Models\Read).
		dbDelta(
			"CREATE TABLE {$p}reads (
				conversation_id bigint(20) unsigned NOT NULL,
				user_id bigint(20) unsigned NOT NULL,
				read_at datetime NOT NULL,
				PRIMARY KEY  (conversation_id,user_id),
				KEY user_id (user_id)
			) {$charset_collate};"
		);
	}

	private static function create_roles(): void {
		$admin = get_role( 'administrator' );

		if ( $admin ) {
			foreach ( [ 'bridle_manage_conversations', 'bridle_reply_conversations', 'bridle_manage_settings' ] as $cap ) {
				$admin->add_cap( $cap );
			}
		}

		remove_role( 'bridle_support_agent' );
		// Untranslated, like WordPress's own roles: an upgrade runs this at
		// plugins_loaded, before translations may load (#160), and a stored
		// translation would keep the language the site had that day.
		add_role( 'bridle_support_agent', 'Support Agent', [
			'read'                    => true,
			'bridle_manage_conversations' => true,
			'bridle_reply_conversations'  => true,
			'bridle_manage_settings'      => false,
		] );
	}
}
