<?php

namespace Bridle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Plugin {

	private static ?Plugin $instance = null;

	public static function get_instance(): Plugin {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function init(): void {
		// Install or upgrade the schema. A current bridle_db_version means
		// activate() already ran on this database, so skip the SHOW TABLES
		// probe that would otherwise run on every request, front end
		// included. Otherwise (never activated here, or DB_VERSION was
		// bumped) check for the real table rather than trusting the option.
		// Tables dropped by hand behind a current option come back on the
		// next activation.
		if ( Activator::DB_VERSION !== get_option( 'bridle_db_version' ) ) {
			global $wpdb;
			$table        = $wpdb->prefix . 'bridle_conversations';
			$table_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
			if ( ! $table_exists ) {
				Activator::activate();
			} else {
				Activator::maybe_upgrade();
			}
		}

		// Admin.
		if ( is_admin() ) {
			( new Admin\AdminMenu() )->register();
			Admin\AdminPage::register();
		}

		// REST API.
		add_action( 'rest_api_init', [ $this, 'register_rest_routes' ] );

		// Email service hooks.
		Services\EmailService::init_hooks();

		// The agent drafts replies in the background (per-inbox agent mode).
		Services\AgentQueue::init_hooks();
		Services\AutoSend::init_hooks();
		// Forget the kept provider check when a connector changes.
		Services\AiService::init_hooks();

		// Bridle Chat's bubble on the front end, while Chat is on (#114).
		Services\ChatWidget::init_hooks();
		Services\ChatFollowUp::init_hooks();
		// Kept chat answers start fresh when the knowledge changes (#158).
		Services\ChatAnswers::init_hooks();
		Services\SiteOverview::init_hooks();
		// Bridle AI's edge answers the chat (#172): set it up when Bridle AI comes on.
		add_action( 'bridle_ai_on', [ Services\BridleAi::class, 'enable_edge' ] );
		add_action( 'admin_init', [ Services\BridleAi::class, 'maybe_enable_edge' ] );

		// CSAT email + public rating page (fires on bridle_conversation_closed).
		Services\CsatService::init_hooks();

		// Admin-bar / menu count bubbles, and the cache that keeps them cheap.
		Services\Counts::init_hooks();

		// Keep the email worker's registrations pointed at this site: re-sync
		// when siteurl/home change, plus a daily safety net that also heals
		// inboxes whose initial registration failed.
		Services\WorkerSyncService::init_hooks();
		if ( ! wp_next_scheduled( 'bridle_worker_sync_daily' ) ) {
			wp_schedule_event( time() + ( 3 * HOUR_IN_SECONDS ), 'daily', 'bridle_worker_sync_daily' );
		}
		add_action( 'bridle_worker_sync_daily', [ Services\WorkerSyncService::class, 'run_register' ] );

		// Daily sweep: delete orphan attachments uploaded by the composer
		// but never attached to a sent message (older than 24h).
		if ( ! wp_next_scheduled( 'bridle_purge_orphan_attachments' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'bridle_purge_orphan_attachments' );
		}
		add_action( 'bridle_purge_orphan_attachments', [ Services\AttachmentService::class, 'purge_stale_orphans' ] );

		// Daily sweep: Trash empties itself after TrashPurge::days() (30).
		if ( ! wp_next_scheduled( 'bridle_purge_trash' ) ) {
			wp_schedule_event( time() + ( 2 * HOUR_IN_SECONDS ), 'daily', 'bridle_purge_trash' );
		}
		add_action( 'bridle_purge_trash', [ Services\TrashPurge::class, 'run' ] );

		// A deleted teammate's read marks go with them.
		add_action( 'deleted_user', [ self::class, 'forget_reads' ] );

		// GDPR / CCPA privacy tools (data export + erasure).
		Privacy::init();

		// Cross-plugin contact federation (read-only) — lets sibling PlugPress
		// products surface "this person is also a support contact" and vice versa.
		ContactBridge::init();

		// Integration registry — extensible customer profile cards.
		// Third-party plugins call IntegrationRegistry::register() during plugins_loaded.
		// Built-in integrations are loaded here when their dependency is active.
		IntegrationRegistry::init();
		if ( class_exists( 'WooCommerce' ) ) {
			Integrations\WooCommerce::register();
		}

		// Abilities API (WP 7.0+): the inbox for external AI agents.
		if ( function_exists( 'wp_register_ability' ) ) {
			Abilities\AbilitiesRegistrar::init();
		}
	}

	public function register_rest_routes(): void {
		( new RestApi\ConversationsController() )->register_routes();
		( new RestApi\ThreadsController() )->register_routes();
		( new RestApi\CustomersController() )->register_routes();
		( new RestApi\InboundEmailController() )->register_routes();
		( new RestApi\AiController() )->register_routes();
		( new RestApi\SettingsController() )->register_routes();
		( new RestApi\InboxesController() )->register_routes();
		( new RestApi\AttachmentsController() )->register_routes();
		( new RestApi\RatingsController() )->register_routes();
		( new RestApi\SavedRepliesController() )->register_routes();
		( new RestApi\HomeController() )->register_routes();
		( new RestApi\ChatController() )->register_routes();
	}

	public static function get_version(): string {
		return BRIDLE_VERSION;
	}

	/** `deleted_user`: drop the user's read marks. */
	public static function forget_reads( $user_id ): void {
		( new Models\Read() )->delete_for_user( (int) $user_id );
	}

}
