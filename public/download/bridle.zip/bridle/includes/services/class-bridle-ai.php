<?php
/**
 * Bridle AI: answers without the site's own AI key, from PlugPress's service
 * (owner decisions, 2026-11-02). Opt-in; the site's own key always wins.
 *
 * @package Bridle
 */

namespace Bridle\Services;

use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * The client for the bridle-ai worker: sign up (the site proves itself by
 * answering a challenge with an HMAC keyed by a nonce only it holds), ask for an answer, give back one that failed Bridle's
 * checks, read the balance and start a checkout for a pack.
 */
class BridleAi {

	/** { key, email, on, balance, balance_at }. The key never leaves the server. */
	public const OPTION = 'bridle_ai';

	private const NONCE = 'bridle_ai_signup_nonce';

	/** Packs and their prices, as the worker and Polar sell them. */
	public const PACKS = [
		'1k'  => [
			'answers' => 1000,
			'price'   => '$10',
		],
		'5k'  => [
			'answers' => 5000,
			'price'   => '$45',
		],
		'25k' => [
			'answers' => 25000,
			'price'   => '$200',
		],
	];

	/**
	 * Bytes of system instruction + prompt one answer may carry. The service
	 * takes 80,000 UTF-16 units; a byte is never fewer, so this always fits.
	 */
	public const MAX_PROMPT_BYTES = 78000;

	/** Seconds an answer may take; the service stops the model 2 s before. */
	public const TIMEOUT = 60;

	/** The service's address; BRIDLE_AI_URL in wp-config.php points at a dev worker. */
	public static function url(): string {
		return untrailingslashit( defined( 'BRIDLE_AI_URL' ) ? (string) BRIDLE_AI_URL : 'https://ai.bridle.to' );
	}

	private static function stored(): array {
		$stored = get_option( self::OPTION, [] );
		return is_array( $stored ) ? $stored : [];
	}

	/** Signed up and switched on. */
	public static function active(): bool {
		$stored = self::stored();
		return ! empty( $stored['on'] ) && '' !== (string) ( $stored['key'] ?? '' );
	}

	/** What Settings shows. */
	public static function status(): array {
		$stored = self::stored();
		return [
			'active'  => self::active(),
			'email'   => (string) ( $stored['email'] ?? '' ),
			'balance' => self::active() ? self::balance() : null,
			'packs'   => self::PACKS,
		];
	}

	/**
	 * Sign up (or sign in again) and switch Bridle AI on.
	 *
	 * @return array|WP_Error status()
	 */
	public static function sign_up( string $email ) {
		$email = sanitize_email( $email );
		if ( ! is_email( $email ) ) {
			return new WP_Error( 'bridle_ai_email', __( 'Enter an email for receipts.', 'bridle' ), [ 'status' => 400 ] );
		}

		$nonce = wp_generate_password( 32, false );
		set_transient( self::NONCE, $nonce, 5 * MINUTE_IN_SECONDS );
		$response = self::post(
			'/v1/sites',
			[
				'site_url'   => home_url(),
				'email'      => $email,
				'verify_url' => rest_url( BRIDLE_REST_NAMESPACE . '/ai/bridle/verify' ),
				'nonce'      => $nonce,
			],
			''
		);
		delete_transient( self::NONCE );
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		update_option(
			self::OPTION,
			[
				'key'        => (string) ( $response['key'] ?? '' ),
				'email'      => $email,
				'on'         => true,
				'balance'    => self::balance_of( $response ),
				'balance_at' => time(),
			],
			false
		);
		self::forget_ai_cache();
		self::switched_on();
		return self::status();
	}

	/** Switch off; the key and balance stay, so switching on again needs no sign-up. */
	public static function turn_off(): array {
		$stored       = self::stored();
		$stored['on'] = false;
		update_option( self::OPTION, $stored, false );
		self::forget_ai_cache();
		return self::status();
	}

	/** Switch on again with the stored key, or sign up. */
	public static function turn_on( string $email ) {
		$stored = self::stored();
		if ( '' !== (string) ( $stored['key'] ?? '' ) && ( '' === $email || ( $stored['email'] ?? '' ) === $email ) ) {
			$stored['on'] = true;
			update_option( self::OPTION, $stored, false );
			self::forget_ai_cache();
			self::switched_on();
			return self::status();
		}
		return self::sign_up( $email );
	}

	/**
	 * Add the Bridle AI answers that come with a Bridle Pro licence to this
	 * site (1,000, 3,000 or 10,000), once per key. The service checks the key
	 * with Polar; the site's own Bridle AI key never leaves this class.
	 *
	 * @return array{answers: int, balance: array}|WP_Error `bridle_ai_already_claimed`
	 *         when the key's answers were added before (here or elsewhere).
	 */
	public static function claim( string $licence_key ) {
		if ( ! self::active() ) {
			return new WP_Error( 'bridle_ai_off', __( 'Turn on Bridle AI first.', 'bridle' ), [ 'status' => 400 ] );
		}
		$response = self::request( 'POST', '/v1/claim', [ 'licence_key' => strtoupper( trim( $licence_key ) ) ] );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		self::remember_balance( $response );
		return [
			'answers' => (int) ( $response['answers'] ?? 0 ),
			'balance' => self::balance_of( $response ),
		];
	}

	/** Bridle AI just came on (signed up, or switched on again). */
	private static function switched_on(): void {
		/**
		 * Fires when Bridle AI is switched on, after sign-up or with the stored
		 * key. Bridle Pro adds its licence's answers here.
		 */
		do_action( 'bridle_ai_on' );
	}

	/**
	 * Bridle AI's edge for this site (#172): the address the chat bubble
	 * sends messages to, and the secret its requests here are signed with.
	 *
	 * @return array{id: string, secret: string, url: string}|array{} Empty until set up.
	 */
	public static function edge(): array {
		$edge = (array) ( self::stored()['edge'] ?? [] );
		return '' !== (string) ( $edge['url'] ?? '' ) && '' !== (string) ( $edge['secret'] ?? '' ) ? $edge : [];
	}

	/**
	 * Ask Bridle AI for this site's edge (new, or rotated). `bridle_ai_on`
	 * runs it, and admin_init once a day while it is missing.
	 *
	 * @return bool Whether the site has an edge now.
	 */
	public static function enable_edge(): bool {
		if ( ! self::active() ) {
			return false;
		}
		$response = self::request( 'POST', '/v1/edge', [ 'endpoint' => rest_url( BRIDLE_REST_NAMESPACE . '/chat/edge' ) ] );
		if ( is_wp_error( $response ) || '' === (string) ( $response['url'] ?? '' ) || '' === (string) ( $response['secret'] ?? '' ) ) {
			return false;
		}
		$stored         = self::stored();
		$stored['edge'] = [
			'id'     => sanitize_text_field( (string) ( $response['edge_id'] ?? '' ) ),
			'secret' => sanitize_text_field( (string) $response['secret'] ),
			'url'    => esc_url_raw( (string) $response['url'] ),
		];
		update_option( self::OPTION, $stored, false );
		return true;
	}

	/** admin_init: a site signed up before the edge gets one, tried once a day. */
	public static function maybe_enable_edge(): void {
		if ( ! self::active() || self::edge() || get_transient( 'bridle_ai_edge_tried' ) || ! current_user_can( 'bridle_manage_settings' ) ) {
			return;
		}
		set_transient( 'bridle_ai_edge_tried', 1, DAY_IN_SECONDS );
		self::enable_edge();
	}

	/** The nonce of a pending sign-up, or ''. It never leaves the site. */
	public static function pending_nonce(): string {
		return (string) get_transient( self::NONCE );
	}

	/**
	 * The answer to the service's challenge while a sign-up waits: an HMAC
	 * of the challenge keyed with the nonce, so the service can tell the site
	 * itself is signing up and nobody can read the nonce off the site.
	 *
	 * @return string Lowercase hex, or '' with no sign-up waiting or a bad challenge.
	 */
	public static function proof( string $challenge ): string {
		return self::proof_for( self::pending_nonce(), $challenge );
	}

	/** proof(), pure. */
	public static function proof_for( string $nonce, string $challenge ): string {
		if ( '' === $nonce || ! preg_match( '/^[0-9a-f]{32,128}$/i', $challenge ) ) {
			return '';
		}
		return hash_hmac( 'sha256', $challenge, $nonce );
	}

	/**
	 * Free answers left, the free total and paid credits; cached ten minutes.
	 *
	 * @return array{month: string, free_left: int, free_total: int, credits: int}|null
	 */
	public static function balance( bool $refresh = false ): ?array {
		$stored = self::stored();
		if ( '' === (string) ( $stored['key'] ?? '' ) ) {
			return null;
		}
		if ( ! $refresh && ! empty( $stored['balance'] ) && time() - (int) ( $stored['balance_at'] ?? 0 ) < 10 * MINUTE_IN_SECONDS ) {
			return $stored['balance'];
		}
		$response = self::request( 'GET', '/v1/balance' );
		if ( is_wp_error( $response ) ) {
			return $stored['balance'] ?? null;
		}
		self::remember_balance( $response );
		return self::balance_of( $response );
	}

	/** Whether there is anything left to answer with (as last seen). */
	public static function has_answers(): bool {
		$balance = self::balance();
		return null === $balance || (int) $balance['free_left'] + (int) $balance['credits'] > 0;
	}

	/**
	 * Ask for an answer.
	 *
	 * @param array|null $schema  JSON schema for the answer.
	 * @param int        $timeout Seconds to wait. The service hears it as
	 *                            `deadline_ms` and gives up (and gives the
	 *                            answer back) before we do.
	 * @return array{id: string, text: string}|WP_Error
	 */
	public static function generate( string $system, string $prompt, ?array $schema = null, int $timeout = self::TIMEOUT ) {
		$timeout  = max( 5, $timeout );
		$response = self::request(
			'POST',
			'/v1/answer',
			[
				'system'      => $system,
				'prompt'      => $prompt,
				'schema'      => $schema,
				'deadline_ms' => $timeout * 1000,
			],
			$timeout
		);
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		self::remember_balance( $response );
		return [
			'id'   => (string) ( $response['id'] ?? '' ),
			'text' => (string) ( $response['text'] ?? '' ),
		];
	}

	/** Give back an answer that failed Bridle's checks ("only checked answers count"). */
	public static function refund( string $answer_id ): void {
		if ( '' === $answer_id || ! preg_match( '/^[0-9a-f-]{36}$/', $answer_id ) ) {
			return;
		}
		self::request( 'POST', '/v1/answers/' . $answer_id . '/refund', [], 5, false );
	}

	/**
	 * A Polar checkout for a pack, for this site.
	 *
	 * @return string|WP_Error The checkout URL.
	 */
	public static function checkout( string $pack ) {
		if ( ! isset( self::PACKS[ $pack ] ) ) {
			return new WP_Error( 'bridle_ai_pack', __( 'Unknown pack.', 'bridle' ), [ 'status' => 400 ] );
		}
		$response = self::request( 'POST', '/v1/checkout', [ 'pack' => $pack ] );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$url = esc_url_raw( (string) ( $response['url'] ?? '' ) );
		return '' !== $url ? $url : new WP_Error( 'bridle_ai_checkout', __( 'The checkout couldn’t start.', 'bridle' ), [ 'status' => 502 ] );
	}

	private static function balance_of( array $data ): array {
		return [
			'month'      => (string) ( $data['month'] ?? '' ),
			'free_left'  => (int) ( $data['free_left'] ?? 0 ),
			'free_total' => (int) ( $data['free_total'] ?? 0 ),
			'credits'    => (int) ( $data['credits'] ?? 0 ),
		];
	}

	private static function remember_balance( array $data ): void {
		if ( ! isset( $data['free_left'] ) ) {
			return;
		}
		$stored               = self::stored();
		$stored['balance']    = self::balance_of( $data );
		$stored['balance_at'] = time();
		update_option( self::OPTION, $stored, false );
	}

	/** Drop a key the service no longer knows; the email stays for signing up again. */
	private static function forget_key(): void {
		$stored = self::stored();
		if ( '' === (string) ( $stored['key'] ?? '' ) ) {
			return;
		}
		$stored['key'] = '';
		$stored['on']  = false;
		unset( $stored['balance'], $stored['balance_at'], $stored['edge'] );
		update_option( self::OPTION, $stored, false );
		self::forget_ai_cache();
	}

	/** can_use_ai() caches its answer for the request; a switch changes it. */
	private static function forget_ai_cache(): void {
		AiService::reset();
	}

	private static function post( string $path, array $body, string $key ) {
		return self::request( 'POST', $path, $body, 20, true, $key );
	}

	/**
	 * One call to the service, with the site key unless another is given.
	 *
	 * @return array|WP_Error The decoded JSON body.
	 */
	private static function request( string $method, string $path, array $body = [], int $timeout = 20, bool $blocking = true, ?string $key = null ) {
		$key_given = $key;
		$key       = $key ?? (string) ( self::stored()['key'] ?? '' );
		$args      = [
			'method'   => $method,
			'timeout'  => $timeout,
			'blocking' => $blocking,
			'headers'  => array_filter(
				[
					'Content-Type'  => 'application/json',
					'Authorization' => '' !== $key ? 'Bearer ' . $key : '',
				]
			),
		];
		if ( 'GET' !== $method ) {
			$args['body'] = wp_json_encode( $body );
		}
		$response = wp_remote_request( self::url() . $path, $args );
		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'bridle_ai_unreachable', __( 'Bridle AI can’t be reached right now.', 'bridle' ), [ 'status' => 502 ] );
		}
		if ( ! $blocking ) {
			return [];
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		$data = is_array( $data ) ? $data : [];
		if ( $code >= 200 && $code < 300 ) {
			return $data;
		}
		if ( 402 === $code ) {
			self::remember_balance( $data );
			return new WP_Error( 'bridle_ai_empty', __( 'No Bridle AI answers left this month.', 'bridle' ), [ 'status' => 402 ] );
		}
		if ( 401 === $code && null === $key_given ) {
			// The key was replaced or revoked: forget it, so switching on
			// again signs up afresh instead of reusing a dead key.
			self::forget_key();
			return new WP_Error( 'bridle_ai_signed_out', __( 'Bridle AI signed this site out. Switch it on again under Settings → Replies.', 'bridle' ), [ 'status' => 401 ] );
		}
		$known = [
			'busy'            => __( 'Bridle AI is busy. Try again soon.', 'bridle' ),
			'prompt_too_long' => __( 'This conversation is too long for Bridle AI.', 'bridle' ),
		];
		$which = (string) ( $data['code'] ?? '' );
		if ( isset( $known[ $which ] ) ) {
			return new WP_Error( 'bridle_ai_' . $which, $known[ $which ], [ 'status' => $code ] );
		}
		return new WP_Error(
			'bridle_ai_' . sanitize_key( (string) ( $data['code'] ?? 'failed' ) ),
			sanitize_text_field( (string) ( $data['message'] ?? __( 'Bridle AI didn’t answer.', 'bridle' ) ) ),
			[ 'status' => $code ? $code : 502 ]
		);
	}
}
