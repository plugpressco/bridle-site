<?php

namespace Bridle\Services;

use Bridle\Models\Conversation;
use Bridle\Models\Customer;
use Bridle\Models\Draft;
use Bridle\Models\Thread;
use WP_Error;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The agent's reply drafts.
 *
 * Loads a conversation and the business's knowledge (Agent instructions,
 * Snippets, and what KnowledgeSearch finds: docs, pages, posts, products,
 * past answers), asks the model through the WP 7.0 AI Client, so on whatever
 * provider the site owner connected with their own key, checks the reply
 * against the knowledge it cites (AgentPrompt::verify) and stores it as the
 * conversation's agent draft: the drafts row with user_id 0, its details in
 * `meta`. A teammate sends, edits or discards it, or AutoSend sends it;
 * nothing here sends email.
 */
class AgentService {

	/** Drafts row owner for the agent. Teammates are WP users, so never 0. */
	const USER_ID = 0;

	/** Seconds a chat answer may take before the visitor is handed to a person (#151). */
	const CHAT_TIMEOUT = 25;

	/**
	 * Model preference among what the site's own AI connector offers; the
	 * first one it lists wins. IDs must match the provider's exactly, or the
	 * AI Client falls back to whichever model it found first.
	 */
	const MODELS = [ 'claude-sonnet-5-5', 'claude-sonnet-5', 'claude-haiku-4-5', 'gpt-4o', 'gemini-2.0-flash' ];

	/** HTML a draft may contain; matches what the prompt allows. */
	const REPLY_TAGS = [
		'p'      => [],
		'br'     => [],
		'ul'     => [],
		'ol'     => [],
		'li'     => [],
		'a'      => [ 'href' => true ],
		'strong' => [],
		'em'     => [],
		'code'   => [],
	];

	/**
	 * Write and store a reply draft for the conversation.
	 *
	 * @return array|WP_Error The stored draft: [ 'content' => html, 'meta' => [...] ].
	 */
	public static function draft( int $conversation_id ) {
		if ( ! AiService::can_use_ai() ) {
			return new WP_Error( 'bridle_ai_unavailable', __( 'No AI provider is configured in WordPress.', 'bridle' ) );
		}

		$conversation = ( new Conversation() )->get_by_id( $conversation_id );
		if ( ! $conversation ) {
			return new WP_Error( 'bridle_not_found', __( 'Conversation not found.', 'bridle' ) );
		}

		// The newest message the model will see, read before the (slow) call,
		// so one that lands meanwhile shows the draft as stale.
		$based_on = self::newest_public_thread_id( $conversation_id );
		$composed = self::compose( $conversation );
		if ( is_wp_error( $composed ) ) {
			return $composed;
		}
		[ 'draft' => $draft, 'knowledge' => $knowledge, 'found' => $found, 'problems' => $problems ] = $composed;

		$meta = self::store_draft(
			$conversation_id,
			$draft['reply_html'],
			[
				'source'             => 'agent',
				'based_on_thread_id' => $based_on,
				'confidence'         => $draft['confidence'],
				'grounded_in'        => AgentPrompt::cite( $draft['grounded_in'], $knowledge ),
				'flags'              => $draft['flags'],
				'needs_human_reason' => $draft['needs_human_reason'],
				'summary'            => $draft['summary'],
				'verified'           => empty( $problems ),
				'problems'           => $problems,
				'retrieved'          => array_column( $found['items'], 'id' ),
			]
		);
		self::record( 'drafted' );

		/**
		 * Fires after the agent answered a conversation: an email draft was
		 * stored, or (from ChatService) a chat answer was decided on.
		 *
		 * @param int   $conversation_id The conversation.
		 * @param array $draft           AgentPrompt::parse(): reply_html, confidence, grounded_in,
		 *                               flags, needs_human_reason, summary.
		 * @param array $context         kind (email | chat), terms (what knowledge was searched for),
		 *                               verified (every fact checked out), shown (chat: the visitor
		 *                               saw it; email: false), reason (chat: ChatPolicy::decide()).
		 */
		do_action(
			'bridle_agent_answered',
			$conversation_id,
			$draft,
			[
				'kind'     => 'email',
				'terms'    => (array) ( $found['terms'] ?? [] ),
				'verified' => empty( $problems ),
				'shown'    => false,
				'reason'   => '',
			]
		);

		return [
			'content' => $draft['reply_html'],
			'meta'    => $meta,
		];
	}

	/**
	 * Ask the model for an answer to a conversation and check it: the
	 * knowledge it found, the prompt, the call, parse, sanitize and verify.
	 * Email drafts and Bridle Chat (#114) share it; only the instruction differs.
	 *
	 * A chat answer goes straight to an anonymous visitor (#150): it never
	 * sees internal notes, contact cards, the email or other customers' past
	 * answers. An email draft on a chat sees contact cards only once the
	 * visitor confirmed the email they left (ChatService::email_confirmed()).
	 *
	 * @param object $conversation Conversation row.
	 * @param string $kind         'email' (a draft a teammate reviews) or 'chat'.
	 * @return array{draft: array, knowledge: array, found: array, problems: string[]}|WP_Error
	 */
	public static function compose( object $conversation, string $kind = 'email' ) {
		/**
		 * Fires before the agent reads knowledge for a conversation and asks
		 * the model. Bridle Pro uses it to know whose answer it is adding
		 * knowledge to; `bridle_agent_composed` always follows.
		 *
		 * @param object $conversation The conversation.
		 * @param string $kind         'email' (a draft a teammate reviews) or 'chat' (shown to a visitor).
		 */
		do_action( 'bridle_agent_composing', $conversation, $kind );
		try {
			return self::compose_answer( $conversation, $kind );
		} finally {
			/**
			 * Fires after compose() is done, whether it answered or failed.
			 *
			 * @param object $conversation The conversation.
			 * @param string $kind         'email' or 'chat'.
			 */
			do_action( 'bridle_agent_composed', $conversation, $kind );
		}
	}

	/** compose() without its hooks: prepare, ask the model, check. */
	private static function compose_answer( object $conversation, string $kind ) {
		$prepared = self::prepare_answer( $conversation, $kind );
		if ( is_wp_error( $prepared ) ) {
			return $prepared;
		}
		// A visitor is waiting in the bubble: give up in time to hand off (#151).
		$answer = self::ask( $prepared['system'], $prepared['prompt'], AgentPrompt::schema(), 'chat' === $kind ? 'chat' : 'email', 'chat' === $kind ? self::CHAT_TIMEOUT : 0 );
		if ( is_wp_error( $answer ) ) {
			return $answer;
		}
		$checked = self::check( $prepared, (string) $answer['raw'] );
		// Only checked answers count against Bridle AI.
		if ( $checked['refund'] ) {
			BridleAi::refund( (string) $answer['id'] );
		}
		return $checked['result'];
	}

	/**
	 * Everything up to the model call, with compose()'s hooks: for a chat
	 * answered on Bridle AI's edge (#172), which asks the model itself.
	 *
	 * @param object $conversation The conversation.
	 * @param string $kind         'chat' or 'email'.
	 * @return array|WP_Error prepare_answer()'s result.
	 */
	public static function prepare( object $conversation, string $kind ) {
		/** This action is documented in includes/services/class-agent-service.php */
		do_action( 'bridle_agent_composing', $conversation, $kind );
		try {
			return self::prepare_answer( $conversation, $kind );
		} finally {
			/** This action is documented in includes/services/class-agent-service.php */
			do_action( 'bridle_agent_composed', $conversation, $kind );
		}
	}

	/**
	 * The model's answer, parsed and checked against exactly the passages
	 * it saw.
	 *
	 * @param array  $prepared prepare_answer()'s result.
	 * @param string $raw      What the model said.
	 * @return array{result: array|WP_Error, refund: bool} result is compose()'s; refund:
	 *         Bridle AI should give the answer back (it was unusable or didn't check out).
	 */
	public static function check( array $prepared, string $raw ): array {
		$draft = AgentPrompt::parse( $raw );
		if ( ! $draft ) {
			return [
				'result' => new WP_Error( 'bridle_agent_bad_response', __( 'The model did not return a usable draft.', 'bridle' ) ),
				'refund' => true,
			];
		}
		$draft['reply_html'] = wp_kses( $draft['reply_html'], self::REPLY_TAGS );
		$problems            = AgentPrompt::verify( $draft, $prepared['knowledge'] );
		return [
			'result' => [
				'draft'     => $draft,
				'knowledge' => $prepared['knowledge'],
				'found'     => $prepared['found'],
				'problems'  => $problems,
			],
			'refund' => (bool) $problems,
		];
	}

	/**
	 * The prompt for a conversation: knowledge, instruction and messages,
	 * fitted to Bridle AI's size.
	 *
	 * @return array{system: string, prompt: string, knowledge: array, found: array}|WP_Error
	 */
	private static function prepare_answer( object $conversation, string $kind ) {
		// Every AI call a chat causes counts against one hourly budget (#151).
		if ( 'chat' === (string) ( $conversation->channel ?? '' ) ) {
			$spend = ChatService::spend_ai( $conversation, $kind );
			if ( is_wp_error( $spend ) ) {
				return $spend;
			}
		}
		$chat    = 'chat' === $kind;
		$threads = ( new Thread() )->get_by_conversation( (int) $conversation->id );
		if ( $chat ) {
			$threads = array_values( array_filter( $threads, static fn( $t ) => empty( $t->is_private ) ) );
		}
		$customer = ( new Customer() )->get_by_id( (int) $conversation->customer_id );
		$email    = $chat ? '' : (string) ( $customer->email ?? '' );
		$cards    = '' !== $email && ChatService::email_confirmed( $conversation );

		$found     = KnowledgeSearch::for_conversation( $conversation, $threads, $chat ? KnowledgeSearch::PUBLIC_SOURCES : KnowledgeSearch::SOURCES );
		$knowledge = AgentPrompt::knowledge( (string) Settings::get( 'agent_instructions', '' ), AgentPrompt::rank_snippets( self::snippets(), (array) ( $found['terms'] ?? [] ) ), $found['items'] );
		$business  = (string) Settings::get( 'business_name' );
		if ( '' === $business ) {
			$business = (string) get_bloginfo( 'name' );
		}
		/**
		 * Filters whose answer it is: the business the agent speaks for in
		 * this conversation's prompt (#162). Bridle Pro names another site's
		 * own business for a chat that started there.
		 *
		 * @param string $business     Settings → Emails' business name, else the site title.
		 * @param object $conversation The conversation.
		 * @param string $kind         'email' or 'chat'.
		 */
		$business = trim( (string) apply_filters( 'bridle_agent_business', $business, $conversation, $kind ) );

		$instruction = 'chat' === $kind ? AgentPrompt::chat_instruction( $business ) : AgentPrompt::system_instruction( $business );

		// Where a chat's visitor is (#169): its knowledge entry when there is one.
		$here = '';
		if ( 'chat' === (string) ( $conversation->channel ?? '' ) ) {
			$page = is_array( $found['page'] ?? null ) ? $found['page'] : null;
			$here = $page
				? trim( sprintf( '%s (%s) [%s]', $page['title'], $page['url'], $page['id'] ) )
				: (string) ( $conversation->source_url ?? '' );
		}

		// Bridle AI takes a prompt of a set size: trim the oldest messages and
		// the weakest knowledge first. verify() then checks against what's left.
		[ 'knowledge' => $knowledge, 'prompt' => $user_prompt ] = AgentPrompt::fit(
			$instruction,
			$knowledge,
			[
				'name'  => (string) ( $customer->name ?? '' ),
				'email' => $email,
				// Shared PlugPress filter (see ContactBridge), hence no bridle_ prefix.
				// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
				'cards' => $cards ? (array) apply_filters( 'plugpress_contact_cards', [], $email, 'bridle' ) : [],
				'page'  => $here,
			],
			array_map( [ self::class, 'message' ], $threads ),
			'bridle' === AiService::source() ? BridleAi::MAX_PROMPT_BYTES : 0
		);

		return [
			'system'    => $instruction,
			'prompt'    => $user_prompt,
			'knowledge' => $knowledge,
			'found'     => $found,
		];
	}

	/**
	 * One call to the model: the owner's own key first, Bridle AI only when
	 * none is connected. Drafts, chat answers and rewrites (#130) share it.
	 *
	 * @param string $system The system instruction.
	 * @param string $prompt The user message.
	 * @param array  $schema JSON schema for the answer.
	 * @param string $task    'email' or 'chat': whose model it uses (Settings → Replies, #133).
	 * @param int    $timeout Seconds to wait for the model; 0 keeps each path's default
	 *                        (BridleAi::TIMEOUT). A chat answer a visitor waits for asks for less.
	 * @return array{id: string, raw: string}|WP_Error id is Bridle AI's answer id ('' on the owner's key), for a refund.
	 */
	public static function ask( string $system, string $prompt, array $schema, string $task = 'email', int $timeout = 0 ) {
		if ( 'bridle' === AiService::source() ) {
			$answer = BridleAi::generate( $system, $prompt, $schema, $timeout > 0 ? $timeout : BridleAi::TIMEOUT );
			if ( is_wp_error( $answer ) ) {
				return $answer;
			}
			return [
				'id'  => $answer['id'],
				'raw' => $answer['text'],
			];
		}
		if ( ! function_exists( 'wp_ai_client_prompt' ) ) {
			return new WP_Error( 'bridle_agent_failed', __( 'No AI provider is connected.', 'bridle' ) );
		}
		// The AI Client reads its timeout when the prompt is built.
		$limit = static fn() => (float) $timeout;
		if ( $timeout > 0 ) {
			add_filter( 'wp_ai_client_default_request_timeout', $limit );
		}
		try {
			$raw = wp_ai_client_prompt( $prompt )
				->using_system_instruction( $system )
				->using_temperature( 0.3 )
				->as_json_response( $schema )
				->using_model_preference(
					// Model per task (#133): the owner's choice first, then MODELS.
					...AiService::preference(
						(string) Settings::get( 'chat' === $task ? 'model_chat' : 'model_email', '' ),
						self::MODELS,
						array_column( AiService::models(), 'id' )
					)
				)
				->generate_text();
		} catch ( \Throwable $e ) {
			return new WP_Error( 'bridle_agent_failed', $e->getMessage() );
		} finally {
			remove_filter( 'wp_ai_client_default_request_timeout', $limit );
		}
		if ( is_wp_error( $raw ) ) {
			return $raw;
		}
		return [
			'id'  => '',
			'raw' => (string) $raw,
		];
	}

	/**
	 * Store a reply as the conversation's agent draft (the AI DRAFT card),
	 * whoever wrote it: the built-in agent or an external one (draft-reply).
	 * Replaces any earlier agent draft, which also cancels its scheduled send.
	 *
	 * @param array $meta Draft details; status, based_on_thread_id and created_at are filled in.
	 * @return array The stored meta.
	 */
	public static function store_draft( int $conversation_id, string $html, array $meta ): array {
		$meta += [
			'status'             => 'ready',
			'based_on_thread_id' => self::newest_public_thread_id( $conversation_id ),
			'created_at'         => current_time( 'mysql', true ),
		];

		( new Draft() )->upsert( $conversation_id, self::USER_ID, $html, 'reply', wp_json_encode( $meta ) );

		return $meta;
	}

	/** The id of the newest message the customer or the team could see. */
	public static function newest_public_thread_id( int $conversation_id ): int {
		global $wpdb;

		$sql = $wpdb->prepare(
			'SELECT MAX( id ) FROM %i WHERE conversation_id = %d AND is_private = 0',
			$wpdb->prefix . 'bridle_threads',
			$conversation_id
		);

		return (int) $wpdb->get_var( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- prepared just above.
	}

	/**
	 * The conversation's agent draft, or null.
	 *
	 * @return array{content: string, meta: array, updated_at: string}|null
	 */
	public static function get_draft( int $conversation_id ): ?array {
		$row = ( new Draft() )->get( $conversation_id, self::USER_ID );
		if ( ! $row ) {
			return null;
		}

		$meta = json_decode( (string) ( $row->meta ?? '' ), true );

		return [
			'content'    => (string) $row->content,
			'meta'       => is_array( $meta ) ? $meta : [],
			'updated_at' => (string) $row->updated_at,
		];
	}

	/**
	 * Count what happens to the agent's drafts. Deciding when an inbox is
	 * ready for auto-send rests on these numbers.
	 *
	 * @param string $outcome drafted | failed | sent_unedited | sent_edited | discarded.
	 */
	public static function record( string $outcome ): void {
		$stats             = (array) get_option( 'bridle_agent_stats', [] );
		$stats[ $outcome ] = (int) ( $stats[ $outcome ] ?? 0 ) + 1;
		update_option( 'bridle_agent_stats', $stats, false );
	}

	/** Snippets (saved replies) as knowledge: [ id, title, body ]. */
	public static function snippets(): array {
		// Same option SavedRepliesController manages; read directly because
		// services never call into the REST layer.
		$raw = get_option( 'bridle_saved_replies', [] );
		if ( ! is_array( $raw ) ) {
			$raw = json_decode( (string) $raw, true );
		}

		$snippets = [];
		foreach ( is_array( $raw ) ? $raw : [] as $reply ) {
			if ( is_array( $reply ) && ! empty( $reply['body'] ) ) {
				$snippets[] = [
					'id'    => (string) ( $reply['id'] ?? '' ),
					'title' => (string) ( $reply['title'] ?? '' ),
					'body'  => (string) $reply['body'],
				];
			}
		}

		return $snippets;
	}

	/** One thread row as a transcript message for AgentPrompt. */
	public static function message( object $thread ): array {
		$name = '';
		if ( 'teammate' === $thread->author_type && $thread->author_id ) {
			$user = get_userdata( (int) $thread->author_id );
			$name = $user ? $user->display_name : '';
		}

		return [
			'author'  => (string) $thread->author_type,
			'name'    => $name,
			'private' => ! empty( $thread->is_private ),
			'auto'    => 'auto_reply' === (string) ( $thread->thread_type ?? '' ),
			'at'      => (string) $thread->created_at,
			'text'    => (string) $thread->content,
		];
	}
}
