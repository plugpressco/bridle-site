<?php
/**
 * Puts Bridle Chat's bubble on the site's front end (#114).
 *
 * @package Bridle
 */

namespace Bridle\Services;

defined( 'ABSPATH' ) || exit;

/**
 * One small script, no dependencies, loaded deferred in the footer only while
 * Chat is ready. It draws itself in a shadow root, so the theme's CSS and the
 * widget's never meet. Every word it shows comes from here, translated.
 */
class ChatWidget {

	public const HANDLE = 'bridle-chat';

	public static function init_hooks(): void {
		add_action( 'wp_enqueue_scripts', [ self::class, 'enqueue' ] );
	}

	public static function enqueue(): void {
		if ( is_admin() || ! ChatService::ready() ) {
			return;
		}
		/**
		 * Whether the chat bubble shows on this page.
		 *
		 * @param bool $show True on every front-end page while Chat is on.
		 */
		if ( ! apply_filters( 'bridle_chat_show', true ) ) {
			return;
		}

		$script = self::script();
		wp_enqueue_script(
			self::HANDLE,
			$script['url'],
			[],
			$script['version'],
			[
				'in_footer' => true,
				'strategy'  => 'defer',
			]
		);
		wp_add_inline_script( self::HANDLE, 'window.bridleChat = ' . wp_json_encode( self::config() ) . ';', 'before' );
	}

	/**
	 * The bubble's script and its build version. An embed on another site
	 * (Bridle Pro) loads the same file with `?ver=`.
	 *
	 * @return array{url: string, version: string}
	 */
	public static function script(): array {
		$asset_file = BRIDLE_PLUGIN_DIR . 'build/chat.asset.php';
		$asset      = file_exists( $asset_file ) ? include $asset_file : [];
		return [
			'url'     => BRIDLE_PLUGIN_URL . 'build/chat.js',
			'version' => (string) ( $asset['version'] ?? BRIDLE_VERSION ),
		];
	}

	/** What the widget needs: where to post, how it looks, and its words. */
	public static function config(): array {
		$business = trim( (string) Settings::get( 'business_name', '' ) );
		if ( '' === $business ) {
			$business = (string) get_bloginfo( 'name' );
		}
		$greeting = trim( (string) Settings::get( 'chat_greeting', '' ) );
		$color    = sanitize_hex_color( (string) Settings::get( 'chat_color', '' ) );

		/**
		 * Filters Bridle Chat's bubble config (window.bridleChat). Bridle Pro
		 * sets `live` (try a live handoff before asking for an email).
		 *
		 * @param array $config rest, title, greeting, color, live, strings, ….
		 */
		return (array) apply_filters( 'bridle_chat_config', self::defaults( $business, $greeting, $color ) );
	}

	/** Launcher icons the bubble can draw (src/chat/icons.js). */
	public const ICONS = [ 'bubble', 'message', 'sparkle', 'question', 'headset' ];

	/** The assistant's built-in faces (src/chat/faces.js), first is the default (#163). */
	public const FACES = [ 'sky', 'sun', 'mint', 'rose', 'lilac', 'sand' ];

	/** Seconds on a page before the greeting peek, by setting; 0 is never. */
	public const PEEK = [
		'off' => 0,
		'15'  => 15,
		'30'  => 30,
		'60'  => 60,
	];

	/**
	 * Who visitors talk to (#163): a name ("Blake" unless the owner renamed
	 * it), and a built-in face or the owner's own picture. The bubble always
	 * says it's an AI beside it.
	 *
	 * @return array{name: string, face: string, image: string}
	 */
	public static function agent(): array {
		$name  = trim( (string) Settings::get( 'chat_agent_name', '' ) );
		$face  = (string) Settings::get( 'chat_face', '' );
		$image = 'custom' === $face ? esc_url_raw( (string) Settings::get( 'chat_face_url', '' ) ) : '';
		return [
			'name'  => '' !== $name ? mb_substr( $name, 0, 40 ) : 'Blake',
			'face'  => in_array( $face, self::FACES, true ) ? $face : self::FACES[0],
			'image' => $image,
		];
	}

	/** A look setting, or the first allowed value when it isn't one of them. */
	private static function pick( string $key, array $allowed ): string {
		$value = (string) Settings::get( $key, '' );
		return in_array( $value, $allowed, true ) ? $value : $allowed[0];
	}

	/** The bubble's own config before the filter. */
	private static function defaults( string $business, string $greeting, $color ): array {
		return [
			'live'      => false,
			'rest'      => esc_url_raw( rest_url( BRIDLE_REST_NAMESPACE . '/chat' ) ),
			// Bridle AI answers the chat on its edge (#172); '' keeps it here.
			'edge'      => 'bridle' === AiService::source() ? (string) ( BridleAi::edge()['url'] ?? '' ) : '',
			'title'     => $business,
			'greeting'  => '' !== $greeting ? $greeting : __( 'Hi! Ask me anything. I answer from this site’s help pages, and a person can take over.', 'bridle' ),
			'color'     => $color ? $color : '#2d6fcd',
			// The look (#142), each checked against what the bubble knows.
			'icon'      => self::pick( 'chat_icon', self::ICONS ),
			'position'  => self::pick( 'chat_position', [ 'right', 'left' ] ),
			'size'      => self::pick( 'chat_size', [ 'large', 'compact' ] ),
			'theme'     => self::pick( 'chat_theme', [ 'light', 'dark', 'auto' ] ),
			// The assistant and the greeting peek (#163).
			'agent'     => self::agent(),
			'peek'      => self::PEEK[ (string) Settings::get( 'chat_peek', '30' ) ] ?? 30,
			'sound'     => (bool) Settings::get( 'chat_sound', true ),
			// The site icon: the assistant's face only if its own can't show.
			'logo'      => esc_url_raw( (string) get_site_icon_url( 96 ) ),
			'turnstile' => ChatService::turnstile_config()['site_key'],
			// The invisible check before a new chat: GET {rest}/challenge, then
			// send "{challenge}:{nonce}" as `pow` (#165). 0: not needed.
			'pow'       => ChatService::pow_bits(),
			'privacy'   => esc_url_raw( (string) get_privacy_policy_url() ),
			// A link off the owner's site only when they said yes (WordPress.org guideline 10).
			'powered'   => Settings::get( 'chat_credit_enabled', false ) ? 'https://bridle.to/?utm_source=chat&utm_medium=powered-by' : '',
			'strings'   => [
				'open'        => __( 'Open chat', 'bridle' ),
				'close'       => __( 'Close chat', 'bridle' ),
				'subtitle'    => __( 'AI assistant · a person can help', 'bridle' ),
				'role'        => __( 'AI Assistant', 'bridle' ),
				'dismiss'     => __( 'Not now', 'bridle' ),
				'menu'        => __( 'More', 'bridle' ),
				'agent'       => __( 'AI agent', 'bridle' ),
				'placeholder' => __( 'Ask a question…', 'bridle' ),
				'send'        => __( 'Send', 'bridle' ),
				'thinking'    => __( 'Looking that up…', 'bridle' ),
				'sources'     => __( 'From', 'bridle' ),
				'person'      => __( 'Talk to a person', 'bridle' ),
				'handoff'     => __( 'A person handles this kind of question.', 'bridle' ),
				'unsure'      => __( 'I don’t know that one for sure, and I’d rather not guess. You can ask me something else, or talk to a person.', 'bridle' ),
				'busy'        => __( 'I can’t answer right now. A person will help.', 'bridle' ),
				'ask'         => __( 'Leave your email and a person will reply.', 'bridle' ),
				'email'       => __( 'Your email', 'bridle' ),
				'name'        => __( 'Your name (optional)', 'bridle' ),
				'note'        => __( 'Anything to add? (optional)', 'bridle' ),
				'submit'      => __( 'Send to a person', 'bridle' ),
				'replyTo'     => __( 'Where should we send the reply?', 'bridle' ),
				/* translators: 1: when we usually reply, a sentence, 2: the visitor's email address */
				'sent'        => __( 'Thanks! %1$s You’ll see the reply here and at %2$s.', 'bridle' ),
				'team'        => __( 'Support', 'bridle' ),
				'waiting'     => __( 'Got it. A person will see this with your chat.', 'bridle' ),
				'restart'     => __( 'New chat', 'bridle' ),
				'error'       => __( 'Something went wrong. Try again.', 'bridle' ),
				'powered'     => __( 'Powered by Bridle', 'bridle' ),
				'privacy'     => __( 'Privacy', 'bridle' ),
				'cancel'      => __( 'Back', 'bridle' ),
				'live'        => __( 'A person is here and will answer in the chat.', 'bridle' ),
				'typing'      => __( 'Typing…', 'bridle' ),
				'leaveEmail'  => __( 'Leave your email too, in case you leave the page.', 'bridle' ),
				'confirmAsk'  => __( 'You left your email in our chat. Is it yours?', 'bridle' ),
				'confirmYes'  => __( 'Yes, confirm my email', 'bridle' ),
				'confirmed'   => __( 'Thanks. Your email is confirmed.', 'bridle' ),
			],
		];
	}
}
