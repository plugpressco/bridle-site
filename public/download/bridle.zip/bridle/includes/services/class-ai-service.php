<?php

namespace Bridle\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Where the agent's answers come from: the provider the owner connected in
 * WordPress (their own key, always first), else Bridle AI when they switched
 * it on (2026-11-02, hybrid), else nowhere.
 */
class AiService {

	private static ?bool $own_cache = null;

	/**
	 * The last answer of the provider check: [ 'own' => bool, 'at' => unix time ].
	 * Autoloaded, so a page with the chat bubble reads it without a query.
	 */
	const OWN_OPTION = 'bridle_ai_own';

	/** How long a yes is kept; a no is asked again sooner, in case it was a blip. */
	const OWN_TTL    = 10 * MINUTE_IN_SECONDS;
	const OWN_NO_TTL = MINUTE_IN_SECONDS;

	/** Options whose change means the connection changed (WordPress's Connectors). */
	const CONNECTOR_OPTION_PREFIX = 'connectors_ai_';

	public static function init_hooks(): void {
		foreach ( [ 'added_option', 'updated_option', 'deleted_option' ] as $hook ) {
			add_action( $hook, [ self::class, 'on_option_changed' ] );
		}
		add_action( 'activated_plugin', [ self::class, 'forget' ] );
		add_action( 'deactivated_plugin', [ self::class, 'forget' ] );
	}

	/** Hook: a connector's key or setting changed, so ask again. */
	public static function on_option_changed( $option ): void {
		if ( str_starts_with( (string) $option, self::CONNECTOR_OPTION_PREFIX ) ) {
			self::forget();
		}
	}

	/**
	 * A WordPress AI Client provider is connected (the WP 7.0 AI Client, the
	 * owner's key). Asking can mean an HTTP call to the provider (its model
	 * list), so the answer is kept: a yes for ten minutes, a no for one.
	 */
	public static function own_provider(): bool {
		if ( null !== self::$own_cache ) {
			return self::$own_cache;
		}

		if ( ! function_exists( 'wp_ai_client_prompt' ) ) {
			self::$own_cache = false;
			return false;
		}

		$kept = get_option( self::OWN_OPTION, [] );
		if ( self::fresh( is_array( $kept ) ? $kept : [], time() ) ) {
			self::$own_cache = ! empty( $kept['own'] );
			return self::$own_cache;
		}

		try {
			self::$own_cache = (bool) wp_ai_client_prompt( 'test' )
				->using_temperature( 0.3 )
				->is_supported_for_text_generation();
		} catch ( \Throwable $e ) {
			self::$own_cache = false;
		}

		update_option(
			self::OWN_OPTION,
			[
				'own' => self::$own_cache,
				'at'  => time(),
			],
			true
		);

		return self::$own_cache;
	}

	/** Whether a kept provider check still holds at $now. Pure. */
	public static function fresh( array $kept, int $now ): bool {
		if ( ! isset( $kept['own'], $kept['at'] ) ) {
			return false;
		}
		$ttl = $kept['own'] ? self::OWN_TTL : self::OWN_NO_TTL;
		$age = $now - (int) $kept['at'];
		return $age >= 0 && $age < $ttl;
	}

	/** Forget the kept provider check, for this request and the next. */
	public static function forget(): void {
		self::$own_cache = null;
		delete_option( self::OWN_OPTION );
	}

	/** 'own', 'bridle' or '' (nothing can answer). */
	public static function source(): string {
		if ( self::own_provider() ) {
			return 'own';
		}
		return BridleAi::active() ? 'bridle' : '';
	}

	/** Whether the agent can draft and Chat can answer. */
	public static function can_use_ai(): bool {
		return '' !== self::source();
	}

	/** How long the list of the connection's models is kept. */
	const MODELS_TTL = 12 * HOUR_IN_SECONDS;

	/**
	 * Text models the site's own AI connection offers, for Settings → Replies:
	 * [ [ id 'provider:model', provider, provider_name, model, name ], … ].
	 * Listing can ask the provider, so it is kept for 12 hours. Empty without
	 * the WP AI Client or a connected provider.
	 */
	public static function models( bool $refresh = false ): array {
		$cached = get_transient( 'bridle_ai_models' );
		if ( ! $refresh && is_array( $cached ) ) {
			return $cached;
		}
		$out = [];
		if ( self::own_provider() && class_exists( '\WordPress\AiClient\AiClient' ) ) {
			try {
				$requirements = new \WordPress\AiClient\Providers\Models\DTO\ModelRequirements( [ \WordPress\AiClient\Providers\Models\Enums\CapabilityEnum::textGeneration() ], [] );
				foreach ( \WordPress\AiClient\AiClient::defaultRegistry()->findModelsMetadataForSupport( $requirements ) as $group ) {
					$provider = $group->getProvider();
					foreach ( $group->getModels() as $model ) {
						$out[] = [
							'id'            => $provider->getId() . ':' . $model->getId(),
							'provider'      => $provider->getId(),
							'provider_name' => $provider->getName(),
							'model'         => $model->getId(),
							'name'          => $model->getName(),
						];
					}
				}
			} catch ( \Throwable $e ) {
				$out = [];
			}
		}
		set_transient( 'bridle_ai_models', $out, self::MODELS_TTL );
		return $out;
	}

	/**
	 * The model preference for one task: the owner's choice first (when it is
	 * still offered), then Bridle's own order. Pure.
	 *
	 * @param string   $choice   'provider:model' or '' (automatic).
	 * @param string[] $fallback AgentService::MODELS.
	 * @param array    $offered  models() ids, to drop a choice that went away; [] skips the check.
	 * @return array List for using_model_preference(): [ provider, model ] then model ids.
	 */
	public static function preference( string $choice, array $fallback, array $offered = [] ): array {
		[ $provider, $model ] = array_pad( explode( ':', $choice, 2 ), 2, '' );
		if ( '' === $provider || '' === $model || ( $offered && ! in_array( $choice, $offered, true ) ) ) {
			return $fallback;
		}
		return array_merge( [ [ $provider, $model ] ], array_values( array_diff( $fallback, [ $model ] ) ) );
	}

	/** Forget the cached answer (after Bridle AI is switched on or off). */
	public static function reset(): void {
		self::$own_cache = null;
	}
}
