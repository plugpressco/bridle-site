<?php

namespace Bridle\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * What the agent is told, what it must answer, and whether the answer holds up.
 *
 * Kept apart from AgentService (which loads data, calls the model and stores
 * the draft) because everything here is pure: it takes plain arrays and
 * strings and is unit-tested without WordPress.
 *
 * Knowledge is a map of sources keyed by id: the Agent instructions, the
 * Snippets, and what KnowledgeSearch found for this email (help docs, site
 * pages and posts, products, how the team answered before). A draft is
 * "verified" only when every source it cites is in that map, every quote
 * really appears in that source, and every link in the reply comes from it.
 */
class AgentPrompt {

	/** Messages from the end of the conversation the model sees. */
	const MAX_MESSAGES = 12;

	/** Characters kept per message; long quoted mail is noise. */
	const MAX_MESSAGE_CHARS = 4000;

	/** A shorter quote can't show where a fact came from. */
	const MIN_QUOTE_CHARS = 8;

	/** Agent instructions the model reads; anything longer is clipped. */
	const MAX_INSTRUCTIONS_CHARS = 8000;

	/** Characters of saved replies per prompt, and per saved reply. */
	const SNIPPET_BUDGET    = 6000;
	const MAX_SNIPPET_CHARS = 2000;

	/** Source id prefixes, in the order the prompt lists them (most authoritative first). */
	const SOURCE_TYPES = [ 'instructions', 'snippet', 'kb', 'product', 'page', 'post', 'past' ];

	/** What the model may flag about an email: each one keeps a person in the loop. */
	const FLAGS = [ 'refund', 'billing', 'legal', 'privacy', 'security', 'cancellation', 'upset' ];

	/** The shape the model must answer in. */
	public static function schema(): array {
		return [
			'type'       => 'object',
			'properties' => [
				'reply_html'         => [ 'type' => 'string' ],
				'confidence'         => [
					'type' => 'string',
					'enum' => [ 'high', 'medium', 'low' ],
				],
				'grounded_in'        => [
					'type'  => 'array',
					'items' => [
						'type'       => 'object',
						'properties' => [
							'source' => [
								'type'        => 'string',
								'description' => 'The id in brackets: instructions, snippet:…, kb:…, product:…, page:…, post:… or past:…',
							],
							'quote'  => [ 'type' => 'string' ],
						],
						'required'   => [ 'source', 'quote' ],
					],
				],
				'flags'              => [
					'type'  => 'array',
					'items' => [
						'type' => 'string',
						'enum' => self::FLAGS,
					],
				],
				'needs_human_reason' => [ 'type' => 'string' ],
				'summary'            => [ 'type' => 'string' ],
			],
			'required'   => [ 'reply_html', 'confidence', 'grounded_in', 'flags', 'needs_human_reason', 'summary' ],
		];
	}

	public static function system_instruction( string $business ): string {
		$business = '' !== trim( $business ) ? trim( $business ) : 'this business';

		return "You are the customer support agent for {$business}. You draft email replies; a teammate usually reviews them, and some are sent as written, so be exact.\n\n"
			. "Rules:\n"
			. "- Answer only from KNOWLEDGE and the conversation. Never invent facts, prices, policies, features, dates or links.\n"
			. "- For every fact you use, add an entry to grounded_in: source = the id in square brackets before that piece of knowledge (for example \"instructions\", \"snippet:sr_1\", \"kb:123\", \"page:45\"), with a short quote copied exactly from it.\n"
			. "- Only include links that appear in KNOWLEDGE. A source's own link, shown in its heading, counts.\n"
			. "- Prices and stock come only from [product:…] entries or the instructions.\n"
			. "- [past:…] entries show how the team answered other customers. Use them for the approach and the wording, never as policy over the instructions or docs, and never mention those customers or anything specific to them.\n"
			. "- Text like [email], [link], [name] or [number] is redacted. Never copy it into a reply.\n"
			. "- If KNOWLEDGE does not cover the question, still write the most useful reply you can (for example, ask the one clarifying question you need), set confidence to low or medium, and say in needs_human_reason what a person must check.\n"
			. "- Refunds, billing disputes, legal, privacy or security matters, cancellations and angry customers always need a person: list them in flags and say why in needs_human_reason.\n"
			. "- needs_human_reason is an empty string only when the reply fully and safely answers the customer.\n"
			. "- Reply in the customer's language. Be warm, specific and brief. Greet the customer by first name. Do not sign off with a name; a signature is added automatically.\n"
			. "- reply_html uses only p, br, ul, ol, li, a, strong, em and code.\n"
			. '- summary is one sentence for the teammate: what the customer needs and where things stand.';
	}

	/**
	 * Bridle Chat's instruction (#114): the same rules and the same answer
	 * shape as a draft, for a visitor on the website who reads it at once.
	 * ChatPolicy::decide() shows it only when it is verified and sure.
	 */
	public static function chat_instruction( string $business ): string {
		$business = '' !== trim( $business ) ? trim( $business ) : 'this business';

		return "You are the AI assistant for {$business}, answering a visitor in a chat on the website. Your answer is shown to them at once unless you say a person must check it.\n\n"
			. "Rules:\n"
			. "- Answer only from KNOWLEDGE and the conversation. Never invent facts, prices, policies, features, dates or links.\n"
			. "- For every fact you use, add an entry to grounded_in: source = the id in square brackets before that piece of knowledge, with a short quote copied exactly from it.\n"
			. "- Only include links that appear in KNOWLEDGE. A source's own link, shown in its heading, counts. Link the page that answers the question when there is one.\n"
			. "- Prices and stock come only from [product:…] entries or the instructions.\n"
			. "- [past:…] entries show how the team answered other customers. Use them for the approach, never as policy over the instructions or docs, and never mention those customers.\n"
			. "- Text like [email], [link], [name] or [number] is redacted. Never copy it.\n"
			. "- The visitor is on the page named under CUSTOMER. Words like \"this\", \"it\" or \"here\" usually mean that page or what it sells. Read the whole conversation: a short message often follows on from an earlier one.\n"
			. "- If you need one detail before you can answer (which product, plan or version, what they tried, what they see), ask one short follow-up question instead of guessing or giving up. A follow-up holds only questions: no facts, no links, no sources. Set confidence to medium and needs_human_reason to an empty string.\n"
			. "- If KNOWLEDGE does not cover the question and a follow-up won't help, do not guess: set confidence to low and say in needs_human_reason what is missing. The visitor will be offered a person.\n"
			. "- Refunds, billing disputes, legal or security matters and angry visitors always need a person: list them in flags.\n"
			. "- How to cancel, billing and invoices, and privacy are fine to answer when KNOWLEDGE covers them: answer, cite, and add the flag cancellation, billing or privacy so the team sees it.\n"
			. "- needs_human_reason is an empty string only when the answer fully and safely answers the visitor, or is a follow-up question.\n"
			. "- A greeting or thanks gets a short friendly answer with confidence high and no sources.\n"
			. "- Reply in the visitor's language. Be warm and brief: one to three short paragraphs or a short list. No greeting by name, no sign-off.\n"
			. "- reply_html uses only p, br, ul, ol, li, a, strong, em and code.\n"
			. '- summary is one sentence for the team: what the visitor wanted.';
	}

	/**
	 * The knowledge map: id => [ id, type, ref, title, url, text, date? ], in
	 * the order the prompt shows it.
	 *
	 * @param string $instructions The business's Agent instructions.
	 * @param array  $snippets     [ [ 'id' => …, 'title' => …, 'body' => … ], … ].
	 * @param array  $found        Items from KnowledgeSearch (each has id, type, title, url, text).
	 */
	public static function knowledge( string $instructions, array $snippets, array $found = [] ): array {
		$map = [
			'instructions' => [
				'id'    => 'instructions',
				'type'  => 'instructions',
				'ref'   => '',
				'title' => 'Agent instructions',
				'url'   => '',
				'text'  => KnowledgeText::clip( $instructions, self::MAX_INSTRUCTIONS_CHARS ),
			],
		];

		foreach ( $snippets as $snippet ) {
			$ref = (string) ( $snippet['id'] ?? '' );
			if ( '' === $ref ) {
				continue;
			}
			$map[ "snippet:{$ref}" ] = [
				'id'    => "snippet:{$ref}",
				'type'  => 'snippet',
				'ref'   => $ref,
				'title' => trim( (string) ( $snippet['title'] ?? '' ) ),
				'url'   => '',
				'text'  => trim( (string) ( $snippet['body'] ?? '' ) ),
			];
		}

		// The page a chat's visitor is on goes first, then the site overview
		// (#169), so trimming for size (fit()) drops them last.
		$order = array_flip( self::SOURCE_TYPES );
		$rank  = static function ( array $item ) use ( $order ): int {
			if ( ! empty( $item['here'] ) ) {
				return -2;
			}
			return ! empty( $item['overview'] ) ? -1 : ( $order[ $item['type'] ?? '' ] ?? 99 );
		};
		usort( $found, static fn( $a, $b ) => $rank( $a ) <=> $rank( $b ) );
		foreach ( $found as $item ) {
			if ( ! empty( $item['id'] ) && ! isset( $map[ $item['id'] ] ) ) {
				$map[ $item['id'] ] = $item + [
					'ref'   => '',
					'title' => '',
					'url'   => '',
					'text'  => '',
				];
			}
		}

		return $map;
	}

	/**
	 * The saved replies that go into one prompt. All of them while they fit
	 * SNIPPET_BUDGET; past that, the ones that match the email best (same
	 * scoring as other knowledge), each clipped to MAX_SNIPPET_CHARS, so a
	 * long list can't swamp the prompt or its cost.
	 *
	 * @param array    $snippets AgentService::snippets(): [ id, title, body ].
	 * @param string[] $terms    What the knowledge search looked for.
	 */
	public static function rank_snippets( array $snippets, array $terms, int $budget = self::SNIPPET_BUDGET ): array {
		$snippets = array_map(
			static function ( $snippet ) {
				$body = (string) ( $snippet['body'] ?? '' );
				if ( mb_strlen( $body ) > self::MAX_SNIPPET_CHARS ) {
					$snippet['body'] = KnowledgeText::clip( KnowledgeText::plain( $body ), self::MAX_SNIPPET_CHARS );
				}
				return $snippet;
			},
			array_values( $snippets )
		);
		$size     = static fn( $snippet ) => mb_strlen( (string) ( $snippet['body'] ?? '' ) );
		if ( array_sum( array_map( $size, $snippets ) ) <= $budget ) {
			return $snippets;
		}

		$ranked = [];
		foreach ( $snippets as $i => $snippet ) {
			$ranked[] = [ KnowledgeText::score( 'snippet', (string) ( $snippet['title'] ?? '' ), (string) ( $snippet['body'] ?? '' ), $terms ), $i, $snippet ];
		}
		usort( $ranked, static fn( $a, $b ) => [ $b[0], $a[1] ] <=> [ $a[0], $b[1] ] );

		$kept = [];
		$used = 0;
		foreach ( $ranked as [ , , $snippet ] ) {
			if ( $used + $size( $snippet ) <= $budget ) {
				$kept[] = $snippet;
				$used  += $size( $snippet );
			}
		}
		return $kept;
	}

	/**
	 * The user message: knowledge, the customer, then the conversation.
	 *
	 * @param array $knowledge Output of knowledge().
	 * @param array $customer  [ 'name' => …, 'email' => …, 'cards' => [ card, … ] ].
	 * @param array $messages  [ [ 'author' => 'customer'|'teammate'|'agent'|'system', 'name' => …,
	 *                         'private' => bool, 'at' => 'Y-m-d H:i:s', 'text' => … ], … ] oldest first.
	 */
	public static function user_prompt( array $knowledge, array $customer, array $messages ): string {
		$out = [ 'KNOWLEDGE' ];

		foreach ( $knowledge as $id => $entry ) {
			$out[] = '';
			$out[] = self::heading( (string) $id, $entry );
			$text  = trim( (string) ( $entry['text'] ?? '' ) );
			$out[] = '' !== $text ? $text : '(none)';
		}

		$out[] = '';
		$out[] = 'CUSTOMER';
		$who   = trim( sprintf( '%s <%s>', $customer['name'] ?? '', $customer['email'] ?? '' ) );
		$out[] = '<>' !== $who ? $who : 'A website visitor';
		// A chat's page, even one the knowledge doesn't hold (#169).
		$page = trim( (string) ( $customer['page'] ?? '' ) );
		if ( '' !== $page ) {
			$out[] = 'Is on the page: ' . $page;
		}
		foreach ( $customer['cards'] ?? [] as $card ) {
			$rows   = array_map(
				static fn( $row ) => ( $row[0] ?? '' ) . ': ' . ( $row[1] ?? '' ),
				array_filter( (array) ( $card['rows'] ?? [] ), 'is_array' )
			);
			$status = $card['status']['label'] ?? '';
			$out[]  = sprintf( '%s%s: %s', $card['title'] ?? 'Info', $status ? " ({$status})" : '', implode( '; ', $rows ) );
		}

		$out[] = '';
		$out[] = 'CONVERSATION (oldest first)';
		foreach ( array_slice( $messages, -self::MAX_MESSAGES ) as $message ) {
			$out[] = '';
			$out[] = sprintf( '[%s] %s', $message['at'] ?? '', self::speaker( $message ) );
			$out[] = self::clip( (string) ( $message['text'] ?? '' ) );
		}

		return implode( "\n", $out );
	}

	/**
	 * The user message, trimmed so the system instruction and it together
	 * fit $limit bytes (Bridle AI's size limit): the oldest messages go
	 * first, then the lowest-ranked knowledge (the end of the map: past
	 * answers, posts, pages, products, docs, then saved replies), then the
	 * instructions are clipped (never below 1,000 bytes). The customer's
	 * newest message and everything after it always stay. Pure.
	 *
	 * @param int $limit Bytes; 0 means no limit.
	 * @return array{knowledge: array, prompt: string} The knowledge the
	 *         prompt really carries, for verify().
	 */
	public static function fit( string $system, array $knowledge, array $customer, array $messages, int $limit ): array {
		$messages = array_values( array_slice( $messages, -self::MAX_MESSAGES ) );
		$build    = static fn( array $k, array $m ) => self::user_prompt( $k, $customer, $m );
		$over     = static fn( string $prompt ) => strlen( $system ) + strlen( $prompt ) - $limit;
		$prompt   = $build( $knowledge, $messages );
		if ( $limit <= 0 || $over( $prompt ) <= 0 ) {
			return [
				'knowledge' => $knowledge,
				'prompt'    => $prompt,
			];
		}

		$newest = 0;
		foreach ( $messages as $i => $message ) {
			if ( 'customer' === ( $message['author'] ?? '' ) && empty( $message['private'] ) ) {
				$newest = $i;
			}
		}
		while ( $newest > 0 && $over( $prompt ) > 0 ) {
			array_shift( $messages );
			--$newest;
			$prompt = $build( $knowledge, $messages );
		}

		while ( $over( $prompt ) > 0 ) {
			$last = array_key_last( $knowledge );
			if ( null === $last || 'instructions' === $last ) {
				break;
			}
			unset( $knowledge[ $last ] );
			$prompt = $build( $knowledge, $messages );
		}

		$excess = $over( $prompt );
		if ( $excess > 0 && isset( $knowledge['instructions'] ) ) {
			$text = (string) ( $knowledge['instructions']['text'] ?? '' );
			$keep = max( 1000, strlen( $text ) - $excess - 8 );
			if ( $keep < strlen( $text ) ) {
				$knowledge['instructions']['text'] = rtrim( mb_strcut( $text, 0, $keep, 'UTF-8' ) ) . '…';
				$prompt                            = $build( $knowledge, $messages );
			}
		}

		return [
			'knowledge' => $knowledge,
			'prompt'    => $prompt,
		];
	}

	/**
	 * Decode the model's JSON answer into a normalized draft, or null when
	 * it isn't usable. Sources keep whatever id the model gave, so verify()
	 * can flag one that isn't in knowledge instead of it vanishing here.
	 *
	 * @param mixed $raw JSON string (or an already-decoded array).
	 */
	public static function parse( $raw ): ?array {
		$data = is_array( $raw ) ? $raw : self::decode( (string) $raw );
		if ( ! is_array( $data ) || '' === trim( (string) ( $data['reply_html'] ?? '' ) ) ) {
			return null;
		}

		$sources = [];
		foreach ( (array) ( $data['grounded_in'] ?? [] ) as $source ) {
			if ( ! is_array( $source ) ) {
				continue;
			}
			$id = self::source_id( $source );
			if ( '' !== $id ) {
				$sources[] = [
					'source' => $id,
					'quote'  => (string) ( $source['quote'] ?? '' ),
				];
			}
		}

		$flags = array_values( array_intersect( self::FLAGS, array_map( 'strval', (array) ( $data['flags'] ?? [] ) ) ) );

		return [
			'reply_html'         => (string) $data['reply_html'],
			'confidence'         => in_array( $data['confidence'] ?? '', [ 'high', 'medium', 'low' ], true ) ? $data['confidence'] : 'low',
			'grounded_in'        => $sources,
			'flags'              => $flags,
			'needs_human_reason' => sanitize_textarea_field( (string) ( $data['needs_human_reason'] ?? '' ) ),
			'summary'            => sanitize_text_field( (string) ( $data['summary'] ?? '' ) ),
		];
	}

	/**
	 * The JSON object in a model's answer. Some models wrap it in a ```json
	 * fence or add a line before it; take the outermost { … } then.
	 */
	public static function decode( string $raw ): ?array {
		$raw  = trim( $raw );
		$data = json_decode( $raw, true );
		if ( is_array( $data ) ) {
			return $data;
		}
		$raw   = (string) preg_replace( '/^```[a-z]*\s*|\s*```$/i', '', $raw );
		$start = strpos( $raw, '{' );
		$end   = strrpos( $raw, '}' );
		if ( false === $start || false === $end || $end <= $start ) {
			return null;
		}
		$data = json_decode( substr( $raw, $start, $end - $start + 1 ), true );
		return is_array( $data ) ? $data : null;
	}

	/**
	 * Does the draft stand on the knowledge it claims?
	 *
	 * @param array $draft     Output of parse().
	 * @param array $knowledge Output of knowledge(): exactly what the model saw.
	 * @return string[] Problems found; empty means verified.
	 */
	public static function verify( array $draft, array $knowledge ): array {
		$problems = [];

		foreach ( $draft['grounded_in'] as $cited ) {
			$entry = $knowledge[ $cited['source'] ] ?? null;
			if ( ! $entry ) {
				$problems[] = sprintf( 'Cites %s, which is not in knowledge.', $cited['source'] );
				continue;
			}

			$quote = self::flatten( $cited['quote'] );
			if ( mb_strlen( $quote ) < self::MIN_QUOTE_CHARS ) {
				$problems[] = sprintf( 'Quote too short to check in %s.', $cited['source'] );
				continue;
			}
			if ( ! str_contains( self::flatten( ( $entry['title'] ?? '' ) . "\n" . ( $entry['text'] ?? '' ) ), $quote ) ) {
				$problems[] = sprintf( 'Quote not found in %s: "%s"', $cited['source'], self::clip( $cited['quote'], 80 ) );
			}
		}

		$corpus = implode( "\n", array_map( static fn( $e ) => (string) ( $e['text'] ?? '' ), $knowledge ) );
		$urls   = array_map( [ self::class, 'norm_url' ], array_filter( array_map( static fn( $e ) => (string) ( $e['url'] ?? '' ), $knowledge ) ) );
		foreach ( self::links( $draft['reply_html'] ) as $url ) {
			if ( ! in_array( self::norm_url( $url ), $urls, true ) && ! str_contains( $corpus, $url ) ) {
				$problems[] = sprintf( 'Link not found in knowledge: %s', $url );
			}
		}

		if ( preg_match( KnowledgeText::PLACEHOLDER_RE, self::flatten( $draft['reply_html'] ) ) ) {
			$problems[] = 'Reply contains a redacted placeholder.';
		}

		return $problems;
	}

	/**
	 * The draft's citations with what the UI needs to show and link them:
	 * [ source, type, ref, title, url, quote ].
	 */
	public static function cite( array $grounded_in, array $knowledge ): array {
		return array_map(
			static function ( $cited ) use ( $knowledge ) {
				$entry          = $knowledge[ $cited['source'] ] ?? [];
				[ $type, $ref ] = array_pad( explode( ':', $cited['source'], 2 ), 2, '' );

				return [
					'source' => $cited['source'],
					'type'   => $type,
					'ref'    => $ref,
					'title'  => (string) ( $entry['title'] ?? '' ),
					'url'    => (string) ( $entry['url'] ?? '' ),
					'quote'  => $cited['quote'],
				];
			},
			$grounded_in
		);
	}

	/** Every http(s) URL in the reply, from href attributes and bare text. */
	public static function links( string $html ): array {
		preg_match_all( '#https?://[^\s"\'<>)]+#i', $html, $matches );

		return array_values( array_unique( array_map( static fn( $url ) => rtrim( $url, '.,;:!?' ), $matches[0] ) ) );
	}

	/** Compare links without caring about case in the host or a trailing slash. */
	public static function norm_url( string $url ): string {
		$url = trim( $url );
		if ( preg_match( '#^(https?://)([^/?\#]+)(.*)$#i', $url, $m ) ) {
			$url = strtolower( $m[1] . $m[2] ) . $m[3];
		}

		return rtrim( $url, '/' );
	}

	/**
	 * Plain lowercase text with collapsed whitespace, so a quote matches its
	 * source across line breaks and the HTML of rich-text snippets.
	 */
	public static function flatten( string $text ): string {
		$text = html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );

		return mb_strtolower( trim( (string) preg_replace( '/\s+/u', ' ', $text ) ) );
	}

	/** A cited source as a canonical id; accepts the old { type, ref } shape and stray brackets. */
	private static function source_id( array $source ): string {
		if ( isset( $source['source'] ) ) {
			$id = trim( (string) $source['source'], " \t\n\r\0\x0B[]" );
		} elseif ( 'instructions' === ( $source['type'] ?? '' ) ) {
			$id = 'instructions';
		} else {
			$id = trim( (string) ( $source['type'] ?? '' ) ) . ':' . trim( (string) ( $source['ref'] ?? '' ) );
		}

		if ( 'instructions' === strtolower( $id ) ) {
			return 'instructions';
		}
		if ( ! str_contains( $id, ':' ) ) {
			return '';
		}
		[ $type, $ref ] = explode( ':', $id, 2 );
		$type           = strtolower( trim( $type ) );
		$ref            = trim( $ref );

		return '' !== $type && '' !== $ref ? "{$type}:{$ref}" : '';
	}

	/** The line that introduces one source in the prompt. */
	private static function heading( string $id, array $entry ): string {
		$title = trim( (string) ( $entry['title'] ?? '' ) );
		$url   = trim( (string) ( $entry['url'] ?? '' ) );
		$date  = trim( (string) ( $entry['date'] ?? '' ) );

		if ( 'instructions' === $id ) {
			return '[instructions]';
		}
		if ( 'past' === ( $entry['type'] ?? '' ) ) {
			return sprintf( '[%s] How the team answered "%s"%s', $id, $title, $date ? " (resolved {$date})" : '' );
		}

		return rtrim( sprintf( '[%s] %s%s%s%s', $id, $title, $date ? ", {$date}" : '', $url ? " ({$url})" : '', ! empty( $entry['here'] ) ? ' (the page the visitor is on)' : '' ) );
	}

	private static function speaker( array $message ): string {
		$name = trim( (string) ( $message['name'] ?? '' ) );
		switch ( $message['author'] ?? '' ) {
			case 'customer':
				// An out-of-office or other auto-responder, not the person.
				if ( ! empty( $message['auto'] ) ) {
					return 'Customer\'s mailbox, an automatic reply they did not write';
				}
				return 'Customer' . ( $name ? " ({$name})" : '' );
			case 'agent':
				return 'Agent (you)';
			default:
				$who = 'Teammate' . ( $name ? " ({$name})" : '' );
				return ! empty( $message['private'] ) ? "{$who}, internal note, not seen by the customer" : $who;
		}
	}

	private static function clip( string $text, int $max = self::MAX_MESSAGE_CHARS ): string {
		$text = trim( $text );

		return mb_strlen( $text ) > $max ? rtrim( mb_substr( $text, 0, $max - 1 ) ) . '…' : $text;
	}
}
