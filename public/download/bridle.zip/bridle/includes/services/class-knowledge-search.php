<?php

namespace Bridle\Services;

use Bridle\Models\Conversation;
use Bridle\Models\Customer;
use Bridle\Models\Thread;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Finds what the agent should know for one email: help docs (Bridle KB),
 * the site's pages and posts, WooCommerce products, and how the team
 * answered similar questions before. Keyword search, no embeddings: every
 * query is a WP_Query or the conversation list, run in the background job.
 *
 * Shared by AgentService (the built-in agent) and the search-knowledge
 * ability, so an external agent grounds its answers the same way.
 * KnowledgeText does the text work; this class only fetches.
 */
class KnowledgeSearch {

	/** Settings switch per source. */
	const SOURCES = [ 'kb', 'site', 'products', 'past' ];

	/**
	 * What a chat answer may draw on (#150): it goes straight to an anonymous
	 * visitor, so never other customers' past answers.
	 */
	const PUBLIC_SOURCES = [ 'kb', 'site', 'products' ];

	/** Items kept per type. */
	const LIMITS = [
		'kb'      => 4,
		'page'    => 3,
		'post'    => 2,
		'product' => 3,
		'past'    => 3,
	];

	/** Characters kept per item of each type. */
	const ITEM_CHARS = [
		'kb'      => 1500,
		'page'    => 1200,
		'post'    => 1200,
		'product' => 600,
		'past'    => 900,
	];

	/** Characters of found knowledge per prompt (about 2,300 tokens). */
	const BUDGET = 9000;

	/** How far back the team's past answers count. */
	const PAST_DAYS = 540;

	const CACHE_TTL = 600;

	/** Is the source there at all on this site? */
	public static function available( string $source ): bool {
		switch ( $source ) {
			case 'kb':
				return post_type_exists( 'docs' );
			case 'products':
				return class_exists( 'WooCommerce' ) && post_type_exists( 'product' );
			case 'site':
			case 'past':
				return true;
		}

		return false;
	}

	/** Available and switched on in Settings → Agent. */
	public static function enabled( string $source ): bool {
		return self::available( $source ) && (bool) Settings::get( 'knowledge_' . $source, true );
	}

	/** [ source => [ available, enabled ] ] for the settings screen. */
	public static function status(): array {
		$out = [];
		foreach ( self::SOURCES as $source ) {
			$out[ $source ] = [
				'available' => self::available( $source ),
				'enabled'   => self::enabled( $source ),
			];
		}

		return $out;
	}

	/**
	 * Knowledge for one conversation, from its subject and the newest
	 * customer message.
	 *
	 * @param object   $conversation Conversation row.
	 * @param object[] $threads      Its threads, oldest first.
	 * @param string[] $sources      Limit to these sources (default: all of SOURCES).
	 * @return array{terms: string[], items: array[]}
	 */
	public static function for_conversation( object $conversation, array $threads, array $sources = self::SOURCES ): array {
		$customer = array_values(
			array_filter(
				$threads,
				static fn( $t ) => 'customer' === $t->author_type && empty( $t->is_private )
			)
		);
		$latest   = $customer ? end( $customer ) : null;
		$previous = count( $customer ) > 1 ? $customer[ count( $customer ) - 2 ] : null;

		$customer_row = ( new Customer() )->get_by_id( (int) $conversation->customer_id );
		$chat         = 'chat' === ( $conversation->channel ?? '' );
		$terms_with   = static fn( string $context ) => KnowledgeText::terms(
			// A chat's subject is only its first message: weighting it would keep
			// every later question searching for the first topic (#165).
			$chat ? '' : (string) $conversation->subject,
			$latest ? EmailQuoteStripper::strip_text( (string) $latest->content ) : '',
			$previous ? EmailQuoteStripper::strip_text( (string) $previous->content ) : '',
			// Their own name finds nothing useful.
			KnowledgeText::name_parts( (string) ( $customer_row->name ?? '' ), (string) ( $customer_row->email ?? '' ) ),
			$context
		);

		// A chat knows where the visitor is and what they said before (#169):
		// the page they're on is its first piece of knowledge, and its title
		// and the earlier messages lightly steer the search.
		$page  = null;
		$terms = $terms_with( '' );
		if ( $chat ) {
			$earlier = array_map( static fn( $t ) => (string) $t->content, array_slice( $customer, 0, -1 ) );
			$terms   = $terms_with( implode( "\n", $earlier ) );
			$page    = self::page_entry( (string) ( $conversation->source_url ?? '' ), $terms );
			if ( $page ) {
				$terms = $terms_with( $page['title'] . "\n" . implode( "\n", $earlier ) );
			}
		}

		$items = self::search(
			$terms,
			[
				'inbox_id'   => (int) ( $conversation->inbox_id ?? 0 ),
				'exclude_id' => (int) $conversation->id,
				'sources'    => $sources,
			]
		);
		if ( $page ) {
			$items = array_merge( [ $page + [ 'here' => true ] ], array_values( array_filter( $items, static fn( $i ) => ( $i['id'] ?? '' ) !== $page['id'] ) ) );
		}
		// What the site is and sells, so a basic question always has ground (#169).
		$overview = $chat ? SiteOverview::entry() : null;
		if ( $overview ) {
			$items[] = $overview + [ 'overview' => true ];
		}

		return [
			'terms' => $terms,
			'items' => $items,
			'page'  => $page,
		];
	}

	/** Characters of the visitor's own page a chat's prompt carries. */
	const PAGE_CHARS = 2000;

	/**
	 * The page a chat started on, as knowledge: a published page, post, doc
	 * or product of this site whose source is switched on, or a page an
	 * add-on knows (Bridle Pro: another site's page read from its sitemap,
	 * `bridle_chat_page_entry`). Null when it is neither.
	 *
	 * @param string   $url   The chat's source_url.
	 * @param string[] $terms What the visitor asked, to pick the passage that matters.
	 * @return array|null [ id, type, ref, title, url, text, date ].
	 */
	public static function page_entry( string $url, array $terms = [] ): ?array {
		if ( '' === $url ) {
			return null;
		}
		$host = ChatPolicy::host( $url );
		if ( in_array( $host, [ ChatPolicy::host( home_url() ), ChatPolicy::host( site_url() ) ], true ) ) {
			return self::own_page( $url, $terms );
		}
		/**
		 * Filters the knowledge entry for a chat's page on another site
		 * (#169). Bridle Pro answers from the pages it read from that site.
		 *
		 * @param array|null $entry Null: Bridle knows no such page.
		 * @param string     $url   The page, without query or fragment.
		 * @param string[]   $terms What the visitor asked.
		 * @return array|null [ id, type, ref, title, url, text ].
		 */
		$entry = apply_filters( 'bridle_chat_page_entry', null, $url, $terms );
		if ( ! is_array( $entry ) || empty( $entry['id'] ) || '' === trim( (string) ( $entry['text'] ?? '' ) ) ) {
			return null;
		}
		return [
			'id'    => (string) $entry['id'],
			'type'  => (string) ( $entry['type'] ?? '' ),
			'ref'   => (string) ( $entry['ref'] ?? '' ),
			'title' => (string) ( $entry['title'] ?? '' ),
			'url'   => (string) ( $entry['url'] ?? $url ),
			'text'  => KnowledgeText::clip( (string) $entry['text'], self::PAGE_CHARS ),
			'date'  => '',
		];
	}

	/** page_entry() for a page of this site. */
	private static function own_page( string $url, array $terms ): ?array {
		$id = url_to_postid( $url );
		if ( ! $id && '/' === (string) ( wp_parse_url( $url, PHP_URL_PATH ) ?? '/' ) && 'page' === get_option( 'show_on_front' ) ) {
			$id = (int) get_option( 'page_on_front' );
		}
		$post = $id ? get_post( $id ) : null;
		if ( ! $post || ! self::is_public( $post ) ) {
			return null;
		}
		if ( function_exists( 'wc_get_page_id' ) && in_array( (int) $post->ID, array_map( 'intval', [ wc_get_page_id( 'cart' ), wc_get_page_id( 'checkout' ), wc_get_page_id( 'myaccount' ) ] ), true ) ) {
			return null;
		}
		if ( 'product' === $post->post_type ) {
			return self::enabled( 'products' ) && self::available( 'products' ) ? self::product_entry( (int) $post->ID ) : null;
		}
		$type = self::type_of( $post );
		if ( '' === $type || ! self::enabled( 'kb' === $type ? 'kb' : 'site' ) ) {
			return null;
		}
		if ( 'kb' === $type && '0' === (string) get_post_meta( $post->ID, '_bridle_kb_searchable', true ) ) {
			return null;
		}
		$entry = self::post_entry( $post, $type, $terms, self::PAGE_CHARS );
		// A block theme's home page has no content of its own: SiteOverview reads it.
		return '' !== trim( $entry['text'] ) ? $entry : null;
	}

	/**
	 * Search every enabled source, rank, and keep what fits the budget.
	 *
	 * @param string[] $terms From KnowledgeText::terms().
	 * @param array    $opts  inbox_id (past answers stay within one inbox),
	 *                        exclude_id (the conversation being answered),
	 *                        sources (limit to some of self::SOURCES).
	 * @return array[] [ id, type, ref, title, url, text, date, score ].
	 */
	public static function search( array $terms, array $opts = [] ): array {
		$terms = array_values( array_filter( array_map( 'strval', $terms ) ) );
		if ( ! $terms ) {
			return [];
		}

		$sources = array_values(
			array_filter(
				$opts['sources'] ?? self::SOURCES,
				static fn( $s ) => in_array( $s, self::SOURCES, true ) && self::enabled( $s )
			)
		);
		$inbox   = (int) ( $opts['inbox_id'] ?? 0 );
		$key     = 'bridle_kn_' . md5( wp_json_encode( [ $terms, $sources, $inbox ] ) );
		$items   = get_transient( $key );

		if ( ! is_array( $items ) ) {
			$items = [];
			if ( in_array( 'kb', $sources, true ) ) {
				$items = array_merge( $items, self::docs( $terms ) );
			}
			if ( in_array( 'site', $sources, true ) ) {
				$items = array_merge( $items, self::site( $terms ) );
			}
			if ( in_array( 'products', $sources, true ) ) {
				$items = array_merge( $items, self::products( $terms ) );
			}
			if ( in_array( 'past', $sources, true ) ) {
				// Already redacted, so the cache never holds anyone's details.
				$items = array_merge( $items, self::past( $terms, $inbox ) );
			}
			set_transient( $key, $items, self::CACHE_TTL );
		}

		$exclude = 'past:' . (int) ( $opts['exclude_id'] ?? 0 );
		$items   = array_values( array_filter( $items, static fn( $i ) => $i['id'] !== $exclude ) );
		$items   = KnowledgeText::fit( $items, self::LIMITS, self::BUDGET );

		/**
		 * Filters what the agent knows for one email, after ranking and budgeting.
		 *
		 * @param array[]  $items [ id, type, ref, title, url, text, date, score ].
		 * @param string[] $terms The search terms.
		 * @param array    $opts  inbox_id, exclude_id, sources.
		 */
		return (array) apply_filters( 'bridle_knowledge_items', $items, $terms, $opts );
	}

	/**
	 * Full text of sources by id, for checking a draft written elsewhere (an
	 * external agent) against what those sources really say.
	 *
	 * @param string[] $ids e.g. [ 'kb:12', 'page:4', 'past:88' ].
	 * @return array id => [ id, type, ref, title, url, text ].
	 */
	public static function resolve( array $ids ): array {
		$out = [];
		foreach ( array_unique( $ids ) as $id ) {
			[ $type, $ref ] = array_pad( explode( ':', (string) $id, 2 ), 2, '' );
			$ref            = absint( $ref );
			if ( ! $ref ) {
				continue;
			}

			if ( 'past' === $type ) {
				$entry = self::past_entry( $ref, [], 0 );
			} elseif ( 'product' === $type ) {
				$entry = self::available( 'products' ) ? self::product_entry( $ref ) : null;
			} elseif ( ! in_array( $type, [ 'kb', 'page', 'post' ], true ) ) {
				/**
				 * Filters the full text of a source an add-on put in through
				 * `bridle_knowledge_items`, so a draft citing it can be checked.
				 *
				 * @param array|null $entry Null: Bridle doesn't know this type.
				 * @param string     $type  The id's prefix, e.g. 'web'.
				 * @param int        $ref   The id's number.
				 */
				$entry = apply_filters( 'bridle_knowledge_entry', null, $type, $ref );
				$entry = is_array( $entry ) && ! empty( $entry['id'] ) ? $entry : null;
			} else {
				$post  = get_post( $ref );
				$entry = $post && self::post_type_for( $type ) === self::type_of( $post ) && self::is_public( $post )
					? self::post_entry( $post, $type, [], PHP_INT_MAX )
					: null;
			}

			if ( $entry ) {
				$out[ $entry['id'] ] = $entry;
			}
		}

		return $out;
	}

	/** Hosts a past reply may keep links to: this site, plus hosts the business itself links to. */
	public static function allowed_hosts(): array {
		$hosts = [ (string) wp_parse_url( home_url(), PHP_URL_HOST ) ];
		$text  = (string) Settings::get( 'agent_instructions', '' ) . ' ' . wp_json_encode( get_option( 'bridle_saved_replies', [] ) );
		preg_match_all( '#https?://([^/\s"\'<>\\\\]+)#i', $text, $m );

		return array_values( array_unique( array_filter( array_merge( $hosts, $m[1] ) ) ) );
	}

	/** Published Bridle KB docs, minus the ones KB marks as not searchable. */
	private static function docs( array $terms ): array {
		$ids = self::query(
			[ 'docs' ],
			$terms,
			self::LIMITS['kb'],
			[],
			[
				'meta_query' => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- same opt-out query Bridle KB's own search runs.
					'relation' => 'OR',
					[
						'key'     => '_bridle_kb_searchable',
						'value'   => '1',
						'compare' => '=',
					],
					[
						'key'     => '_bridle_kb_searchable',
						'compare' => 'NOT EXISTS',
					],
				],
			]
		);

		return self::entries( $ids, 'kb', $terms );
	}

	/**
	 * Post types that count as the site's own pages and posts. Only public
	 * types: nothing like orders or reusable blocks can become knowledge.
	 */
	private static function site_types(): array {
		/**
		 * Filters which post types count as the site's own knowledge.
		 *
		 * @param string[] $post_types Default: page and post.
		 */
		return array_values(
			array_filter(
				(array) apply_filters( 'bridle_knowledge_post_types', [ 'page', 'post' ] ),
				static fn( $t ) => is_string( $t ) && ! in_array( $t, [ 'docs', 'product' ], true ) && is_post_type_viewable( $t )
			)
		);
	}

	/** Pages and posts (and any type added through the filter). */
	private static function site( array $terms ): array {
		$types = self::site_types();
		if ( ! $types ) {
			return [];
		}

		$exclude = [];
		if ( function_exists( 'wc_get_page_id' ) ) {
			foreach ( [ 'cart', 'checkout', 'myaccount' ] as $page ) {
				$exclude[] = (int) wc_get_page_id( $page );
			}
		}

		$ids = self::query( $types, $terms, self::LIMITS['page'] + self::LIMITS['post'], array_filter( $exclude ) );

		$items = [];
		foreach ( $ids as $id ) {
			$post = get_post( $id );
			if ( $post ) {
				$type    = 'page' === $post->post_type ? 'page' : 'post';
				$entry   = self::post_entry( $post, $type, $terms, self::ITEM_CHARS[ $type ] );
				$items[] = $entry + [ 'score' => KnowledgeText::score( $type, $entry['title'], $entry['text'], $terms ) ];
			}
		}

		return $items;
	}

	/** WooCommerce products shown in search. */
	private static function products( array $terms ): array {
		$ids = self::query(
			[ 'product' ],
			$terms,
			self::LIMITS['product'],
			[
				'tax_query' => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- Woo's own catalogue visibility.
					[
						'taxonomy' => 'product_visibility',
						'field'    => 'name',
						'terms'    => [ 'exclude-from-search' ],
						'operator' => 'NOT IN',
					],
				],
			]
		);

		$items = [];
		foreach ( $ids as $id ) {
			$entry = self::product_entry( (int) $id );
			if ( $entry ) {
				$items[] = $entry + [ 'score' => KnowledgeText::score( 'product', $entry['title'], $entry['text'], $terms ) ];
			}
		}

		return $items;
	}

	/**
	 * How the team answered similar questions: resolved conversations in the
	 * same inbox with a public teammate reply. Customer words only help to
	 * match; the model sees just the redacted teammate reply.
	 */
	private static function past( array $terms, int $inbox_id ): array {
		$result = ( new Conversation() )->list(
			[
				'box'          => 'closed',
				'inbox_id'     => $inbox_id,
				'search_terms' => array_slice( $terms, 0, 4 ),
				'closed_since' => gmdate( 'Y-m-d H:i:s', time() - self::PAST_DAYS * DAY_IN_SECONDS ),
				'per_page'     => 30,
			]
		);

		$candidates = $result['items'] ?? [];
		if ( ! $candidates ) {
			return [];
		}

		$threads = ( new Thread() )->get_public_by_conversations( array_map( static fn( $c ) => (int) $c->id, $candidates ) );
		$hosts   = self::allowed_hosts();
		$need    = min( 2, count( $terms ) );
		$items   = [];

		foreach ( $candidates as $conversation ) {
			$rows      = $threads[ (int) $conversation->id ] ?? [];
			$questions = array_filter( $rows, static fn( $t ) => 'customer' === $t->author_type );
			$first     = $questions ? reset( $questions ) : null;
			$haystack  = $conversation->subject . ' ' . ( $first ? EmailQuoteStripper::strip_text( (string) $first->content ) : '' );

			if ( KnowledgeText::hits( $haystack, $terms ) < $need ) {
				continue;
			}

			$entry = self::past_entry( (int) $conversation->id, $terms, self::ITEM_CHARS['past'], $conversation, $rows, $hosts );
			if ( $entry ) {
				$items[] = $entry + [ 'score' => KnowledgeText::score( 'past', $conversation->subject, $haystack, $terms ) ];
			}
		}

		return $items;
	}

	/**
	 * One past conversation as knowledge, or null when the team never wrote
	 * a public reply there (receipts, agent-only answers).
	 */
	private static function past_entry( int $conversation_id, array $terms, int $max, ?object $conversation = null, ?array $rows = null, ?array $hosts = null ): ?array {
		$conversation ??= ( new Conversation() )->get_by_id( $conversation_id );
		if ( ! $conversation || 'closed' !== $conversation->status ) {
			return null;
		}
		$rows  ??= ( new Thread() )->get_public_by_conversations( [ $conversation_id ] )[ $conversation_id ] ?? [];
		$hosts ??= self::allowed_hosts();

		$replies = array_map(
			static fn( $t ) => KnowledgeText::plain( (string) ( ! empty( $t->content_html ) ? $t->content_html : $t->content ) ),
			array_filter( $rows, static fn( $t ) => 'teammate' === $t->author_type )
		);
		if ( ! $replies ) {
			return null;
		}

		$customer = ( new Customer() )->get_by_id( (int) $conversation->customer_id );
		$names    = KnowledgeText::name_parts( (string) ( $customer->name ?? '' ), (string) ( $customer->email ?? '' ) );

		$text = $terms ? KnowledgeText::best_reply( $replies, $terms ) : implode( "\n\n", $replies );

		return [
			'id'    => "past:{$conversation_id}",
			'type'  => 'past',
			'ref'   => (string) $conversation_id,
			'title' => KnowledgeText::redact( (string) $conversation->subject, $names, [] ),
			'url'   => '',
			'text'  => KnowledgeText::clip( KnowledgeText::redact( $text, $names, $hosts ), $max ),
			'date'  => substr( (string) ( ! empty( $conversation->closed_at ) ? $conversation->closed_at : $conversation->updated_at ), 0, 10 ),
		];
	}

	private static function product_entry( int $product_id ): ?array {
		$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : null;
		if ( ! $product || 'publish' !== $product->get_status() ) {
			return null;
		}

		$price = trim( html_entity_decode( wp_strip_all_tags( (string) $product->get_price_html() ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
		$stock = $product->is_in_stock() ? 'In stock' : 'Out of stock';
		$lines = array_filter(
			[
				$price ? "Price: {$price}" : '',
				$stock,
				KnowledgeText::plain( (string) ( '' !== (string) $product->get_short_description() ? $product->get_short_description() : $product->get_description() ) ),
			]
		);

		return [
			'id'    => "product:{$product_id}",
			'type'  => 'product',
			'ref'   => (string) $product_id,
			'title' => (string) $product->get_name(),
			'url'   => (string) get_permalink( $product_id ),
			'text'  => KnowledgeText::clip( implode( "\n", $lines ), self::ITEM_CHARS['product'] ),
			'date'  => '',
		];
	}

	private static function post_entry( \WP_Post $post, string $type, array $terms, int $max ): array {
		return [
			'id'    => "{$type}:{$post->ID}",
			'type'  => $type,
			'ref'   => (string) $post->ID,
			'title' => html_entity_decode( get_the_title( $post ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ),
			'url'   => (string) get_permalink( $post ),
			'text'  => $terms ? KnowledgeText::passage( (string) $post->post_content, $terms, $max ) : KnowledgeText::plain( (string) $post->post_content ),
			'date'  => 'post' === $type ? substr( (string) $post->post_date_gmt, 0, 10 ) : '',
		];
	}

	/** @return array[] Entries with scores, for posts of one knowledge type. */
	private static function entries( array $ids, string $type, array $terms ): array {
		$items = [];
		foreach ( $ids as $id ) {
			$post = get_post( $id );
			if ( $post ) {
				$entry   = self::post_entry( $post, $type, $terms, self::ITEM_CHARS[ $type ] );
				$items[] = $entry + [ 'score' => KnowledgeText::score( $type, $entry['title'], $entry['text'], $terms ) ];
			}
		}

		return $items;
	}

	/**
	 * Post ids matching the strongest terms. WordPress search ANDs words,
	 * so it tries the top three together, then two, then each of the top
	 * three alone, until it has enough candidates to rank.
	 *
	 * @param int[] $exclude Post ids to drop.
	 * @param array $extra   More WP_Query arguments (docs' searchable opt-out).
	 */
	private static function query( array $post_types, array $terms, int $want, array $exclude = [], array $extra = [] ): array {
		$searches = [];
		if ( count( $terms ) >= 3 ) {
			$searches[] = implode( ' ', array_slice( $terms, 0, 3 ) );
		}
		if ( count( $terms ) >= 2 ) {
			$searches[] = implode( ' ', array_slice( $terms, 0, 2 ) );
		}
		$searches = array_merge( $searches, array_slice( $terms, 0, 3 ) );

		$ids = [];
		foreach ( $searches as $search ) {
			$query = new \WP_Query(
				$extra + [
					'post_type'           => $post_types,
					'post_status'         => 'publish',
					'has_password'        => false,
					's'                   => $search,
					'orderby'             => 'relevance',
					'posts_per_page'      => $want * 2,
					'fields'              => 'ids',
					'no_found_rows'       => true,
					'ignore_sticky_posts' => true,
				]
			);

			// Excluded ids (WooCommerce's cart, checkout, account pages) are
			// dropped here rather than with a post__not_in query.
			$found = array_diff( array_map( 'intval', $query->posts ), $exclude );
			$ids   = array_values( array_unique( array_merge( $ids, $found ) ) );
			if ( count( $ids ) >= $want * 2 ) {
				break;
			}
		}

		return $ids;
	}

	private static function is_public( \WP_Post $post ): bool {
		return 'publish' === $post->post_status && '' === (string) $post->post_password;
	}

	/** Knowledge type of a post: kb, page or post; '' when it isn't knowledge at all. */
	private static function type_of( \WP_Post $post ): string {
		if ( 'docs' === $post->post_type ) {
			return self::available( 'kb' ) ? 'kb' : '';
		}
		if ( ! in_array( $post->post_type, self::site_types(), true ) ) {
			return '';
		}

		return 'page' === $post->post_type ? 'page' : 'post';
	}

	/** Knowledge type → the type_of() value it must match. */
	private static function post_type_for( string $type ): string {
		return in_array( $type, [ 'kb', 'page', 'post' ], true ) ? $type : '';
	}
}
