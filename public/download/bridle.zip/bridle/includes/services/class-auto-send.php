<?php

namespace Bridle\Services;

use Bridle\Models\Conversation;
use Bridle\Models\Customer;
use Bridle\Models\Draft;
use WP_Error;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The agent sending replies itself.
 *
 * In an inbox set to Auto, a draft that clears every guardrail is scheduled
 * to send after a hold (15 minutes) in which a person can read it, send it
 * now or stop it. An external agent's send-reply goes the same way with a
 * shorter hold. Nothing sends from here directly: when the hold ends the job
 * re-checks everything, claims the draft and hands it to ReplyService, the
 * one write path, recorded as the agent.
 *
 * Its own class because it has its own job, lifecycle and guardrails;
 * AgentQueue only drafts.
 */
class AutoSend {

	const HOOK = 'bridle_agent_send';

	/** Seconds a built-in agent's reply waits before it goes out. */
	const HOLD = 900;

	/** Seconds an external agent's send-reply waits. */
	const EXTERNAL_HOLD = 120;

	/** Past this long after send_at (a sleepy WP-Cron), the reply waits for a person instead. */
	const STALE_AFTER = 7200;

	/** The agent answers a conversation at most this many times on its own. */
	const MAX_AGENT_REPLIES = 2;

	/** Agent replies per inbox per hour. */
	const INBOX_PER_HOUR = 30;

	/** Seconds between agent replies to the same customer. */
	const CUSTOMER_GAP = 600;

	/** Topics that always wait for a person, in the customer's words or the reply's. */
	const TRIPWIRE = '/\b(refund\w*|chargeback\w*|cancel\w*|billing|invoice\w*|charged|overcharg\w*|dispute\w*|lawyer\w*|legal|lawsuit|gdpr|privacy|delete my (data|account)|hack\w*|breach\w*|password\w*|fraud\w*|scam\w*|discount\w*|compensat\w*|guarantee\w*|money back)\b/i';

	public static function init_hooks(): void {
		add_action( self::HOOK, [ self::class, 'run' ], 10, 2 );
	}

	/**
	 * Why a reply may not go out on its own. Pure: everything comes in $s.
	 *
	 * @param array  $s   State, see state().
	 * @param string $who 'agent' (Bridle's own, every guardrail) or 'external'
	 *                    (an agent someone allowed to send: the safety checks only).
	 * @return string[] Reason codes; empty means it may send.
	 */
	public static function blockers( array $s, string $who = 'agent' ): array {
		$reasons = [];
		$mode    = (string) ( $s['mode'] ?? 'off' );

		if ( 'external' === $who ? ! in_array( $mode, [ 'draft', 'auto' ], true ) : 'auto' !== $mode ) {
			$reasons[] = 'mode';
		}
		if ( 'active' !== ( $s['status'] ?? '' ) ) {
			$reasons[] = 'not_active';
		}
		if ( ! empty( $s['is_feed'] ) ) {
			$reasons[] = 'feed';
		}
		if ( 'customer' !== ( $s['last_author'] ?? '' ) ) {
			$reasons[] = 'customer_not_last';
		}
		if ( (int) ( $s['based_on_thread_id'] ?? 0 ) !== (int) ( $s['newest_thread_id'] ?? -1 ) ) {
			$reasons[] = 'stale_draft';
		}
		if ( 'ready' !== ( $s['draft_status'] ?? '' ) ) {
			$reasons[] = 'not_ready';
		}
		if ( ! empty( $s['is_machine_sender'] ) ) {
			$reasons[] = 'machine_sender';
		}
		if ( (int) ( $s['inbox_last_hour'] ?? 0 ) >= self::INBOX_PER_HOUR ) {
			$reasons[] = 'inbox_rate';
		}
		if ( (int) ( $s['customer_recent'] ?? 0 ) > 0 ) {
			$reasons[] = 'customer_rate';
		}
		if ( ! empty( $s['teammate_typing'] ) ) {
			$reasons[] = 'teammate_typing';
		}
		if ( ! empty( $s['send_at'] ) && (int) ( $s['now'] ?? 0 ) - (int) $s['send_at'] > self::STALE_AFTER ) {
			$reasons[] = 'window_passed';
		}

		if ( 'agent' !== $who ) {
			return $reasons;
		}

		if ( empty( $s['verified'] ) ) {
			$reasons[] = 'not_verified';
		}
		if ( 'high' !== ( $s['confidence'] ?? '' ) ) {
			$reasons[] = 'confidence';
		}
		if ( '' !== trim( (string) ( $s['needs_human_reason'] ?? '' ) ) ) {
			$reasons[] = 'needs_human';
		}
		foreach ( (array) ( $s['flags'] ?? [] ) as $flag ) {
			$reasons[] = 'flag:' . $flag;
		}
		if ( (int) ( $s['agent_replies'] ?? 0 ) >= self::MAX_AGENT_REPLIES ) {
			$reasons[] = 'reply_cap';
		}

		$cited = array_values( array_unique( (array) ( $s['cited_types'] ?? [] ) ) );
		if ( ! $cited ) {
			$reasons[] = 'no_sources';
		} elseif ( [ 'past' ] === $cited ) {
			// How the team answered before is a precedent, not a policy.
			$reasons[] = 'only_past';
		}

		if ( preg_match( self::TRIPWIRE, (string) ( $s['customer_text'] ?? '' ) . "\n" . (string) ( $s['reply_text'] ?? '' ) ) ) {
			$reasons[] = 'tripwire';
		}

		$jev = $s['classification'] ?? null;
		if ( is_array( $jev ) ) {
			if ( isset( $jev['needs_human'] ) && (float) $jev['needs_human'] >= 0.3 ) {
				$reasons[] = 'jev_needs_human';
			}
			if ( in_array( $jev['sentiment']['value'] ?? '', [ 'frustrated', 'angry' ], true ) ) {
				$reasons[] = 'jev_upset';
			}
			if ( 'high' === ( $jev['urgency']['value'] ?? '' ) ) {
				$reasons[] = 'jev_urgent';
			}
			if ( in_array( $jev['intent']['value'] ?? '', [ 'refund', 'billing' ], true ) ) {
				$reasons[] = 'jev_intent';
			}
		}

		return $reasons;
	}

	public static function should_auto_send( array $s ): bool {
		return [] === self::blockers( $s, 'agent' );
	}

	/**
	 * How the Inbox shows a conversation's agent draft (#108): `ready` when a
	 * person can send it as written (it answers the newest message, every fact
	 * checked out, the agent is sure and nothing asks for a person), `sending`
	 * while Auto holds it, `check` when a person should look, with the one
	 * reason that matters most, and null with no draft. Pure.
	 *
	 * Reasons: a flag (`refund`, `billing`, `legal`, `privacy`, `security`,
	 * `cancellation`, `upset`), `failed`, `stale` (the customer wrote again),
	 * `person` (the agent asks for one), `unverified`, `unsure`.
	 *
	 * @param array|null $meta             drafts.meta of the agent draft.
	 * @param int        $newest_thread_id The newest public thread's id.
	 * @return array{state: ?string, reason: ?string}
	 */
	public static function review( ?array $meta, int $newest_thread_id ): array {
		$status = (string) ( $meta['status'] ?? '' );
		$check  = static fn( string $reason ): array => [
			'state'  => 'check',
			'reason' => $reason,
		];

		if ( 'failed' === $status ) {
			return $check( 'failed' );
		}
		if ( 'ready' !== $status ) {
			return [
				'state'  => null,
				'reason' => null,
			];
		}
		if ( (int) ( $meta['based_on_thread_id'] ?? 0 ) < $newest_thread_id ) {
			return $check( 'stale' );
		}
		if ( 'scheduled' === ( $meta['auto']['state'] ?? '' ) ) {
			return [
				'state'  => 'sending',
				'reason' => null,
			];
		}
		$flags = array_values( array_filter( array_map( 'strval', (array) ( $meta['flags'] ?? [] ) ) ) );
		if ( $flags ) {
			return $check( $flags[0] );
		}
		if ( '' !== trim( (string) ( $meta['needs_human_reason'] ?? '' ) ) ) {
			return $check( 'person' );
		}
		if ( empty( $meta['verified'] ) ) {
			return $check( 'unverified' );
		}
		if ( 'high' !== ( $meta['confidence'] ?? '' ) ) {
			return $check( 'unsure' );
		}

		return [
			'state'  => 'ready',
			'reason' => null,
		];
	}

	/**
	 * Hook from AgentQueue: a fresh draft is stored. In an Auto inbox,
	 * schedule it or note why it waits for a person.
	 */
	public static function after_draft( int $conversation_id ): void {
		$conversation = ( new Conversation() )->get_by_id( $conversation_id );
		if ( ! $conversation || 'auto' !== InboxAiSettings::agent_mode( (int) $conversation->inbox_id ) ) {
			return;
		}

		$draft = AgentService::get_draft( $conversation_id );
		if ( ! $draft ) {
			return;
		}

		$reasons = self::blockers( self::state( $conversation, $draft ), 'agent' );
		if ( $reasons ) {
			self::set_auto(
				$conversation_id,
				$draft,
				[
					'state'      => 'held',
					'reasons'    => $reasons,
					'decided_at' => current_time( 'mysql', true ),
				]
			);
			AgentService::record( 'auto_held' );
			return;
		}

		self::schedule( $conversation_id, $draft, self::HOLD );
	}

	/**
	 * An external agent asked to send the draft it just stored. Safety
	 * checks only; the caller checked the send permission.
	 *
	 * @return array|WP_Error [ send_at ] (UTC, MySQL format).
	 */
	public static function schedule_external( int $conversation_id ) {
		$conversation = ( new Conversation() )->get_by_id( $conversation_id );
		$draft        = AgentService::get_draft( $conversation_id );
		if ( ! $conversation || ! $draft ) {
			return new WP_Error( 'bridle_not_found', __( 'Conversation or draft not found.', 'bridle' ), [ 'status' => 404 ] );
		}

		$reasons = self::blockers( self::state( $conversation, $draft ), 'external' );
		if ( $reasons ) {
			return new WP_Error(
				'bridle_send_blocked',
				/* translators: %s: why Bridle held the reply, e.g. "the agent is off for this inbox" */
				sprintf( __( 'Not sent: %s. The reply is saved as a draft for a person.', 'bridle' ), self::reason_text( $reasons, 'external' ) ),
				[
					'status'  => 409,
					'reasons' => $reasons,
				]
			);
		}

		return [ 'send_at' => self::schedule( $conversation_id, $draft, self::EXTERNAL_HOLD )['send_at'] ];
	}

	/**
	 * Why a reply was held, in words: the first two distinct reasons, the
	 * same phrases the app shows (src/app/lib/agent.js REASONS), so an AI
	 * client that calls send-reply can tell its person what to change.
	 * Unknown codes are listed as they are.
	 *
	 * @param string[] $reasons Codes from blockers(), e.g. 'mode', 'flag:refund'.
	 * @param string   $who     'auto' (Bridle's own sending) or 'external'.
	 */
	public static function reason_text( array $reasons, string $who = 'auto' ): string {
		$words = [
			'mode'              => 'external' === $who
				? __( 'the agent is off for this inbox (Settings → Inbox)', 'bridle' )
				: __( 'Auto is off for this inbox', 'bridle' ),
			'not_active'        => __( 'the conversation is resolved, in spam or in trash', 'bridle' ),
			'feed'              => __( 'it is in Updates, not the Inbox', 'bridle' ),
			'not_ready'         => __( 'the draft is not ready', 'bridle' ),
			'confidence'        => __( 'it wasn’t sure enough', 'bridle' ),
			'not_verified'      => __( 'not every fact checked out', 'bridle' ),
			'needs_human'       => __( 'it wants a person to look', 'bridle' ),
			'flag'              => __( 'it’s about money, the law or an upset customer', 'bridle' ),
			'tripwire'          => __( 'it’s about money, the law or an upset customer', 'bridle' ),
			'jev_intent'        => __( 'it’s about money, the law or an upset customer', 'bridle' ),
			'jev_upset'         => __( 'it’s about money, the law or an upset customer', 'bridle' ),
			'jev_needs_human'   => __( 'it wants a person to look', 'bridle' ),
			'jev_urgent'        => __( 'it reads as urgent', 'bridle' ),
			'reply_cap'         => __( 'it already answered twice here', 'bridle' ),
			'no_sources'        => __( 'it found nothing to stand on', 'bridle' ),
			'only_past'         => __( 'it only had past replies to go on', 'bridle' ),
			'teammate_typing'   => __( 'a teammate started writing', 'bridle' ),
			'stale_draft'       => __( 'the customer wrote again', 'bridle' ),
			'customer_not_last' => __( 'the customer isn’t waiting', 'bridle' ),
			'machine_sender'    => __( 'the sender looks automated', 'bridle' ),
			'inbox_rate'        => __( 'too many automatic replies just now', 'bridle' ),
			'customer_rate'     => __( 'it answered this person moments ago', 'bridle' ),
			'window_passed'     => __( 'its send time passed', 'bridle' ),
		];

		$phrases = [];
		foreach ( $reasons as $code ) {
			$code   = (string) $code;
			$phrase = $words[ $code ] ?? $words[ strtok( $code, ':' ) ] ?? $code;
			if ( ! in_array( $phrase, $phrases, true ) ) {
				$phrases[] = $phrase;
			}
		}

		return implode( '; ', array_slice( $phrases, 0, 2 ) );
	}

	/**
	 * Stop a scheduled send; the draft stays for a person.
	 *
	 * @return bool False when nothing was scheduled.
	 */
	public static function stop( int $conversation_id, int $user_id ): bool {
		$draft = AgentService::get_draft( $conversation_id );
		if ( ! $draft || 'scheduled' !== ( $draft['meta']['auto']['state'] ?? '' ) ) {
			return false;
		}

		self::set_auto(
			$conversation_id,
			$draft,
			[
				'state'      => 'stopped',
				'stopped_by' => $user_id,
				'decided_at' => current_time( 'mysql', true ),
			]
		);
		self::unschedule( $conversation_id, (string) $draft['meta']['auto']['token'] );
		AgentService::record( 'auto_stopped' );

		return true;
	}

	/** Job: the hold is over. Re-check, claim, send. */
	public static function run( $conversation_id, $token ): void {
		$conversation_id = (int) $conversation_id;
		$token           = (string) $token;

		$lock = AgentQueue::lock( $conversation_id );
		if ( false === $lock ) {
			// The drafting job holds it; try again shortly.
			self::enqueue( $conversation_id, $token, MINUTE_IN_SECONDS );
			return;
		}

		try {
			$row   = ( new Draft() )->get( $conversation_id, AgentService::USER_ID );
			$draft = AgentService::get_draft( $conversation_id );
			$auto  = $draft['meta']['auto'] ?? [];

			// Stopped, discarded, sent by a person, redrafted or replaced: nothing to do.
			if ( ! $row || ! $draft || 'scheduled' !== ( $auto['state'] ?? '' ) || ( $auto['token'] ?? '' ) !== $token ) {
				return;
			}

			$conversation = ( new Conversation() )->get_by_id( $conversation_id );
			$who          = 'external' === ( $draft['meta']['source'] ?? '' ) ? 'external' : 'agent';
			$reasons      = $conversation ? self::blockers( self::state( $conversation, $draft, strtotime( (string) $auto['send_at'] . ' UTC' ) ), $who ) : [ 'not_found' ];

			if ( $reasons ) {
				self::set_auto(
					$conversation_id,
					$draft,
					[
						'state'      => 'held',
						'reasons'    => $reasons,
						'decided_at' => current_time( 'mysql', true ),
					]
				);
				AgentService::record( 'auto_held' );
				return;
			}

			// Claim: exactly one job gets past here, GET_LOCK or not.
			$meta         = $draft['meta'];
			$meta['auto'] = array_merge( $auto, [ 'state' => 'sending' ] );
			$claimed_meta = (string) wp_json_encode( $meta );
			if ( ! ( new Draft() )->swap_meta( $conversation_id, AgentService::USER_ID, (string) $row->meta, $claimed_meta ) ) {
				return;
			}

			$thread = ReplyService::add(
				$conversation_id,
				[
					'content'          => wp_strip_all_tags( $draft['content'] ),
					'content_html'     => $draft['content'],
					'author_type'      => 'agent',
					'author_id'        => (int) ( $meta['user_id'] ?? 0 ),
					'from_agent_draft' => true,
					'agent'            => [
						'source'  => $who,
						'client'  => (string) ( $meta['client'] ?? '' ),
						'via'     => (string) ( $meta['via'] ?? '' ),
						'user_id' => (int) ( $meta['user_id'] ?? 0 ),
						'auto'    => true,
					],
				]
			);

			if ( is_wp_error( $thread ) ) {
				$meta['auto'] = array_merge(
					$auto,
					[
						'state'   => 'failed',
						'reasons' => [ $thread->get_error_code() ],
					]
				);
				( new Draft() )->swap_meta( $conversation_id, AgentService::USER_ID, $claimed_meta, (string) wp_json_encode( $meta ) );
				AgentService::record( 'auto_failed' );
				return;
			}

			self::check_delivery( $conversation_id, (int) $thread->id );
		} finally {
			AgentQueue::unlock( $conversation_id, $lock );
		}
	}

	/**
	 * Everything blockers() needs, read from the database.
	 *
	 * @param object   $conversation Conversation row.
	 * @param array    $draft        AgentService::get_draft().
	 * @param int|null $send_at      Unix time the send was due, when deciding at send time.
	 */
	public static function state( object $conversation, array $draft, ?int $send_at = null ): array {
		global $wpdb;

		$id      = (int) $conversation->id;
		$threads = $wpdb->prefix . 'bridle_threads';
		$convs   = $wpdb->prefix . 'bridle_conversations';
		$joins   = Conversation::box_joins();
		$feed    = Conversation::box_sql( 'feed' );
		$meta    = $draft['meta'];

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- $feed and $joins are constant fragments (box_sql(), box_joins()); the tables and the id are bound.
		$box = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT ( {$feed} ) AS is_feed, lt.author_type AS last_author FROM %i c {$joins} WHERE c.id = %d",
				array_merge( [ $convs ], Conversation::box_join_tables(), [ $id ] )
			)
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber

		$latest_customer = (string) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT content FROM %i WHERE conversation_id = %d AND author_type = 'customer' AND is_private = 0 ORDER BY id DESC LIMIT 1",
				$threads,
				$id
			)
		);

		// The agent's answers in Bridle Chat aren't email: they never count
		// toward Auto's limits (#151), or a busy chat would hold every send.
		$chat_answer = '%"via":"chat"%';

		$agent_replies = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM %i WHERE conversation_id = %d AND author_type = 'agent' AND thread_type = 'reply' AND is_private = 0 AND ( ai_sources IS NULL OR ai_sources NOT LIKE %s )",
				$threads,
				$id,
				$chat_answer
			)
		);

		$hour_ago        = gmdate( 'Y-m-d H:i:s', time() - HOUR_IN_SECONDS );
		$inbox_last_hour = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM %i t INNER JOIN %i c ON c.id = t.conversation_id
				WHERE c.inbox_id = %d AND t.author_type = 'agent' AND t.thread_type = 'reply' AND t.is_private = 0 AND t.created_at >= %s
				AND ( t.ai_sources IS NULL OR t.ai_sources NOT LIKE %s )",
				$threads,
				$convs,
				(int) $conversation->inbox_id,
				$hour_ago,
				$chat_answer
			)
		);

		$customer_recent = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM %i t INNER JOIN %i c ON c.id = t.conversation_id
				WHERE c.customer_id = %d AND t.author_type = 'agent' AND t.thread_type = 'reply' AND t.is_private = 0 AND t.created_at >= %s
				AND ( t.ai_sources IS NULL OR t.ai_sources NOT LIKE %s )",
				$threads,
				$convs,
				(int) $conversation->customer_id,
				gmdate( 'Y-m-d H:i:s', time() - self::CUSTOMER_GAP ),
				$chat_answer
			)
		);

		// A teammate who started writing after the agent drafted has taken over.
		$typing = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM %i WHERE conversation_id = %d AND user_id > 0 AND content <> '' AND updated_at >= %s",
				$wpdb->prefix . 'bridle_drafts',
				$id,
				(string) ( $meta['created_at'] ?? $draft['updated_at'] )
			)
		);

		$customer = ( new Customer() )->get_by_id( (int) $conversation->customer_id );
		$jev      = json_decode( (string) ( $conversation->ai_classification ?? '' ), true );

		return [
			'mode'               => InboxAiSettings::agent_mode( (int) $conversation->inbox_id ),
			'status'             => (string) $conversation->status,
			'is_feed'            => ! empty( $box->is_feed ),
			'last_author'        => $box->last_author ?? null,
			'newest_thread_id'   => AgentService::newest_public_thread_id( $id ),
			'based_on_thread_id' => (int) ( $meta['based_on_thread_id'] ?? 0 ),
			'draft_status'       => (string) ( $meta['status'] ?? '' ),
			'verified'           => ! empty( $meta['verified'] ),
			'confidence'         => (string) ( $meta['confidence'] ?? '' ),
			'needs_human_reason' => (string) ( $meta['needs_human_reason'] ?? '' ),
			'flags'              => (array) ( $meta['flags'] ?? [] ),
			'cited_types'        => array_values( array_filter( array_map( static fn( $g ) => (string) ( $g['type'] ?? strtok( (string) ( $g['source'] ?? '' ), ':' ) ), (array) ( $meta['grounded_in'] ?? [] ) ) ) ),
			'classification'     => is_array( $jev ) ? $jev : null,
			'customer_text'      => EmailQuoteStripper::strip_text( $latest_customer ),
			'reply_text'         => wp_strip_all_tags( (string) $draft['content'] ),
			'is_machine_sender'  => AutomatedMail::is_machine_sender( (string) ( $customer->email ?? '' ) ),
			'agent_replies'      => $agent_replies,
			'inbox_last_hour'    => $inbox_last_hour,
			'customer_recent'    => $customer_recent,
			'teammate_typing'    => $typing > 0,
			'now'                => time(),
			'send_at'            => $send_at,
		];
	}

	/** @return array The meta.auto that was stored. */
	private static function schedule( int $conversation_id, array $draft, int $delay ): array {
		$token = substr( md5( $draft['content'] . ( $draft['meta']['created_at'] ?? '' ) . wp_rand() ), 0, 12 );
		$auto  = [
			'state'      => 'scheduled',
			'send_at'    => gmdate( 'Y-m-d H:i:s', time() + $delay ),
			'token'      => $token,
			'decided_at' => current_time( 'mysql', true ),
		];

		self::set_auto( $conversation_id, $draft, $auto );
		self::enqueue( $conversation_id, $token, $delay );

		return $auto;
	}

	private static function enqueue( int $conversation_id, string $token, int $delay ): void {
		$args = [ $conversation_id, $token ];
		if ( function_exists( 'as_schedule_single_action' ) ) {
			as_schedule_single_action( time() + $delay, self::HOOK, $args, 'bridle', false );
			return;
		}
		wp_schedule_single_event( time() + $delay, self::HOOK, $args );
	}

	private static function unschedule( int $conversation_id, string $token ): void {
		$args = [ $conversation_id, $token ];
		if ( function_exists( 'as_unschedule_action' ) ) {
			as_unschedule_action( self::HOOK, $args, 'bridle' );
		}
		wp_clear_scheduled_hook( self::HOOK, $args );
	}

	/** Write meta.auto onto the agent draft, leaving everything else as it is. */
	private static function set_auto( int $conversation_id, array $draft, array $auto ): void {
		$meta         = $draft['meta'];
		$meta['auto'] = $auto;
		( new Draft() )->upsert( $conversation_id, AgentService::USER_ID, (string) $draft['content'], 'reply', wp_json_encode( $meta ) );
	}

	/**
	 * The email only counts as sent once it has a Message-ID. If the mail
	 * server refused it, the words stay as a note and the conversation keeps
	 * waiting for a reply, rather than looking answered.
	 */
	private static function check_delivery( int $conversation_id, int $thread_id ): void {
		// A reply to a chat shows in the bubble first; its email waits a few
		// minutes (ChatFollowUp), so no Message-ID yet means "pending".
		$conversation = ( new Conversation() )->get_by_id( $conversation_id );
		if ( $conversation && 'chat' === ( $conversation->channel ?? '' ) ) {
			return;
		}

		$thread_model = new \Bridle\Models\Thread();
		$thread       = $thread_model->get_by_id( $thread_id );
		if ( ! $thread || ! empty( $thread->email_message_id ) ) {
			return;
		}

		$thread_model->update( $thread_id, [ 'is_private' => 1 ] );
		ReplyService::add(
			$conversation_id,
			[
				'content'     => __( 'Couldn’t email the reply above, so it is kept here as a note. Send it again from the composer.', 'bridle' ),
				'thread_type' => 'note',
				'author_type' => 'agent',
				'agent'       => [ 'source' => 'agent' ],
			]
		);
		AgentService::record( 'auto_failed' );
	}
}
