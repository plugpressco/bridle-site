<?php

namespace Bridle\Services;

use Bridle\Models\Conversation;
use Bridle\Models\Customer;
use Bridle\Models\Inbox;
use Bridle\Models\Thread;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EmailService {

	/**
	 * Append a small "Powered by Bridle" line to outgoing email.
	 *
	 * Off unless the owner turns it on (Settings → Emails, or the welcome asks
	 * once): WordPress.org guideline 10 makes every credit opt-in, and Pro
	 * changes nothing here. It is one quiet grey line under the reply, so it
	 * never disrupts the conversation's tone.
	 */
	public static function append_credit_footer( string $body ): string {
		if ( ! Settings::get( 'email_credit_enabled', false ) ) {
			return $body;
		}

		// Lets code keep it off even when the setting is on.
		if ( apply_filters( 'bridle_hide_credit_footer', false ) ) {
			return $body;
		}

		// Email-safe markup: <table>-based layout, inline styles only. No
		// logo, no brand colour: one quiet grey line under a thin divider.
		// Renders cleanly in Gmail, Outlook, Apple Mail, and dark-mode clients.
		$sent  = esc_html__( 'Powered by', 'bridle' );
		$brand = esc_html__( 'Bridle', 'bridle' );
		$url   = esc_url( 'https://bridle.to' );
		$font  = '-apple-system,BlinkMacSystemFont,&quot;Segoe UI&quot;,Roboto,Helvetica,Arial,sans-serif';

		$footer  = '<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="margin:36px 0 4px;border-collapse:collapse;">';
		$footer .= '<tr><td align="center" style="padding:0;">';
		$footer .= '<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse;">';
		// Thin slate divider.
		$footer .= '<tr><td style="padding:0 0 12px;border-top:1px solid #E2E8F0;width:64px;line-height:0;font-size:0;">&nbsp;</td></tr>';
		// Single quiet line: "Powered by" + "Bridle", both muted grey, the name underlined.
		$footer .= '<tr><td align="center" style="padding:0;white-space:nowrap;">';
		$footer .= '<a href="' . $url . '" target="_blank" rel="noopener" style="text-decoration:none;white-space:nowrap;font-family:' . $font . ';font-size:11px;line-height:18px;color:#94A3B8;">';
		$footer .= '<span style="color:#94A3B8;font-weight:400;">' . $sent . '</span> ';
		$footer .= '<span style="color:#94A3B8;font-weight:400;text-decoration:underline;">' . $brand . '</span>';
		$footer .= '</a>';
		$footer .= '</td></tr>';
		$footer .= '</table>';
		$footer .= '</td></tr>';
		$footer .= '</table>';

		return $body . $footer;
	}

	/**
	 * Append the inbox signature to an outgoing reply body.
	 *
	 * Merge tags: {{teammate_name}} (reply author), {{inbox_name}},
	 * {{company_name}} / {{business_name}} (workspace business name).
	 */
	public static function append_signature( string $body, ?object $inbox, ?object $thread = null ): string {
		if ( ! $inbox || '' === trim( (string) ( $inbox->signature ?? '' ) ) ) {
			return $body;
		}

		$business_name = Settings::get( 'business_name' ) ?: get_bloginfo( 'name' );

		$teammate_name = '';
		if ( $thread && 'agent' === ( $thread->author_type ?? '' ) ) {
			// The agent signs with its own name, never as the teammate whose key an external agent used.
			$agent_name    = trim( (string) Settings::get( 'agent_name', '' ) );
			$teammate_name = '' !== $agent_name ? $agent_name : $business_name;
		} elseif ( $thread && 'teammate' === ( $thread->author_type ?? '' ) && ! empty( $thread->author_id ) ) {
			$user          = get_userdata( (int) $thread->author_id );
			$teammate_name = $user ? $user->display_name : '';
		}

		$signature = strtr( $inbox->signature, [
			'{{teammate_name}}' => $teammate_name,
			'{{inbox_name}}'    => $inbox->display_name,
			'{{company_name}}'  => $business_name,
			'{{business_name}}' => $business_name,
		] );

		$signature = wp_kses_post( $signature );

		// Plain-text signatures (pre rich-text editor) need paragraphs.
		if ( false === strpos( $signature, '<' ) ) {
			$signature = wpautop( $signature );
		}

		return $body . '<div style="margin-top:24px;">' . $signature . '</div>';
	}

	public static function init_hooks(): void {
		add_action( 'bridle_thread_added', [ self::class, 'maybe_send_email' ], 10, 3 );
		add_action( 'bridle_thread_added', [ self::class, 'maybe_auto_assign' ], 10, 3 );
		add_action( 'bridle_conversation_created', [ self::class, 'maybe_send_auto_reply' ], 20, 3 );
	}

	/**
	 * One quiet line under a reply the agent wrote, so the customer knows an
	 * AI answered and how to reach a person. On by default (AI transparency
	 * rules, such as the EU AI Act's, ask for it); filter it to '' to drop it.
	 */
	public static function append_agent_disclosure( string $body, ?object $thread ): string {
		if ( ! $thread || 'agent' !== ( $thread->author_type ?? '' ) ) {
			return $body;
		}

		/**
		 * Filters the line added under replies the agent wrote. Return '' to leave it out.
		 *
		 * @param string $line   Plain text.
		 * @param object $thread The reply.
		 */
		$line = (string) apply_filters( 'bridle_agent_disclosure', __( 'Written by an AI assistant. Reply to this email to reach a person.', 'bridle' ), $thread );
		if ( '' === trim( $line ) ) {
			return $body;
		}

		return $body . '<p style="margin-top:20px;color:#94A3B8;font-size:12px;line-height:18px;">' . esc_html( $line ) . '</p>';
	}

	/**
	 * Send email to the customer when a teammate or the agent adds a public reply.
	 */
	public static function maybe_send_email( int $thread_id, int $conversation_id, ?object $thread = null ): void {
		if ( ! $thread ) {
			$thread = ( new Thread() )->get_by_id( $thread_id );
		}

		if ( ! $thread ) {
			return;
		}

		// Only public replies, from a teammate or the agent; never notes.
		if ( ! in_array( $thread->author_type, [ 'teammate', 'agent' ], true ) || 'reply' !== $thread->thread_type || $thread->is_private ) {
			return;
		}

		// The agent's answers in Bridle Chat were read in the chat (#114).
		$sources = json_decode( (string) ( $thread->ai_sources ?? '' ), true );
		if ( is_array( $sources ) && 'chat' === ( $sources['via'] ?? '' ) ) {
			return;
		}

		// A reply to a chat shows in the bubble first and is emailed only if
		// the visitor hasn't read it there within a few minutes (#120).
		$conversation = ( new Conversation() )->get_by_id( $conversation_id );
		if ( $conversation && 'chat' === ( $conversation->channel ?? '' ) ) {
			ChatFollowUp::hold_email( $thread_id, $conversation_id );
			return;
		}

		self::send_reply( $conversation_id, $thread_id );
	}

	/**
	 * Auto-assign conversation to teammate who replies.
	 */
	public static function maybe_auto_assign( int $thread_id, int $conversation_id, ?object $thread = null ): void {
		if ( ! Settings::get( 'auto_assign_on_reply', true ) ) {
			return;
		}

		if ( ! $thread ) {
			$thread = ( new Thread() )->get_by_id( $thread_id );
		}

		if ( ! $thread || 'teammate' !== $thread->author_type || ! $thread->author_id ) {
			return;
		}

		$conversation = ( new Conversation() )->get_by_id( $conversation_id );
		if ( $conversation && empty( $conversation->assigned_to ) ) {
			( new Conversation() )->update( $conversation_id, [
				'assigned_to' => absint( $thread->author_id ),
			] );
		}
	}

	/**
	 * Send auto-reply acknowledgement when a new conversation is created via email.
	 *
	 * Loop-prevention follows HelpScout/RFC 3834:
	 * - Skip automated senders (noreply@, mailer-daemon@, bounces, lists)
	 * - Skip messages carrying Precedence: bulk/list/junk or Auto-Submitted != no
	 * - Skip if we already auto-replied to this email address within 24 hours
	 * - Outgoing auto-reply carries Auto-Submitted: auto-replied so other systems know
	 */
	public static function maybe_send_auto_reply( int $conversation_id, $conversation = null, $incoming_headers = [] ): void {
		if ( ! $conversation ) {
			$conversation = ( new Conversation() )->get_by_id( $conversation_id );
		}

		if ( ! $conversation || 'email' !== ( $conversation->channel ?? 'email' ) ) {
			return;
		}

		// Get inbox — auto-reply settings live on the inbox.
		$inbox = self::get_inbox_for_conversation( $conversation );

		if ( ! $inbox || empty( $inbox->auto_reply_enabled ) ) {
			return;
		}

		// Feed mail (receipts, newsletters, pitches) gets no acknowledgement.
		if ( ! empty( $conversation->is_automated ) ) {
			return;
		}

		$customer = ( new Customer() )->get_by_id( $conversation->customer_id );
		if ( ! $customer || ! $customer->email ) {
			return;
		}

		// Loop prevention

		// 1. Refuse to reply to known automated/system senders.
		if ( AutomatedMail::is_machine_sender( $customer->email ) ) {
			return;
		}

		// 2. Check incoming headers for RFC 3834 loop signals.
		if ( AutomatedMail::has_loop_headers( $incoming_headers ) ) {
			return;
		}

		// 3. Don't reply if we already auto-replied to this address in the last 24h.
		$cooldown_key = 'bridle_ar_' . md5( strtolower( $customer->email ) );
		if ( get_transient( $cooldown_key ) ) {
			return;
		}

		$business_name = Settings::get( 'business_name' ) ?: get_bloginfo( 'name' );
		$vars          = [
			'{{ticket_id}}'     => $conversation->thread_id,
			'{{customer_name}}' => $customer->name ?: $customer->email,
			'{{business_name}}' => $business_name,
			'{{company_name}}'  => $business_name,
			'{{inbox_name}}'    => $inbox->display_name,
		];

		// Subject from inbox, fallback to default.
		$subject_template = ! empty( $inbox->auto_reply_subject )
			? $inbox->auto_reply_subject
			/* translators: {{ticket_id}} is replaced with the conversation reference, e.g. BR-1A2B3C. Keep it as is. */
			: __( "We've received your message — [#{{ticket_id}}]", 'bridle' );
		$subject = strtr( $subject_template, $vars );

		// Body from inbox (HTML), fallback to default plain text. Names come
		// from the sender and the site, so they are escaped; the body is not.
		if ( ! empty( $inbox->auto_reply_body ) ) {
			$body = strtr( $inbox->auto_reply_body, array_map( 'esc_html', $vars ) );
		} else {
			$body = wpautop( esc_html( sprintf(
				/* translators: %1$s: customer name, %2$s: business name */
				__( "Hi %1\$s,\n\nThanks for reaching out! We've received your message and will get back to you as soon as possible.\n\nBest,\n%2\$s Support", 'bridle' ),
				$customer->name ?: __( 'there', 'bridle' ),
				$business_name
			) ) );
		}

		$from_name  = $inbox->display_name;
		$from_email = $inbox->email_address;
		$domain     = wp_parse_url( home_url(), PHP_URL_HOST );

		$headers = [
			sprintf( 'From: %s <%s>', $from_name, $from_email ),
			sprintf( 'Message-ID: <bridle-%s-auto@%s>', $conversation->thread_id, $domain ),
			'Content-Type: text/html; charset=UTF-8',
			// RFC 3834 — mark this outgoing message as an automatic reply so other
			// mail servers / auto-responders know not to reply back.
			'Auto-Submitted: auto-replied',
			'Precedence: auto_reply',
			'X-Auto-Response-Suppress: All',
		];

		$body = self::append_credit_footer( $body );

		$sent = wp_mail( $customer->email, $subject, $body, $headers );

		// Mark 24h cooldown (even if wp_mail returned false — don't retry in a loop).
		set_transient( $cooldown_key, 1, DAY_IN_SECONDS );
	}

	/**
	 * Send a reply email to the customer.
	 */
	public static function send_reply( int $conversation_id, int $thread_id ) {
		$conv_model    = new Conversation();
		$conversation  = $conv_model->get_by_id( $conversation_id );

		if ( ! $conversation ) {
			return new \WP_Error( 'bridle_no_conversation', __( 'Conversation not found.', 'bridle' ) );
		}

		$thread = ( new Thread() )->get_by_id( $thread_id );

		if ( ! $thread ) {
			return new \WP_Error( 'bridle_no_thread', __( 'Thread not found.', 'bridle' ) );
		}

		// A note, or a reply kept back as one, never leaves the team.
		if ( ! empty( $thread->is_private ) ) {
			return new \WP_Error( 'bridle_private_thread', __( 'This message is a private note, so it isn’t emailed.', 'bridle' ) );
		}

		$customer = ( new Customer() )->get_by_id( $conversation->customer_id );

		if ( ! $customer || ! $customer->email ) {
			return new \WP_Error( 'bridle_no_customer', __( 'Contact not found or has no email.', 'bridle' ) );
		}

		$inbox      = self::get_inbox_for_conversation( $conversation );
		$from_name  = $inbox ? $inbox->display_name : get_bloginfo( 'name' );
		$from_email = $inbox ? $inbox->email_address : get_option( 'admin_email' );
		$domain     = wp_parse_url( home_url(), PHP_URL_HOST );

		// Build threading headers.
		$position      = ( new Thread() )->public_position( $conversation_id, $thread_id );
		$sd_message_id = sprintf( '<sd-%s-%d@%s>', $conversation->thread_id, $position, $domain );

		// Find last customer message_id for In-Reply-To.
		$threads     = ( new Thread() )->get_by_conversation( $conversation_id );
		$in_reply_to = '';
		$references  = [];

		foreach ( array_reverse( $threads ) as $t ) {
			if ( $t->email_message_id ) {
				if ( ! $in_reply_to ) {
					$in_reply_to = $t->email_message_id;
				}
				$references[] = $t->email_message_id;
			}
		}

		$subject = sprintf( 'Re: [#%s] %s', $conversation->thread_id, $conversation->subject );

		$headers = [
			sprintf( 'From: %s <%s>', $from_name, $from_email ),
			sprintf( 'Message-ID: %s', $sd_message_id ),
		];

		if ( $in_reply_to ) {
			$headers[] = sprintf( 'In-Reply-To: %s', $in_reply_to );
		}
		if ( ! empty( $references ) ) {
			$headers[] = sprintf( 'References: %s', implode( ' ', array_reverse( $references ) ) );
		}

		$headers[] = 'Content-Type: text/html; charset=UTF-8';

		// Auto BCC.
		$bcc = Settings::get( 'auto_bcc_email', '' );
		if ( ! empty( $bcc ) && is_email( $bcc ) ) {
			$headers[] = sprintf( 'Bcc: %s', $bcc );
		}

		$body = $thread->content_html ?: wpautop( esc_html( $thread->content ) );

		// Inbox signature goes above the CID pass so any local images in it
		// get embedded too. Credit footer is appended after, at the very end.
		$body = self::append_signature( $body, $inbox, $thread );
		$body = self::append_agent_disclosure( $body, $thread );

		// Embed local images as inline CID attachments so they render even
		// when the site is behind a VPN / basic auth / localhost. Scans for
		// <img src="https://thissite/..."> tags, downloads the file from
		// disk (no HTTP round-trip), base64-encodes, and attaches as a MIME
		// inline part. The src attribute is rewritten to cid:hash@domain.
		$inline_images = [];
		$site_url      = home_url();
		$upload_dir    = wp_upload_dir();

		$body = preg_replace_callback(
			'/<img\b([^>]*)\bsrc=["\'](' . preg_quote( $site_url, '/' ) . '[^"\']+)["\']/i',
			function ( $m ) use ( $domain, $upload_dir, &$inline_images ) {
				$url       = $m[2];
				$local_path = str_replace( $upload_dir['baseurl'], $upload_dir['basedir'], $url );

				if ( ! file_exists( $local_path ) ) {
					return $m[0];
				}

				$mime = wp_check_filetype( $local_path )['type'] ?? 'image/png';
				$cid  = md5( $url ) . '@' . $domain;

				$inline_images[] = [
					'path' => $local_path,
					'cid'  => $cid,
					'mime' => $mime,
				];

				return str_replace( $m[2], 'cid:' . $cid, $m[0] );
			},
			$body
		);

		// If we have inline images, hook into PHPMailer to attach them
		// as inline MIME parts before the message is sent.
		if ( ! empty( $inline_images ) ) {
			$embed_hook = function ( $phpmailer ) use ( &$inline_images, &$embed_hook ) {
				foreach ( $inline_images as $img ) {
					$phpmailer->addEmbeddedImage(
						$img['path'],
						$img['cid'],
						basename( $img['path'] ),
						'base64',
						$img['mime']
					);
				}
				// Self-remove so we don't leak into other wp_mail calls.
				remove_action( 'phpmailer_init', $embed_hook, 10 );
			};
			add_action( 'phpmailer_init', $embed_hook, 10 );
		}

		$body = self::append_credit_footer( $body );

		$sent = wp_mail( $customer->email, $subject, $body, $headers );

		if ( ! $sent ) {
			return new \WP_Error( 'bridle_email_failed', __( 'Failed to send email.', 'bridle' ) );
		}

		// Store the message ID on the thread.
		global $wpdb;
		$wpdb->update(
			$wpdb->prefix . 'bridle_threads',
			[ 'email_message_id' => $sd_message_id ],
			[ 'id' => $thread_id ]
		);

		return true;
	}

	/**
	 * Get the inbox for a conversation (with fallback to first active).
	 */
	/**
	 * The visitor's copy of a chat handed to a person (#120): what to expect,
	 * the chat so far, and that replying continues it. Sent from the inbox
	 * with the conversation's subject tag and Message-ID, so their reply
	 * threads into the same conversation.
	 *
	 * @param object $conversation The chat.
	 * @param string $promise      ChatFollowUp::promise().
	 * @return bool|\WP_Error
	 */
	public static function send_chat_confirmation( object $conversation, string $promise ) {
		$customer = ( new Customer() )->get_by_id( (int) $conversation->customer_id );
		if ( ! $customer || ! is_email( (string) $customer->email ) ) {
			return new \WP_Error( 'bridle_no_customer', __( 'Contact not found or has no email.', 'bridle' ) );
		}

		$inbox    = self::get_inbox_for_conversation( $conversation );
		$business = trim( (string) Settings::get( 'business_name', '' ) );
		$business = '' !== $business ? $business : (string) get_bloginfo( 'name' );
		$domain   = wp_parse_url( home_url(), PHP_URL_HOST );

		$rows = '';
		foreach ( ( new Thread() )->get_by_conversation( (int) $conversation->id ) as $thread ) {
			if ( ! empty( $thread->is_private ) || 'reply' !== $thread->thread_type ) {
				continue;
			}
			$who   = 'customer' === $thread->author_type
				? __( 'You', 'bridle' )
				/* translators: %s: business name */
				: sprintf( __( '%s assistant', 'bridle' ), $business );
			$text  = $thread->content_html ? wp_kses_post( (string) $thread->content_html ) : wpautop( esc_html( (string) $thread->content ) );
			$rows .= '<p style="margin:0 0 4px;color:#6b6b66;font-size:13px">' . esc_html( $who ) . '</p>'
				. '<div style="margin:0 0 16px">' . $text . '</div>';
		}

		// One tap on the site proves the address is theirs (#150), so the team
		// can trust it. Someone else typed it? Then nothing happens.
		$confirm = ChatService::confirm_url( $conversation );
		$body    = '<p>' . esc_html__( 'Thanks for your question. A person will reply.', 'bridle' ) . ' ' . esc_html( $promise ) . '</p>'
			. '<p>' . esc_html__( 'Reply to this email to add anything, or come back to the chat on our site.', 'bridle' ) . '</p>'
			. ( '' !== $confirm ? '<p><a href="' . esc_url( $confirm ) . '">' . esc_html__( 'Confirm this is your email', 'bridle' ) . '</a><br><span style="color:#6b6b66;font-size:13px">' . esc_html__( 'Didn’t start this chat? Ignore this email.', 'bridle' ) . '</span></p>' : '' )
			. '<hr style="border:0;border-top:1px solid #e6e6e1;margin:20px 0">'
			. $rows;
		$body    = self::append_credit_footer( $body );

		$headers = [
			sprintf( 'From: %s <%s>', $inbox ? $inbox->display_name : $business, $inbox ? $inbox->email_address : get_option( 'admin_email' ) ),
			sprintf( 'Message-ID: <sd-%s-0@%s>', $conversation->thread_id, $domain ),
			'Content-Type: text/html; charset=UTF-8',
		];

		$sent = wp_mail( $customer->email, sprintf( 'Re: [#%s] %s', $conversation->thread_id, $conversation->subject ), $body, $headers );
		return $sent ? true : new \WP_Error( 'bridle_email_failed', __( 'Failed to send email.', 'bridle' ) );
	}

	private static function get_inbox_for_conversation( object $conversation ): ?object {
		$inbox = null;

		if ( $conversation->inbox_id ) {
			$inbox = ( new Inbox() )->get_by_id( (int) $conversation->inbox_id );
		}

		if ( ! $inbox ) {
			$inboxes = ( new Inbox() )->list( [ 'is_active' => 1 ] );
			$inbox   = $inboxes[0] ?? null;
		}

		return $inbox;
	}
}
