<?php
/**
 * Bridle Chat's rules (#114): what a visitor may send, when the agent may
 * answer, and the token that ties a visitor to their chat. Pure, unit-tested.
 *
 * @package Bridle
 */

namespace Bridle\Services;

defined( 'ABSPATH' ) || exit;

/**
 * Everything here takes its state as arguments, so it runs without WordPress.
 */
class ChatPolicy {

	/**
	 * Default limits. ChatService::limits() passes them through the
	 * `bridle_chat_limits` filter.
	 */
	public const LIMITS = [
		'max_chars'              => 1000, // One message.
		'per_chat'               => 20,   // Visitor messages in one chat.
		'per_visitor_hour'       => 30,   // Messages from one visitor in an hour.
		'chats_per_visitor_hour' => 6,    // New chats from one visitor in an hour.
		'handoffs_per_hour'      => 3,    // Emails left by one visitor in an hour.
		'answers_per_hour'       => 120,  // AI calls a chat causes (answers and drafts), whole site, an hour.
		'drafts_per_chat'        => 10,   // Email drafts for one chat after it reached a person.
		'emails_per_hour'        => 30,   // Confirmation emails and team alerts, whole site, an hour.
		'ai_per_visitor_hour'    => 12,   // AI answers for one visitor in an hour (#165).
		'answers_per_day'        => 600,  // AI calls a chat causes, whole site, a day (#165).
	];

	/**
	 * Leading zero bits of the invisible check a browser solves before it
	 * may start a chat when Turnstile isn't set up (#165): about a second of
	 * work in a visitor's browser, which a script spamming the chat must pay
	 * for every chat. `bridle_chat_pow_bits` changes it; 0 turns it off.
	 */
	public const POW_BITS = 18;

	/** Minutes a check's challenge stays good. */
	public const POW_MINUTES = 15;

	/** Option names of the site-wide daily counters (TrashPurge clears old ones). */
	public const DAY_PREFIX = 'bridle_chat_day_';

	/**
	 * Cloudflare's proxy addresses (cloudflare.com/ips, 2026-11). Only a
	 * request from one of these may name the visitor in CF-Connecting-IP.
	 */
	public const CLOUDFLARE_RANGES = [
		'173.245.48.0/20',
		'103.21.244.0/22',
		'103.22.200.0/22',
		'103.31.4.0/22',
		'141.101.64.0/18',
		'108.162.192.0/18',
		'190.93.240.0/20',
		'188.114.96.0/20',
		'197.234.240.0/22',
		'198.41.128.0/17',
		'162.158.0.0/15',
		'104.16.0.0/13',
		'104.24.0.0/14',
		'172.64.0.0/13',
		'131.0.72.0/22',
		'2400:cb00::/32',
		'2606:4700::/32',
		'2803:f800::/32',
		'2405:b500::/32',
		'2405:8100::/32',
		'2a06:98c0::/29',
		'2c0f:f248::/32',
	];

	/**
	 * Topics a person always answers in a chat: money owed back, disputes,
	 * legal and security. Auto's list (AutoSend::TRIPWIRE) without "password",
	 * "discount" and "guarantee", which visitors ask about every day, and
	 * without SOFT_TOPICS (#169); the model's own flags still catch the rest.
	 */
	public const TRIPWIRE = '/\b(refund\w*|chargeback\w*|charged|overcharg\w*|dispute\w*|lawyer\w*|legal|lawsuit|delete my (data|account)|hack\w*|breach\w*|fraud\w*|scam\w*|compensat\w*|money back)\b/i';

	/**
	 * Topics the chat may answer when the knowledge covers them, with a note
	 * for the team (#169, owner: "how do I cancel" has an answer in the docs).
	 * Email's Auto still holds them.
	 */
	public const SOFT_TOPICS = '/\b(cancel\w*|billing|invoice\w*|privacy|gdpr)\b/i';

	/** The model's flags (AgentPrompt::FLAGS) a grounded chat answer may carry: the same topics. */
	public const SOFT_FLAGS = [ 'billing', 'privacy', 'cancellation' ];

	/**
	 * Follow-up questions the agent may ask in one chat before a person is
	 * offered (#169): it asks what it needs instead of handing off at once.
	 */
	public const FOLLOW_UPS = 2;

	/** Seconds an edge request's clock may be off (#172). */
	public const EDGE_SKEW = 300;

	/**
	 * The signature Bridle AI's edge puts on a request to this site (#172):
	 * HMAC-SHA256 of "{time}.{body}" with the site's edge secret, hex. Pure.
	 *
	 * @param string $secret The edge secret.
	 * @param string $time   Unix seconds, as sent.
	 * @param string $body   The raw request body.
	 */
	public static function edge_sign( string $secret, string $time, string $body ): string {
		return hash_hmac( 'sha256', $time . '.' . $body, $secret );
	}

	/**
	 * Whether a request came from Bridle AI's edge: a secret is set, the time
	 * is within EDGE_SKEW of now and the signature matches. Pure.
	 *
	 * @param string $secret The edge secret ('' when the edge isn't set up).
	 * @param string $time   X-Bridle-Edge-Time.
	 * @param string $body   The raw request body.
	 * @param string $given  X-Bridle-Edge-Sign.
	 * @param int    $now    Unix time.
	 */
	public static function edge_valid( string $secret, string $time, string $body, string $given, int $now ): bool {
		if ( '' === $secret || ! ctype_digit( $time ) || abs( $now - (int) $time ) > self::EDGE_SKEW ) {
			return false;
		}
		return hash_equals( self::edge_sign( $secret, $time, $body ), strtolower( trim( $given ) ) );
	}

	/** Longest follow-up question, in characters. */
	public const FOLLOW_UP_CHARS = 280;

	/** Option names of the site-wide hourly counters (ChatService::within_hour(); TrashPurge clears old ones). */
	public const HOUR_PREFIX = 'bridle_chat_hour_';

	/** Longest subject a chat gets in the Inbox, in characters. */
	public const SUBJECT_CHARS = 80;

	/**
	 * Longest answer the chat shows without a source: a greeting or a thanks
	 * (#150). Anything with a fact in it must cite one.
	 */
	public const SMALL_TALK_CHARS = 160;

	/**
	 * A visitor's message, tidied, or null when it can't be sent: empty,
	 * too long, or the honeypot field was filled in.
	 *
	 * @param string $text      What the visitor typed.
	 * @param int    $max_chars Longest allowed.
	 * @param string $honeypot  The hidden field only bots fill in.
	 */
	public static function clean( string $text, int $max_chars, string $honeypot = '' ): ?string {
		if ( '' !== trim( $honeypot ) ) {
			return null;
		}
		// Keep line breaks, drop control characters, squeeze blank lines.
		$text = (string) preg_replace( '/[^\P{C}\n]+/u', '', str_replace( "\r\n", "\n", $text ) );
		$text = trim( (string) preg_replace( "/\n{3,}/", "\n\n", $text ) );
		if ( '' === $text || mb_strlen( $text ) > $max_chars ) {
			return null;
		}
		return $text;
	}

	/**
	 * Whether the agent may show its answer, or why a person takes over.
	 *
	 * Two answers pass without the usual checks' every step (#169): a
	 * follow-up question (questions only, no facts or links, at most
	 * FOLLOW_UPS a chat), and a grounded answer about a SOFT_TOPICS subject,
	 * which says so in `topic` so the team gets a note.
	 *
	 * @param array  $draft    AgentPrompt::parse() output.
	 * @param array  $problems AgentPrompt::verify() output.
	 * @param string $visitor  The visitor's newest message.
	 * @param int    $asked    Follow-up questions the agent already asked in this chat.
	 * @return array{answer: bool, reason: string, ask: bool, topic: string} reason: '' | a model
	 *         flag | tripwire | unverified | uncited | unsure; ask: it is a follow-up question;
	 *         topic: the soft topic a shown answer is about ('' when none).
	 */
	public static function decide( array $draft, array $problems, string $visitor, int $asked = 0 ): array {
		$out   = static fn( bool $answer, string $reason, bool $ask = false, string $topic = '' ) => [
			'answer' => $answer,
			'reason' => $reason,
			'ask'    => $ask,
			'topic'  => $topic,
		];
		$flags = array_values( array_filter( array_map( 'strval', (array) ( $draft['flags'] ?? [] ) ) ) );
		$hard  = array_values( array_diff( $flags, self::SOFT_FLAGS ) );
		if ( $hard ) {
			return $out( false, $hard[0] );
		}
		$html  = (string) ( $draft['reply_html'] ?? '' );
		$reply = AgentPrompt::flatten( $html );
		if ( self::tripwire( $visitor . "\n" . $reply ) ) {
			return $out( false, 'tripwire' );
		}
		if ( $problems ) {
			return $out( false, 'unverified' );
		}
		// Asking for the one detail it needs beats handing off (#169).
		if ( $asked < self::FOLLOW_UPS && self::follow_up( $html ) ) {
			return $out( true, '', true );
		}
		// verify() passes an answer that cites nothing (#150): only small
		// talk may go without a source.
		if ( ! self::cited( (array) ( $draft['grounded_in'] ?? [] ) ) && ! self::small_talk( $visitor, $html ) ) {
			return $out( false, 'uncited' );
		}
		if ( 'low' === ( $draft['confidence'] ?? 'low' ) || '' !== trim( (string) ( $draft['needs_human_reason'] ?? '' ) ) ) {
			return $out( false, 'unsure' );
		}
		return $out( true, '', false, self::topic( $flags, $visitor . "\n" . $reply ) );
	}

	/**
	 * Whether an answer is only a follow-up question: short, every sentence
	 * a question, no link and no address, so it states nothing a source
	 * would have to back. Pure.
	 *
	 * @param string $reply_html The answer.
	 */
	public static function follow_up( string $reply_html ): bool {
		$text = trim( AgentPrompt::flatten( $reply_html ) );
		if ( '' === $text || mb_strlen( $text ) > self::FOLLOW_UP_CHARS || preg_match( '~<a\b|https?:|www\.|@~i', $reply_html . ' ' . $text ) ) {
			return false;
		}
		$sentences = preg_split( '/(?<=[.!?。！？])\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY );
		foreach ( (array) $sentences as $sentence ) {
			if ( ! preg_match( '/[?？]["”’)\s]*$/u', trim( (string) $sentence ) ) ) {
				return false;
			}
		}
		return (bool) $sentences;
	}

	/**
	 * The soft topic an answer is about, for the team's note: the model's
	 * flag, else the word that matched SOFT_TOPICS, else ''. Pure.
	 *
	 * @param string[] $flags The model's flags.
	 * @param string   $text  The visitor's message and the answer.
	 */
	public static function topic( array $flags, string $text ): string {
		$soft = array_values( array_intersect( $flags, self::SOFT_FLAGS ) );
		if ( $soft ) {
			return (string) $soft[0];
		}
		return preg_match( self::SOFT_TOPICS, $text, $m ) ? mb_strtolower( (string) $m[1] ) : '';
	}

	/**
	 * A challenge for the invisible check: when, a random part, and a
	 * signature only this site can make. Pure.
	 *
	 * @param int    $now  Unix time.
	 * @param string $rand Random letters and digits.
	 * @param string $key  This site's secret.
	 */
	public static function pow_challenge( int $now, string $rand, string $key ): string {
		$body = $now . '.' . $rand;
		return $body . '.' . substr( hash_hmac( 'sha256', 'pow|' . $body, $key ), 0, 32 );
	}

	/**
	 * Whether a browser solved the check: "{challenge}:{nonce}", where the
	 * challenge is this site's and still fresh, and SHA-256 of the whole
	 * string starts with $bits zero bits. Pure.
	 *
	 * @param string $proof What the browser sent.
	 * @param int    $bits  Zero bits needed.
	 * @param string $key   This site's secret.
	 * @param int    $now   Unix time.
	 */
	public static function pow_valid( string $proof, int $bits, string $key, int $now ): bool {
		[ $challenge, $nonce ] = array_pad( explode( ':', $proof, 2 ), 2, '' );
		$parts                 = explode( '.', $challenge );
		if ( 3 !== count( $parts ) || ! ctype_digit( $parts[0] ) || ! ctype_digit( $nonce ) || strlen( $nonce ) > 12
			|| ! preg_match( '/^[A-Za-z0-9]{8,40}$/', $parts[1] ) ) {
			return false;
		}
		$signed = substr( hash_hmac( 'sha256', 'pow|' . $parts[0] . '.' . $parts[1], $key ), 0, 32 );
		$age    = $now - (int) $parts[0];
		if ( ! hash_equals( $signed, $parts[2] ) || $age > self::POW_MINUTES * MINUTE_IN_SECONDS || $age < -60 ) {
			return false;
		}
		return self::zero_bits( hash( 'sha256', $challenge . ':' . $nonce, true ) ) >= $bits;
	}

	/**
	 * How many zero bits a hash starts with. Pure.
	 *
	 * @param string $raw Raw hash bytes.
	 */
	public static function zero_bits( string $raw ): int {
		$bits = 0;
		foreach ( str_split( $raw ) as $byte ) {
			$value = ord( $byte );
			if ( 0 === $value ) {
				$bits += 8;
				continue;
			}
			while ( 0 === ( $value & 0x80 ) ) {
				++$bits;
				$value <<= 1;
			}
			break;
		}
		return $bits;
	}

	/**
	 * Whether a first message says nothing the agent could look up (no
	 * search words): "???", an emoji, a random string. It gets a ready line
	 * asking for more instead of an AI call (#165). Pure.
	 *
	 * @param string[] $terms What the knowledge search would look for.
	 */
	public static function says_nothing( array $terms ): bool {
		return ! array_filter( array_map( 'strval', $terms ) );
	}

	/**
	 * Whether a text is about something a person always answers in a chat
	 * (TRIPWIRE). A visitor's message that is goes to a person before any AI
	 * call (#158). Pure.
	 *
	 * @param string $text The text.
	 */
	public static function tripwire( string $text ): bool {
		return (bool) preg_match( self::TRIPWIRE, $text );
	}

	/**
	 * Whether an answer stands on at least one source the visitor may see
	 * quoted. Other customers' past answers don't count.
	 *
	 * @param array $grounded_in The draft's [ { source, quote } ].
	 */
	public static function cited( array $grounded_in ): bool {
		foreach ( $grounded_in as $cite ) {
			$source = is_array( $cite ) ? trim( (string) ( $cite['source'] ?? '' ) ) : '';
			if ( '' !== $source && 0 !== strpos( $source, 'past:' ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Words a greeting, a thanks or a goodbye is made of, in the languages
	 * visitors write most. A visitor's message made only of these may get an
	 * answer with no source; anything else must cite one.
	 */
	public const SMALL_TALK_WORDS = [ 'hi', 'hello', 'hey', 'hiya', 'yo', 'thanks', 'thank', 'you', 'thx', 'ty', 'cheers', 'ok', 'okay', 'cool', 'great', 'nice', 'perfect', 'awesome', 'bye', 'goodbye', 'good', 'morning', 'afternoon', 'evening', 'night', 'so', 'much', 'a', 'lot', 'there', 'all', 'got', 'it', 'hola', 'gracias', 'adiós', 'adios', 'bonjour', 'salut', 'merci', 'hallo', 'danke', 'tschüss', 'ciao', 'grazie', 'olá', 'ola', 'obrigado', 'obrigada', 'hej', 'tack', 'dank', 'je', 'wel' ];

	/**
	 * Small talk: the visitor only greeted, thanked or said goodbye, and the
	 * answer is short with no number and no link, so it states no price,
	 * date, order or address.
	 *
	 * @param string $visitor    The visitor's newest message.
	 * @param string $reply_html The answer.
	 */
	public static function small_talk( string $visitor, string $reply_html ): bool {
		$said  = mb_strtolower( trim( (string) preg_replace( '/[^\p{L}\s]+/u', ' ', $visitor ) ) );
		$words = '' !== $said ? preg_split( '/\s+/u', $said ) : [];
		if ( ! $words || mb_strlen( $said ) > 40 || array_diff( $words, self::SMALL_TALK_WORDS ) ) {
			return false;
		}
		$text = AgentPrompt::flatten( $reply_html );
		return '' !== $text
			&& mb_strlen( $text ) <= self::SMALL_TALK_CHARS
			&& ! preg_match( '/\p{Nd}/u', $text )
			&& ! preg_match( '~<a\b|https?:|www\.|@~i', $reply_html . ' ' . $text );
	}

	/**
	 * The key in a chat's confirmation link (#150): only the inbox of the
	 * email the visitor left gets it, so following it proves the address.
	 *
	 * @param string $thread_id The chat's thread_id.
	 * @param string $email     The email the visitor left.
	 * @param string $key       A site secret (wp_salt).
	 */
	public static function confirm_key( string $thread_id, string $email, string $key ): string {
		return substr( hash_hmac( 'sha256', 'bridle-chat-confirm|' . $thread_id . '|' . strtolower( trim( $email ) ), $key ), 0, 32 );
	}

	public static function check_confirm_key( string $thread_id, string $email, string $given, string $key ): bool {
		return '' !== $thread_id && '' !== trim( $email ) && '' !== $given && hash_equals( self::confirm_key( $thread_id, $email, $key ), $given );
	}

	/**
	 * The secret a visitor's browser keeps to continue its chat. Bound to the
	 * conversation's random thread id, so it can't be guessed from the id.
	 *
	 * @param string $thread_id The conversation's thread_id.
	 * @param string $key       A site secret (wp_salt).
	 */
	public static function token( string $thread_id, string $key ): string {
		return hash_hmac( 'sha256', 'bridle-chat|' . $thread_id, $key );
	}

	public static function check_token( string $thread_id, string $token, string $key ): bool {
		return '' !== $thread_id && '' !== $token && hash_equals( self::token( $thread_id, $key ), $token );
	}

	/**
	 * The chat's subject in the Inbox: the visitor's first line, cut at a word.
	 */
	public static function subject( string $text ): string {
		$line = trim( (string) strtok( trim( $text ), "\n" ) );
		if ( mb_strlen( $line ) <= self::SUBJECT_CHARS ) {
			return $line;
		}
		$cut   = mb_substr( $line, 0, self::SUBJECT_CHARS );
		$space = mb_strrpos( $cut, ' ' );
		return rtrim( false !== $space && $space > 40 ? mb_substr( $cut, 0, $space ) : $cut, ' ,.;:-' ) . '…';
	}

	/** Conversations needed before a reply time is promised (Intercom's rule). */
	public const REPLY_TIME_MIN_SAMPLES = 5;

	/**
	 * What to promise a visitor at handoff, from the minutes each recent
	 * conversation waited for its first reply from a person.
	 *
	 * @param float[] $minutes One value per conversation.
	 * @return array{kind: string, n: int} kind: unknown | minutes | hour | hours | day | days.
	 */
	public static function reply_time( array $minutes ): array {
		if ( count( $minutes ) < self::REPLY_TIME_MIN_SAMPLES ) {
			return [ 'kind' => 'unknown', 'n' => 0 ];
		}
		sort( $minutes );
		$mid    = intdiv( count( $minutes ), 2 );
		$median = count( $minutes ) % 2 ? $minutes[ $mid ] : ( $minutes[ $mid - 1 ] + $minutes[ $mid ] ) / 2;

		if ( $median < 15 ) {
			return [ 'kind' => 'minutes', 'n' => 0 ];
		}
		if ( $median < 90 ) {
			return [ 'kind' => 'hour', 'n' => 1 ];
		}
		if ( $median < 20 * 60 ) {
			return [ 'kind' => 'hours', 'n' => (int) ceil( $median / 60 ) ];
		}
		if ( $median < 36 * 60 ) {
			return [ 'kind' => 'day', 'n' => 1 ];
		}
		return [ 'kind' => 'days', 'n' => (int) ceil( $median / 1440 ) ];
	}

	/** Longest page address a chat keeps, in characters. */
	public const PAGE_CHARS = 500;

	/**
	 * The host a URL or browser origin names, lowercased, without a leading
	 * "www.", or '' when there is none.
	 */
	public static function host( string $url ): string {
		$host = strtolower( (string) wp_parse_url( trim( $url ), PHP_URL_HOST ) );
		return (string) preg_replace( '/^www\./', '', $host );
	}

	/**
	 * Whether a browser's Origin header is this site. No header (a server, or
	 * an old browser) passes; the limits still apply. "www." and the scheme
	 * don't count, so http/https and www/apex twins of the site pass.
	 *
	 * @param string   $origin The Origin header, e.g. https://example.com.
	 * @param string[] $hosts  This site's hosts, from host().
	 */
	public static function same_site( string $origin, array $hosts ): bool {
		$origin = trim( $origin );
		if ( '' === $origin ) {
			return true;
		}
		$host = self::host( $origin );
		return '' !== $host && in_array( $host, array_filter( $hosts ), true );
	}

	/**
	 * The page a chat started on, as the team sees it: http(s) only, without
	 * the query or fragment (where addresses and tokens hide), and only when
	 * it is on the origin that sent the request. '' when it isn't.
	 *
	 * @param string $url    location.href from the visitor's browser.
	 * @param string $origin The request's Origin header ('' when none).
	 */
	public static function page( string $url, string $origin ): string {
		$parts  = wp_parse_url( trim( $url ) );
		$scheme = strtolower( (string) ( $parts['scheme'] ?? '' ) );
		$host   = strtolower( (string) ( $parts['host'] ?? '' ) );
		if ( ! in_array( $scheme, [ 'http', 'https' ], true ) || '' === $host || preg_match( '/[^a-z0-9.\-]/', $host ) ) {
			return '';
		}
		if ( '' !== trim( $origin ) && self::host( $origin ) !== self::host( $url ) ) {
			return '';
		}
		$port = isset( $parts['port'] ) ? ':' . (int) $parts['port'] : '';
		$path = (string) preg_replace( '/[^\x21-\x7e]/', '', (string) ( $parts['path'] ?? '/' ) );
		$page = $scheme . '://' . $host . $port . ( '' !== $path ? $path : '/' );
		return strlen( $page ) <= self::PAGE_CHARS ? $page : '';
	}

	/**
	 * The visitor's address: REMOTE_ADDR, or the CF-Connecting-IP header
	 * when the request came through one of `$proxies` (#151). Anyone can send
	 * the header, so it counts only from a proxy we know.
	 *
	 * @param string   $remote  REMOTE_ADDR.
	 * @param string   $header  CF-Connecting-IP ('' when none).
	 * @param string[] $proxies CIDR ranges, e.g. CLOUDFLARE_RANGES.
	 */
	public static function visitor_ip( string $remote, string $header, array $proxies ): string {
		$header = trim( $header );
		if ( '' !== $header && filter_var( $header, FILTER_VALIDATE_IP ) ) {
			foreach ( $proxies as $range ) {
				if ( self::in_range( $remote, (string) $range ) ) {
					return $header;
				}
			}
		}
		return trim( $remote );
	}

	/**
	 * Whether an address is inside a CIDR range (IPv4 or IPv6).
	 */
	public static function in_range( string $ip, string $cidr ): bool {
		[ $net, $bits ] = array_pad( explode( '/', $cidr, 2 ), 2, '' );
		$ip_bin         = @inet_pton( trim( $ip ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- inet_pton warns on junk; false is the answer.
		$net_bin        = @inet_pton( $net ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- as above.
		if ( false === $ip_bin || false === $net_bin || strlen( $ip_bin ) !== strlen( $net_bin ) ) {
			return false;
		}
		$bits = '' === $bits ? strlen( $ip_bin ) * 8 : (int) $bits;
		if ( $bits < 0 || $bits > strlen( $ip_bin ) * 8 ) {
			return false;
		}
		$bytes = intdiv( $bits, 8 );
		if ( substr( $ip_bin, 0, $bytes ) !== substr( $net_bin, 0, $bytes ) ) {
			return false;
		}
		$rest = $bits % 8;
		if ( 0 === $rest ) {
			return true;
		}
		$mask = ( 0xff << ( 8 - $rest ) ) & 0xff;
		return ( ord( $ip_bin[ $bytes ] ) & $mask ) === ( ord( $net_bin[ $bytes ] ) & $mask );
	}

	/**
	 * What limits count by: an IPv4 address as it is, an IPv6 address by its
	 * /64 (one home or one server gets a whole /64, so rotating inside it
	 * isn't a new visitor).
	 */
	public static function bucket( string $ip ): string {
		$ip  = trim( $ip );
		$bin = @inet_pton( $ip ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- inet_pton warns on junk.
		if ( false === $bin || 16 !== strlen( $bin ) ) {
			return $ip;
		}
		// An IPv4-mapped IPv6 address is that IPv4 address.
		if ( 0 === strpos( $bin, str_repeat( "\0", 10 ) . "\xff\xff" ) ) {
			return (string) inet_ntop( substr( $bin, 12 ) );
		}
		return inet_ntop( substr( $bin, 0, 8 ) . str_repeat( "\0", 8 ) ) . '/64';
	}

	/**
	 * Whether a limit is reached, given how many there were so far.
	 */
	public static function over( int $count, int $limit ): bool {
		return $limit > 0 && $count >= $limit;
	}
}
