<?php

namespace Bridle\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The text side of the agent's knowledge: what to search for, which part of
 * a page to keep, how to rank and budget what was found, and how to strip a
 * past reply of anything personal before the model sees it.
 *
 * Pure (plain strings and arrays in and out) and unit-tested without
 * WordPress, like AgentPrompt. KnowledgeSearch does the querying.
 */
class KnowledgeText {

	/** Search terms kept per email. */
	const MAX_TERMS = 6;

	/** What a context word adds to its weight (terms()): less than half a message word. */
	const CONTEXT_WEIGHT = 0.3;

	/** A redaction token the model must never copy into a reply. */
	const PLACEHOLDER_RE = '/\[(email|link|phone|number|key|ip|name)\]/i';

	/** Rank weight per source type: docs are the most authoritative. */
	const WEIGHTS = [
		'kb'      => 1.2,
		'product' => 1.1,
		'page'    => 1.0,
		'past'    => 0.9,
		'post'    => 0.8,
	];

	/** Words that never make a useful search: grammar, greetings, support filler. */
	const STOPWORDS = 'a about after again all also am an and any are as at be because been before being best but by'
		. ' can cannot cant could dear did didnt do does doesnt doing dont each even ever for from get'
		. ' getting got had has have having hello help her here hey him his how i im if in into is isnt it'
		. ' its ive just know let like look looking make many may me might mine more most much must my need'
		. ' needs new no not now of off ok okay on once one only or other our out over please pls problem'
		. ' question really regards same see she should since so some still such sure team than thank thanks'
		. ' that the their them then there these they thing things this those though through thx to too try'
		. ' tried trying up us use using very want was way we well were what when where which while who why'
		. ' will with without work working works would yes yet you your yours cheers kind hope hi issue'
		. ' support reply email mail fwd attached attach attachment screenshot screenshots log logs below'
		. ' above following today yesterday asap urgent time times asking everything anything something';

	/**
	 * What to search for: the subject (counted twice) and the newest
	 * customer message, plus the one before it when the newest says little
	 * ("still not working").
	 *
	 * @param string[] $ignore  Words to leave out, such as the customer's own name.
	 * @param string   $context Light background, each word counted once at CONTEXT_WEIGHT: a
	 *                          chat's page title and earlier messages (#169), so "does it work
	 *                          with Divi 5?" on the Flip Box page still finds the Flip Box doc.
	 * @return string[] Up to MAX_TERMS stemmed terms, the strongest first.
	 */
	public static function terms( string $subject, string $latest, string $previous = '', array $ignore = [], string $context = '' ): array {
		$subject = (string) preg_replace( '/^\s*((re|fw|fwd|aw|sv)\s*:\s*)+/i', '', $subject );
		$subject = (string) preg_replace( '/\[#?[a-z]{2,4}-[a-z0-9]{4,8}\]/i', ' ', $subject );

		$weights = [];
		$add     = static function ( string $text, float $weight ) use ( &$weights ): void {
			foreach ( self::tokens( $text ) as $token ) {
				$weights[ $token ] = ( $weights[ $token ] ?? 0 ) + $weight;
			}
		};

		$add( $subject, 2.0 );
		$add( $latest, 1.0 );
		if ( count( self::tokens( $latest ) ) < 3 ) {
			$add( $previous, 0.5 );
		}
		foreach ( array_unique( self::tokens( $context ) ) as $token ) {
			$weights[ $token ] = ( $weights[ $token ] ?? 0 ) + self::CONTEXT_WEIGHT;
		}

		foreach ( $ignore as $word ) {
			foreach ( self::tokens( (string) $word ) as $token ) {
				unset( $weights[ $token ] );
			}
		}

		// Most mentioned first; between equals, the longer word carries more meaning.
		uksort(
			$weights,
			static fn( $a, $b ) => [ $weights[ $b ], mb_strlen( (string) $b ) ] <=> [ $weights[ $a ], mb_strlen( (string) $a ) ]
		);

		return array_slice( array_map( 'strval', array_keys( $weights ) ), 0, self::MAX_TERMS );
	}

	/** Lowercase content words with light stemming, URLs and addresses removed. */
	public static function tokens( string $text ): array {
		$text = html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$text = (string) preg_replace( '#https?://\S+|\S+@\S+#u', ' ', $text );
		$out  = [];

		$words = preg_split( '/[^\p{L}\p{N}]+/u', mb_strtolower( $text ) );
		foreach ( is_array( $words ) ? $words : [] as $word ) {
			if ( mb_strlen( $word ) < 3 || ctype_digit( $word ) || isset( self::stopwords()[ $word ] ) ) {
				continue;
			}
			$out[] = self::stem( $word );
		}

		return $out;
	}

	/** STOPWORDS as a lookup set. */
	private static function stopwords(): array {
		static $set = null;
		$set      ??= array_flip( explode( ' ', self::STOPWORDS ) );

		return $set;
	}

	/** "licenses" → "license", "installing" → "install". LIKE matching covers the rest. */
	public static function stem( string $word ): string {
		if ( mb_strlen( $word ) > 6 && str_ends_with( $word, 'ing' ) ) {
			return mb_substr( $word, 0, -3 );
		}
		if ( mb_strlen( $word ) > 4 && str_ends_with( $word, 's' ) && ! str_ends_with( $word, 'ss' ) ) {
			return mb_substr( $word, 0, -1 );
		}

		return $word;
	}

	/**
	 * A page as plain text the model can quote: links kept as "text (url)"
	 * so they survive and can be verified, shortcodes and tags removed.
	 */
	public static function plain( string $html ): string {
		$html = (string) preg_replace_callback(
			'#<a\s[^>]*href=["\'](https?://[^"\']+)["\'][^>]*>(.*?)</a>#is',
			static function ( $m ) {
				$text = trim( wp_strip_all_tags( $m[2] ) );
				return '' === $text || $text === $m[1] ? $m[1] : "{$text} ({$m[1]})";
			},
			$html
		);
		if ( function_exists( 'strip_shortcodes' ) ) {
			$html = strip_shortcodes( $html );
		}
		// Shortcodes no plugin registered in this request (Divi 4 layouts in cron).
		$html = (string) preg_replace( '#\[/?[a-z][a-z0-9_-]*(\s[^\]]*)?\]#i', ' ', $html );
		$html = (string) preg_replace( '#<(br|/p|/li|/h[1-6]|/div|/tr)\b[^>]*>#i', "$0\n", $html );
		$text = html_entity_decode( wp_strip_all_tags( $html ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$text = (string) preg_replace( '/[ \t\x{00A0}]+/u', ' ', $text );

		return trim( (string) preg_replace( '/\s*\n\s*/u', "\n", $text ) );
	}

	/**
	 * The part of a page that answers the email: the best-scoring window of
	 * about 500 characters plus its better neighbour, clipped to $max.
	 */
	public static function passage( string $html, array $terms, int $max ): string {
		$text = self::plain( $html );
		if ( mb_strlen( $text ) <= $max ) {
			return $text;
		}

		$windows = self::windows( $text, 500 );
		$scores  = array_map( static fn( $w ) => self::hits( $w, $terms ), $windows );
		$best    = (int) array_search( max( $scores ), $scores, true );

		$before = $scores[ $best - 1 ] ?? -1;
		$after  = $scores[ $best + 1 ] ?? -1;
		$pick   = $after >= $before && isset( $windows[ $best + 1 ] )
			? $windows[ $best ] . ' ' . $windows[ $best + 1 ]
			: ( isset( $windows[ $best - 1 ] ) ? $windows[ $best - 1 ] . ' ' . $windows[ $best ] : $windows[ $best ] );

		return self::clip( $pick, $max );
	}

	/**
	 * Relevance of one source to the email. Title hits count three times,
	 * body hits are capped so a long page can't win on repetition alone.
	 */
	public static function score( string $type, string $title, string $text, array $terms ): float {
		$title = mb_strtolower( $title );
		$text  = mb_strtolower( $text );
		$score = 0;

		foreach ( $terms as $term ) {
			$score += 3 * substr_count( $title, $term ) + min( 3, substr_count( $text, $term ) );
		}

		return $score * ( self::WEIGHTS[ $type ] ?? 1.0 );
	}

	/**
	 * Keep what fits the prompt: each source type's best item first (so a
	 * busy blog can't crowd out the docs), then the rest by score, within
	 * per-type caps and a total character budget.
	 *
	 * @param array $items  [ [ 'id', 'type', 'title', 'text', 'score', … ], … ].
	 * @param array $limits type => max items.
	 * @param int   $budget Total characters of text.
	 */
	public static function fit( array $items, array $limits, int $budget ): array {
		usort( $items, static fn( $a, $b ) => ( $b['score'] ?? 0 ) <=> ( $a['score'] ?? 0 ) );

		$kept  = [];
		$count = [];
		$used  = 0;
		$take  = static function ( array $item ) use ( &$kept, &$count, &$used, $limits, $budget ): void {
			$type = $item['type'];
			$size = mb_strlen( (string) ( $item['text'] ?? '' ) );
			if ( isset( $kept[ $item['id'] ] ) || ( $count[ $type ] ?? 0 ) >= ( $limits[ $type ] ?? 0 ) || $used + $size > $budget ) {
				return;
			}
			$kept[ $item['id'] ] = $item;
			$count[ $type ]      = ( $count[ $type ] ?? 0 ) + 1;
			$used               += $size;
		};

		$firsts = [];
		foreach ( $items as $item ) {
			$firsts[ $item['type'] ] ??= $item;
		}
		array_map( $take, $firsts );
		array_map( $take, $items );

		$kept = array_values( $kept );
		usort( $kept, static fn( $a, $b ) => ( $b['score'] ?? 0 ) <=> ( $a['score'] ?? 0 ) );

		return $kept;
	}

	/**
	 * A past reply with nothing personal left in it: addresses, phone
	 * numbers, order and invoice numbers, keys, IPs, the customer's name and
	 * any link to a site that isn't ours become placeholders, and the
	 * greeting line goes.
	 *
	 * @param string   $text          Plain text of a teammate reply.
	 * @param string[] $names         Name parts and the email local part of that customer.
	 * @param string[] $allowed_hosts Hosts a link may keep (the site, hosts in instructions/snippets).
	 */
	public static function redact( string $text, array $names, array $allowed_hosts ): string {
		$text = (string) preg_replace( '/^\s*(hi|hello|hey|dear|good\s+(morning|afternoon|evening)|thanks|thank\s+you)\b[^\n]*\n/iu', '', trim( $text ) );

		$hosts = array_map( static fn( $h ) => preg_replace( '/^www\./', '', mb_strtolower( (string) $h ) ), $allowed_hosts );
		$text  = (string) preg_replace_callback(
			'#\bhttps?://[^\s<>"\')]+#i',
			static function ( $m ) use ( $hosts ) {
				$host = preg_replace( '/^www\./', '', mb_strtolower( (string) wp_parse_url( $m[0], PHP_URL_HOST ) ) );
				return in_array( $host, $hosts, true ) ? $m[0] : '[link]';
			},
			$text
		);

		$text = (string) preg_replace( '/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i', '[email]', $text );
		$text = (string) preg_replace( '/\b\d{1,3}(\.\d{1,3}){3}\b/', '[ip]', $text );
		// Only a token with a digit is a number: "order details" stays as it is.
		$text = (string) preg_replace( '/\b(order|invoice|ticket|transaction|receipt|case|account)(\s*(no\.?|number|#|id))?\s*:?\s*#?\s*(?=[A-Z0-9-]*\d)[A-Z0-9-]{3,}\b/i', '$1 [number]', $text );
		$text = (string) preg_replace( '/#\d{3,}\b/', '[number]', $text );
		$text = (string) preg_replace( '/\b[A-Z0-9]{4,}(-[A-Z0-9]{4,}){2,}\b/i', '[key]', $text );
		$text = (string) preg_replace( '/\b(?=[A-Z0-9]*\d)(?=[A-Z0-9]*[A-Z])[A-Z0-9]{20,}\b/i', '[key]', $text );
		$text = (string) preg_replace( '/(?<![\w\]])\+?\d[\d\s().-]{7,}\d\b/', '[phone]', $text );

		foreach ( array_unique( array_filter( array_map( 'trim', $names ) ) ) as $name ) {
			if ( mb_strlen( $name ) >= 2 ) {
				$text = (string) preg_replace( '/\b' . preg_quote( $name, '/' ) . '\b/iu', '[name]', $text );
			}
		}

		// A thread code ties the reply to one customer's conversation.
		$text = (string) preg_replace( '/\[?#?\b[A-Z]{2,4}-[A-Z0-9]{6}\b\]?/', '', $text );

		return trim( $text );
	}

	/** The teammate reply that answers the question best: most term overlap, then the longest. */
	public static function best_reply( array $replies, array $terms ): string {
		$best       = '';
		$best_score = -1;

		foreach ( $replies as $reply ) {
			$reply = (string) $reply;
			$score = self::hits( $reply, $terms ) * 10000 + mb_strlen( $reply );
			if ( $score > $best_score ) {
				$best       = $reply;
				$best_score = $score;
			}
		}

		return $best;
	}

	/** The words that identify a customer: each part of their name and their email's local part. */
	public static function name_parts( string $name, string $email ): array {
		$parts = preg_split( '/\s+/u', trim( $name ), -1, PREG_SPLIT_NO_EMPTY );
		$local = str_contains( $email, '@' ) ? (string) strstr( $email, '@', true ) : '';

		return array_values( array_filter( array_merge( is_array( $parts ) ? $parts : [], [ $local ] ) ) );
	}

	/** How many distinct terms appear in the text. */
	public static function hits( string $text, array $terms ): int {
		$text = mb_strtolower( $text );

		return count( array_filter( $terms, static fn( $t ) => '' !== $t && str_contains( $text, (string) $t ) ) );
	}

	public static function clip( string $text, int $max ): string {
		$text = trim( $text );

		return mb_strlen( $text ) > $max ? rtrim( mb_substr( $text, 0, $max - 1 ) ) . '…' : $text;
	}

	/** Consecutive windows of about $size characters, cut on sentence or line ends. */
	private static function windows( string $text, int $size ): array {
		$parts   = preg_split( '/(?<=[.!?])\s+|\n+/u', $text );
		$parts   = is_array( $parts ) ? $parts : [ $text ];
		$windows = [];
		$current = '';

		foreach ( $parts as $part ) {
			if ( '' !== $current && mb_strlen( $current ) + mb_strlen( $part ) > $size ) {
				$windows[] = $current;
				$current   = '';
			}
			$current = trim( $current . ' ' . $part );
		}
		if ( '' !== $current ) {
			$windows[] = $current;
		}

		return $windows ? $windows : [ $text ];
	}
}
