<?php

namespace Bridle\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bridle settings — single nested store.
 *
 * All user-configurable settings (business details, notifications,
 * assignment rules, auto-reply copy, widget copy, future business-hour
 * config, etc.) live under one wp_option row: 'bridle_settings'. The
 * value is an associative array — keys map 1:1 to the public REST
 * shape the React admin sees.
 *
 * Why not many flat options? Each flat option was a separate DB row
 * and a separate read; saving the General tab fired 4–6 update_option
 * calls; option clutter made uninstall/migration brittle. One row is
 * one read, one write, one thing to delete.
 *
 * What does NOT live here:
 *   - bridle_api_key + bridle_api_key_created — auth credential, its
 *     own lifecycle (rotate / reveal-once).
 *   - bridle_onboarding_done — boolean flag distinct from settings.
 *   - bridle_db_version — internal schema marker.
 *   - Per-inbox AI settings — JSON on the inboxes table row.
 *
 * Reads are cached in a static so a single request doesn't repeatedly
 * unserialize the same blob.
 */
class Settings {

	const OPTION_KEY = 'bridle_settings';

	/**
	 * Allowlist of keys + their default values.
	 *
	 * The defaults double as documentation of every settable field.
	 * `get( $key )` returns the default when the key is absent;
	 * `update_many()` silently ignores unknown keys so REST input
	 * can't pollute the store.
	 */
	const DEFAULTS = [
		// Business
		'business_name'        => '',
		'agent_name'           => '',

		// The agent's knowledge: product facts, policies, tone, links.
		'agent_instructions'   => '',

		// What else the agent may read (KnowledgeSearch), each on unless turned off.
		'knowledge_kb'         => true,
		'knowledge_site'       => true,
		'knowledge_products'   => true,
		'knowledge_past'       => true,

		// Where team alerts go (else the admin email): "A chat needs you".
		'notification_email'   => '',

		// Conversation assignment
		'auto_assign_on_reply' => true,

		// Auto-reply
		'auto_reply_enabled'   => true,
		'auto_reply_subject'   => '',
		'auto_reply_body'      => '',

		// BCC
		'auto_bcc_email'       => '',

		// Outgoing email: the "Powered by Bridle" line, off unless the owner turns it on (WordPress.org guideline 10).
		'email_credit_enabled' => false,

		// Model per task (#133): '' = automatic (AgentService::MODELS), else
		// 'provider:model' from AiService::models(). Only for the owner's own key.
		'model_email'          => '',
		'model_chat'           => '',

		// Bridle Chat (#114): off until switched on; the inbox chats file into
		// (0 = the first active one), the first line it says, its colour.
		'chat_enabled'         => false,
		'chat_inbox_id'        => '',
		'chat_greeting'        => '',
		'chat_color'           => '',
		// The bubble's look (#142): launcher icon, corner, window size, theme.
		'chat_icon'            => 'bubble',
		'chat_position'        => 'right',
		'chat_size'            => 'large',
		'chat_theme'           => 'light',
		// The assistant (#163): its name ('' = Blake), face (a ChatWidget::FACES
		// key, or 'custom' for the owner's picture in chat_face_url), and the
		// greeting peek after chat_peek seconds on a page ('off', '15', '30',
		// '60') with a soft chime while chat_sound is on.
		'chat_agent_name'      => '',
		'chat_face'            => 'sky',
		'chat_face_url'        => '',
		'chat_peek'            => '30',
		'chat_sound'           => true,
		// Email the team (notification_email, else the admin email) when a chat needs a person.
		'chat_alerts'          => true,
		// "Powered by Bridle" under the chat, off unless the owner turns it on (guideline 10).
		'chat_credit_enabled'  => false,
	];

	private static ?array $cache = null;

	/** Return the full settings array, merged with defaults. */
	public static function all(): array {
		if ( null === self::$cache ) {
			$stored = get_option( self::OPTION_KEY, [] );
			if ( ! is_array( $stored ) ) {
				$stored = [];
			}
			self::$cache = array_merge( self::DEFAULTS, $stored );
		}
		return self::$cache;
	}

	/**
	 * Get a single setting. If $key isn't in the allowlist, returns
	 * $default (or null) — never reads from DB for unknown keys.
	 */
	public static function get( string $key, $default = null ) {
		if ( ! array_key_exists( $key, self::DEFAULTS ) ) {
			return $default;
		}
		$all = self::all();
		return array_key_exists( $key, $all ) ? $all[ $key ] : ( $default ?? self::DEFAULTS[ $key ] );
	}

	/**
	 * Set a single setting and persist. Unknown keys are dropped.
	 * Returns true if the value changed.
	 */
	public static function set( string $key, $value ): bool {
		if ( ! array_key_exists( $key, self::DEFAULTS ) ) {
			return false;
		}
		return self::update_many( [ $key => $value ] );
	}

	/**
	 * Bulk update. Unknown keys are silently dropped. Returns true if
	 * any value changed. Single update_option call, single DB write.
	 */
	public static function update_many( array $values ): bool {
		$current = self::all();
		$next    = $current;
		$changed = false;

		foreach ( $values as $key => $value ) {
			if ( ! array_key_exists( $key, self::DEFAULTS ) ) {
				continue;
			}
			if ( ( $next[ $key ] ?? null ) !== $value ) {
				$next[ $key ] = $value;
				$changed      = true;
			}
		}

		if ( $changed ) {
			update_option( self::OPTION_KEY, $next );
			self::$cache = $next;
		}

		return $changed;
	}

	/** Reset the in-process cache. */
	public static function clear_cache(): void {
		self::$cache = null;
	}
}
