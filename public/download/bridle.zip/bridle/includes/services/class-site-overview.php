<?php
/**
 * A short overview of the website for every chat (#169).
 *
 * @package Bridle
 */

namespace Bridle\Services;

defined( 'ABSPATH' ) || exit;

/**
 * What a visitor sees first: the site's name, tagline and home page as
 * rendered, menu included. A chat always gets it, so a basic question ("how
 * many plugins do you have?") has something to stand on even when the
 * keyword search finds nothing that fits (owner, 2026-11-10).
 *
 * A block theme's home page lives in its template, not in a page's content,
 * so the template is rendered here; a classic theme gives the front page's
 * content and its menus. Kept a day, forgotten when the site's pages,
 * templates, name or tagline change. Its own class because it owns that
 * cache and its hooks, like ChatAnswers.
 */
class SiteOverview {

	/** Where the overview is kept. */
	const TRANSIENT = 'bridle_site_overview';

	/** Seconds it is kept. */
	const TTL = 86400;

	/** Characters of the home page the overview keeps. */
	const HOME_CHARS = 3500;

	/** The knowledge id answers cite. */
	const ID = 'site:overview';

	/** Hooks: forget the overview when what it reads changes. */
	public static function init_hooks(): void {
		add_action( 'transition_post_status', [ self::class, 'on_post_status' ], 10, 3 );
		foreach ( [ 'blogname', 'blogdescription', 'show_on_front', 'page_on_front', 'bridle_settings' ] as $option ) {
			add_action( "update_option_{$option}", [ self::class, 'forget' ] );
		}
		add_action( 'switch_theme', [ self::class, 'forget' ] );
		add_action( 'wp_update_nav_menu', [ self::class, 'forget' ] );
		add_action( 'bridle_knowledge_changed', [ self::class, 'forget' ] );
	}

	/**
	 * The overview as a knowledge entry, or null when pages and posts are
	 * switched off as a source or there is nothing to say.
	 *
	 * @return array|null [ id, type, ref, title, url, text, date ].
	 */
	public static function entry(): ?array {
		if ( ! KnowledgeSearch::enabled( 'site' ) ) {
			return null;
		}
		$kept = get_transient( self::TRANSIENT );
		if ( ! is_array( $kept ) ) {
			$kept = [ 'text' => self::build() ];
			set_transient( self::TRANSIENT, $kept, self::TTL );
		}
		$text = (string) ( $kept['text'] ?? '' );
		if ( '' === trim( $text ) ) {
			return null;
		}
		return [
			'id'    => self::ID,
			'type'  => 'site',
			'ref'   => 'overview',
			'title' => __( 'About this website', 'bridle' ),
			'url'   => home_url( '/' ),
			'text'  => $text,
			'date'  => '',
		];
	}

	/**
	 * The overview's text. Pure.
	 *
	 * @param string $name    The site's name.
	 * @param string $tagline Its tagline.
	 * @param string $url     Its home page.
	 * @param string $home    The home page as plain text.
	 */
	public static function compose( string $name, string $tagline, string $url, string $home ): string {
		$name    = trim( $name );
		$tagline = trim( $tagline );
		$home    = trim( $home );
		if ( '' === $name && '' === $home ) {
			return '';
		}
		$head = $name . ( '' !== $tagline ? ': ' . $tagline : '' );
		$out  = trim( $head . "\n" . 'Website: ' . $url );
		if ( '' !== $home ) {
			$out .= "\n\nThe home page says:\n" . KnowledgeText::clip( $home, self::HOME_CHARS );
		}
		return $out;
	}

	/**
	 * `transition_post_status`: a page went live, changed while live, or
	 * came down; or a template the home page is built from changed.
	 *
	 * @param string   $new_status The new status.
	 * @param string   $old_status The old status.
	 * @param \WP_Post $post       The post.
	 */
	public static function on_post_status( $new_status, $old_status, $post ): void {
		$type = (string) ( $post->post_type ?? '' );
		if ( in_array( $type, [ 'wp_template', 'wp_template_part', 'wp_navigation' ], true )
			|| ( 'page' === $type && ( 'publish' === $new_status || 'publish' === $old_status ) ) ) {
			self::forget();
		}
	}

	/**
	 * Forget the overview. Hook callbacks pass arguments this ignores.
	 *
	 * @param mixed ...$unused Hook arguments.
	 */
	public static function forget( ...$unused ): void { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- hook arguments, ignored.
		delete_transient( self::TRANSIENT );
	}

	/** Read the site and compose the overview. */
	private static function build(): string {
		return self::compose(
			html_entity_decode( (string) get_bloginfo( 'name' ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ),
			html_entity_decode( (string) get_bloginfo( 'description' ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ),
			home_url( '/' ),
			self::home_text()
		);
	}

	/** The home page as plain text: a block theme's rendered template, else the front page and the menus. */
	private static function home_text(): string {
		$front = 'page' === get_option( 'show_on_front' ) ? get_post( (int) get_option( 'page_on_front' ) ) : null;
		$front = $front && 'publish' === $front->post_status && '' === (string) $front->post_password ? $front : null;
		$html  = '';

		if ( function_exists( 'wp_is_block_theme' ) && wp_is_block_theme() && function_exists( 'get_block_template' ) ) {
			foreach ( [ 'front-page', 'home' ] as $slug ) {
				$template = get_block_template( get_stylesheet() . '//' . $slug );
				if ( $template && '' !== trim( (string) $template->content ) ) {
					$html = self::render( (string) $template->content, $front );
					break;
				}
			}
		}
		if ( '' === trim( wp_strip_all_tags( $html ) ) && $front ) {
			$html = self::render( (string) $front->post_content, $front );
		}
		if ( function_exists( 'wp_is_block_theme' ) && ! wp_is_block_theme() ) {
			$html .= self::menus();
		}
		return KnowledgeText::plain( $html );
	}

	/**
	 * Blocks as HTML, with the front page as the current post so a
	 * post-content block shows it. Nothing a block prints or throws gets out.
	 *
	 * @param string        $content Block markup.
	 * @param \WP_Post|null $front   The front page, if there is one.
	 */
	private static function render( string $content, $front ): string {
		global $post;
		$before = $post;
		if ( $front ) {
			$post = $front; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- restored below; post-content needs it.
			setup_postdata( $front );
		}
		ob_start();
		try {
			$html = do_blocks( $content );
		} catch ( \Throwable $e ) {
			$html = '';
		}
		ob_end_clean();
		$post = $before; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- put back.
		if ( $front ) {
			wp_reset_postdata();
		}
		return (string) $html;
	}

	/** A classic theme's menus, as lists of links. */
	private static function menus(): string {
		$out = '';
		foreach ( array_unique( array_filter( array_map( 'intval', (array) get_nav_menu_locations() ) ) ) as $menu_id ) {
			$items = wp_get_nav_menu_items( $menu_id );
			if ( ! $items ) {
				continue;
			}
			$out .= '<ul>';
			foreach ( $items as $item ) {
				$out .= '<li><a href="' . esc_url( (string) $item->url ) . '">' . esc_html( (string) $item->title ) . '</a></li>';
			}
			$out .= '</ul>';
		}
		return $out;
	}
}
