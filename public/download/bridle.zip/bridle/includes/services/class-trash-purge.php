<?php

namespace Bridle\Services;

use Bridle\Models\Conversation;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Trash empties itself, the way Gmail's does: a conversation that has sat in
 * Trash longer than days() (30 by default) is deleted for good by the daily
 * `bridle_purge_trash` job, with its messages, attachments and drafts
 * (Conversation::hard_delete()). The same job deletes chats that never
 * reached a person after 30 days (#151).
 *
 * `trashed_at` is stamped when a conversation enters Trash
 * (Conversation::update()). Rows trashed before that column existed have it
 * empty; the first run starts their clock, so nothing older than the feature
 * disappears without its full grace period.
 */
class TrashPurge {

	/** Days a conversation stays in Trash before it is deleted for good. */
	public const DAYS = 30;

	/** Most conversations one run deletes; the next day picks up the rest. */
	public const BATCH = 200;

	/**
	 * Retention in days. 0 keeps Trash until someone empties it.
	 */
	public static function days(): int {
		/**
		 * Filter how many days a conversation stays in Trash before the daily
		 * job deletes it for good. Return 0 to keep Trash until it is emptied.
		 *
		 * @param int $days Default 30.
		 */
		return max( 0, (int) apply_filters( 'bridle_trash_days', self::DAYS ) );
	}

	/**
	 * The UTC datetime before which trashed conversations go.
	 *
	 * @param int $now  Unix time.
	 * @param int $days Retention.
	 */
	public static function cutoff( int $now, int $days ): string {
		return gmdate( 'Y-m-d H:i:s', $now - ( $days * DAY_IN_SECONDS ) );
	}

	/** Days a chat no person ever saw is kept (#151). */
	public const CHAT_DAYS = 30;

	/**
	 * The daily job: Trash, then chats no person ever saw, then Bridle
	 * Chat's old hourly counters. Returns how many conversations it deleted.
	 */
	public static function run(): int {
		$deleted  = self::empty_trash();
		$deleted += self::anonymous_chats();
		self::forget_counters();
		return $deleted;
	}

	/**
	 * Delete chats that never reached a person: no email left, Resolved, no
	 * reply from a teammate, quiet for chat_days(). They are a visitor's
	 * questions and the agent's answers, kept only for the team to look
	 * back on; nobody can find them by email to export or erase them.
	 */
	public static function anonymous_chats(): int {
		global $wpdb;

		/**
		 * Filter how many days a chat that never reached a person is kept.
		 * Return 0 to keep them.
		 *
		 * @param int $days Default 30.
		 */
		$days = max( 0, (int) apply_filters( 'bridle_chat_keep_days', self::CHAT_DAYS ) );
		if ( $days < 1 ) {
			return 0;
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- our own tables.
		$ids = array_map(
			'intval',
			(array) $wpdb->get_col(
				$wpdb->prepare(
					"SELECT c.id FROM %i c
					WHERE c.channel = 'chat' AND c.customer_id = 0 AND c.status = 'closed' AND c.last_activity_at < %s
					AND NOT EXISTS ( SELECT 1 FROM %i t WHERE t.conversation_id = c.id AND t.author_type = 'teammate' )
					ORDER BY c.id ASC LIMIT %d",
					$wpdb->prefix . 'bridle_conversations',
					self::cutoff( time(), $days ),
					$wpdb->prefix . 'bridle_threads',
					self::BATCH
				)
			)
		);
		return $ids ? ( new Conversation() )->hard_delete( $ids ) : 0;
	}

	/** Bridle Chat's site-wide counters from hours gone by (ChatService::within_hour()). */
	private static function forget_counters(): void {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- option rows only ChatService writes, never autoloaded.
		$wpdb->query(
			$wpdb->prepare(
				'DELETE FROM %i WHERE option_name LIKE %s AND option_name NOT LIKE %s',
				$wpdb->options,
				$wpdb->esc_like( ChatPolicy::HOUR_PREFIX ) . '%',
				'%' . $wpdb->esc_like( '_' . gmdate( 'YmdH' ) )
			)
		);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- the daily counters' old rows (#165).
		$wpdb->query(
			$wpdb->prepare(
				'DELETE FROM %i WHERE option_name LIKE %s AND option_name NOT LIKE %s',
				$wpdb->options,
				$wpdb->esc_like( ChatPolicy::DAY_PREFIX ) . '%',
				'%' . $wpdb->esc_like( '_' . gmdate( 'Ymd' ) )
			)
		);
	}

	/** Trash older than days(). */
	private static function empty_trash(): int {
		global $wpdb;

		$days = self::days();
		if ( $days < 1 ) {
			return 0;
		}

		$table = $wpdb->prefix . 'bridle_conversations';
		$now   = time();

		// Start the clock for rows trashed before trashed_at existed.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- our own table.
		$wpdb->query( $wpdb->prepare( 'UPDATE %i SET trashed_at = %s WHERE status = %s AND trashed_at IS NULL', $table, gmdate( 'Y-m-d H:i:s', $now ), 'trash' ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- as above.
		$ids = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM %i WHERE status = %s AND trashed_at < %s ORDER BY trashed_at ASC LIMIT %d', $table, 'trash', self::cutoff( $now, $days ), self::BATCH ) ) );

		if ( ! $ids ) {
			return 0;
		}

		return ( new Conversation() )->hard_delete( $ids );
	}
}
