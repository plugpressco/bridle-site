<?php
/**
 * Chat answers that need no AI call (#158).
 *
 * @package Bridle
 */

namespace Bridle\Services;

defined( 'ABSPATH' ) || exit;

/**
 * Bridle Chat answers without the model when the outcome is already known
 * (owner, 2026-11-10: a good product with cheap replies), so those chats
 * cost nothing and answer at once:
 *
 * - small talk (hello, thanks, bye) gets a ready-made line;
 * - a chat's first question that was answered before, word for word, on the
 *   same site, gets the same checked, cited answer again for CACHE_DAYS,
 *   until anything the agent reads changes (`bridle_knowledge_changed`).
 *
 * ChatService decides when; the handoffs that skip the model (a topic a
 * person takes, a question nothing matches) use nothing_matches() and
 * ChatPolicy::tripwire(). Its own class because ChatService is past the
 * split signal, and the cache owns its invalidation hooks.
 */
class ChatAnswers {

	/** Days a checked answer is reused (`bridle_chat_answer_cache_days`; 0 turns reuse off). */
	const CACHE_DAYS = 7;

	/** The knowledge version every cache key includes; a new one forgets them all. */
	const VERSION_OPTION = 'bridle_chat_answers_version';

	/** Transient prefix of the kept answers. */
	const PREFIX = 'bridle_chat_ans_';

	/** Longest question, in characters, whose answer is kept. */
	const QUESTION_CHARS = 300;

	/** Words a question may open or close with that don't change what it asks. */
	const EDGE_WORDS = [ 'hi', 'hello', 'hey', 'there', 'please', 'pls', 'thanks', 'thank', 'you', 'thx' ];

	/** Small talk that says hello (ChatPolicy::SMALL_TALK_WORDS has them all). */
	const HELLO = [ 'hi', 'hello', 'hey', 'hiya', 'yo', 'morning', 'afternoon', 'evening', 'hola', 'bonjour', 'salut', 'hallo', 'ciao', 'olá', 'ola', 'hej' ];

	/** Small talk that says thank you. */
	const THANKS = [ 'thanks', 'thank', 'thx', 'ty', 'cheers', 'gracias', 'merci', 'danke', 'grazie', 'obrigado', 'obrigada', 'tack', 'dank' ];

	/** Small talk that says goodbye. */
	const BYE = [ 'bye', 'goodbye', 'night', 'adiós', 'adios', 'tschüss' ];

	/** Hooks: forget every kept answer when the knowledge changes. */
	public static function init_hooks(): void {
		add_action( 'bridle_knowledge_changed', [ self::class, 'forget' ] );
		add_action( 'transition_post_status', [ self::class, 'on_post_status' ], 10, 3 );
		add_action( 'before_delete_post', [ self::class, 'on_delete_post' ], 10, 2 );
		add_action( 'update_option_bridle_settings', [ self::class, 'forget' ] );
		add_action( 'add_option_bridle_saved_replies', [ self::class, 'forget' ] );
		add_action( 'update_option_bridle_saved_replies', [ self::class, 'forget' ] );
	}

	/**
	 * What kind of small talk a message is: hello, thanks or bye, or '' when
	 * it says anything else. Pure.
	 *
	 * @param string $text The visitor's message.
	 */
	public static function small_talk( string $text ): string {
		$said  = mb_strtolower( trim( (string) preg_replace( '/[^\p{L}\s]+/u', ' ', $text ) ) );
		$words = '' !== $said ? preg_split( '/\s+/u', $said ) : [];
		if ( ! $words || mb_strlen( $said ) > 40 || array_diff( $words, ChatPolicy::SMALL_TALK_WORDS ) ) {
			return '';
		}
		if ( array_intersect( $words, self::BYE ) ) {
			return 'bye';
		}
		// "ok", "great", "got it" and the like answer something: a thanks.
		return array_intersect( $words, self::HELLO ) && ! array_intersect( $words, self::THANKS ) ? 'hello' : 'thanks';
	}

	/**
	 * The ready-made line for a kind of small talk, as HTML.
	 *
	 * @param string $kind hello | thanks | bye.
	 */
	public static function small_talk_reply( string $kind ): string {
		$lines = [
			'hello'  => __( 'Hi! What can I help you with?', 'bridle' ),
			'thanks' => __( 'You’re welcome! Anything else I can help with?', 'bridle' ),
			'bye'    => __( 'Bye! Come back any time.', 'bridle' ),
		];
		/**
		 * Filters the chat's ready-made answer to small talk.
		 *
		 * @param string $line The line, plain text.
		 * @param string $kind hello | thanks | bye.
		 */
		$line = (string) apply_filters( 'bridle_chat_small_talk_reply', $lines[ $kind ] ?? $lines['hello'], $kind );
		return '<p>' . esc_html( $line ) . '</p>';
	}

	/** The ready follow-up when nothing matches (#169): ask before a person is offered. */
	public static function follow_up_line(): string {
		return '<p>' . esc_html__( 'I couldn’t find that yet. Can you tell me a bit more about what you need?', 'bridle' ) . '</p>';
	}

	/**
	 * A question as the cache knows it: lower case, letters and digits only,
	 * a greeting, "please" or "thanks" at either end dropped. '' when it is
	 * too short or too long to keep. Pure.
	 *
	 * @param string $text The visitor's message.
	 */
	public static function question( string $text ): string {
		$text  = mb_strtolower( (string) preg_replace( '/[^\p{L}\p{Nd}]+/u', ' ', $text ) );
		$words = preg_split( '/\s+/u', trim( $text ), -1, PREG_SPLIT_NO_EMPTY );
		while ( $words && in_array( $words[0], self::EDGE_WORDS, true ) ) {
			array_shift( $words );
		}
		while ( $words && in_array( end( $words ), self::EDGE_WORDS, true ) ) {
			array_pop( $words );
		}
		$question = implode( ' ', $words );
		return count( $words ) >= 2 && mb_strlen( $question ) <= self::QUESTION_CHARS ? $question : '';
	}

	/**
	 * Whether nothing the agent would read has any of the question's words:
	 * the search found nothing, and no search word is in the instructions or
	 * the saved replies. Then its answer would only be "not sure". Pure.
	 *
	 * @param string[] $terms What the knowledge search looked for.
	 * @param int      $found How many items it found.
	 * @param string   $other The instructions and saved replies, as text.
	 */
	public static function nothing_matches( array $terms, int $found, string $other ): bool {
		$terms = array_values( array_filter( array_map( 'strval', $terms ) ) );
		if ( ! $terms || $found > 0 ) {
			return false;
		}
		$other = mb_strtolower( $other );
		foreach ( $terms as $term ) {
			if ( false !== mb_strpos( $other, mb_strtolower( $term ) ) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Where an answer is kept. Pure.
	 *
	 * @param string $question From question().
	 * @param string $site     The chat's site (host), so each site keeps its own.
	 * @param string $version  The knowledge version.
	 */
	public static function key( string $question, string $site, string $version ): string {
		return self::PREFIX . md5( $version . '|' . $site . '|' . $question );
	}

	/**
	 * The answer kept for this question on this site, or null.
	 *
	 * @param string $text The visitor's message.
	 * @param string $site The chat's site.
	 * @return array{html: string, sources: array, grounded_in: array, confidence: string, summary: string, terms: array}|null
	 */
	public static function find( string $text, string $site ): ?array {
		$question = self::question( $text );
		if ( '' === $question || ! self::days() ) {
			return null;
		}
		$kept = get_transient( self::key( $question, $site, self::version() ) );
		return is_array( $kept ) && '' !== (string) ( $kept['html'] ?? '' ) ? $kept : null;
	}

	/**
	 * Keep a checked, cited answer to a chat's first question.
	 *
	 * @param string $text   The visitor's message.
	 * @param string $site   The chat's site.
	 * @param array  $answer html, sources, grounded_in, confidence, summary, terms.
	 */
	public static function remember( string $text, string $site, array $answer ): void {
		$question = self::question( $text );
		$days     = self::days();
		if ( '' === $question || ! $days || ! ChatPolicy::cited( (array) ( $answer['grounded_in'] ?? [] ) ) ) {
			return;
		}
		set_transient( self::key( $question, $site, self::version() ), $answer, $days * DAY_IN_SECONDS );
	}

	/**
	 * Forget every kept answer: the knowledge changed. Hook callbacks pass
	 * arguments this ignores.
	 *
	 * @param mixed ...$unused Hook arguments.
	 */
	public static function forget( ...$unused ): void { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- hook arguments, ignored.
		update_option( self::VERSION_OPTION, (string) microtime( true ), true );
	}

	/**
	 * `transition_post_status`: a knowledge post was published, updated
	 * while published, or taken down.
	 *
	 * @param string   $new_status The new status.
	 * @param string   $old_status The old status.
	 * @param \WP_Post $post       The post.
	 */
	public static function on_post_status( $new_status, $old_status, $post ): void {
		if ( ( 'publish' === $new_status || 'publish' === $old_status ) && self::is_knowledge( $post ) ) {
			self::forget();
		}
	}

	/**
	 * `before_delete_post`: a published knowledge post deleted outright.
	 *
	 * @param int      $post_id The post's id.
	 * @param \WP_Post $post    The post.
	 */
	public static function on_delete_post( $post_id, $post = null ): void {
		if ( $post && 'publish' === ( $post->post_status ?? '' ) && self::is_knowledge( $post ) ) {
			self::forget();
		}
	}

	/** Whether the agent reads this kind of post (KnowledgeSearch's sources). */
	private static function is_knowledge( $post ): bool {
		$types = array_merge( [ 'docs', 'product' ], (array) apply_filters( 'bridle_knowledge_post_types', [ 'page', 'post' ] ) );
		return is_object( $post ) && in_array( (string) ( $post->post_type ?? '' ), $types, true );
	}

	/** Days an answer is kept; 0 turns reuse off. */
	private static function days(): int {
		/**
		 * Filters how many days Bridle Chat reuses a checked answer to the same
		 * first question (#158). 0 turns reuse off.
		 *
		 * @param int $days Default 7.
		 */
		return max( 0, (int) apply_filters( 'bridle_chat_answer_cache_days', self::CACHE_DAYS ) );
	}

	/** The knowledge version every key includes. */
	private static function version(): string {
		return (string) get_option( self::VERSION_OPTION, '1' );
	}
}
