<?php
/**
 * Bridle Chat (#114): a visitor's chat on the website, answered by the agent
 * from the same knowledge as email drafts, handed to a person when it isn't sure.
 *
 * @package Bridle
 */

namespace Bridle\Services;

use Bridle\Models\Conversation;
use Bridle\Models\Customer;
use Bridle\Models\Inbox;
use Bridle\Models\Thread;
use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * Every chat is a conversation (channel `chat`) in the chosen inbox. It starts
 * Resolved, so an answered chat never waits in the Inbox; a handoff gives it
 * the visitor's email and reopens it, and the team replies by email. Rules
 * live in ChatPolicy; this class does the reading and writing.
 */
class ChatService {

	/** Cloudflare Turnstile keys, kept out of bridle_settings so the secret never reaches the app. */
	public const TURNSTILE_OPTION = 'bridle_chat_turnstile';

	// phpcs:ignore PluginCheck.CodeAnalysis.Offloading.OffloadedContent -- Turnstile's server-side verify API (readme, External services), called only when the owner adds keys; no asset is loaded from it.
	private const TURNSTILE_VERIFY = 'https://challenges.cloudflare.com/turnstile/v0/siteverify';

	/** The limits after the `bridle_chat_limits` filter. */
	public static function limits(): array {
		/**
		 * Filter Bridle Chat's limits (ChatPolicy::LIMITS). 0 turns one off.
		 *
		 * @param array $limits max_chars, per_chat, per_visitor_hour, chats_per_visitor_hour,
		 *                      handoffs_per_hour, answers_per_hour (every AI call a chat
		 *                      causes, site-wide), drafts_per_chat, emails_per_hour.
		 */
		return array_map( 'intval', array_merge( ChatPolicy::LIMITS, (array) apply_filters( 'bridle_chat_limits', ChatPolicy::LIMITS ) ) );
	}

	/** The inbox chats file into: the chosen one while active, else the first active inbox, else 0. */
	public static function inbox_id(): int {
		$inboxes = ( new Inbox() )->list( [ 'is_active' => 1 ] );
		$chosen  = absint( Settings::get( 'chat_inbox_id', 0 ) );
		foreach ( $inboxes as $inbox ) {
			if ( (int) $inbox->id === $chosen ) {
				return $chosen;
			}
		}
		return $inboxes ? (int) $inboxes[0]->id : 0;
	}

	/**
	 * The inbox a new chat goes to: Settings → Chat's, unless an add-on picks
	 * another for the page it started on (#162; Bridle Pro: each other site's
	 * own inbox). An unknown or inactive inbox falls back to Settings → Chat's.
	 *
	 * @param string $page The page the chat started on ('' when unknown).
	 */
	public static function inbox_for( string $page ): int {
		$default = self::inbox_id();
		/**
		 * Filters the inbox a new chat goes to.
		 *
		 * @param int    $inbox_id Settings → Chat's inbox.
		 * @param string $page     The page the chat started on, without query or fragment ('' when unknown).
		 */
		$chosen = absint( apply_filters( 'bridle_chat_inbox', $default, $page ) );
		if ( $chosen && $chosen !== $default ) {
			$inbox = ( new Inbox() )->get_by_id( $chosen );
			if ( ! $inbox || ! (int) $inbox->is_active ) {
				return $default;
			}
		}
		return $chosen ? $chosen : $default;
	}

	/** Chat shows when it is switched on, has an inbox and an AI provider. */
	public static function ready(): bool {
		return (bool) Settings::get( 'chat_enabled', false ) && AiService::can_use_ai() && self::inbox_id() > 0;
	}

	/**
	 * Whether a browser on this origin may chat. Bridle answers its own
	 * site; an add-on (Bridle Pro) adds the other sites an owner lists.
	 *
	 * @param string $origin The request's Origin header ('' when none).
	 */
	public static function origin_allowed( string $origin ): bool {
		if ( ChatPolicy::same_site( $origin, self::hosts() ) ) {
			return true;
		}
		/**
		 * Whether Bridle Chat answers a browser on another site.
		 *
		 * @param bool   $allowed False: Bridle answers only its own site's pages.
		 * @param string $origin  The Origin header, e.g. https://shop.example.com.
		 */
		return (bool) apply_filters( 'bridle_chat_origin_allowed', false, $origin );
	}

	/** This site's hosts, as ChatPolicy::host() writes them. */
	public static function hosts(): array {
		return array_values( array_unique( array_filter( [ ChatPolicy::host( home_url() ), ChatPolicy::host( site_url() ) ] ) ) );
	}

	/** The request's Origin header, or ''. */
	public static function origin(): string {
		return null !== self::$edge ? (string) self::$edge['origin'] : (string) get_http_origin();
	}

	/**
	 * A chat the visitor's token opens, or null.
	 */
	public static function find( int $id, string $token ): ?object {
		$conversation = $id ? ( new Conversation() )->get_by_id( $id ) : null;
		if ( ! $conversation || 'chat' !== $conversation->channel || in_array( $conversation->status, [ 'spam', 'trash' ], true ) ) {
			return null;
		}
		return ChatPolicy::check_token( (string) $conversation->thread_id, $token, wp_salt( 'auth' ) ) ? $conversation : null;
	}

	/**
	 * A visitor's message: starts a chat or continues one, then answers it.
	 *
	 * @param array $input message, id, token, hp (honeypot), turnstile, page (where a new chat
	 *                     started), cid (the bubble's id for this message: a retry with the
	 *                     same one gets the first answer instead of a second one).
	 * @return array|WP_Error { id, token, answer: {id, html, sources}|null, handoff: string|null,
	 *                        waiting: bool, pending?: true while the first try is still answering }
	 */
	public static function send( array $input ) {
		$result = self::receive( $input, false );
		return is_wp_error( $result ) ? $result : $result['final'];
	}

	/**
	 * send() for Bridle AI's edge (#172), step one: everything up to the
	 * model call. The edge (ai.bridle.to) asks the model and comes back to
	 * edge_finish() with its answer, so no PHP worker waits on the AI.
	 *
	 * @param array  $input   As send().
	 * @param string $visitor The visitor's address, as the edge saw it.
	 * @param string $origin  The visitor's Origin header, as the edge saw it.
	 * @return array|WP_Error { final: send()'s result } or { ask: { system, prompt, schema, ticket, deadline_ms } }.
	 */
	public static function edge_prepare( array $input, string $visitor, string $origin ) {
		self::$edge = [
			'visitor' => $visitor,
			'origin'  => $origin,
		];
		return self::receive( $input, true );
	}

	/**
	 * Step two: the model's answer, judged and stored as send() would.
	 *
	 * @param string $ticket From edge_prepare()'s ask.
	 * @param string $raw    What the model said ('' when it didn't).
	 * @param string $error  '' or why the edge got no answer: busy, no_credits, model_failed, prompt_too_long.
	 * @return array|WP_Error { final: send()'s result, refund: bool }.
	 */
	public static function edge_finish( string $ticket, string $raw, string $error ) {
		$key  = self::EDGE_TICKET . md5( $ticket );
		$kept = '' !== $ticket ? get_transient( $key ) : false;
		delete_transient( $key );
		$conversation = is_array( $kept ) ? ( new Conversation() )->get_by_id( (int) $kept['id'] ) : null;
		if ( ! $conversation ) {
			return new WP_Error( 'bridle_chat_edge_ticket', __( 'This answer came too late.', 'bridle' ), [ 'status' => 410 ] );
		}
		$refund = false;
		if ( '' !== $error ) {
			$composed = new WP_Error( 'bridle_ai_' . sanitize_key( $error ), $error );
		} else {
			$checked  = AgentService::check( (array) $kept['prepared'], $raw );
			$composed = $checked['result'];
			$refund   = $checked['refund'];
		}
		$reply = self::judge( $conversation, (string) $kept['text'], $composed, (bool) $kept['quiet'] );
		$out   = self::after_ai( $conversation, (array) $kept['out'], (bool) $kept['quiet'], $reply );
		if ( '' !== (string) $kept['memo'] ) {
			set_transient( (string) $kept['memo'], $out, 10 * MINUTE_IN_SECONDS );
		}
		return [
			'final'  => $out,
			'refund' => $refund,
		];
	}

	/** Where an edge answer's prompt waits for the model (edge_finish()), two minutes. */
	private const EDGE_TICKET = 'bridle_chat_edge_';

	/**
	 * The visitor's address and Origin as Bridle AI's edge reported them, for
	 * the one request it signed (#172); null otherwise.
	 *
	 * @var array{visitor: string, origin: string}|null
	 */
	private static $edge = null;

	/**
	 * send(), or with $defer the edge's first step: stops before the model
	 * call and keeps what edge_finish() needs.
	 *
	 * @return array|WP_Error { final } or, with $defer, { ask }.
	 */
	private static function receive( array $input, bool $defer ) {
		$limits = self::limits();
		$text   = ChatPolicy::clean( (string) ( $input['message'] ?? '' ), $limits['max_chars'], (string) ( $input['hp'] ?? '' ) );
		if ( null === $text ) {
			return new WP_Error( 'bridle_chat_message', __( 'That message can’t be sent.', 'bridle' ), [ 'status' => 400 ] );
		}
		// The same message again (the bubble retrying after the network or a
		// proxy gave up): what the first try said, never a second answer (#151).
		$memo = self::memo_key( (string) ( $input['cid'] ?? '' ) );
		$seen = '' !== $memo ? get_transient( $memo ) : false;
		if ( is_array( $seen ) ) {
			return [ 'final' => $seen ];
		}
		if ( ChatPolicy::over( self::count( 'message' ), $limits['per_visitor_hour'] ) ) {
			return self::slow_down();
		}

		$conversation = null;
		if ( ! empty( $input['id'] ) ) {
			$conversation = self::find( absint( $input['id'] ), (string) ( $input['token'] ?? '' ) );
			if ( ! $conversation ) {
				return new WP_Error( 'bridle_chat_gone', __( 'This chat has ended. Start a new one.', 'bridle' ), [ 'status' => 403 ] );
			}
			if ( ChatPolicy::over( self::visitor_messages( (int) $conversation->id ), $limits['per_chat'] ) ) {
				return self::slow_down();
			}
		} else {
			if ( ChatPolicy::over( self::count( 'chat' ), $limits['chats_per_visitor_hour'] ) ) {
				return self::slow_down();
			}
			if ( ! self::turnstile_passes( (string) ( $input['turnstile'] ?? '' ) ) ) {
				return new WP_Error( 'bridle_chat_check', __( 'Please confirm you’re human and try again.', 'bridle' ), [ 'status' => 403 ] );
			}
			// Without Turnstile, the browser's invisible check (#165).
			if ( ! self::pow_passes( (string) ( $input['pow'] ?? '' ) ) ) {
				return new WP_Error( 'bridle_chat_pow', __( 'Something went wrong. Please try again.', 'bridle' ), [ 'status' => 403 ] );
			}
			$conversation = self::start( $text, ChatPolicy::page( (string) ( $input['page'] ?? '' ), self::origin() ) );
			if ( ! $conversation ) {
				return new WP_Error( 'bridle_chat_failed', __( 'The chat couldn’t start. Try again.', 'bridle' ), [ 'status' => 500 ] );
			}
			self::bump( 'chat' );
		}

		self::bump( 'message' );
		self::add_visitor_message( $conversation, $text );

		$out = [
			'id'      => (int) $conversation->id,
			'token'   => ChatPolicy::token( (string) $conversation->thread_id, wp_salt( 'auth' ) ),
			'answer'  => null,
			'handoff' => null,
			'waiting' => false,
		];
		if ( '' !== $memo ) {
			set_transient( $memo, $out + [ 'pending' => true ], 10 * MINUTE_IN_SECONDS );
		}
		$plan = self::before_ai( $conversation, $text, $out );
		if ( empty( $plan['ai'] ) ) {
			$out = $plan['out'];
		} elseif ( ! $defer ) {
			$out = self::after_ai( $conversation, $plan['out'], $plan['quiet'], self::answer( $conversation, $text, $plan['quiet'] ) );
		} else {
			$prepared = AgentService::prepare( $conversation, 'chat' );
			if ( ! is_wp_error( $prepared ) ) {
				$ticket = wp_generate_password( 32, false, false );
				set_transient(
					self::EDGE_TICKET . md5( $ticket ),
					[
						'id'       => (int) $conversation->id,
						'text'     => $text,
						'out'      => $plan['out'],
						'quiet'    => $plan['quiet'],
						'prepared' => $prepared,
						'memo'     => $memo,
					],
					2 * MINUTE_IN_SECONDS
				);
				return [
					'ask' => [
						'system'      => $prepared['system'],
						'prompt'      => $prepared['prompt'],
						'schema'      => AgentPrompt::schema(),
						'ticket'      => $ticket,
						'deadline_ms' => AgentService::CHAT_TIMEOUT * 1000,
					],
				];
			}
			$out = self::after_ai( $conversation, $plan['out'], $plan['quiet'], self::judge( $conversation, $text, $prepared, $plan['quiet'] ) );
		}
		if ( '' !== $memo ) {
			set_transient( $memo, $out, 10 * MINUTE_IN_SECONDS );
		}
		return [ 'final' => $out ];
	}

	/**
	 * After the visitor's message is stored, up to the model call: an
	 * answer or handoff that needs no AI, or that the agent must be asked
	 * (`ai`), and whether the chat is already with a person (`quiet`).
	 *
	 * @return array{out: array, ai?: bool, quiet?: bool}
	 */
	private static function before_ai( object $conversation, string $text, array $out ): array {
		// Handed to a person already. Until one has replied (or is here, live),
		// the agent keeps answering what it can; anything else waits for them
		// (#165: "any black friday deal?" after leaving an email).
		if ( 'active' === $conversation->status ) {
			$out['live'] = self::live( $conversation );
			if ( $out['live'] || self::person_replied( (int) $conversation->id )
				|| ( 'bridle' === AiService::source() && ! BridleAi::has_answers() ) ) {
				$out['waiting'] = true;
				return [ 'out' => $out ];
			}
			$quick = self::quick( $conversation, $text, true );
			if ( null !== $quick ) {
				return [ 'out' => self::after_ai( $conversation, $out, true, $quick ) ];
			}
			return [
				'out'   => $out,
				'ai'    => true,
				'quiet' => true,
			];
		}

		// Known already, so no AI call: small talk, a kept answer, or a
		// question a person takes (#158).
		$quick = self::quick( $conversation, $text );
		if ( null !== $quick ) {
			return [ 'out' => self::after_ai( $conversation, $out, false, $quick ) ];
		}
		if ( 'bridle' === AiService::source() && ! BridleAi::has_answers() ) {
			// Bridle AI is out of answers: straight to a person, no call (#151).
			self::note( $conversation, __( 'Bridle Chat didn’t answer: Bridle AI has no answers left (bridle_ai_empty).', 'bridle' ) );
			return [
				'out' => self::after_ai(
					$conversation,
					$out,
					false,
					[
						'answer'  => null,
						'handoff' => 'busy',
					]
				),
			];
		}
		return [
			'out'   => $out,
			'ai'    => true,
			'quiet' => false,
		];
	}

	/**
	 * With the agent's answer or handoff: what the bubble gets. Already with
	 * a person, an answer it can't give just waits; otherwise a handoff says
	 * what a person will do and when (#120).
	 *
	 * @param array $reply { answer: ?array, handoff: ?string } from quick() or answer().
	 */
	private static function after_ai( object $conversation, array $out, bool $quiet, array $reply ): array {
		if ( $quiet ) {
			if ( empty( $reply['answer'] ) ) {
				$out['waiting'] = true;
				return $out;
			}
			return array_merge( $out, $reply, [ 'handoff' => null ] );
		}
		$out = array_merge( $out, $reply );
		if ( null !== $out['handoff'] ) {
			// A person is here (an add-on says so): they take it in the chat.
			if ( self::live( $conversation ) ) {
				self::go_live( $conversation );
				$out['live'] = true;
			}
			$out['promise'] = ChatFollowUp::promise();
		}
		return $out;
	}

	/**
	 * Whether a person is here to take this chat live, in the bubble,
	 * instead of asking the visitor for an email first.
	 */
	public static function live( object $conversation ): bool {
		/**
		 * Whether a person can answer this chat live right now. Bridle has
		 * no live chat; Bridle Pro says yes while a teammate is online and
		 * within business hours.
		 *
		 * @param bool   $live         False.
		 * @param object $conversation The chat.
		 */
		return (bool) apply_filters( 'bridle_chat_live', false, $conversation );
	}

	/**
	 * Move a chat to the Inbox without a contact, for a person to answer in
	 * the bubble. The agent drafts a reply the teammate can send there.
	 */
	private static function go_live( object $conversation ): void {
		$id = (int) $conversation->id;
		( new Conversation() )->update(
			$id,
			[
				'status'    => 'active',
				'closed_at' => null,
			]
		);
		$conversation = (object) array_merge( (array) $conversation, [ 'status' => 'active' ] );
		if ( 'customer' === self::last_public_author( $id ) ) {
			AgentQueue::on_thread_added( self::last_public_thread( $id ), $id );
		} else {
			self::add_visitor_message( $conversation, __( '(Asked for a person in the chat.)', 'bridle' ) );
		}
		Counts::flush();

		/**
		 * A chat went to a person live, in the bubble.
		 *
		 * @param int $conversation_id The chat.
		 */
		do_action( 'bridle_chat_went_live', $id );
	}

	/**
	 * The visitor leaves their email: the chat gets a contact and moves to
	 * the Inbox, where the team answers by email.
	 *
	 * With `live` and no email, a person who is here takes the chat in the
	 * bubble instead (an add-on decides, see live()).
	 *
	 * @param object $conversation From find().
	 * @param array  $input        email, name, message (optional), live, turnstile.
	 * @return array|WP_Error { email, promise, live? }
	 */
	public static function handoff( object $conversation, array $input ) {
		// A handoff sends email and alerts the team, so it is checked like a
		// new chat when the owner set up Turnstile (#151).
		if ( ! self::turnstile_passes( (string) ( $input['turnstile'] ?? '' ) ) ) {
			return new WP_Error( 'bridle_chat_check', __( 'Please confirm you’re human and try again.', 'bridle' ), [ 'status' => 403 ] );
		}
		$email = sanitize_email( (string) ( $input['email'] ?? '' ) );
		if ( '' === $email && ! empty( $input['live'] ) ) {
			if ( ! self::live( $conversation ) ) {
				return new WP_Error( 'bridle_chat_offline', __( 'Leave your email and a person will reply.', 'bridle' ), [ 'status' => 409 ] );
			}
			if ( ChatPolicy::over( self::count( 'handoff' ), self::limits()['handoffs_per_hour'] ) ) {
				return self::slow_down();
			}
			self::bump( 'handoff' );
			if ( 'active' !== $conversation->status ) {
				self::go_live( $conversation );
			}
			return [
				'email'   => '',
				'live'    => true,
				'promise' => '',
			];
		}
		if ( ! is_email( $email ) || ! self::domain_takes_mail( $email ) ) {
			return new WP_Error( 'bridle_chat_email', __( 'That email address doesn’t look right.', 'bridle' ), [ 'status' => 400 ] );
		}
		if ( ChatPolicy::over( self::count( 'handoff' ), self::limits()['handoffs_per_hour'] ) ) {
			return self::slow_down();
		}
		self::bump( 'handoff' );

		$customers = new Customer();
		// A chat keeps the first email it was given (#150): anyone can type
		// one, so it never moves to another contact.
		$linked = (int) $conversation->customer_id > 0 ? $customers->get_by_id( (int) $conversation->customer_id ) : null;
		if ( $linked && strtolower( (string) $linked->email ) !== strtolower( $email ) ) {
			return new WP_Error( 'bridle_chat_email_taken', __( 'This chat already has an email. Start a new chat to use another one.', 'bridle' ), [ 'status' => 409 ] );
		}

		$name     = sanitize_text_field( mb_substr( (string) ( $input['name'] ?? '' ), 0, 80 ) );
		$customer = $customers->find_by_email( $email );
		if ( $customer ) {
			$customer_id = (int) $customer->id;
			if ( '' !== $name && '' === (string) $customer->name ) {
				$customers->update( $customer_id, [ 'name' => $name ] );
			}
		} else {
			$customer_id = (int) $customers->create(
				[
					'email' => $email,
					'name'  => '' !== $name ? $name : null,
				]
			);
		}
		if ( ! $customer_id ) {
			return new WP_Error( 'bridle_chat_failed', __( 'That didn’t work. Try again.', 'bridle' ), [ 'status' => 500 ] );
		}

		$id = (int) $conversation->id;
		// Already with a person by email; a live chat getting its first
		// email still gets the confirmation and counts for the contact.
		$already = 'active' === $conversation->status && (int) $conversation->customer_id > 0;
		( new Conversation() )->update(
			$id,
			[
				'customer_id' => $customer_id,
				'status'      => 'active',
				'closed_at'   => null,
			]
		);
		if ( ! $already ) {
			$customers->increment_conversations( $customer_id );
		}

		$note = ChatPolicy::clean( (string) ( $input['message'] ?? '' ), self::limits()['max_chars'] );
		if ( null !== $note ) {
			// Open now, so the agent drafts an email reply for the team.
			self::add_visitor_message( (object) array_merge( (array) $conversation, [ 'status' => 'active' ] ), $note );
		} elseif ( 'customer' === self::last_public_author( $id ) ) {
			AgentQueue::on_thread_added( self::last_public_thread( $id ), $id );
		} else {
			self::add_visitor_message( $conversation, __( '(Asked for a person in the chat.)', 'bridle' ) );
		}
		Counts::flush();
		if ( ! $already ) {
			ChatFollowUp::after_handoff( $id );
		}

		return [
			'email'   => $email,
			'promise' => ChatFollowUp::promise(),
		];
	}

	/**
	 * Whether the email on a conversation is known to be its customer's. Mail
	 * comes from the address itself, so any conversation that isn't a chat
	 * says yes. A chat says yes only once the visitor followed the one-time
	 * link in the confirmation email (#150): until then anyone could have
	 * typed that address, so no contact cards or store lookups for it.
	 *
	 * @param object|array $conversation A conversation row (needs channel, id, customer_id).
	 */
	public static function email_confirmed( $conversation ): bool {
		$conversation = (object) $conversation;
		if ( 'chat' !== (string) ( $conversation->channel ?? 'email' ) ) {
			return true;
		}
		$customer = ( new Customer() )->get_by_id( (int) ( $conversation->customer_id ?? 0 ) );
		if ( ! $customer || '' === (string) $customer->email ) {
			return false;
		}
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one indexed lookup; the answer changes when the visitor confirms.
		return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM %i WHERE conversation_id = %d AND author_type = 'agent' AND thread_type = 'note' AND ai_sources = %s LIMIT 1", $wpdb->prefix . 'bridle_threads', (int) $conversation->id, self::confirmed_mark( (string) $customer->email ) ) );
	}

	/**
	 * The link in a chat's confirmation email: the site's home page, where
	 * the bubble asks the visitor to tap to confirm (a mail scanner that
	 * opens links doesn't tap). '' when the chat has no email.
	 */
	public static function confirm_url( object $conversation ): string {
		$customer = ( new Customer() )->get_by_id( (int) $conversation->customer_id );
		if ( ! $customer || '' === (string) $customer->email ) {
			return '';
		}
		$key = ChatPolicy::confirm_key( (string) $conversation->thread_id, (string) $customer->email, wp_salt( 'auth' ) );
		return add_query_arg( 'bridle_confirm', (int) $conversation->id . '.' . $key, home_url( '/' ) );
	}

	/**
	 * The visitor tapped confirm: the email is theirs. Kept as a private
	 * note on the chat, so the team sees it too.
	 *
	 * @return array|WP_Error { confirmed: true }
	 */
	public static function confirm_email( int $id, string $key ) {
		if ( ChatPolicy::over( self::count( 'confirm' ), self::limits()['handoffs_per_hour'] * 3 ) ) {
			return self::slow_down();
		}
		self::bump( 'confirm' );
		$conversation = $id ? ( new Conversation() )->get_by_id( $id ) : null;
		$customer     = $conversation ? ( new Customer() )->get_by_id( (int) $conversation->customer_id ) : null;
		if ( ! $conversation || 'chat' !== $conversation->channel || ! $customer
			|| ! ChatPolicy::check_confirm_key( (string) $conversation->thread_id, (string) $customer->email, $key, wp_salt( 'auth' ) ) ) {
			return new WP_Error( 'bridle_chat_confirm', __( 'This link has expired.', 'bridle' ), [ 'status' => 403 ] );
		}
		if ( ! self::email_confirmed( $conversation ) ) {
			( new Thread() )->create(
				[
					'conversation_id' => (int) $conversation->id,
					'author_type'     => 'agent',
					'thread_type'     => 'note',
					'is_private'      => 1,
					/* translators: %s: the visitor's email */
					'content'         => sprintf( __( 'The visitor confirmed their email, %s.', 'bridle' ), (string) $customer->email ),
					'ai_sources'      => [ self::CONFIRMED => self::email_hash( (string) $customer->email ) ],
				]
			);
		}
		return [ 'confirmed' => true ];
	}

	/** The private note's mark that a chat's email was confirmed. */
	private const CONFIRMED = 'chat_email_confirmed';

	private static function email_hash( string $email ): string {
		return hash( 'sha256', strtolower( trim( $email ) ) );
	}

	/** The mark as Thread::create() stores it (wp_json_encode of ai_sources). */
	private static function confirmed_mark( string $email ): string {
		return (string) wp_json_encode( [ self::CONFIRMED => self::email_hash( $email ) ] );
	}

	/** Start a chat: a Resolved conversation with no contact yet, and the page it started on. */
	private static function start( string $text, string $page ): ?object {
		$model = new Conversation();
		$id    = $model->create(
			[
				'subject'     => ChatPolicy::subject( $text ),
				'status'      => 'closed',
				'channel'     => 'chat',
				'source_url'  => $page,
				'inbox_id'    => self::inbox_for( $page ),
				'customer_id' => 0,
			]
		);
		if ( ! $id ) {
			return null;
		}
		$model->update( $id, [ 'closed_at' => current_time( 'mysql', true ) ] );
		$conversation = $model->get_by_id( $id );

		/** This action is documented in includes/rest-api/class-inbound-email-controller.php */
		do_action( 'bridle_conversation_created', $id, $conversation, [] );

		return $conversation;
	}

	/**
	 * An answer or a handoff that needs no AI call (#158), or null to ask
	 * the agent. Small talk gets a ready-made line; a topic a person always
	 * takes, or a question nothing in the knowledge matches, goes to a person
	 * (the agent's answer would be refused anyway); a chat's first question
	 * answered before on this site gets that checked answer again.
	 *
	 * @param object $conversation The chat.
	 * @param string $text         The visitor's message.
	 * @param bool   $waiting      The chat is already with a person: no note,
	 *                             a message the agent can't answer just waits.
	 * @return array{answer: ?array, handoff: ?string}|null
	 */
	private static function quick( object $conversation, string $text, bool $waiting = false ): ?array {
		$kind = ChatAnswers::small_talk( $text );
		if ( '' !== $kind ) {
			return self::say( $conversation, ChatAnswers::small_talk_reply( $kind ), [], 'ready' );
		}

		// An answer the owner wrote for this question (Bridle Pro's training):
		// theirs to give, so it goes before the topics a person takes.
		$given = self::instant_answer( $conversation, $text );
		if ( $given ) {
			self::answered( $conversation, $given, (array) ( $given['terms'] ?? [] ), '' );
			return self::say( $conversation, $given['html'], $given['sources'], 'trained' );
		}

		if ( ChatPolicy::tripwire( $text ) ) {
			if ( ! $waiting ) {
				self::handed_over( $conversation, 'tripwire', 'tripwire', [] );
			}
			return [
				'answer'  => null,
				'handoff' => 'person',
			];
		}

		$first = 1 === self::visitor_messages( (int) $conversation->id );
		$kept  = $first ? ChatAnswers::find( $text, self::answer_scope( $conversation ) ) : null;
		if ( $kept ) {
			self::answered( $conversation, $kept, (array) ( $kept['terms'] ?? [] ), '' );
			return self::say( $conversation, (string) $kept['html'], (array) ( $kept['sources'] ?? [] ), 'cache' );
		}

		$threads = array_values(
			array_filter(
				( new Thread() )->get_by_conversation( (int) $conversation->id ),
				static fn( $t ) => empty( $t->is_private )
			)
		);
		$found   = KnowledgeSearch::for_conversation( $conversation, $threads, KnowledgeSearch::PUBLIC_SOURCES );
		$other   = (string) Settings::get( 'agent_instructions', '' );
		foreach ( AgentService::snippets() as $snippet ) {
			$other .= "\n" . $snippet['title'] . "\n" . $snippet['body'];
		}
		// A first message with nothing to look up ("???", an emoji, a random
		// string): ask for more, no AI call (#165).
		if ( $first && ChatPolicy::says_nothing( (array) $found['terms'] ) ) {
			return self::say( $conversation, '<p>' . esc_html__( 'Could you tell me a little more about what you need?', 'bridle' ) . '</p>', [], 'ready' );
		}
		if ( ChatAnswers::nothing_matches( (array) $found['terms'], count( (array) $found['items'] ), $other ) ) {
			// Ask what they mean before offering a person (#169), once a chat.
			if ( 0 === self::asked( (int) $conversation->id ) ) {
				return self::say( $conversation, ChatAnswers::follow_up_line(), [], 'ask' );
			}
			if ( ! $waiting ) {
				self::handed_over( $conversation, 'no_sources', 'unsure', (array) $found['terms'] );
			}
			return [
				'answer'  => null,
				'handoff' => 'unsure',
			];
		}
		return null;
	}

	/**
	 * An answer an add-on gives for this message without the AI, or null.
	 *
	 * @return array{html: string, sources: array, terms: array}|null
	 */
	private static function instant_answer( object $conversation, string $text ): ?array {
		/**
		 * Filters an answer given without the AI (#165): Bridle Pro's trained
		 * answers, written by the owner. Return null to let Bridle go on, or
		 * [ html, sources?: [ [ title, url ] ], terms?: string[] ]. The HTML is
		 * limited to the tags a reply may use.
		 *
		 * @param array|null $answer       Null.
		 * @param string     $text         The visitor's message.
		 * @param object     $conversation The chat.
		 */
		$given = apply_filters( 'bridle_chat_instant_answer', null, $text, $conversation );
		if ( ! is_array( $given ) ) {
			return null;
		}
		$html = trim( wp_kses( (string) ( $given['html'] ?? '' ), AgentService::REPLY_TAGS ) );
		if ( '' === $html ) {
			return null;
		}
		$sources = [];
		foreach ( array_slice( (array) ( $given['sources'] ?? [] ), 0, 3 ) as $source ) {
			$url = esc_url_raw( (string) ( $source['url'] ?? '' ) );
			if ( '' !== $url ) {
				$sources[] = [
					'title' => sanitize_text_field( (string) ( $source['title'] ?? '' ) ),
					'url'   => $url,
				];
			}
		}
		return [
			'html'    => $html,
			'sources' => $sources,
			'terms'   => array_map( 'strval', (array) ( $given['terms'] ?? [] ) ),
		];
	}

	/**
	 * A handoff decided without the agent: the note for the team, and
	 * `bridle_agent_answered` so add-ons (Pro's gaps) still hear of it.
	 *
	 * @param object   $conversation The chat.
	 * @param string   $code         Auto's reason code, for the note's words.
	 * @param string   $reason       ChatPolicy::decide()'s reason.
	 * @param string[] $terms        What the knowledge search looked for.
	 */
	private static function handed_over( object $conversation, string $code, string $reason, array $terms ): void {
		self::note(
			$conversation,
			sprintf(
				/* translators: %s: why, in Auto's words (e.g. "it found nothing to stand on") */
				__( 'Bridle Chat handed this to a person: %s.', 'bridle' ),
				AutoSend::reason_text( [ $code ] )
			)
		);
		self::answered(
			$conversation,
			[
				'confidence'         => 'low',
				'needs_human_reason' => 'no_sources' === $code ? 'Nothing in the knowledge matches.' : '',
			],
			$terms,
			$reason
		);
	}

	/**
	 * `bridle_agent_answered` for a chat answer or handoff that needed no AI
	 * call (`model` false in the context).
	 *
	 * @param object   $conversation The chat.
	 * @param array    $answer       What was shown (html, grounded_in, confidence, summary), or why not.
	 * @param string[] $terms        What the knowledge search looked for.
	 * @param string   $reason       '' when shown, else ChatPolicy::decide()'s reason.
	 */
	private static function answered( object $conversation, array $answer, array $terms, string $reason ): void {
		$shown = '' === $reason;
		/** This action is documented in includes/services/class-agent-service.php */
		do_action(
			'bridle_agent_answered',
			(int) $conversation->id,
			[
				'reply_html'         => (string) ( $answer['html'] ?? '' ),
				'confidence'         => (string) ( $answer['confidence'] ?? ( $shown ? 'high' : 'low' ) ),
				'grounded_in'        => (array) ( $answer['grounded_in'] ?? [] ),
				'flags'              => [],
				'needs_human_reason' => (string) ( $answer['needs_human_reason'] ?? '' ),
				'summary'            => (string) ( $answer['summary'] ?? '' ),
			],
			[
				'kind'     => 'chat',
				'terms'    => $terms,
				'verified' => $shown,
				'shown'    => $shown,
				'reason'   => $reason,
				'model'    => false,
			]
		);
	}

	/**
	 * Store and show an agent answer in the chat.
	 *
	 * @param object $conversation The chat.
	 * @param string $html         The answer.
	 * @param array  $sources      [ title, url ] to show under it.
	 * @param string $from         '' (the agent just wrote it), cache or ready (#158), trained (#165).
	 * @return array{answer: array, handoff: null}
	 */
	private static function say( object $conversation, string $html, array $sources, string $from ): array {
		$stored = ReplyService::add(
			(int) $conversation->id,
			[
				'content'      => wp_strip_all_tags( str_replace( '</p>', "</p>\n\n", $html ) ),
				'content_html' => $html,
				'author_type'  => 'agent',
				'agent'        => [
					'source' => 'agent',
					'via'    => 'chat',
					'answer' => $from,
				],
			]
		);
		return [
			'answer'  => [
				// The bubble remembers it, so checking for replies never shows it twice.
				'id'      => is_wp_error( $stored ) ? 0 : (int) $stored->id,
				'html'    => $html,
				'sources' => array_values( $sources ),
			],
			'handoff' => null,
		];
	}

	/** Where a kept answer may be reused: the chat's page, as answers can lean on it (#169). */
	private static function answer_scope( object $conversation ): string {
		$url = (string) ( $conversation->source_url ?? '' );
		return ChatPolicy::host( $url ) . (string) wp_parse_url( $url, PHP_URL_PATH );
	}

	/** The site a chat's AI budget counts for (#169): '' for this one, else a listed other site's host. */
	private static function budget_site( object $conversation ): string {
		$host = ChatPolicy::host( (string) ( $conversation->source_url ?? '' ) );
		if ( '' === $host || in_array( $host, self::hosts(), true ) ) {
			return '';
		}
		return self::origin_allowed( 'https://' . $host ) || self::origin_allowed( 'http://' . $host ) ? $host : '';
	}

	/** Follow-up questions the agent asked in this chat (#169). */
	private static function asked( int $conversation_id ): int {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- a live count on each chat message.
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i WHERE conversation_id = %d AND author_type = 'agent' AND ai_sources LIKE %s", $wpdb->prefix . 'bridle_threads', $conversation_id, '%' . $wpdb->esc_like( '"answer":"ask"' ) . '%' ) );
	}

	/**
	 * Ask the agent and decide whether its answer is shown.
	 *
	 * @param object $conversation The chat.
	 * @param string $text         The visitor's message.
	 * @param bool   $quiet        The chat is already with a person: no note when it doesn't answer.
	 * @return array{answer: ?array, handoff: ?string}
	 */
	private static function answer( object $conversation, string $text, bool $quiet = false ): array {
		return self::judge( $conversation, $text, AgentService::compose( $conversation, 'chat' ), $quiet );
	}

	/**
	 * Decide whether the agent's answer is shown, and store it or the note.
	 *
	 * @param object         $conversation The chat.
	 * @param string         $text         The visitor's message.
	 * @param array|WP_Error $composed     AgentService::compose()'s result.
	 * @param bool           $quiet        The chat is already with a person.
	 * @return array{answer: ?array, handoff: ?string}
	 */
	private static function judge( object $conversation, string $text, $composed, bool $quiet ): array {
		if ( is_wp_error( $composed ) ) {
			if ( ! $quiet ) {
				self::note(
					$conversation,
					'bridle_chat_busy' === $composed->get_error_code()
						? __( 'Bridle Chat didn’t answer: the chat’s hourly AI limit was reached (bridle_chat_busy).', 'bridle' )
						/* translators: %s: the error code, e.g. bridle_agent_failed */
						: sprintf( __( 'Bridle Chat couldn’t answer: the AI provider returned an error (%s).', 'bridle' ), sanitize_key( (string) $composed->get_error_code() ) )
				);
			}
			return [
				'answer'  => null,
				'handoff' => 'busy',
			];
		}

		$draft    = $composed['draft'];
		$decision = ChatPolicy::decide( $draft, $composed['problems'], $text, self::asked( (int) $conversation->id ) );

		/** This action is documented in includes/services/class-agent-service.php */
		do_action(
			'bridle_agent_answered',
			(int) $conversation->id,
			$draft,
			[
				'kind'     => 'chat',
				'terms'    => (array) ( $composed['found']['terms'] ?? [] ),
				'verified' => empty( $composed['problems'] ),
				'shown'    => (bool) $decision['answer'],
				'reason'   => (string) $decision['reason'],
			]
		);
		if ( ! $decision['answer'] ) {
			$why  = trim( (string) $draft['needs_human_reason'] );
			$code = [
				'unverified' => 'not_verified',
				'uncited'    => 'no_sources',
				'unsure'     => 'needs_human',
				'tripwire'   => 'tripwire',
			][ $decision['reason'] ] ?? 'flag';
			// Already with a person (#165): their message waits, no new note.
			if ( ! $quiet ) {
				self::note(
					$conversation,
					sprintf(
						/* translators: 1: why, in Auto's words (e.g. "not every fact checked out"), 2: the agent's note for the team */
						__( 'Bridle Chat handed this to a person: %1$s. %2$s', 'bridle' ),
						AutoSend::reason_text( [ $code ] ),
						'' !== $why ? $why : (string) $draft['summary']
					)
				);
			}
			return [
				'answer'  => null,
				'handoff' => in_array( $decision['reason'], [ 'unsure', 'unverified', 'uncited' ], true ) ? 'unsure' : 'person',
			];
		}

		// A follow-up question (#169): no sources, never kept for reuse.
		if ( $decision['ask'] ) {
			return self::say( $conversation, $draft['reply_html'], [], 'ask' );
		}
		// Answered a topic the team likes to know about (#169).
		if ( '' !== $decision['topic'] ) {
			/* translators: %s: the topic, e.g. cancellation, billing, privacy */
			self::note( $conversation, sprintf( __( 'Bridle Chat answered a question about %s from your knowledge.', 'bridle' ), $decision['topic'] ) );
		}

		$sources = [];
		foreach ( AgentPrompt::cite( $draft['grounded_in'], $composed['knowledge'] ) as $cited ) {
			$url = (string) ( $cited['url'] ?? '' );
			if ( '' !== $url && ! isset( $sources[ $url ] ) && count( $sources ) < 3 ) {
				$sources[ $url ] = [
					'title' => (string) ( $cited['title'] ?? '' ),
					'url'   => $url,
				];
			}
		}

		// A chat's first question, answered and cited: the next visitor who
		// asks it on this site gets this answer with no AI call (#158).
		if ( 1 === self::visitor_messages( (int) $conversation->id ) ) {
			ChatAnswers::remember(
				$text,
				self::answer_scope( $conversation ),
				[
					'html'        => $draft['reply_html'],
					'sources'     => array_values( $sources ),
					'grounded_in' => (array) $draft['grounded_in'],
					'confidence'  => (string) $draft['confidence'],
					'summary'     => (string) $draft['summary'],
					'terms'       => (array) ( $composed['found']['terms'] ?? [] ),
				]
			);
		}

		return self::say( $conversation, $draft['reply_html'], $sources, '' );
	}

	/** Store a visitor's message as a customer thread. */
	private static function add_visitor_message( object $conversation, string $text ): void {
		$thread_model = new Thread();
		$thread_id    = $thread_model->create(
			[
				'conversation_id' => (int) $conversation->id,
				'author_type'     => 'customer',
				'content'         => $text,
				'content_html'    => wpautop( esc_html( $text ) ),
			]
		);
		if ( ! $thread_id ) {
			return;
		}
		( new Conversation() )->update( (int) $conversation->id, [ 'last_activity_at' => current_time( 'mysql', true ) ] );

		/** This action is documented in includes/services/class-reply-service.php */
		do_action( 'bridle_thread_added', $thread_id, (int) $conversation->id, $thread_model->get_by_id( $thread_id ) );
	}

	/** A private note for the team, from the agent. */
	private static function note( object $conversation, string $text ): void {
		ReplyService::add(
			(int) $conversation->id,
			[
				'content'     => $text,
				'thread_type' => 'note',
				'author_type' => 'agent',
			]
		);
	}

	private static function visitor_messages( int $conversation_id ): int {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- a live count for the per-chat limit.
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i WHERE conversation_id = %d AND author_type = 'customer'", $wpdb->prefix . 'bridle_threads', $conversation_id ) );
	}

	private static function last_public_thread( int $conversation_id ): int {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- the newest message, read once at handoff.
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT MAX( id ) FROM %i WHERE conversation_id = %d AND is_private = 0', $wpdb->prefix . 'bridle_threads', $conversation_id ) );
	}

	/** Whether a teammate has replied in this conversation (in the chat or by email). */
	private static function person_replied( int $conversation_id ): bool {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- a live check on each chat message.
		return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT 1 FROM %i WHERE conversation_id = %d AND author_type = 'teammate' AND is_private = 0 LIMIT 1", $wpdb->prefix . 'bridle_threads', $conversation_id ) );
	}

	private static function last_public_author( int $conversation_id ): string {
		$thread = ( new Thread() )->get_by_id( self::last_public_thread( $conversation_id ) );
		return $thread ? (string) $thread->author_type : '';
	}

	/** Whether the address's domain can receive mail (MX, or an A record as mail servers fall back to). */
	private static function domain_takes_mail( string $email ): bool {
		$domain = MailHost::domain( $email );
		if ( '' === $domain || ! function_exists( 'checkdnsrr' ) ) {
			return '' !== $domain;
		}
		return checkdnsrr( $domain, 'MX' ) || checkdnsrr( $domain, 'A' );
	}

	private static function slow_down(): WP_Error {
		return new WP_Error( 'bridle_chat_limit', __( 'Too many messages. Please wait a little and try again.', 'bridle' ), [ 'status' => 429 ] );
	}

	/**
	 * Who is asking, as a hash of their address: enough to count, nothing to store.
	 */
	private static function visitor(): string {
		$remote = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		$header = isset( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) : '';
		// Through Bridle AI's edge (#172) the request comes from Cloudflare; the
		// edge signed the visitor's own address.
		if ( null !== self::$edge && filter_var( self::$edge['visitor'], FILTER_VALIDATE_IP ) ) {
			$remote = (string) self::$edge['visitor'];
			$header = '';
		}
		/**
		 * Filter the proxies whose CF-Connecting-IP header names the visitor
		 * (#151). Cloudflare's ranges by default; return [] to trust no header.
		 *
		 * @param string[] $ranges CIDR ranges.
		 */
		$proxies = (array) apply_filters( 'bridle_chat_proxy_ranges', ChatPolicy::CLOUDFLARE_RANGES );
		/**
		 * Filter the visitor address Bridle Chat counts limits by, for sites
		 * behind another proxy that puts the real one in a header.
		 *
		 * @param string $ip REMOTE_ADDR, or CF-Connecting-IP from Cloudflare.
		 */
		$ip = (string) apply_filters( 'bridle_chat_visitor_ip', ChatPolicy::visitor_ip( $remote, $header, $proxies ) );
		// An IPv6 visitor counts by their /64, so hopping inside it doesn't help.
		return substr( hash_hmac( 'sha256', ChatPolicy::bucket( $ip ), wp_salt( 'nonce' ) ), 0, 20 );
	}

	/** Where a message's first answer is kept for a retry, or '' without a usable cid. */
	private static function memo_key( string $cid ): string {
		return preg_match( '/^[A-Za-z0-9]{8,40}$/', $cid ) ? 'bridle_chat_cid_' . md5( self::visitor() . '|' . $cid ) : '';
	}

	/**
	 * Before the agent answers or drafts for a chat (AgentService::compose):
	 * one site-wide budget an hour for every AI call a chat causes, so no
	 * visitor can spend the owner's AI key or Bridle AI answers without end,
	 * and a cap on email drafts for one chat (#151).
	 *
	 * @param object $conversation A chat.
	 * @param string $kind         'chat' (an answer in the bubble) or 'email' (a draft).
	 * @return true|WP_Error bridle_chat_busy | bridle_chat_drafts
	 */
	public static function spend_ai( object $conversation, string $kind ) {
		$limits = self::limits();
		if ( 'chat' !== $kind ) {
			$key    = 'bridle_chat_drafts_' . (int) $conversation->id;
			$drafts = (int) get_transient( $key );
			if ( ChatPolicy::over( $drafts, $limits['drafts_per_chat'] ) ) {
				return new WP_Error( 'bridle_chat_drafts', __( 'This chat had its share of AI drafts. Write the reply yourself.', 'bridle' ) );
			}
			set_transient( $key, $drafts + 1, 30 * DAY_IN_SECONDS );
		}
		if ( 'chat' === $kind ) {
			// One visitor (a script rotating chats, too) can't spend the site's budget (#165).
			if ( ChatPolicy::over( self::count( 'ai' ), $limits['ai_per_visitor_hour'] ) ) {
				return new WP_Error( 'bridle_chat_busy', __( 'Bridle Chat reached its AI limit for this visitor.', 'bridle' ) );
			}
			self::bump( 'ai' );
		}
		$site   = self::budget_site( $conversation );
		$budget = '' === $site ? 'ai' : 'ai_' . substr( md5( $site ), 0, 10 );
		if ( ! self::within_hour( $budget, $limits['answers_per_hour'] ) || ! self::within_day( $budget, $limits['answers_per_day'] ) ) {
			return new WP_Error( 'bridle_chat_busy', __( 'Bridle Chat reached its AI limit for now.', 'bridle' ) );
		}
		return true;
	}

	/**
	 * Count one more of a site-wide kind this hour; whether it is still
	 * within `$limit` (0: no limit). Atomic, so a burst of requests can't all
	 * read the same count: a persistent object cache's incr, else one
	 * UPDATE on an option row (MySQL and SQLite run it as one statement).
	 *
	 * @param string $kind  ai | mail.
	 * @param int    $limit Most allowed in the hour.
	 */
	public static function within_hour( string $kind, int $limit ): bool {
		return self::within( ChatPolicy::HOUR_PREFIX . $kind . '_' . gmdate( 'YmdH' ), $limit, HOUR_IN_SECONDS );
	}

	/** Like within_hour(), for the UTC day (#165). */
	public static function within_day( string $kind, int $limit ): bool {
		return self::within( ChatPolicy::DAY_PREFIX . $kind . '_' . gmdate( 'Ymd' ), $limit, DAY_IN_SECONDS );
	}

	/** Count one more under $name, atomically; whether it is still within $limit. */
	private static function within( string $name, int $limit, int $period ): bool {
		if ( $limit < 1 ) {
			return true;
		}
		if ( wp_using_ext_object_cache() ) {
			wp_cache_add( $name, 0, 'bridle', $period + MINUTE_IN_SECONDS );
			$count = wp_cache_incr( $name, 1, 'bridle' );
			return false !== $count && $count <= $limit;
		}
		global $wpdb;
		add_option( $name, '0', '', false );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- an atomic counter; the options API can't add one in place.
		$wpdb->query( $wpdb->prepare( 'UPDATE %i SET option_value = option_value + 1 WHERE option_name = %s', $wpdb->options, $name ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- read back what this request's UPDATE made.
		$count = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT option_value FROM %i WHERE option_name = %s', $wpdb->options, $name ) );
		wp_cache_delete( $name, 'options' );
		return $count <= $limit;
	}


	/** This hour's count of one kind, for this visitor or the whole site. */
	private static function count( string $kind, string $who = '' ): int {
		return (int) get_transient( self::counter( $kind, $who ) );
	}

	private static function bump( string $kind, string $who = '' ): void {
		set_transient( self::counter( $kind, $who ), self::count( $kind, $who ) + 1, HOUR_IN_SECONDS + MINUTE_IN_SECONDS );
	}

	private static function counter( string $kind, string $who ): string {
		return 'bridle_chat_' . $kind . '_' . ( '' !== $who ? $who : self::visitor() ) . '_' . gmdate( 'YmdH' );
	}

	/** Turnstile keys without the secret: what Settings and the widget may see. */
	public static function turnstile_config(): array {
		$stored = (array) get_option( self::TURNSTILE_OPTION, [] );
		$secret = (string) ( $stored['secret'] ?? '' );
		return [
			'site_key'    => (string) ( $stored['site_key'] ?? '' ),
			'has_secret'  => '' !== $secret,
			'secret_hint' => '' !== $secret ? substr( $secret, -4 ) : '',
		];
	}

	/**
	 * Save Turnstile keys. An empty secret keeps the stored one; an empty
	 * site key turns Turnstile off and forgets both.
	 */
	public static function save_turnstile( array $input ): array {
		$site_key = sanitize_text_field( (string) ( $input['site_key'] ?? '' ) );
		$stored   = (array) get_option( self::TURNSTILE_OPTION, [] );
		if ( '' === $site_key ) {
			delete_option( self::TURNSTILE_OPTION );
			return self::turnstile_config();
		}
		$secret = sanitize_text_field( (string) ( $input['secret'] ?? '' ) );
		update_option(
			self::TURNSTILE_OPTION,
			[
				'site_key' => $site_key,
				'secret'   => '' !== $secret ? $secret : (string) ( $stored['secret'] ?? '' ),
			],
			false
		);
		return self::turnstile_config();
	}

	/** True without Turnstile keys; with them, Cloudflare must accept the token. */
	/**
	 * Zero bits the invisible check needs: none when Turnstile is set up
	 * (it does the job), else ChatPolicy::POW_BITS (`bridle_chat_pow_bits`).
	 */
	public static function pow_bits(): int {
		if ( '' !== (string) ( self::turnstile_config()['site_key'] ?? '' ) ) {
			return 0;
		}
		/**
		 * Filters how hard the invisible check is (#165): zero bits a browser's
		 * SHA-256 must start with before it may start a chat. 0 turns it off.
		 *
		 * @param int $bits Default ChatPolicy::POW_BITS.
		 */
		return max( 0, min( 24, (int) apply_filters( 'bridle_chat_pow_bits', ChatPolicy::POW_BITS ) ) );
	}

	/**
	 * A fresh challenge for the invisible check (GET /chat/challenge).
	 *
	 * @return array{challenge: string, bits: int}
	 */
	public static function challenge(): array {
		return [
			'challenge' => ChatPolicy::pow_challenge( time(), wp_generate_password( 16, false, false ), wp_salt( 'nonce' ) ),
			'bits'      => self::pow_bits(),
		];
	}

	/** Whether the browser solved the check, once per challenge. */
	private static function pow_passes( string $proof ): bool {
		$bits = self::pow_bits();
		if ( ! $bits ) {
			return true;
		}
		if ( ! ChatPolicy::pow_valid( $proof, $bits, wp_salt( 'nonce' ), time() ) ) {
			return false;
		}
		$used = 'bridle_chat_pow_' . md5( strtok( $proof, ':' ) );
		if ( get_transient( $used ) ) {
			return false;
		}
		set_transient( $used, 1, ChatPolicy::POW_MINUTES * MINUTE_IN_SECONDS );
		return true;
	}

	private static function turnstile_passes( string $token ): bool {
		$stored = (array) get_option( self::TURNSTILE_OPTION, [] );
		$secret = (string) ( $stored['secret'] ?? '' );
		if ( '' === (string) ( $stored['site_key'] ?? '' ) || '' === $secret ) {
			return true;
		}
		if ( '' === $token ) {
			return false;
		}
		$response = wp_remote_post(
			self::TURNSTILE_VERIFY,
			[
				'timeout' => 5,
				'body'    => [
					'secret'   => $secret,
					'response' => $token,
				],
			]
		);
		if ( is_wp_error( $response ) ) {
			return false;
		}
		$body = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		return is_array( $body ) && ! empty( $body['success'] );
	}
}
