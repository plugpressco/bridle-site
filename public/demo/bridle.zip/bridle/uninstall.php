<?php
/**
 * Uninstall handler.
 *
 * Deleting the plugin is intentionally NON-DESTRUCTIVE. It NEVER drops tables or
 * deletes conversations, customers, drafts, attachments, or settings. Erasing
 * data is irreversible, so it is only ever performed from an explicit, confirmed
 * "Delete all data" action inside the plugin (Settings -> Danger Zone) — never
 * silently when the plugin is removed.
 *
 * Do NOT add DROP TABLE / delete_option / remove_role calls here.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

// Intentionally a no-op.
