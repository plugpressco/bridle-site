import { useEffect, useRef } from 'react';

import { SettingsStore } from '@/components/settings/settings-store';
import { DOCK_ITEMS, Dock } from '@/components/shell/dock';
import { SEARCH_INPUT_ID } from '@/components/shell/search-box';
import { ShellProvider, useShell } from '@/components/shell/shell-context';
import { TopBar } from '@/components/shell/top-bar';
import { TooltipProvider } from '@/components/ui/tooltip';
import { navigate } from '@/lib/router';
import { useShortcuts } from '@/lib/shortcuts';
import { BoxPage } from '@/pages/box';
import { ConversationPage } from '@/pages/conversation';
import { HomePage } from '@/pages/home';
import { InboxPage } from '@/pages/inbox';
import { OnboardingPage } from '@/pages/onboarding';
import { NotFoundPage } from '@/pages/placeholder';
import { SearchPage } from '@/pages/search';
import { SettingsPage } from '@/pages/settings';
import { UpdatesPage } from '@/pages/updates';

// Keyboard map, AGENTS.md §7. j/k/↵/x belong to the list (#52).
function Shortcuts() {
	const { route, lastList } = useShell();

	useShortcuts( {
		// 1–5 jump between the boxes in the dock.
		...Object.fromEntries(
			DOCK_ITEMS.filter( ( { key } ) => key ).map( ( { box, key } ) => [
				key,
				() => navigate( '/' + box ),
			] )
		),
		'/': () => document.getElementById( SEARCH_INPUT_ID )?.focus(),
		// Esc steps back one level: from a conversation to the list it was
		// opened from, from anything else that isn't a list to the Inbox.
		escape: () => {
			if ( route.name === 'box' ) {
				return false;
			}
			if ( route.name === 'conversation' && lastList ) {
				navigate( lastList.path, lastList.query );
				return;
			}
			navigate( '/inbox' );
		},
	} );

	return null;
}

/* Onboarding takes the whole screen until the workspace is set up. */
function Frame() {
	const { onboardingDone, route, setPillSlot } = useShell();
	const main = useRef( null );

	// Only <main> scrolls (shell.css), so a route change has to reset it
	// itself: without this, Settings → Agent opens wherever Settings → Inbox
	// was scrolled to.
	useEffect( () => {
		main.current?.scrollTo( 0, 0 );
	}, [ route.path ] );

	if ( ! onboardingDone ) {
		return (
			<main className="flex min-h-0 flex-1 flex-col overflow-hidden">
				<OnboardingPage />
			</main>
		);
	}
	return (
		<SettingsStore>
			<Shortcuts />
			<TopBar />
			<main ref={ main } className="min-h-0 flex-1 overflow-y-auto">
				<Screen />
			</main>
			{ /* Where list text meets the floating pill it fades out instead of
			running under it (Apple's scroll edge effect). */ }
			<div
				aria-hidden="true"
				className="pointer-events-none absolute inset-x-0 bottom-0 z-30 h-24 bg-gradient-to-t from-background via-background/75 to-transparent"
			/>
			{ /* The floating pill slot (components/shell/floating-pill.jsx). */ }
			<div
				ref={ setPillSlot }
				className="pointer-events-none absolute inset-x-0 bottom-6 z-40 grid justify-items-center px-3"
			/>
			<Dock />
		</SettingsStore>
	);
}

function Screen() {
	const { route } = useShell();
	switch ( route.name ) {
		case 'box':
			if ( route.params.box === 'inbox' ) {
				return <InboxPage />;
			}
			if ( route.params.box === 'updates' ) {
				return <UpdatesPage />;
			}
			return (
				<BoxPage key={ route.params.box } box={ route.params.box } />
			);
		case 'home':
			return <HomePage />;
		case 'conversation':
			return (
				<ConversationPage
					key={ route.params.id }
					id={ route.params.id }
				/>
			);
		case 'settings':
			return (
				<SettingsPage
					key={ route.params.section }
					section={ route.params.section }
					inboxId={ route.params.inboxId }
				/>
			);
		case 'search':
			return <SearchPage key={ route.params.q } q={ route.params.q } />;
		default:
			return <NotFoundPage />;
	}
}

/*
 * App root of the new shell (AGENTS.md §6). Mounted into `.bridle-shell` by
 * index.js, next to the portal container (see lib/portal.js).
 */
export default function App() {
	return (
		<TooltipProvider>
			<ShellProvider>
				<Frame />
			</ShellProvider>
		</TooltipProvider>
	);
}
