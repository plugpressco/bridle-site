/**
 * Bridle admin: the shell (shadcn/ui + Tailwind, AGENTS.md §7).
 *
 * Built to build/app.js + build/app.css, which the admin page enqueues
 * (includes/admin/class-admin-page.php).
 */
import { createRoot } from 'react-dom/client';

import './styles/app.css';
import App from './app';

const root = document.getElementById( 'bridle-root' );

if ( root ) {
	// Two siblings inside the scoped root: the React mount, and the container
	// floating components portal into (see lib/portal.js). The container is
	// created here, before React renders, because the shadcn wrappers read it
	// on their first render and never re-render on open.
	const shell = document.createElement( 'div' );
	shell.className = 'bridle-shell';
	const portal = document.createElement( 'div' );
	portal.id = 'bridle-portal';
	root.replaceChildren( shell, portal );

	createRoot( shell ).render( <App /> );
}
