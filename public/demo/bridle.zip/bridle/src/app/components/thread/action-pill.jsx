import { __ } from '@wordpress/i18n';
import {
	Archive,
	ArchiveRestore,
	Merge,
	MoreHorizontal,
	RotateCcw,
	Send,
	ShieldAlert,
	ShieldCheck,
	StickyNote,
	Trash,
	UserRound,
} from 'lucide-react';

import { FloatingPill } from '@/components/shell/floating-pill';
import { useClaimPill } from '@/components/shell/shell-context';
import { Button } from '@/components/ui/button';
import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuItem,
	DropdownMenuLabel,
	DropdownMenuRadioGroup,
	DropdownMenuRadioItem,
	DropdownMenuSeparator,
	DropdownMenuSub,
	DropdownMenuSubContent,
	DropdownMenuSubTrigger,
	DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

/*
 * The sticky action pill under a conversation (AGENTS.md §6.3): Reply,
 * Note, Resolve (Reopen when resolved), and More. The keys (r, n, e) work
 * but aren't printed on the buttons; they're in the docs. Assign appears only when there is a team.
 * It holds the dock's slot while the conversation is open.
 */
export function ActionPill( { conversation, teammates, on } ) {
	const status = conversation.status;
	const isTeam = ( teammates || [] ).length > 1;
	useClaimPill();

	return (
		<FloatingPill>
			<Button size="sm" className="rounded-full" onClick={ on.reply }>
				<Send />
				{ __( 'Reply', 'bridle' ) }
			</Button>
			<Button
				size="sm"
				variant="ghost"
				className="rounded-full"
				onClick={ on.note }
			>
				<StickyNote />
				{ __( 'Note', 'bridle' ) }
			</Button>
			{ status === 'closed' ? (
				<Button
					size="sm"
					variant="ghost"
					className="rounded-full"
					onClick={ on.reopen }
				>
					<ArchiveRestore />
					{ __( 'Reopen', 'bridle' ) }
				</Button>
			) : (
				<Button
					size="sm"
					variant="ghost"
					className="rounded-full"
					onClick={ on.resolve }
				>
					<Archive />
					{ __( 'Resolve', 'bridle' ) }
				</Button>
			) }
			<DropdownMenu>
				<DropdownMenuTrigger asChild>
					<Button
						size="icon-sm"
						variant="ghost"
						className="rounded-full"
						aria-label={ __( 'More actions', 'bridle' ) }
					>
						<MoreHorizontal />
					</Button>
				</DropdownMenuTrigger>
				<DropdownMenuContent align="center" side="top" className="w-56">
					{ isTeam && (
						<DropdownMenuSub>
							<DropdownMenuSubTrigger>
								<UserRound />
								{ __( 'Assign to…', 'bridle' ) }
							</DropdownMenuSubTrigger>
							<DropdownMenuSubContent>
								<DropdownMenuRadioGroup
									value={ String(
										conversation.assigned_to || ''
									) }
									onValueChange={ ( v ) =>
										on.assign( Number( v ) || null )
									}
								>
									<DropdownMenuRadioItem value="">
										{ __( 'Nobody', 'bridle' ) }
									</DropdownMenuRadioItem>
									{ teammates.map( ( t ) => (
										<DropdownMenuRadioItem
											key={ t.id }
											value={ String( t.id ) }
										>
											{ t.display_name }
										</DropdownMenuRadioItem>
									) ) }
								</DropdownMenuRadioGroup>
							</DropdownMenuSubContent>
						</DropdownMenuSub>
					) }
					<DropdownMenuItem onSelect={ on.contact }>
						<UserRound />
						{ __( 'Open contact', 'bridle' ) }
					</DropdownMenuItem>
					<DropdownMenuItem onSelect={ on.merge }>
						<Merge />
						{ __( 'Merge into another…', 'bridle' ) }
					</DropdownMenuItem>
					<DropdownMenuSeparator />
					<DropdownMenuLabel className="text-xs text-muted-foreground">
						{ __( 'Move to', 'bridle' ) }
					</DropdownMenuLabel>
					{ status === 'spam' ? (
						<DropdownMenuItem onSelect={ on.notSpam }>
							<ShieldCheck />
							{ __( 'Not spam', 'bridle' ) }
						</DropdownMenuItem>
					) : (
						<DropdownMenuItem onSelect={ on.spam }>
							<ShieldAlert />
							{ __( 'Spam', 'bridle' ) }
						</DropdownMenuItem>
					) }
					{ status === 'trash' ? (
						<DropdownMenuItem onSelect={ on.restore }>
							<RotateCcw />
							{ __( 'Restore', 'bridle' ) }
						</DropdownMenuItem>
					) : (
						<DropdownMenuItem
							variant="destructive"
							onSelect={ on.trash }
						>
							<Trash />
							{ __( 'Trash', 'bridle' ) }
						</DropdownMenuItem>
					) }
				</DropdownMenuContent>
			</DropdownMenu>
		</FloatingPill>
	);
}
