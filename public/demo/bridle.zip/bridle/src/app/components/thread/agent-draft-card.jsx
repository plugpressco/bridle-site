import { useEffect, useState } from 'react';
import { __, sprintf } from '@wordpress/i18n';
import { Clock, Pencil, RefreshCw, Send, Square, Trash } from 'lucide-react';
import { cn } from 'cn';

import { RewriteMenu } from '@/components/thread/rewrite-menu';
import { AgentAvatar } from '@/components/ui/bridle-avatar';
import { Button } from '@/components/ui/button';
import { inboxAi } from '@/lib/api';
import {
	draftAuthor,
	readSource,
	reasonText,
	sourceHref,
	sourceLabel,
	viaText,
} from '@/lib/agent';
import { fullDateTime, parseUtc } from '@/lib/time';

const modeCache = new Map();

export const agentModeOf = ( row ) => row?.agent_mode || 'off';

/* "14:32": when a scheduled reply goes out, in the viewer's time. */
function sendTime( value ) {
	const date = parseUtc( value );
	return date
		? date.toLocaleTimeString( undefined, {
				hour: '2-digit',
				minute: '2-digit',
		  } )
		: '';
}

/*
 * Where an automatic send stands: on its way (with Send now and Stop),
 * held for a person (and why), or stopped. Nothing for a plain draft.
 */
function AutoLine( { auto, author, agentMode, busy, onSend, onStop } ) {
	if ( auto?.state === 'scheduled' ) {
		return (
			<div className="mb-4 flex flex-wrap items-center gap-2 rounded-md bg-card/80 px-3 py-2 text-sm">
				<Clock className="size-4 shrink-0 text-brand" />
				<span className="min-w-0 flex-1">
					{ sprintf(
						/* translators: 1: Bridle or the external agent's name, 2: a time like 14:32 */
						__( '%1$s will send this at %2$s.', 'bridle' ),
						author,
						sendTime( auto.send_at )
					) }
				</span>
				<Button size="sm" onClick={ onSend } disabled={ busy }>
					<Send />
					{ __( 'Send now', 'bridle' ) }
				</Button>
				<Button
					size="sm"
					variant="outline"
					onClick={ onStop }
					disabled={ busy }
				>
					<Square />
					{ __( 'Stop', 'bridle' ) }
				</Button>
			</div>
		);
	}
	if ( auto?.state === 'held' && agentMode === 'auto' ) {
		const why = reasonText( auto.reasons );
		return (
			<p className="mb-3 text-sm text-muted-foreground">
				{ why
					? sprintf(
							/* translators: %s: why, e.g. "it wasn’t sure enough" */
							__( 'Not sent automatically: %s.', 'bridle' ),
							why
					  )
					: __( 'Not sent automatically.', 'bridle' ) }
			</p>
		);
	}
	if ( auto?.state === 'stopped' ) {
		return (
			<p className="mb-3 text-sm text-muted-foreground">
				{ __( 'Stopped before sending. It’s here for you.', 'bridle' ) }
			</p>
		);
	}
	if ( auto?.state === 'failed' ) {
		return (
			<p className="mb-3 text-sm text-destructive">
				{ __(
					'The automatic send failed. Send it yourself.',
					'bridle'
				) }
			</p>
		);
	}
	return null;
}

/* The inbox's agent mode, cached per inbox for the session. */
export function useAgentMode( inboxId ) {
	const [ mode, setMode ] = useState(
		modeCache.get( Number( inboxId ) ) || null
	);
	useEffect( () => {
		if ( ! inboxId ) {
			return undefined;
		}
		if ( modeCache.has( Number( inboxId ) ) ) {
			setMode( modeCache.get( Number( inboxId ) ) );
			return undefined;
		}
		let cancelled = false;
		inboxAi
			.get( inboxId )
			.then( ( row ) => {
				modeCache.set( Number( inboxId ), agentModeOf( row ) );
				if ( ! cancelled ) {
					setMode( agentModeOf( row ) );
				}
			} )
			.catch( () => ! cancelled && setMode( 'off' ) );
		return () => {
			cancelled = true;
		};
	}, [ inboxId ] );
	return mode;
}

export function forgetAgentMode( inboxId ) {
	modeCache.delete( Number( inboxId ) );
}

const CONFIDENCE = {
	high: __( 'High confidence', 'bridle' ),
	medium: __( 'Medium confidence', 'bridle' ),
	low: __( 'Low confidence', 'bridle' ),
};

/* The one-line states (nothing drafted, failed): the agent, a sentence, one action. */
function QuietLine( { children, action, tone } ) {
	return (
		<div
			className={ cn(
				'flex items-center gap-3 text-sm',
				tone === 'error' ? 'text-destructive' : 'text-muted-foreground'
			) }
		>
			<AgentAvatar className="size-6" />
			<span className="min-w-0 flex-1">{ children }</span>
			{ action }
		</div>
	);
}

/* One cited source: what kind it is, its title (linked when it has a page) and the quote. */
function SourceItem( { source } ) {
	const href = sourceHref( source );
	const name = source.title || source.ref;
	return (
		<li className="rounded-md bg-card/70 px-3 py-2">
			<div className="mb-0.5 font-medium">
				{ sourceLabel( source.type ) }
				{ name && (
					<span className="font-normal text-muted-foreground">
						{ ' · ' }
						{ href ? (
							<a
								href={ href }
								target={
									href.startsWith( '#' )
										? undefined
										: '_blank'
								}
								rel="noopener noreferrer"
								className="underline-offset-2 hover:text-foreground hover:underline"
							>
								{ name }
							</a>
						) : (
							name
						) }
					</span>
				) }
			</div>
			{ source.quote && (
				<blockquote className="border-l-2 pl-2 text-muted-foreground">
					{ source.quote }
				</blockquote>
			) }
		</li>
	);
}

/*
 * The agent's draft, in the flow of the thread as Bridle's own letter: a
 * soft card with one line of meta in words (draft, confidence, verified),
 * the body, and quiet actions. Sources stay behind "Grounded in (n)". One
 * keystroke (`a`) opens it in the composer.
 *
 * `draft` is GET /conversations/{id}/agent-draft: { content, meta, updated_at }
 * or null. `meta.status` is 'ready' or 'failed'.
 */
export function AgentDraftCard( {
	draft,
	agentMode,
	canDraft,
	busy,
	onSend,
	onEdit,
	onRewrite,
	rewriting,
	onDiscard,
	onRetry,
	onStop,
} ) {
	const [ showSources, setShowSources ] = useState( false );

	if ( ! draft && ( ! agentMode || agentMode === 'off' ) ) {
		return null;
	}

	if ( ! draft ) {
		if ( ! canDraft ) {
			return null;
		}
		return (
			<QuietLine
				action={
					<Button
						size="sm"
						variant="ghost"
						onClick={ onRetry }
						disabled={ busy }
					>
						<RefreshCw className={ cn( busy && 'animate-spin' ) } />
						{ __( 'Draft now', 'bridle' ) }
					</Button>
				}
			>
				{ __(
					'Bridle hasn’t drafted a reply for this one.',
					'bridle'
				) }
			</QuietLine>
		);
	}

	const meta = draft.meta || {};

	if ( meta.status === 'failed' ) {
		return (
			<QuietLine
				tone="error"
				action={
					<Button
						size="sm"
						variant="ghost"
						onClick={ onRetry }
						disabled={ busy }
					>
						<RefreshCw className={ cn( busy && 'animate-spin' ) } />
						{ __( 'Try again', 'bridle' ) }
					</Button>
				}
			>
				{ __( 'Bridle could not draft a reply.', 'bridle' ) }
				{ meta.error && (
					<span className="text-muted-foreground">
						{ ' ' }
						{ meta.error }
					</span>
				) }
			</QuietLine>
		);
	}

	const sources = Array.isArray( meta.grounded_in ) ? meta.grounded_in : [];
	const problems = Array.isArray( meta.problems ) ? meta.problems : [];
	const author = draftAuthor( meta );
	const external = meta.source === 'external';
	const metaLine = [
		__( 'Draft', 'bridle' ),
		external && viaText( meta.via ),
		meta.confidence && ( CONFIDENCE[ meta.confidence ] || '' ),
		meta.verified
			? __( 'Verified', 'bridle' )
			: __( 'Not verified', 'bridle' ),
	].filter( Boolean );

	return (
		<section
			className="rounded-card border border-brand/30 bg-brand-soft/50 p-5"
			aria-label={ sprintf(
				/* translators: %s: Bridle or the external agent's name */
				__( 'Draft from %s', 'bridle' ),
				author
			) }
		>
			<header className="mb-4 flex items-center gap-3">
				<AgentAvatar className="size-9" />
				<div className="min-w-0 flex-1">
					<div className="font-medium">{ author }</div>
					<div
						className={ cn(
							'text-xs text-muted-foreground',
							! meta.verified && 'text-note-foreground'
						) }
						title={ fullDateTime( draft.updated_at ) }
					>
						{ metaLine.join( ' · ' ) }
					</div>
				</div>
			</header>

			<AutoLine
				auto={ meta.auto }
				author={ author }
				agentMode={ agentMode }
				busy={ busy }
				onSend={ onSend }
				onStop={ onStop }
			/>

			{ meta.needs_human_reason && (
				<p className="mb-3 rounded-md bg-note px-3 py-2 text-sm text-note-foreground">
					{ __( 'Wants a person to look:', 'bridle' ) }{ ' ' }
					{ meta.needs_human_reason }
				</p>
			) }
			{ problems.length > 0 && (
				<ul className="mb-3 list-disc space-y-0.5 rounded-md bg-destructive/5 px-3 py-2 pl-7 text-sm text-destructive">
					{ problems.map( ( problem, i ) => (
						<li key={ i }>{ problem }</li>
					) ) }
				</ul>
			) }

			{ /* The draft body is kses-limited HTML from AgentService. */ }
			<div
				className="bridle-prose"
				dangerouslySetInnerHTML={ { __html: draft.content } }
			/>

			{ sources.length > 0 && (
				<div className="mt-4 text-xs">
					<button
						type="button"
						className="text-muted-foreground underline-offset-2 hover:underline"
						onClick={ () => setShowSources( ( v ) => ! v ) }
					>
						{ showSources
							? __( 'Hide sources', 'bridle' )
							: __( 'Grounded in', 'bridle' ) +
							  ` (${ sources.length })` }
					</button>
					{ showSources && (
						<ul className="mt-2 space-y-1.5">
							{ sources.map( ( source, i ) => (
								<SourceItem
									key={ i }
									source={ readSource( source ) }
								/>
							) ) }
						</ul>
					) }
				</div>
			) }

			<footer className="mt-4 flex flex-wrap items-center gap-1.5">
				{ /* While a send is scheduled, Send now above is the send button. */ }
				{ meta.auto?.state !== 'scheduled' && (
					<Button size="sm" onClick={ onSend } disabled={ busy }>
						<Send />
						{ __( 'Send as is', 'bridle' ) }
					</Button>
				) }
				<Button
					size="sm"
					variant="ghost"
					onClick={ onEdit }
					disabled={ busy }
				>
					<Pencil />
					{ __( 'Edit', 'bridle' ) }
				</Button>
				{ /* The rewrite opens in the composer, with Undo back to this draft (#130). */ }
				{ onRewrite && (
					<RewriteMenu
						onPick={ onRewrite }
						busy={ rewriting }
						disabled={ busy }
						quiet={ false }
					/>
				) }
				<Button
					size="sm"
					variant="ghost"
					onClick={ onRetry }
					disabled={ busy }
				>
					<RefreshCw className={ cn( busy && 'animate-spin' ) } />
					{ __( 'Redraft', 'bridle' ) }
				</Button>
				<Button
					size="sm"
					variant="ghost"
					onClick={ onDiscard }
					disabled={ busy }
					className="ml-auto text-muted-foreground"
				>
					<Trash />
					{ __( 'Discard', 'bridle' ) }
				</Button>
			</footer>
		</section>
	);
}
