import { useState } from 'react';
import { __, sprintf } from '@wordpress/i18n';
import { ChevronDown, Paperclip, Sparkles } from 'lucide-react';
import { cn } from 'cn';

import { ContactAvatar } from '@/components/list/contact-avatar';
import { formatBytes } from '@/components/thread/composer';
import { EmailFrame } from '@/components/thread/email-frame';
import { AgentAvatar } from '@/components/ui/bridle-avatar';
import {
	Tooltip,
	TooltipContent,
	TooltipTrigger,
} from '@/components/ui/tooltip';
import { splitBody, textOf, trailingLabel } from '@/lib/body-split';
import { viaText } from '@/lib/agent';
import { chatPage, isAutoReply } from '@/lib/conversation';
import { isDesignedEmail } from '@/lib/email-html';
import { fullDateTime, relativeTime } from '@/lib/time';

function escapeHtml( text ) {
	return String( text || '' )
		.replace( /&/g, '&amp;' )
		.replace( /</g, '&lt;' )
		.replace( />/g, '&gt;' );
}

/* The message body as HTML: stored HTML, or plain text with its line breaks. */
export function bodyHtml( thread ) {
	if ( thread.content_html ) {
		return thread.content_html;
	}
	return `<p>${ escapeHtml( thread.content )
		.replace( /\n{2,}/g, '</p><p>' )
		.replace( /\n/g, '<br>' ) }</p>`;
}

/* Who wrote it, for the card header. */
export function authorOf( thread, conversation ) {
	if ( thread.author_type === 'agent' ) {
		return {
			name: thread.author_name || __( 'Bridle', 'bridle' ),
			email: '',
			avatar: '',
			agent: true,
		};
	}
	if ( thread.author_type === 'teammate' ) {
		return {
			name: thread.author_name || __( 'Teammate', 'bridle' ),
			email: thread.author_email || '',
			avatar: thread.author_avatar || '',
		};
	}
	return {
		name:
			conversation.customer_name ||
			conversation.customer_email ||
			__( 'Customer', 'bridle' ),
		email: conversation.customer_email || '',
		avatar: conversation.customer_avatar || '',
	};
}

function Body( { html } ) {
	// A designed email (newsletter, receipt, report) renders as its sender
	// built it, whole; there is no quoted history to fold in a layout.
	if ( isDesignedEmail( html ) ) {
		return <EmailFrame html={ html } />;
	}
	return <ProseBody html={ html } />;
}

function ProseBody( { html } ) {
	const [ showTail, setShowTail ] = useState( false );
	const { main, trailing, kind } = splitBody( html );
	return (
		<>
			{ /* Server-stored message HTML, the same way the legacy view rendered it. */ }
			<div
				className="bridle-prose"
				dangerouslySetInnerHTML={ { __html: main } }
			/>
			{ trailing && (
				<div className="mt-3">
					<button
						type="button"
						onClick={ () => setShowTail( ( v ) => ! v ) }
						className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs text-muted-foreground hover:bg-muted"
					>
						<ChevronDown
							className={ cn(
								'size-3 transition-transform',
								showTail && 'rotate-180'
							) }
						/>
						{ showTail
							? __( 'Hide', 'bridle' )
							: trailingLabel( kind ) }
					</button>
					{ showTail && (
						<div
							className="bridle-prose mt-3 border-l-2 pl-3 text-muted-foreground"
							dangerouslySetInnerHTML={ { __html: trailing } }
						/>
					) }
				</div>
			) }
		</>
	);
}

function Attachments( { items } ) {
	if ( ! items?.length ) {
		return null;
	}
	return (
		<ul className="mt-4 flex flex-wrap gap-2">
			{ items.map( ( file ) => (
				<li key={ file.id }>
					<a
						href={ file.url }
						target="_blank"
						rel="noopener noreferrer"
						className="inline-flex items-center gap-1.5 rounded-md bg-muted/60 px-2 py-1 text-xs hover:bg-muted"
					>
						<Paperclip className="size-3.5 text-muted-foreground" />
						<span className="max-w-56 truncate">
							{ file.filename }
						</span>
						<span className="text-muted-foreground">
							{ formatBytes( file.size_bytes ) }
						</span>
					</a>
				</li>
			) ) }
		</ul>
	);
}

/* A message's body and attachments without the card around it (Updates). */
export function MessageBody( { thread } ) {
	return (
		<>
			<Body html={ bodyHtml( thread ) } />
			<Attachments items={ thread.attachments } />
		</>
	);
}

function Avatar( { author, className } ) {
	if ( author.agent ) {
		return <AgentAvatar className={ className } />;
	}
	return (
		<ContactAvatar
			name={ author.name }
			email={ author.email }
			src={ author.avatar }
			className={ className }
		/>
	);
}

/*
 * One message as a letter, not a box: avatar, name, address and date on top,
 * the body in reading type, hairlines between letters. Older messages
 * collapse to a one-liner; notes are a soft amber block; quoted history folds.
 */
/* "sent automatically" for the agent's own sends, "via MCP" for an external agent's. */
function agentTag( thread ) {
	if ( thread.author_type !== 'agent' || ! thread.agent ) {
		return '';
	}
	if ( thread.agent.sent_by === 'external' ) {
		return viaText( thread.agent.via ) || __( 'AI agent', 'bridle' );
	}
	return thread.agent.auto ? __( 'sent automatically', 'bridle' ) : '';
}

export function MessageCard( {
	thread,
	conversation,
	inbox,
	collapsed,
	onExpand,
	pending,
} ) {
	const author = authorOf( thread, conversation );
	const isNote = thread.thread_type === 'note';
	// An out-of-office or other auto-responder: shown, muted, never to answer.
	const isAuto = isAutoReply( thread );
	const html = bodyHtml( thread );
	// Who it went to, the way a mail client says it: the inbox for the
	// customer's mail, the customer for ours. Notes go to nobody.
	let recipient = '';
	if ( ! isNote ) {
		recipient =
			thread.author_type === 'customer'
				? inbox?.email_address || ''
				: conversation.customer_email || '';
	}
	// Said in Bridle Chat (#114), not mailed: the visitor's messages that
	// came without an email, and the agent's answers there.
	const inChat =
		! isNote &&
		conversation.channel === 'chat' &&
		( ( thread.author_type === 'customer' && ! thread.email_message_id ) ||
			thread.agent?.via === 'chat' );
	const page = inChat ? chatPage( conversation ) : null;

	if ( collapsed ) {
		return (
			<button
				type="button"
				onClick={ onExpand }
				className="surface flex w-full cursor-pointer items-center gap-3 px-5 py-3 text-left opacity-80 transition-opacity hover:opacity-100"
			>
				<Avatar author={ author } className="size-7" />
				<span className="shrink-0 text-sm font-medium">
					{ author.name }
				</span>
				<span className="min-w-0 flex-1 truncate text-sm text-muted-foreground">
					{ textOf( splitBody( html ).main ).slice( 0, 160 ) }
				</span>
				<time
					className="shrink-0 text-xs text-muted-foreground tabular-nums"
					dateTime={ thread.created_at }
					title={ fullDateTime( thread.created_at ) }
				>
					{ relativeTime( thread.created_at ) }
				</time>
			</button>
		);
	}

	return (
		<article
			className={ cn(
				'px-5 py-5 sm:px-8 sm:py-7',
				isNote
					? 'rounded-card border border-note-border bg-note text-note-foreground'
					: 'surface',
				isAuto && 'opacity-70',
				pending && 'opacity-60'
			) }
		>
			<header className="mb-4 flex items-start gap-3">
				<Avatar author={ author } className="size-10" />
				<div className="min-w-0 flex-1 pt-0.5">
					<div className="flex items-baseline gap-2">
						<span className="truncate text-[15px] font-medium">
							{ author.name }
						</span>
						{ author.email && (
							<span className="truncate text-sm text-muted-foreground">
								{ author.email }
							</span>
						) }
						{ isNote && (
							<span className="text-xs font-medium tracking-wide uppercase">
								{ __( 'Note', 'bridle' ) }
							</span>
						) }
						{ isAuto && (
							<Tooltip>
								<TooltipTrigger asChild>
									<span className="rounded-full bg-muted px-2 py-0.5 text-[11px] text-muted-foreground">
										{ __( 'Automatic reply', 'bridle' ) }
									</span>
								</TooltipTrigger>
								<TooltipContent>
									{ __(
										'Their mailbox answered on its own (out of office, vacation). It does not need a reply and does not reopen the conversation.',
										'bridle'
									) }
								</TooltipContent>
							</Tooltip>
						) }
						{ agentTag( thread ) && (
							<span className="rounded-full bg-brand-soft px-2 py-0.5 text-[11px] text-brand-ink">
								{ agentTag( thread ) }
							</span>
						) }
						{ Number( thread.ai_generated ) === 1 &&
							! author.agent && (
								<Tooltip>
									<TooltipTrigger asChild>
										<span className="inline-flex self-center">
											<Sparkles
												className="size-3.5 text-brand"
												aria-label={ __(
													'Drafted by Bridle',
													'bridle'
												) }
											/>
										</span>
									</TooltipTrigger>
									<TooltipContent>
										{ __( 'Drafted by Bridle', 'bridle' ) }
									</TooltipContent>
								</Tooltip>
							) }
						{ pending && (
							<span className="text-xs text-muted-foreground">
								{ __( 'Sending…', 'bridle' ) }
							</span>
						) }
					</div>
					{ inChat && (
						<div className="truncate text-sm text-muted-foreground">
							{ page && thread.author_type === 'customer' ? (
								<>
									{ __( 'in the chat on', 'bridle' ) }{ ' ' }
									<a
										href={ page.url }
										target="_blank"
										rel="noopener noreferrer"
										className="hover:text-foreground hover:underline"
									>
										{ page.label }
									</a>
								</>
							) : (
								__( 'in the chat', 'bridle' )
							) }
						</div>
					) }
					{ recipient && ! inChat && (
						<div className="truncate text-sm text-muted-foreground">
							{ sprintf(
								/* translators: %s: the email address the message went to */
								__( 'to %s', 'bridle' ),
								recipient
							) }
						</div>
					) }
				</div>
				<time
					className="shrink-0 pt-1 text-xs text-muted-foreground"
					dateTime={ thread.created_at }
					title={ fullDateTime( thread.created_at ) }
				>
					{ pending ? '' : fullDateTime( thread.created_at ) }
				</time>
			</header>
			{ /* The letter lines up under the name, like a mail client. */ }
			<div className="sm:pl-[3.25rem]">
				<Body html={ html } />
				<Attachments items={ thread.attachments } />
			</div>
		</article>
	);
}
