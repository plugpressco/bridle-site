import { useEffect, useState } from 'react';
import { __, sprintf } from '@wordpress/i18n';
import { ExternalLink } from 'lucide-react';
import { cn } from 'cn';

import { ContactAvatar } from '@/components/list/contact-avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
	Sheet,
	SheetContent,
	SheetDescription,
	SheetHeader,
	SheetTitle,
} from '@/components/ui/sheet';
import { contactCards, customers } from '@/lib/api';
import { STATE_LABELS, stateOf } from '@/lib/conversation';
import { Link } from '@/lib/router';
import { relativeTime } from '@/lib/time';

const TONES = {
	green: 'bg-emerald-600/10 text-emerald-700',
	amber: 'bg-note text-note-foreground',
	red: 'bg-destructive/10 text-destructive',
	blue: 'bg-brand-soft text-brand-ink',
	muted: 'bg-muted text-muted-foreground',
};

function othersHeading( count ) {
	if ( ! count ) {
		return __( 'Other conversations', 'bridle' );
	}
	/* translators: %d: number of other conversations */
	return sprintf( __( '%d other conversations', 'bridle' ), count );
}

const BOX_OPTIONS = [
	[ '', __( 'Automatic', 'bridle' ) ],
	[ 'inbox', __( 'Always Inbox', 'bridle' ) ],
	[ 'feed', __( 'Always Updates', 'bridle' ) ],
];

/*
 * The contact drawer (AGENTS.md §6.3): profile, where their mail files,
 * cards from other PlugPress plugins, and their other conversations.
 */
export function ContactDrawer( {
	open,
	onOpenChange,
	conversation,
	onCustomerChange,
} ) {
	const customer = conversation.customer || {};
	const [ cards, setCards ] = useState( null );
	const [ saving, setSaving ] = useState( false );

	useEffect( () => {
		if ( open && cards === null && conversation.customer_email ) {
			contactCards
				.forEmail( conversation.customer_email )
				.then( ( rows ) =>
					setCards( Array.isArray( rows ) ? rows : [] )
				)
				.catch( () => setCards( [] ) );
		}
	}, [ open, cards, conversation.customer_email ] );

	const setBox = async ( box ) => {
		setSaving( true );
		try {
			const updated = await customers.setBox( customer.id, box || null );
			onCustomerChange?.( {
				...customer,
				box_override: updated?.box_override ?? ( box || null ),
			} );
		} finally {
			setSaving( false );
		}
	};

	const others = ( conversation.customer_conversations || [] ).filter(
		( c ) => Number( c.id ) !== Number( conversation.id )
	);

	return (
		<Sheet open={ open } onOpenChange={ onOpenChange }>
			<SheetContent className="w-96 overflow-y-auto sm:max-w-md">
				<SheetHeader className="flex-row items-center gap-3">
					<ContactAvatar
						name={ conversation.customer_name }
						email={ conversation.customer_email }
						src={ conversation.customer_avatar }
						className="size-12"
					/>
					<div className="min-w-0">
						<SheetTitle className="truncate">
							{ conversation.customer_name ||
								conversation.customer_email }
						</SheetTitle>
						<SheetDescription className="truncate">
							{ conversation.customer_email }
						</SheetDescription>
					</div>
				</SheetHeader>

				<div className="space-y-6 px-4 pb-6">
					<section>
						<h3 className="mb-2 text-xs font-semibold tracking-wide text-muted-foreground uppercase">
							{ __( 'Their mail goes to', 'bridle' ) }
						</h3>
						<div className="flex gap-1">
							{ BOX_OPTIONS.map( ( [ value, label ] ) => (
								<Button
									key={ value }
									size="sm"
									variant={
										( customer.box_override || '' ) ===
										value
											? 'secondary'
											: 'ghost'
									}
									disabled={ saving }
									onClick={ () => setBox( value ) }
								>
									{ label }
								</Button>
							) ) }
						</div>
						<p className="mt-1.5 text-xs text-muted-foreground">
							{ __(
								'Automatic files receipts, newsletters and notifications in Updates and everything else in the Inbox.',
								'bridle'
							) }
						</p>
					</section>

					{ cards === null && (
						<p className="text-sm text-muted-foreground">
							{ __( 'Loading…', 'bridle' ) }
						</p>
					) }
					{ cards?.map( ( card, i ) => (
						<section key={ i } className="rounded-lg border p-3">
							<div className="mb-2 flex items-center justify-between gap-2">
								<div className="text-sm font-medium">
									{ card.title }
								</div>
								{ card.status && (
									<Badge
										className={ cn(
											'border-transparent',
											TONES[ card.status.tone ] ||
												TONES.muted
										) }
									>
										{ card.status.label }
									</Badge>
								) }
							</div>
							<dl className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1 text-sm">
								{ ( card.rows || [] ).map(
									( [ label, value ], j ) => (
										<div key={ j } className="contents">
											<dt className="text-muted-foreground">
												{ label }
											</dt>
											<dd className="truncate">
												{ value }
											</dd>
										</div>
									)
								) }
							</dl>
							{ card.link && (
								<a
									href={ card.link }
									target="_blank"
									rel="noopener noreferrer"
									className="mt-2 inline-flex items-center gap-1 text-xs text-brand-ink hover:underline"
								>
									{ __( 'Open', 'bridle' ) }
									<ExternalLink className="size-3" />
								</a>
							) }
							<div className="mt-1 text-[11px] text-muted-foreground">
								{ card.source }
							</div>
						</section>
					) ) }

					<section>
						<h3 className="mb-2 text-xs font-semibold tracking-wide text-muted-foreground uppercase">
							{ othersHeading( others.length ) }
						</h3>
						{ ! others.length && (
							<p className="text-sm text-muted-foreground">
								{ __(
									'This is their only conversation.',
									'bridle'
								) }
							</p>
						) }
						<ul className="divide-y">
							{ others.map( ( c ) => (
								<li key={ c.id }>
									<Link
										to={ `/c/${ c.id }` }
										onClick={ () => onOpenChange( false ) }
										className="flex items-baseline gap-2 py-2 text-sm hover:underline"
									>
										<span className="min-w-0 flex-1 truncate">
											{ c.subject ||
												__( '(no subject)', 'bridle' ) }
										</span>
										<span className="text-xs text-muted-foreground">
											{ /* These rows carry no last author, so an active one reads as Open. */ }
											{ c.status === 'active'
												? STATE_LABELS.open
												: STATE_LABELS[ stateOf( c ) ] }
										</span>
										<span className="text-xs text-muted-foreground tabular-nums">
											{ relativeTime( c.created_at ) }
										</span>
									</Link>
								</li>
							) ) }
						</ul>
					</section>
				</div>
			</SheetContent>
		</Sheet>
	);
}
