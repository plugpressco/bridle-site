import { useEffect, useState } from 'react';
import { __ } from '@wordpress/i18n';

import { Button } from '@/components/ui/button';
import {
	Command,
	CommandEmpty,
	CommandInput,
	CommandItem,
	CommandList,
} from '@/components/ui/command';
import {
	Dialog,
	DialogContent,
	DialogDescription,
	DialogFooter,
	DialogHeader,
	DialogTitle,
} from '@/components/ui/dialog';
import { conversations } from '@/lib/api';

/* Pick the conversation this one merges into. Its threads move there. */
export function MergeDialog( { open, onOpenChange, conversation, onMerged } ) {
	const [ query, setQuery ] = useState( '' );
	const [ results, setResults ] = useState( [] );
	const [ target, setTarget ] = useState( null );
	const [ busy, setBusy ] = useState( false );

	useEffect( () => {
		if ( ! open ) {
			setQuery( '' );
			setTarget( null );
			return undefined;
		}
		const timer = setTimeout( () => {
			conversations
				.list( {
					search: query.trim(),
					status: 'allmail',
					per_page: 8,
				} )
				.then( ( page ) =>
					setResults(
						page.items.filter(
							( row ) =>
								Number( row.id ) !== Number( conversation.id )
						)
					)
				)
				.catch( () => setResults( [] ) );
		}, 200 );
		return () => clearTimeout( timer );
	}, [ open, query, conversation.id ] );

	const merge = async () => {
		if ( ! target ) {
			return;
		}
		setBusy( true );
		try {
			await conversations.merge( target.id, conversation.id );
			onOpenChange( false );
			onMerged( target.id );
		} finally {
			setBusy( false );
		}
	};

	return (
		<Dialog open={ open } onOpenChange={ onOpenChange }>
			<DialogContent className="p-0 sm:max-w-lg">
				<DialogHeader className="px-4 pt-4">
					<DialogTitle>
						{ __( 'Merge into another conversation', 'bridle' ) }
					</DialogTitle>
					<DialogDescription>
						{ __(
							'Every message here moves into the conversation you pick, and this one is removed.',
							'bridle'
						) }
					</DialogDescription>
				</DialogHeader>
				<Command shouldFilter={ false } className="border-t">
					<CommandInput
						placeholder={ __(
							'Search by subject or contact…',
							'bridle'
						) }
						value={ query }
						onValueChange={ setQuery }
					/>
					<CommandList>
						<CommandEmpty>
							{ __( 'Nothing matches.', 'bridle' ) }
						</CommandEmpty>
						{ results.map( ( row ) => (
							<CommandItem
								key={ row.id }
								value={ String( row.id ) }
								onSelect={ () => setTarget( row ) }
								data-checked={
									target?.id === row.id || undefined
								}
								className="data-checked:bg-accent"
							>
								<span className="truncate">
									{ row.subject ||
										__( '(no subject)', 'bridle' ) }
								</span>
								<span className="ml-auto truncate pl-3 text-xs text-muted-foreground">
									{ row.customer_name || row.customer_email }
								</span>
							</CommandItem>
						) ) }
					</CommandList>
				</Command>
				<DialogFooter className="px-4 pb-4">
					<Button
						variant="ghost"
						onClick={ () => onOpenChange( false ) }
					>
						{ __( 'Cancel', 'bridle' ) }
					</Button>
					<Button onClick={ merge } disabled={ ! target || busy }>
						{ __( 'Merge', 'bridle' ) }
					</Button>
				</DialogFooter>
			</DialogContent>
		</Dialog>
	);
}
