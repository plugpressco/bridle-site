import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { __ } from '@wordpress/i18n';

import { emailDocument } from '@/lib/email-html';

/*
 * A designed email in a frame of its own, so it looks the way its sender
 * built it: the app's CSS can't reach in and the mail's can't leak out. The
 * sandbox has no `allow-scripts`, so nothing in the mail runs; same-origin is
 * only there so the frame can be measured. Links open in a new tab.
 *
 * The frame is as tall as the mail. It is measured as the mail parses, again
 * on load (after its images), and whenever the frame changes width.
 */
export function EmailFrame( { html } ) {
	const frame = useRef( null );
	const [ height, setHeight ] = useState( 0 );
	const doc = useMemo( () => emailDocument( html ), [ html ] );

	const measure = useCallback( () => {
		const root = frame.current?.contentDocument?.documentElement;
		if ( root ) {
			setHeight( Math.ceil( root.getBoundingClientRect().height ) );
		}
	}, [] );

	// Until the frame's load event, look a few times a second, so text shows
	// at its size before the images are in.
	const [ loaded, setLoaded ] = useState( false );
	useEffect( () => {
		setLoaded( false );
	}, [ doc ] );
	useEffect( () => {
		if ( loaded ) {
			return undefined;
		}
		const timer = window.setInterval( measure, 200 );
		const stop = window.setTimeout(
			() => window.clearInterval( timer ),
			8000
		);
		return () => {
			window.clearInterval( timer );
			window.clearTimeout( stop );
		};
	}, [ loaded, measure, doc ] );

	useEffect( () => {
		const element = frame.current;
		if ( ! element || typeof window.ResizeObserver === 'undefined' ) {
			return undefined;
		}
		let width = element.offsetWidth;
		const observer = new window.ResizeObserver( () => {
			if ( element.offsetWidth !== width ) {
				width = element.offsetWidth;
				measure();
			}
		} );
		observer.observe( element );
		return () => observer.disconnect();
	}, [ measure ] );

	return (
		<iframe
			ref={ frame }
			title={ __( 'Message', 'bridle' ) }
			srcDoc={ doc }
			sandbox="allow-same-origin allow-popups allow-popups-to-escape-sandbox"
			onLoad={ () => {
				measure();
				setLoaded( true );
			} }
			className="block w-full border-0"
			style={ { height } }
		/>
	);
}
