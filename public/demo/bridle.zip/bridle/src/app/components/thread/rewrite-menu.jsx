import { useState } from 'react';
import { __ } from '@wordpress/i18n';
import { ChevronLeft, Languages, Loader2, Wand2 } from 'lucide-react';
import { cn } from 'cn';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
	Popover,
	PopoverContent,
	PopoverTrigger,
} from '@/components/ui/popover';
import { appData } from '@/lib/app-data';

/*
 * Rewrite and translate a reply (#130): one small menu in the composer and
 * on the agent's draft. `onPick( { style, language } )` runs it; language ''
 * with style 'translate' means the customer's own language, which the
 * server reads from their newest message. Hidden when nothing can answer.
 *
 * Language names go to the model in English, whatever the app's language.
 */
const STYLES = [
	[ 'shorter', __( 'Shorter', 'bridle' ) ],
	[ 'friendlier', __( 'Friendlier', 'bridle' ) ],
	[ 'formal', __( 'More formal', 'bridle' ) ],
	[ 'fix', __( 'Fix spelling and grammar', 'bridle' ) ],
];

const LANGUAGES = [
	[ 'English', __( 'English', 'bridle' ) ],
	[ 'Spanish', __( 'Spanish', 'bridle' ) ],
	[ 'French', __( 'French', 'bridle' ) ],
	[ 'German', __( 'German', 'bridle' ) ],
	[ 'Portuguese', __( 'Portuguese', 'bridle' ) ],
	[ 'Italian', __( 'Italian', 'bridle' ) ],
	[ 'Dutch', __( 'Dutch', 'bridle' ) ],
	[ 'Japanese', __( 'Japanese', 'bridle' ) ],
	[ 'Chinese (Simplified)', __( 'Chinese (Simplified)', 'bridle' ) ],
	[ 'Arabic', __( 'Arabic', 'bridle' ) ],
];

function Item( { onClick, children, className } ) {
	return (
		<button
			type="button"
			onClick={ onClick }
			className={ cn(
				'flex w-full items-center gap-2 rounded-sm px-2 py-1.5 text-left text-sm outline-none hover:bg-accent focus-visible:bg-accent',
				className
			) }
		>
			{ children }
		</button>
	);
}

export function RewriteMenu( {
	onPick,
	busy,
	disabled,
	label,
	size = 'sm',
	quiet = true,
} ) {
	const [ open, setOpen ] = useState( false );
	const [ view, setView ] = useState( 'main' );
	const [ other, setOther ] = useState( '' );

	if ( ! appData.canUseAi ) {
		return null;
	}

	const pick = ( choice ) => {
		setOpen( false );
		onPick( choice );
	};
	const text = label || __( 'Rewrite', 'bridle' );

	return (
		<Popover
			open={ open }
			onOpenChange={ ( next ) => {
				setOpen( next );
				if ( ! next ) {
					setView( 'main' );
					setOther( '' );
				}
			} }
		>
			<PopoverTrigger asChild>
				<Button
					type="button"
					size={ size }
					variant="ghost"
					className={
						quiet
							? 'text-muted-foreground hover:text-foreground'
							: undefined
					}
					disabled={ disabled || busy }
				>
					{ busy ? <Loader2 className="animate-spin" /> : <Wand2 /> }
					{ busy ? __( 'Rewriting…', 'bridle' ) : text }
				</Button>
			</PopoverTrigger>
			<PopoverContent align="start" className="w-60 p-1">
				{ view === 'main' ? (
					<div>
						{ STYLES.map( ( [ style, name ] ) => (
							<Item
								key={ style }
								onClick={ () => pick( { style } ) }
							>
								{ name }
							</Item>
						) ) }
						<div className="my-1 h-px bg-border" />
						<Item onClick={ () => setView( 'translate' ) }>
							<Languages className="size-4 text-muted-foreground" />
							{ __( 'Translate to…', 'bridle' ) }
						</Item>
					</div>
				) : (
					<div>
						<Item
							onClick={ () => setView( 'main' ) }
							className="text-muted-foreground"
						>
							<ChevronLeft className="size-4" />
							{ __( 'Back', 'bridle' ) }
						</Item>
						<Item
							onClick={ () =>
								pick( { style: 'translate', language: '' } )
							}
							className="font-medium"
						>
							{ __( 'The customer’s language', 'bridle' ) }
						</Item>
						<div className="max-h-56 overflow-y-auto">
							{ LANGUAGES.map( ( [ language, name ] ) => (
								<Item
									key={ language }
									onClick={ () =>
										pick( { style: 'translate', language } )
									}
								>
									{ name }
								</Item>
							) ) }
						</div>
						<form
							className="flex gap-1.5 p-1 pt-2"
							onSubmit={ ( event ) => {
								event.preventDefault();
								if ( other.trim() ) {
									pick( {
										style: 'translate',
										language: other.trim(),
									} );
								}
							} }
						>
							<Input
								value={ other }
								onChange={ ( event ) =>
									setOther( event.target.value )
								}
								maxLength={ 40 }
								placeholder={ __( 'Other language', 'bridle' ) }
								aria-label={ __( 'Other language', 'bridle' ) }
								className="h-8"
							/>
							<Button
								type="submit"
								size="sm"
								disabled={ ! other.trim() }
							>
								{ __( 'Go', 'bridle' ) }
							</Button>
						</form>
					</div>
				) }
			</PopoverContent>
		</Popover>
	);
}
