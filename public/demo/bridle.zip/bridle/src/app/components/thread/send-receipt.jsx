import { useEffect, useState } from 'react';
import { __ } from '@wordpress/i18n';
import { Check, CircleAlert, LoaderCircle, X } from 'lucide-react';
import { cn } from 'cn';

import { Button } from '@/components/ui/button';

const PILL =
	'pointer-events-auto flex min-h-10 items-center gap-2 rounded-full border bg-card/95 py-1 pl-3 text-sm shadow-lg backdrop-blur';

/*
 * "Reply sent · Undo (7)" while a send is held, "Not sent · Retry · Edit"
 * when it failed; see lib/use-delayed-send.js. `error` is the page's own
 * failure (a status change, an assignment), shown in the same place, just
 * above the action pill that caused it.
 */
export function SendReceipt( {
	pending,
	onUndo,
	onRetry,
	onEdit,
	error,
	onDismissError,
} ) {
	const [ , tick ] = useState( 0 );
	const counting = pending.some( ( item ) => ! item.failed );
	useEffect( () => {
		if ( ! counting ) {
			return undefined;
		}
		const timer = setInterval( () => tick( ( n ) => n + 1 ), 500 );
		return () => clearInterval( timer );
	}, [ counting ] );

	if ( ! pending.length && ! error ) {
		return null;
	}
	return (
		<div className="pointer-events-none fixed inset-x-0 bottom-20 z-40 flex flex-col items-center gap-2 px-3">
			{ error && (
				<div role="alert" className={ cn( PILL, 'pr-1' ) }>
					<CircleAlert className="size-4 text-destructive" />
					<span>{ error }</span>
					<Button
						size="icon-sm"
						variant="ghost"
						className="rounded-full"
						aria-label={ __( 'Dismiss', 'bridle' ) }
						onClick={ onDismissError }
					>
						<X />
					</Button>
				</div>
			) }
			{ pending.map( ( item ) =>
				item.failed ? (
					<div
						key={ item.key }
						role="alert"
						className={ cn( PILL, 'pr-1' ) }
					>
						<CircleAlert className="size-4 text-destructive" />
						<span>{ __( 'Not sent', 'bridle' ) }</span>
						<Button
							size="sm"
							variant="ghost"
							className="rounded-full"
							onClick={ () => onRetry( item.key ) }
						>
							{ __( 'Retry', 'bridle' ) }
						</Button>
						<Button
							size="sm"
							variant="ghost"
							className="rounded-full"
							onClick={ () => onEdit( item.key ) }
						>
							{ __( 'Edit', 'bridle' ) }
						</Button>
					</div>
				) : (
					<div
						key={ item.key }
						className={ cn( PILL, item.sending ? 'pr-4' : 'pr-1' ) }
					>
						{ item.sending ? (
							<LoaderCircle className="size-4 animate-spin text-muted-foreground" />
						) : (
							<Check className="size-4 text-brand" />
						) }
						<span>
							{ item.sending
								? __( 'Sending…', 'bridle' )
								: item.label }
						</span>
						{ ! item.sending && (
							<Button
								size="sm"
								variant="ghost"
								className="rounded-full"
								onClick={ () => onUndo( item.key ) }
							>
								{ __( 'Undo', 'bridle' ) }
								<span className="tabular-nums text-muted-foreground">
									{ Math.max(
										0,
										Math.ceil(
											( item.until - Date.now() ) / 1000
										)
									) }
								</span>
							</Button>
						) }
					</div>
				)
			) }
		</div>
	);
}
