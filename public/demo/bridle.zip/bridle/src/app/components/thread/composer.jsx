import {
	lazy,
	Suspense,
	useCallback,
	useEffect,
	useRef,
	useState,
} from 'react';
import { __ } from '@wordpress/i18n';
import { Paperclip, Send, StickyNote, Undo2, X, Zap } from 'lucide-react';
import { cn } from 'cn';

import { EditorToolbar } from '@/components/editor/toolbar';
import { RewriteMenu } from '@/components/thread/rewrite-menu';
import { Button } from '@/components/ui/button';
import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuItem,
	DropdownMenuLabel,
	DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
	ai,
	attachments as attachmentsApi,
	drafts,
	savedReplies,
} from '@/lib/api';
import { announce } from '@/lib/extend';

const loadEditor = () => import( '@/components/editor/rich-text' );
const RichText = lazy( loadEditor );

/* Warm the editor chunk as soon as a conversation opens, so `r` is instant. */
export function preloadEditor() {
	loadEditor().catch( () => {} );
}

/*
 * Until the editor chunk arrives, a plain textarea holds focus and keeps
 * whatever is typed, so keystrokes never fall through to the page shortcuts.
 */
function LoadingEditor( { value, onChange, placeholder } ) {
	const ref = useRef( null );
	useEffect( () => {
		ref.current?.focus();
	}, [] );
	return (
		<textarea
			ref={ ref }
			value={ value }
			onChange={ ( event ) => onChange( event.target.value ) }
			placeholder={ placeholder }
			aria-label={ placeholder }
			className="bridle-rt w-full resize-none bg-transparent"
		/>
	);
}

function escapeHtml( text ) {
	return String( text || '' )
		.replace( /&/g, '&amp;' )
		.replace( /</g, '&lt;' )
		.replace( />/g, '&gt;' );
}

const KB = 1024;
export function formatBytes( bytes ) {
	const n = Number( bytes ) || 0;
	if ( n < KB ) {
		return `${ n } B`;
	}
	if ( n < KB * KB ) {
		return `${ Math.round( n / KB ) } KB`;
	}
	return `${ ( n / ( KB * KB ) ).toFixed( 1 ) } MB`;
}

/* {{customer}}, {{name}}, {{customer_name}}, {{first_name}} in a snippet. */
export function fillTokens( body, customerName ) {
	const name = customerName || '';
	const first = name.split( /\s+/ )[ 0 ] || '';
	return String( body || '' )
		.replace( /\{\{\s*(?:customer|name|customer_name)\s*\}\}/gi, name )
		.replace( /\{\{\s*first_name\s*\}\}/gi, first );
}

function mentionIds( editor ) {
	const ids = [];
	editor?.state.doc.descendants( ( node ) => {
		if ( node.type.name === 'mention' && node.attrs.id ) {
			ids.push( Number( node.attrs.id ) );
		}
	} );
	return ids;
}

/*
 * The reply / note composer (AGENTS.md §6.3). It grows with the text, saves
 * a draft 1.5 s after typing stops (and on unmount), takes attachments and
 * snippets, and hands the finished message to onSend().
 *
 * @param {Object}   props
 * @param {number}   props.conversationId
 * @param {string}   props.customerName   For snippet tokens.
 * @param {Array}    props.teammates      For @mentions in notes.
 * @param {string}   props.mode           'reply' | 'note'
 * @param {Function} props.onModeChange
 * @param {string}   props.seedHtml       Content to start from (an accepted AI draft); replaces the saved draft.
 * @param {string}   props.undoHtml       What "Undo rewrite" puts back when seedHtml is a rewrite (#130).
 * @param {Function} props.onSend         ( { html, text, mode, attachmentIds, mentionedIds, andClose } ) => Promise
 * @param {Function} props.onCancel       Collapse the composer.
 */
// A reply to a chat shows in the visitor's bubble, and by email if unread (#120).
function replyPlaceholder( channel ) {
	return channel === 'chat'
		? __(
				'Write your reply… they’ll see it in the chat and by email',
				'bridle'
		  )
		: __( 'Write your reply…', 'bridle' );
}

export function Composer( {
	conversationId,
	channel,
	customerName,
	teammates,
	mode,
	onModeChange,
	seedHtml,
	undoHtml,
	onSend,
	onCancel,
	className,
} ) {
	const [ html, setHtml ] = useState( seedHtml || '' );
	const [ text, setText ] = useState( '' );
	const [ files, setFiles ] = useState( [] );
	const [ uploading, setUploading ] = useState( false );
	const [ snippets, setSnippets ] = useState( null );
	const [ sending, setSending ] = useState( false );
	const [ error, setError ] = useState( null );
	const [ savedAt, setSavedAt ] = useState( null );
	const [ editor, setEditor ] = useState( null );
	// A rewrite's "before" (#130): one Undo puts it back until the next edit.
	const [ undo, setUndo ] = useState( null );
	const [ rewriting, setRewriting ] = useState( false );
	const applying = useRef( false );
	const dirty = useRef( false );
	const saveTimer = useRef( null );
	const latest = useRef( { html: seedHtml || '', mode } );
	const fileInput = useRef( null );

	// Restore the saved draft, unless the caller seeded the content.
	useEffect( () => {
		if ( seedHtml ) {
			return;
		}
		let cancelled = false;
		drafts
			.get( conversationId )
			.then( ( draft ) => {
				if ( ! cancelled && draft?.content ) {
					setHtml( draft.content );
					latest.current.html = draft.content;
					if ( draft.thread_type && draft.thread_type !== mode ) {
						onModeChange?.( draft.thread_type );
					}
				}
			} )
			.catch( () => {} );
		return () => {
			cancelled = true;
		};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [ conversationId ] );

	useEffect( () => {
		if ( seedHtml ) {
			setHtml( seedHtml );
			latest.current.html = seedHtml;
			dirty.current = true;
			// Open already: the editor takes the new text too.
			if ( editor && editor.getHTML() !== seedHtml ) {
				applying.current = true;
				editor.commands.setContent( seedHtml, true );
				applying.current = false;
			}
			setUndo( undoHtml || null );
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [ seedHtml ] );

	const saveDraft = useCallback( () => {
		if ( ! dirty.current ) {
			return;
		}
		dirty.current = false;
		const { html: content, mode: threadType } = latest.current;
		drafts
			.save( conversationId, content, threadType )
			.then( ( result ) => {
				if ( result?.saved ) {
					setSavedAt( Date.now() );
				}
			} )
			.catch( () => {} );
	}, [ conversationId ] );

	const onChange = ( next ) => {
		// The person's own edit ends the rewrite's Undo.
		if ( ! applying.current ) {
			setUndo( null );
		}
		announce( 'composerInput', { conversationId, channel } );
		setHtml( next.html );
		setText( next.text );
		latest.current = { html: next.html, mode };
		dirty.current = true;
		clearTimeout( saveTimer.current );
		saveTimer.current = setTimeout( saveDraft, 1500 );
	};

	useEffect( () => {
		latest.current.mode = mode;
	}, [ mode ] );

	useEffect(
		() => () => {
			clearTimeout( saveTimer.current );
			saveDraft();
		},
		[ saveDraft ]
	);

	const addFiles = async ( list ) => {
		if ( ! list?.length ) {
			return;
		}
		setUploading( true );
		setError( null );
		try {
			for ( const file of Array.from( list ) ) {
				const saved = await attachmentsApi.upload( file );
				setFiles( ( current ) => [ ...current, saved ] );
			}
		} catch ( err ) {
			// The server's reason (too big, file type) is worth showing.
			setError(
				err?.message ||
					__( 'Couldn’t attach the file. Try again.', 'bridle' )
			);
		} finally {
			setUploading( false );
		}
	};

	// Put text in the editor as one change that saves like typing does.
	const apply = ( next ) => {
		applying.current = true;
		editor?.commands.setContent( next, true );
		applying.current = false;
	};

	const rewrite = async ( choice ) => {
		const before = editor?.getHTML() || '';
		if ( ! editor?.getText().trim() ) {
			setError( __( 'Write a reply first.', 'bridle' ) );
			return;
		}
		setRewriting( true );
		setError( null );
		try {
			const result = await ai.rewrite( {
				html: before,
				conversation_id: conversationId,
				...choice,
			} );
			apply( result.html );
			setUndo( before );
		} catch ( err ) {
			setError(
				err?.message ||
					__( 'Couldn’t rewrite it. Try again.', 'bridle' )
			);
		} finally {
			setRewriting( false );
		}
	};

	const insertSnippet = ( snippet ) => {
		editor
			?.chain()
			.focus()
			.insertContent( fillTokens( snippet.body, customerName ) )
			.run();
	};

	const send = async ( andClose ) => {
		const plain = ( text || editor?.getText() || '' ).trim();
		if ( ( ! plain && ! files.length ) || sending ) {
			return;
		}
		setSending( true );
		setError( null );
		try {
			clearTimeout( saveTimer.current );
			dirty.current = false;
			await onSend( {
				html: editor?.getHTML() || html,
				text: plain || '(attachment)',
				mode,
				attachmentIds: files.map( ( f ) => f.id ),
				mentionedIds: mode === 'note' ? mentionIds( editor ) : [],
				andClose,
			} );
			editor?.commands.clearContent( true );
			setHtml( '' );
			setText( '' );
			setFiles( [] );
			latest.current.html = '';
		} catch {
			// Keep what was written (and its draft); the caller didn't take it.
			dirty.current = true;
			setError(
				mode === 'note'
					? __( 'Couldn’t add the note. Try again.', 'bridle' )
					: __( 'Couldn’t send. Try again.', 'bridle' )
			);
		} finally {
			setSending( false );
		}
	};

	const isNote = mode === 'note';

	return (
		<div
			className={ cn(
				'surface',
				isNote && 'border-note-border bg-note',
				className
			) }
		>
			<div className="flex items-center gap-1 px-3 pt-3">
				<Button
					type="button"
					size="sm"
					variant={ isNote ? 'ghost' : 'secondary' }
					className="rounded-full"
					onClick={ () => onModeChange( 'reply' ) }
				>
					<Send />
					{ __( 'Reply', 'bridle' ) }
				</Button>
				<Button
					type="button"
					size="sm"
					variant={ isNote ? 'secondary' : 'ghost' }
					className="rounded-full"
					onClick={ () => onModeChange( 'note' ) }
				>
					<StickyNote />
					{ __( 'Note', 'bridle' ) }
				</Button>
				<div className="flex-1" />
				{ savedAt && Date.now() - savedAt < 4000 && (
					<span className="mr-2 text-xs text-muted-foreground">
						{ __( 'Draft saved', 'bridle' ) }
					</span>
				) }
				{ onCancel && (
					<Button
						type="button"
						size="icon-sm"
						variant="ghost"
						className="rounded-full text-muted-foreground"
						aria-label={ __( 'Collapse', 'bridle' ) }
						onClick={ onCancel }
					>
						<X />
					</Button>
				) }
			</div>

			<Suspense
				fallback={
					<LoadingEditor
						value={ text }
						placeholder={
							isNote
								? __( 'Write a note for the team…', 'bridle' )
								: replyPlaceholder( channel )
						}
						onChange={ ( plain ) => {
							setText( plain );
							const asHtml = plain
								? `<p>${ escapeHtml( plain ).replace(
										/\n/g,
										'<br>'
								  ) }</p>`
								: '';
							setHtml( asHtml );
							latest.current.html = asHtml;
							dirty.current = true;
						} }
					/>
				}
			>
				<RichText
					value={ html }
					placeholder={
						isNote
							? __(
									'Write a note for the team… @ to mention',
									'bridle'
							  )
							: replyPlaceholder( channel )
					}
					isNote={ isNote }
					teammates={ teammates }
					onChange={ onChange }
					onSubmit={ ( shift ) => send( shift ) }
					onReady={ setEditor }
				/>
			</Suspense>

			{ error && (
				<p role="alert" className="px-3 pb-2 text-sm text-destructive">
					{ error }
				</p>
			) }

			{ files.length > 0 && (
				<ul className="flex flex-wrap gap-2 px-3 pb-2">
					{ files.map( ( file ) => (
						<li
							key={ file.id }
							className="flex items-center gap-1.5 rounded-full border bg-secondary px-2.5 py-1 text-xs"
						>
							<Paperclip className="size-3.5 text-muted-foreground" />
							<span className="max-w-48 truncate">
								{ file.filename }
							</span>
							<span className="text-muted-foreground">
								{ formatBytes( file.size ) }
							</span>
							<button
								type="button"
								aria-label={ __(
									'Remove attachment',
									'bridle'
								) }
								onClick={ () =>
									setFiles( ( current ) =>
										current.filter(
											( f ) => f.id !== file.id
										)
									)
								}
								className="rounded hover:bg-muted"
							>
								<X className="size-3.5" />
							</button>
						</li>
					) ) }
				</ul>
			) }

			<div className="flex items-center gap-1 px-3 pb-3">
				<EditorToolbar editor={ editor } />
				<Button
					type="button"
					size="icon-sm"
					variant="ghost"
					className="text-muted-foreground hover:text-foreground"
					aria-label={ __( 'Attach a file', 'bridle' ) }
					disabled={ uploading }
					onClick={ () => fileInput.current?.click() }
				>
					<Paperclip />
				</Button>
				<input
					ref={ fileInput }
					type="file"
					multiple
					className="hidden"
					onChange={ ( event ) =>
						addFiles( event.target.files ).then( () => {
							event.target.value = '';
						} )
					}
				/>
				{ ! isNote && (
					<DropdownMenu
						onOpenChange={ ( open ) =>
							open &&
							snippets === null &&
							savedReplies
								.list()
								.then( setSnippets )
								.catch( () => setSnippets( [] ) )
						}
					>
						<DropdownMenuTrigger asChild>
							<Button
								type="button"
								size="sm"
								variant="ghost"
								className="text-muted-foreground hover:text-foreground"
							>
								<Zap />
								{ __( 'Snippets', 'bridle' ) }
							</Button>
						</DropdownMenuTrigger>
						<DropdownMenuContent align="start" className="w-64">
							<DropdownMenuLabel>
								{ __( 'Insert a snippet', 'bridle' ) }
							</DropdownMenuLabel>
							{ snippets === null && (
								<DropdownMenuItem disabled>
									{ __( 'Loading…', 'bridle' ) }
								</DropdownMenuItem>
							) }
							{ snippets?.length === 0 && (
								<DropdownMenuItem disabled>
									{ __( 'No snippets yet.', 'bridle' ) }
								</DropdownMenuItem>
							) }
							{ snippets?.map( ( snippet ) => (
								<DropdownMenuItem
									key={ snippet.id }
									onSelect={ () => insertSnippet( snippet ) }
								>
									<span className="truncate">
										{ snippet.title }
									</span>
								</DropdownMenuItem>
							) ) }
						</DropdownMenuContent>
					</DropdownMenu>
				) }
				{ ! isNote && (
					<RewriteMenu
						onPick={ rewrite }
						busy={ rewriting }
						disabled={ ! editor || sending }
					/>
				) }
				{ undo !== null && ! rewriting && (
					<Button
						type="button"
						size="sm"
						variant="ghost"
						className="text-muted-foreground hover:text-foreground"
						onClick={ () => {
							apply( undo );
							setUndo( null );
						} }
					>
						<Undo2 />
						{ __( 'Undo rewrite', 'bridle' ) }
					</Button>
				) }
				<div className="flex-1" />
				{ isNote ? (
					<Button
						type="button"
						size="sm"
						onClick={ () => send( false ) }
						disabled={ sending }
					>
						{ __( 'Add note', 'bridle' ) }
					</Button>
				) : (
					<>
						<Button
							type="button"
							size="sm"
							variant="outline"
							onClick={ () => send( true ) }
							disabled={ sending }
						>
							{ __( 'Send & resolve', 'bridle' ) }
						</Button>
						<Button
							type="button"
							size="sm"
							onClick={ () => send( false ) }
							disabled={ sending }
						>
							<Send />
							{ __( 'Send', 'bridle' ) }
						</Button>
					</>
				) }
			</div>
		</div>
	);
}
