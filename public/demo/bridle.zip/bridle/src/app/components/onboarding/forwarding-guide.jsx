import { useState } from 'react';
import { __, sprintf } from '@wordpress/i18n';
import { Check, Copy } from 'lucide-react';
import { cn } from 'cn';

/*
 * What Bridle shows while it walks someone through forwarding: their
 * @bridle.to address, the steps for their provider, Gmail's confirmation
 * code when it arrives, and whether mail has come through.
 */

async function copyText( text ) {
	try {
		await window.navigator.clipboard.writeText( text );
		return true;
	} catch ( e ) {
		return false;
	}
}

// A value you click to copy: the address, or Gmail's code.
export function CopyValue( { value, className } ) {
	const [ copied, setCopied ] = useState( false );
	const copy = async () => {
		if ( await copyText( value ) ) {
			setCopied( true );
			setTimeout( () => setCopied( false ), 1800 );
		}
	};
	return (
		<button
			type="button"
			onClick={ copy }
			title={ __( 'Click to copy', 'bridle' ) }
			className={ cn(
				'group flex w-full cursor-pointer items-center gap-3 rounded-xl border bg-card px-4 py-3 text-left transition-colors hover:border-brand/50',
				className
			) }
		>
			<span className="min-w-0 flex-1 truncate font-mono text-[15px] text-foreground select-all">
				{ value }
			</span>
			<span
				className={ cn(
					'inline-flex shrink-0 items-center gap-1 text-xs transition-colors',
					copied
						? 'text-brand-ink'
						: 'text-muted-foreground group-hover:text-foreground'
				) }
				aria-live="polite"
			>
				{ copied ? (
					<Check className="size-3.5" />
				) : (
					<Copy className="size-3.5" />
				) }
				{ copied ? __( 'Copied', 'bridle' ) : __( 'Copy', 'bridle' ) }
			</span>
		</button>
	);
}

function A( { href, children } ) {
	return (
		<a
			href={ href }
			target="_blank"
			rel="noopener noreferrer"
			className="text-brand-ink underline decoration-brand/40 underline-offset-4 hover:decoration-brand-ink"
		>
			{ children }
		</a>
	);
}

function Steps( { items } ) {
	return (
		<ol className="mt-3 space-y-2.5">
			{ items.map( ( item, i ) => (
				<li key={ i } className="flex gap-3">
					<span className="mt-0.5 inline-flex size-5 shrink-0 items-center justify-center rounded-full border text-[11px] font-medium text-muted-foreground tabular-nums">
						{ i + 1 }
					</span>
					<span className="min-w-0">{ item }</span>
				</li>
			) ) }
		</ol>
	);
}

function Aside( { children } ) {
	return (
		<div className="mt-3 text-[13px] leading-5 text-muted-foreground">
			{ children }
		</div>
	);
}

const isConsumerOutlook = ( email ) =>
	/@(outlook|hotmail|live|msn)\./i.test( email || '' );

/*
 * Provider steps. Google and Microsoft get their exact screens and a deep
 * link; everyone else gets the general recipe, named after their host when
 * we know it.
 */
export function ForwardingSteps( { provider, label, inbox } ) {
	const from = inbox.email_address;

	if ( provider === 'google' ) {
		return (
			<div>
				{ sprintf(
					/* translators: %s: the support address, e.g. support@example.com */
					__( 'In Gmail, signed in as %s:', 'bridle' ),
					from
				) }
				<Steps
					items={ [
						<>
							{ __( 'Open', 'bridle' ) }{ ' ' }
							<A href="https://mail.google.com/mail/u/0/#settings/fwdandpop">
								{ __( 'Forwarding and POP/IMAP', 'bridle' ) }
							</A>
							.
						</>,
						__(
							'Choose “Add a forwarding address” and paste your Bridle address.',
							'bridle'
						),
						__(
							'Gmail mails a confirmation to Bridle. I’ll catch it and show it to you right here.',
							'bridle'
						),
					] }
				/>
				<Aside>
					{ __(
						'On Google Workspace, if “Add a forwarding address” is greyed out, your admin needs to allow automatic forwarding.',
						'bridle'
					) }
				</Aside>
			</div>
		);
	}

	if ( provider === 'microsoft' ) {
		const href = isConsumerOutlook( from )
			? 'https://outlook.live.com/mail/0/options/mail/forwarding'
			: 'https://outlook.office.com/mail/options/mail/forwarding';
		return (
			<div>
				{ sprintf(
					/* translators: %s: the support address, e.g. support@example.com */
					__( 'In Outlook, signed in as %s:', 'bridle' ),
					from
				) }
				<Steps
					items={ [
						<>
							{ __( 'Open', 'bridle' ) }{ ' ' }
							<A href={ href }>
								{ __(
									'Settings → Mail → Forwarding',
									'bridle'
								) }
							</A>
							.
						</>,
						__(
							'Turn on “Enable forwarding” and paste your Bridle address.',
							'bridle'
						),
						__(
							'Tick “Keep a copy of forwarded messages”, then Save.',
							'bridle'
						),
					] }
				/>
				<Aside>
					{ __(
						'Microsoft 365 blocks forwarding to outside addresses by default. If nothing arrives, your admin can allow it in the outbound spam policy.',
						'bridle'
					) }
				</Aside>
			</div>
		);
	}

	return (
		<div>
			{ label
				? sprintf(
						/* translators: %s: the mail host, e.g. Zoho Mail */
						__( 'In %s’s settings:', 'bridle' ),
						label
				  )
				: __( 'In your mail provider or hosting panel:', 'bridle' ) }
			<Steps
				items={ [
					__(
						'Find “Forwarding” (cPanel and Plesk call it “Forwarders”).',
						'bridle'
					),
					sprintf(
						/* translators: %s: the support address, e.g. support@example.com */
						__(
							'Forward %s to your Bridle address, keeping a copy in the mailbox if it asks.',
							'bridle'
						),
						from
					),
					__(
						'If your provider sends a confirmation, it comes to me. I’ll show it to you here.',
						'bridle'
					),
				] }
			/>
		</div>
	);
}

// Gmail's confirmation, caught as it arrived in the new inbox.
export function GmailConfirm( { code, link } ) {
	return (
		<div>
			{ __(
				'Gmail’s confirmation just arrived. Approve the forwarding:',
				'bridle'
			) }
			{ link ? (
				<div className="mt-3">
					<A href={ link }>
						{ __( 'Confirm forwarding in Gmail', 'bridle' ) } →
					</A>
				</div>
			) : null }
			{ code ? (
				<div className="mt-3">
					<div className="mb-2 text-[13px] text-muted-foreground">
						{ link
							? __(
									'Or enter this code in Gmail’s forwarding settings:',
									'bridle'
							  )
							: __(
									'Enter this code in Gmail’s forwarding settings:',
									'bridle'
							  ) }
					</div>
					<CopyValue value={ code } className="max-w-60" />
				</div>
			) : null }
		</div>
	);
}

/*
 * The live line under the steps: a soft pulse while watching, solid once
 * the first email is in, quiet when forwarding is left for later.
 */
export function MailStatus( { address, state } ) {
	const watching = state === 'watching';
	let text = sprintf(
		/* translators: %s: the Bridle forwarding address */
		__( 'Watching %s for your first email…', 'bridle' ),
		address
	);
	if ( state === 'arrived' ) {
		text = __( 'Mail is coming through.', 'bridle' );
	} else if ( state === 'paused' ) {
		text = __( 'Forwarding not set up yet.', 'bridle' );
	}
	return (
		<span className="inline-flex items-center gap-2.5 text-[14px] text-muted-foreground">
			<span className="relative inline-flex size-2">
				{ watching && (
					<span className="absolute inset-0 animate-ping rounded-full bg-brand/60 motion-reduce:animate-none" />
				) }
				<span
					className={ cn(
						'relative inline-flex size-2 rounded-full',
						state === 'paused' ? 'bg-border' : 'bg-brand'
					) }
				/>
			</span>
			{ text }
		</span>
	);
}
