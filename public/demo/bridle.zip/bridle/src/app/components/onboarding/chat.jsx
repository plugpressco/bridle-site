import { useEffect, useRef, useState } from 'react';
import { __ } from '@wordpress/i18n';
import { cn } from 'cn';

import { BrandIcon } from '@/components/shell/logo';
import { Kbd } from '@/components/ui/kbd';

/*
 * The pieces of the onboarding conversation. Bridle speaks in plain text
 * beside its mark; the user's answers sit right in a soft bubble. There are
 * no buttons: the composer submits on ↵, and suggestions are words you can
 * click instead of typing.
 */

const enter =
	'animate-in fade-in slide-in-from-bottom-1 duration-300 motion-reduce:animate-none';

export function ChatMessage( { from, first, children } ) {
	if ( from === 'you' ) {
		return (
			<div className={ cn( 'flex justify-end', enter ) }>
				<div className="max-w-[85%] rounded-2xl rounded-br-md bg-secondary px-4 py-2 text-[15px] leading-6 break-words whitespace-pre-wrap text-foreground">
					{ children }
				</div>
			</div>
		);
	}
	return (
		<div className={ cn( 'flex gap-3', enter ) }>
			<span className="w-6 shrink-0 pt-0.5">
				{ first && <BrandIcon className="size-6" /> }
			</span>
			<div className="min-w-0 flex-1 text-[15px] leading-[1.65] text-foreground">
				{ children }
			</div>
		</div>
	);
}

export function Typing( { first } ) {
	return (
		<div
			className={ cn( 'flex gap-3', enter ) }
			aria-label={ __( 'Bridle is typing', 'bridle' ) }
		>
			<span className="w-6 shrink-0 pt-0.5">
				{ first && <BrandIcon className="size-6" /> }
			</span>
			<span className="inline-flex h-6 items-center gap-1">
				{ [ 0, 160, 320 ].map( ( delay ) => (
					<span
						key={ delay }
						className="size-1.5 animate-pulse rounded-full bg-muted-foreground/60 motion-reduce:animate-none"
						style={ { animationDelay: `${ delay }ms` } }
					/>
				) ) }
			</span>
		</div>
	);
}

/*
 * One line of input that grows. ↵ answers, Shift+↵ adds a line when the
 * question allows it. `prompt` is the open question, or null while Bridle
 * is talking (the field stays visible but quiet).
 */
export function Composer( { prompt, onAnswer } ) {
	const [ value, setValue ] = useState( '' );
	const field = useRef( null );

	useEffect( () => {
		setValue( prompt?.initial || '' );
		if ( prompt && field.current ) {
			field.current.focus( { preventScroll: true } );
		}
	}, [ prompt ] );

	useEffect( () => {
		const el = field.current;
		if ( el ) {
			el.style.height = 'auto';
			el.style.height = `${ Math.min( el.scrollHeight, 160 ) }px`;
		}
	}, [ value ] );

	const submit = ( text ) => {
		if ( ! prompt ) {
			return;
		}
		const answer = String( text ).trim();
		if ( ! answer && ! prompt.allowEmpty ) {
			return;
		}
		setValue( '' );
		onAnswer( answer );
	};

	const onKeyDown = ( event ) => {
		if ( event.key !== 'Enter' || event.nativeEvent.isComposing ) {
			return;
		}
		if ( event.shiftKey && prompt?.multiline ) {
			return;
		}
		event.preventDefault();
		submit( value );
	};

	return (
		<div>
			<div
				className={ cn(
					'flex items-end gap-3 rounded-2xl border border-input bg-card px-4 py-3 shadow-[0_1px_2px_rgb(24_24_24/0.04),0_16px_32px_-20px_rgb(24_24_24/0.22)] transition-[border-color,box-shadow] focus-within:border-ring focus-within:ring-[3px] focus-within:ring-ring/25',
					! prompt && 'opacity-60'
				) }
			>
				<textarea
					ref={ field }
					rows={ 1 }
					value={ value }
					readOnly={ ! prompt }
					onChange={ ( e ) => setValue( e.target.value ) }
					onKeyDown={ onKeyDown }
					placeholder={ prompt?.placeholder || '' }
					aria-label={
						prompt?.label || __( 'Your answer', 'bridle' )
					}
					inputMode={ prompt?.inputMode }
					autoComplete={ prompt?.autoComplete || 'off' }
					autoCapitalize={
						prompt?.inputMode === 'email' ? 'none' : undefined
					}
					spellCheck={ prompt?.inputMode !== 'email' }
					className="min-h-6 flex-1 resize-none border-0 bg-transparent p-0 text-[15px] leading-6 text-foreground shadow-none outline-none placeholder:text-muted-foreground/70 focus:border-0 focus:shadow-none focus:outline-none"
				/>
				<Kbd className="mb-0.5" aria-hidden="true">
					↵
				</Kbd>
			</div>
			<div className="mt-2.5 flex min-h-5 flex-wrap items-center gap-x-1.5 gap-y-1 px-1 text-xs text-muted-foreground">
				{ prompt?.suggestions?.map( ( suggestion, i ) => (
					<span key={ suggestion } className="inline-flex gap-1.5">
						{ i > 0 && <span aria-hidden="true">·</span> }
						<button
							type="button"
							onClick={ () => submit( suggestion ) }
							className="cursor-pointer text-foreground/80 underline decoration-border underline-offset-4 transition-colors hover:text-foreground hover:decoration-foreground/40"
						>
							{ suggestion }
						</button>
					</span>
				) ) }
				{ prompt?.hint && (
					<span className={ cn( prompt.suggestions && 'ml-2' ) }>
						{ prompt.hint }
					</span>
				) }
			</div>
		</div>
	);
}
