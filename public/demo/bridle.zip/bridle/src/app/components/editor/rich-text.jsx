import { useEffect, useRef, useState } from 'react';
import { EditorContent, useEditor } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Underline from '@tiptap/extension-underline';
import Link from '@tiptap/extension-link';
import Placeholder from '@tiptap/extension-placeholder';
import Mention from '@tiptap/extension-mention';
import { cn } from 'cn';

/*
 * The composer's editor: TipTap with the same extensions the legacy editor
 * used (StarterKit with h2/h3, Underline, Link, Placeholder, @mentions in
 * notes). Loaded lazily by composer.jsx, so the shell stays small.
 *
 * ⌘/Ctrl+Enter calls onSubmit(shiftKey); Shift means "send and resolve".
 */
export default function RichText( {
	value,
	placeholder,
	isNote,
	teammates,
	onChange,
	onSubmit,
	onReady,
	className,
} ) {
	const isNoteRef = useRef( isNote );
	const teammatesRef = useRef( teammates );
	const onSubmitRef = useRef( onSubmit );
	const commandRef = useRef( null );
	const mentionRef = useRef( { items: [], index: 0 } );
	const [ mention, setMention ] = useState( {
		open: false,
		items: [],
		index: 0,
		rect: null,
	} );

	useEffect( () => {
		isNoteRef.current = isNote;
		teammatesRef.current = teammates;
		onSubmitRef.current = onSubmit;
		mentionRef.current = mention;
	} );

	const editor = useEditor( {
		extensions: [
			StarterKit.configure( { heading: { levels: [ 2, 3 ] } } ),
			Underline,
			Link.configure( {
				openOnClick: false,
				autolink: true,
				HTMLAttributes: {
					rel: 'noopener noreferrer',
					target: '_blank',
				},
			} ),
			Placeholder.configure( { placeholder: () => placeholder || '' } ),
			Mention.configure( {
				HTMLAttributes: { class: 'bridle-mention' },
				renderText: ( { node } ) => '@' + ( node.attrs.label || '' ),
				suggestion: {
					char: '@',
					items: ( { query } ) => {
						if ( ! isNoteRef.current ) {
							return [];
						}
						const q = ( query || '' ).toLowerCase();
						return ( teammatesRef.current || [] )
							.filter( ( t ) =>
								( t.display_name || '' )
									.toLowerCase()
									.includes( q )
							)
							.slice( 0, 6 )
							.map( ( t ) => ( {
								id: t.id,
								label: t.display_name || t.email,
							} ) );
					},
					render: () => ( {
						onStart: ( props ) => {
							commandRef.current = props.command;
							setMention( {
								open: props.items.length > 0,
								items: props.items,
								index: 0,
								rect: props.clientRect?.() || null,
							} );
						},
						onUpdate: ( props ) => {
							commandRef.current = props.command;
							setMention( ( s ) => ( {
								...s,
								open: props.items.length > 0,
								items: props.items,
								rect: props.clientRect?.() || s.rect,
							} ) );
						},
						onKeyDown: ( { event } ) => {
							const { items, index } = mentionRef.current;
							if ( ! items.length ) {
								return false;
							}
							if ( event.key === 'ArrowDown' ) {
								setMention( ( s ) => ( {
									...s,
									index: ( s.index + 1 ) % s.items.length,
								} ) );
								return true;
							}
							if ( event.key === 'ArrowUp' ) {
								setMention( ( s ) => ( {
									...s,
									index:
										( s.index - 1 + s.items.length ) %
										s.items.length,
								} ) );
								return true;
							}
							if (
								event.key === 'Enter' ||
								event.key === 'Tab'
							) {
								const item = items[ index ];
								if ( item ) {
									commandRef.current?.( {
										id: item.id,
										label: item.label,
									} );
								}
								return true;
							}
							if ( event.key === 'Escape' ) {
								setMention( ( s ) => ( {
									...s,
									open: false,
								} ) );
								return true;
							}
							return false;
						},
						onExit: () =>
							setMention( ( s ) => ( { ...s, open: false } ) ),
					} ),
				},
			} ),
		],
		content: value || '',
		autofocus: 'end',
		editorProps: {
			attributes: { class: 'bridle-rt' },
			handleKeyDown: ( view, event ) => {
				if (
					( event.metaKey || event.ctrlKey ) &&
					event.key === 'Enter'
				) {
					event.preventDefault();
					onSubmitRef.current?.( event.shiftKey );
					return true;
				}
				return false;
			},
		},
		onUpdate: ( { editor: ed } ) =>
			onChange?.( { html: ed.getHTML(), text: ed.getText() } ),
	} );

	useEffect( () => {
		if ( editor ) {
			onReady?.( editor );
		}
	}, [ editor, onReady ] );

	// Replace the content when the caller swaps it (draft restored, AI draft accepted).
	useEffect( () => {
		if (
			editor &&
			value !== undefined &&
			value !== editor.getHTML() &&
			! editor.isFocused
		) {
			editor.commands.setContent( value || '', false );
		}
	}, [ editor, value ] );

	return (
		<div className={ cn( 'relative', className ) }>
			<EditorContent editor={ editor } />
			{ mention.open && mention.rect && (
				<ul
					role="listbox"
					className="fixed z-50 min-w-40 rounded-md border bg-popover p-1 text-sm shadow-md"
					style={ {
						left: mention.rect.left,
						top: mention.rect.bottom + 4,
					} }
				>
					{ mention.items.map( ( item, i ) => (
						<li key={ item.id }>
							<button
								type="button"
								role="option"
								aria-selected={ i === mention.index }
								onMouseDown={ ( event ) => {
									event.preventDefault();
									commandRef.current?.( {
										id: item.id,
										label: item.label,
									} );
								} }
								className={ cn(
									'w-full rounded-sm px-2 py-1 text-left',
									i === mention.index && 'bg-accent'
								) }
							>
								{ item.label }
							</button>
						</li>
					) ) }
				</ul>
			) }
		</div>
	);
}
