import { useState } from 'react';
import { __ } from '@wordpress/i18n';
import { Bold, Italic, Link2, List } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
	Popover,
	PopoverContent,
	PopoverTrigger,
} from '@/components/ui/popover';
import {
	Tooltip,
	TooltipContent,
	TooltipTrigger,
} from '@/components/ui/tooltip';

function Tool( { label, active, onClick, children } ) {
	return (
		<Tooltip>
			<TooltipTrigger asChild>
				<Button
					type="button"
					size="icon-sm"
					variant="ghost"
					aria-label={ label }
					aria-pressed={ active }
					onMouseDown={ ( event ) => event.preventDefault() }
					onClick={ onClick }
					className={
						active
							? 'bg-secondary text-foreground'
							: 'text-muted-foreground hover:text-foreground'
					}
				>
					{ children }
				</Button>
			</TooltipTrigger>
			<TooltipContent>{ label }</TooltipContent>
		</Tooltip>
	);
}

/* Bold, italic, bullets, link: what a support reply actually needs. */
export function EditorToolbar( { editor } ) {
	const [ url, setUrl ] = useState( '' );
	if ( ! editor ) {
		return null;
	}
	const applyLink = () => {
		const href = url.trim();
		if ( href ) {
			editor
				.chain()
				.focus()
				.extendMarkRange( 'link' )
				.setLink( { href } )
				.run();
		} else {
			editor.chain().focus().unsetLink().run();
		}
		setUrl( '' );
	};
	return (
		<div className="flex items-center gap-0.5">
			<Tool
				label={ __( 'Bold', 'bridle' ) }
				active={ editor.isActive( 'bold' ) }
				onClick={ () => editor.chain().focus().toggleBold().run() }
			>
				<Bold />
			</Tool>
			<Tool
				label={ __( 'Italic', 'bridle' ) }
				active={ editor.isActive( 'italic' ) }
				onClick={ () => editor.chain().focus().toggleItalic().run() }
			>
				<Italic />
			</Tool>
			<Tool
				label={ __( 'Bullet list', 'bridle' ) }
				active={ editor.isActive( 'bulletList' ) }
				onClick={ () =>
					editor.chain().focus().toggleBulletList().run()
				}
			>
				<List />
			</Tool>
			<Popover
				onOpenChange={ ( open ) =>
					open && setUrl( editor.getAttributes( 'link' ).href || '' )
				}
			>
				<PopoverTrigger asChild>
					<Button
						type="button"
						size="icon-sm"
						variant="ghost"
						aria-label={ __( 'Link', 'bridle' ) }
						className={
							editor.isActive( 'link' )
								? 'bg-secondary text-foreground'
								: 'text-muted-foreground hover:text-foreground'
						}
					>
						<Link2 />
					</Button>
				</PopoverTrigger>
				<PopoverContent align="start" className="w-72 p-2">
					<form
						className="flex gap-2"
						onSubmit={ ( event ) => {
							event.preventDefault();
							applyLink();
						} }
					>
						<Input
							value={ url }
							onChange={ ( event ) =>
								setUrl( event.target.value )
							}
							placeholder="https://"
							className="h-8"
						/>
						<Button type="submit" size="sm">
							{ __( 'Apply', 'bridle' ) }
						</Button>
					</form>
				</PopoverContent>
			</Popover>
		</div>
	);
}
