import { useCallback, useLayoutEffect, useRef, useState } from 'react';
import { __ } from '@wordpress/i18n';
import {
	Archive,
	House,
	Inbox,
	Newspaper,
	ShieldAlert,
	Trash,
} from 'lucide-react';
import { cn } from 'cn';

import { Link } from '@/lib/router';
import { FloatingPill } from './floating-pill';
import { useShell } from './shell-context';

// Home, then the boxes, in dock order, with the icons the row actions use
// too. `key` is the number that jumps there (app.jsx); it's in the docs, not
// on screen. Home has none, so 1–5 still mean the five boxes.
export const DOCK_ITEMS = [
	{ box: 'home', label: __( 'Home', 'bridle' ), icon: House },
	{ box: 'inbox', label: __( 'Inbox', 'bridle' ), key: '1', icon: Inbox },
	{
		box: 'updates',
		label: __( 'Updates', 'bridle' ),
		key: '2',
		icon: Newspaper,
	},
	{
		box: 'resolved',
		label: __( 'Resolved', 'bridle' ),
		key: '3',
		icon: Archive,
	},
	{ box: 'spam', label: __( 'Spam', 'bridle' ), key: '4', icon: ShieldAlert },
	{ box: 'trash', label: __( 'Trash', 'bridle' ), key: '5', icon: Trash },
];

// Magnification under the pointer, the macOS Dock's way: an icon grows as
// the pointer nears it and its neighbours follow on a cosine falloff.
const MAGNIFY = 0.2; // the icon under the pointer: 1.2×
const REACH = 96; // px either side that still feels it

function reducedMotion() {
	return (
		typeof window.matchMedia === 'function' &&
		window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches
	);
}

/*
 * The dock (AGENTS.md §7): every box, one tap away, floating over the
 * bottom of the app on a glass material. Each box is an icon over its name,
 * like an iOS tab bar. A soft lens sits behind the current box and glides to
 * the next; the current icon takes the brand blue. Icons press down on
 * pointer-down and magnify under a mouse; both stay still with reduced
 * motion. The Inbox icon carries the needs-reply count as a badge. The dock
 * steps aside while the bulk bar or a conversation's actions hold the slot.
 */
export function Dock() {
	const { route, counts, lastList, pillTaken, pillSlot } = useShell();
	const nav = useRef( null );
	const links = useRef( {} );
	const icons = useRef( {} );
	const frame = useRef( 0 );
	const [ lens, setLens ] = useState( null );
	const [ settled, setSettled ] = useState( false );

	let active = null;
	if ( route.name === 'home' ) {
		active = 'home';
	} else if ( route.name === 'box' ) {
		active = route.params.box;
	} else if ( route.name === 'conversation' ) {
		active = lastList?.box || null;
	}
	const hidden = pillTaken || route.name === 'conversation';
	const waiting = Number( counts?.needs_reply ) || 0;

	// Put the lens behind the active box. The first placement doesn't
	// animate, so it never slides in from the left edge.
	const place = useCallback( () => {
		const element = active && links.current[ active ];
		if ( ! element ) {
			setLens( null );
			return;
		}
		setLens( {
			left: element.offsetLeft,
			width: element.offsetWidth,
		} );
	}, [ active ] );

	// The links only exist once the pill slot has mounted, so measure again then.
	useLayoutEffect( () => {
		place();
	}, [ place, waiting, pillSlot ] );

	useLayoutEffect( () => {
		if ( lens && ! settled ) {
			const raf = window.requestAnimationFrame( () =>
				setSettled( true )
			);
			return () => window.cancelAnimationFrame( raf );
		}
		return undefined;
	}, [ lens, settled ] );

	useLayoutEffect( () => {
		if ( ! nav.current || typeof window.ResizeObserver === 'undefined' ) {
			return undefined;
		}
		const observer = new window.ResizeObserver( place );
		observer.observe( nav.current );
		return () => observer.disconnect();
	}, [ place, pillSlot ] );

	// Scale each icon by its distance from the pointer, once per frame.
	const magnify = ( event ) => {
		if ( event.pointerType !== 'mouse' || reducedMotion() ) {
			return;
		}
		const x = event.clientX;
		window.cancelAnimationFrame( frame.current );
		frame.current = window.requestAnimationFrame( () => {
			Object.values( icons.current ).forEach( ( icon ) => {
				if ( ! icon ) {
					return;
				}
				const box = icon.getBoundingClientRect();
				const distance = Math.abs( x - ( box.left + box.width / 2 ) );
				const pull =
					distance >= REACH
						? 0
						: ( 1 + Math.cos( ( Math.PI * distance ) / REACH ) ) /
						  2;
				icon.style.setProperty(
					'--bridle-mag',
					( 1 + MAGNIFY * pull ).toFixed( 3 )
				);
			} );
		} );
	};

	const rest = () => {
		window.cancelAnimationFrame( frame.current );
		Object.values( icons.current ).forEach( ( icon ) =>
			icon?.style.setProperty( '--bridle-mag', '1' )
		);
	};

	const item = ( { box, label, key, icon: Icon } ) => {
		const isActive = box === active;
		const badge = box === 'inbox' && waiting > 0;
		return (
			<Link
				key={ box }
				ref={ ( element ) => ( links.current[ box ] = element ) }
				to={ '/' + box }
				aria-current={ isActive ? 'page' : undefined }
				aria-keyshortcuts={ key }
				aria-label={ badge ? `${ label } (${ waiting })` : undefined }
				className={ cn(
					'relative z-10 flex h-[52px] w-[68px] flex-col max-sm:w-14 items-center justify-center gap-[5px] rounded-full outline-none select-none',
					// Feedback on press, not on release.
					'transition-[color,transform] duration-150 ease-out active:scale-[0.92] motion-reduce:transition-colors motion-reduce:active:scale-100',
					'focus-visible:ring-[3px] focus-visible:ring-ring/50',
					isActive
						? 'text-brand-ink'
						: 'text-muted-foreground hover:text-foreground'
				) }
			>
				<span
					ref={ ( element ) => ( icons.current[ box ] = element ) }
					className="relative flex origin-bottom items-center justify-center transition-transform duration-150 ease-out [transform:translateY(calc((1_-_var(--bridle-mag,1))*10px))_scale(var(--bridle-mag,1))] motion-reduce:transition-none"
				>
					<Icon
						aria-hidden="true"
						className="size-5"
						strokeWidth={ isActive ? 2.1 : 1.75 }
					/>
					{ badge && (
						<span
							aria-hidden="true"
							className="absolute -top-1.5 left-3 h-[17px] min-w-[17px] rounded-full bg-brand px-1 text-center text-[10.5px] leading-[17px] font-semibold text-white tabular-nums ring-2 ring-white"
						>
							{ waiting > 99 ? '99+' : waiting }
						</span>
					) }
				</span>
				<span
					className={ cn(
						'text-[11px] leading-none tracking-[0.01em]',
						isActive ? 'font-semibold' : 'font-medium'
					) }
				>
					{ label }
				</span>
			</Link>
		);
	};

	return (
		<FloatingPill
			aria-hidden={ hidden || undefined }
			inert={ hidden ? '' : undefined }
			className={ cn(
				'p-1 transition-[opacity,translate,scale] duration-200 ease-out motion-reduce:transition-opacity',
				hidden && 'pointer-events-none translate-y-3 scale-95 opacity-0'
			) }
		>
			<nav
				ref={ nav }
				aria-label={ __( 'Mailboxes', 'bridle' ) }
				onPointerMove={ magnify }
				onPointerLeave={ rest }
				className="relative flex items-center"
			>
				{ lens && (
					<span
						aria-hidden="true"
						className={ cn(
							'absolute inset-y-0 rounded-full bg-foreground/[0.06] shadow-[inset_0_0_0_0.5px_rgb(24_24_24/0.05)]',
							settled &&
								'transition-[left,width] duration-[380ms] ease-[cubic-bezier(0.32,0.72,0,1)] motion-reduce:transition-none'
						) }
						style={ { left: lens.left, width: lens.width } }
					/>
				) }
				{ DOCK_ITEMS.map( item ) }
			</nav>
		</FloatingPill>
	);
}
