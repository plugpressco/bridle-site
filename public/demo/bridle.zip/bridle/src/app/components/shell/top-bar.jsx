import { __ } from '@wordpress/i18n';
import { Settings } from 'lucide-react';

import { Link } from '@/lib/router';
import { ICON_BUTTON } from './chrome';
import { HelpMenu } from './help-menu';
import { BrandIcon } from './logo';
import { SearchBox } from './search-box';
import { useShell } from './shell-context';

/*
 * The top bar (2026-11-02, #110): the mark on the left, a plain link home;
 * search, Settings and one Help menu on the right. Nothing else. The boxes
 * live in the dock, and which inbox a list shows sits beside its title
 * (InboxFilter), only when there is more than one.
 */
export function TopBar() {
	const { route } = useShell();
	const inSettings = route.name === 'settings';

	return (
		<header className="flex h-14 shrink-0 items-center justify-between gap-3 border-b bg-card/80 px-4 backdrop-blur">
			<Link
				to="/home"
				className="inline-flex shrink-0 items-center gap-2 rounded-full py-1 pr-2 pl-0.5 text-[15px] font-semibold outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50"
				aria-label={ __( 'Bridle, go to Home', 'bridle' ) }
			>
				<BrandIcon className="size-7" />
				<span className="max-[480px]:hidden">
					{ __( 'Bridle', 'bridle' ) }
				</span>
			</Link>
			<div className="flex min-w-0 items-center gap-1">
				<SearchBox />
				<Link
					to="/settings"
					className={ ICON_BUTTON }
					aria-label={ __( 'Settings', 'bridle' ) }
					aria-current={ inSettings ? 'page' : undefined }
				>
					<Settings className="size-[18px]" />
				</Link>
				<HelpMenu />
			</div>
		</header>
	);
}
