import { createPortal } from 'react-dom';
import { cn } from 'cn';

import { useShell } from './shell-context';

/*
 * The glass pill at the bottom of the app (AGENTS.md §7). The dock, the
 * bulk bar and a conversation's actions all render through this, into one
 * slot that Frame places over the app (not the whole window, so it centres
 * beside the WordPress menu). They stack in the same grid cell, so when one
 * hands over to another they cross-fade in place.
 *
 * The material is Apple's floating layer: translucent white over a strong
 * blur, a bright top edge where light catches it, a hairline and a soft
 * shadow; it arrives by growing in, not just fading. With reduced
 * transparency it turns solid (shell.css, `.bridle-glass`).
 */
export function FloatingPill( { className, children, ...props } ) {
	const { pillSlot } = useShell();
	if ( ! pillSlot ) {
		return null;
	}
	return createPortal(
		<div
			className={ cn(
				'bridle-glass pointer-events-auto col-start-1 row-start-1 flex max-w-full items-center gap-1 rounded-full border border-black/[0.07] bg-white/72 p-1 backdrop-blur-xl backdrop-saturate-150',
				'shadow-[inset_0_1px_0_rgb(255_255_255/0.9),0_1px_2px_rgb(24_24_24/0.06),0_14px_36px_-14px_rgb(24_24_24/0.32)]',
				'animate-in fade-in-0 zoom-in-95 slide-in-from-bottom-2 duration-200 motion-reduce:animate-none',
				className
			) }
			{ ...props }
		>
			{ children }
		</div>,
		pillSlot
	);
}
