import { cn } from 'cn';

import { InboxFilter } from './inbox-scope';

// Column widths: reading (a thread, the Updates feed, a form), a list, and a
// roomy overview.
const WIDTHS = {
	read: 'max-w-[56rem]',
	list: 'max-w-[72rem]',
	wide: 'max-w-[64rem]',
};

/*
 * The centred column every page sits in (AGENTS.md §7). The bottom padding
 * keeps the floating dock clear of the last row.
 *
 * A `description` makes the headline two-tone, the brand's way: the title in
 * ink, then a second line in grey that says what the page is for. `scope`
 * puts the inbox filter beside the title, for lists (#110), and `note` a
 * short muted fact there (Trash's 30 days). The five boxes use neither
 * description nor another width, so moving between them never shifts the
 * page (#112).
 */
export function Page( {
	title,
	description,
	eyebrow,
	actions,
	scope = false,
	note,
	width = 'read',
	className,
	children,
} ) {
	return (
		<div
			className={ cn(
				'mx-auto w-full px-6 pt-8 pb-28',
				WIDTHS[ width ] || WIDTHS.read,
				className
			) }
		>
			{ ( title || actions ) && (
				<div className="mb-6 flex items-end justify-between gap-4">
					<div className="min-w-0">
						{ eyebrow && (
							<div className="mb-1 text-sm text-muted-foreground">
								{ eyebrow }
							</div>
						) }
						<div className="flex min-w-0 items-center gap-2">
							<h1 className="min-w-0 text-2xl font-[450] tracking-[-0.02em]">
								<span className="block truncate">
									{ title }
								</span>
								{ description && (
									<span className="block text-balance text-muted-foreground">
										{ description }
									</span>
								) }
							</h1>
							{ scope && <InboxFilter /> }
							{ note && (
								<span className="shrink-0 text-sm text-muted-foreground max-sm:hidden">
									{ note }
								</span>
							) }
						</div>
					</div>
					{ actions }
				</div>
			) }
			{ children }
		</div>
	);
}
