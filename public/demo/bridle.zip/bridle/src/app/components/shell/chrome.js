/*
 * The top bar's controls (2026-11-02, #110): round icon buttons, quiet until
 * hovered, so the bar reads as calm chrome rather than a row of pills.
 */
export const ICON_BUTTON =
	'inline-flex size-9 shrink-0 items-center justify-center rounded-full text-muted-foreground outline-none transition-colors hover:bg-accent hover:text-foreground focus-visible:ring-[3px] focus-visible:ring-ring/50 data-[state=open]:bg-accent data-[state=open]:text-foreground aria-[current=page]:bg-accent aria-[current=page]:text-foreground';
