import {
	createContext,
	useCallback,
	useContext,
	useEffect,
	useMemo,
	useState,
} from 'react';

import {
	conversations as conversationsApi,
	inboxes as inboxesApi,
	teammates as teammatesApi,
} from '@/lib/api';
import { appData } from '@/lib/app-data';
import { getPref, savePref } from '@/lib/prefs';
import { navigate, useRoute } from '@/lib/router';

const ShellContext = createContext( null );

// Fallback markers for inboxes without a colour of their own.
const INBOX_COLORS = [
	'#679eee',
	'#181818',
	'#db2777',
	'#d97706',
	'#0d9488',
	'#7c3aed',
	'#65a30d',
];

export function inboxColor( inbox ) {
	if ( inbox?.color ) {
		return inbox.color;
	}
	// Ids start at 1, so the first inbox gets the brand blue, not the ink.
	return INBOX_COLORS[
		Math.max( 0, ( Number( inbox?.id ) || 1 ) - 1 ) % INBOX_COLORS.length
	];
}

// The query param wins, then the saved preference, as long as that inbox exists.
function pickScope( inboxes, fromQuery, saved ) {
	const known = ( id ) =>
		inboxes.some( ( inbox ) => Number( inbox.id ) === id );
	if ( known( fromQuery ) ) {
		return fromQuery;
	}
	if ( known( saved ) ) {
		return saved;
	}
	return 0;
}

/*
 * Shell state: the current route, the inbox scope, the box counts the dock
 * shows, the last list you looked at, and who holds the floating pill slot.
 *
 * The scope is the `?inbox=` query param when present, otherwise the saved
 * `inboxScope` preference (AGENTS.md §7). Picking an inbox writes both.
 */
export function ShellProvider( { children } ) {
	const route = useRoute();
	const [ onboardingDone, setOnboardingDone ] = useState(
		appData.onboardingDone
	);

	// The inbox list starts from the page state and refreshes after Settings
	// connects or deactivates one.
	const [ allInboxes, setAllInboxes ] = useState( appData.inboxes );
	const inboxes = useMemo(
		() =>
			allInboxes.filter(
				( inbox ) => Number( inbox.is_active ?? 1 ) === 1
			),
		[ allInboxes ]
	);
	const refreshInboxes = useCallback( async () => {
		const rows = await inboxesApi.list();
		if ( Array.isArray( rows ) ) {
			setAllInboxes( rows );
			appData.inboxes = rows;
		}
		return rows;
	}, [] );

	// Teammates load once; Settings → People reloads them after a change.
	const [ teammates, setTeammates ] = useState( [] );
	const refreshTeammates = useCallback( async () => {
		const rows = await teammatesApi.list();
		if ( Array.isArray( rows ) ) {
			setTeammates( rows );
		}
		return rows;
	}, [] );
	useEffect( () => {
		refreshTeammates().catch( () => {} );
	}, [ refreshTeammates ] );

	const inboxScope = pickScope(
		inboxes,
		Number( route.query.inbox ) || 0,
		Number( getPref( 'inboxScope' ) ) || 0
	);

	// Counts for the dock. One cheap query; it follows the scope and refreshes
	// on every route change, so a resolve or a move shows up on the way back.
	const [ counts, setCounts ] = useState( null );
	const refreshCounts = useCallback( () => {
		conversationsApi
			.counts( inboxScope )
			.then( ( row ) => setCounts( row ) )
			.catch( () => {} );
	}, [ inboxScope ] );
	useEffect( () => {
		if ( onboardingDone ) {
			refreshCounts();
		}
	}, [ refreshCounts, route.path, onboardingDone ] );

	// The list a conversation was opened from, so Back and Esc return to it:
	// { path, query, box }, `box` being null for search results.
	const [ lastList, setLastList ] = useState( null );
	useEffect( () => {
		if ( route.name === 'box' ) {
			setLastList( {
				path: route.path,
				query: {},
				box: route.params.box,
			} );
		} else if ( route.name === 'search' ) {
			setLastList( {
				path: route.path,
				query: { q: route.params.q },
				box: null,
			} );
		}
	}, [ route ] );

	// The bottom pill slot: the dock, unless the bulk bar or a conversation's
	// action pill has claimed it (useClaimPill).
	const [ pillSlot, setPillSlot ] = useState( null );
	const [ pillClaims, setPillClaims ] = useState( 0 );
	const claimPill = useCallback( () => {
		setPillClaims( ( n ) => n + 1 );
		return () => setPillClaims( ( n ) => n - 1 );
	}, [] );

	const setInboxScope = useCallback(
		( id ) => {
			savePref( 'inboxScope', id || 0 ); // 0 = all inboxes; the server stores it as null.
			navigate( route.path, { inbox: id || null } );
		},
		[ route.path ]
	);

	const value = useMemo(
		() => ( {
			route,
			inboxes,
			inboxScope,
			currentInbox:
				inboxes.find(
					( inbox ) => Number( inbox.id ) === inboxScope
				) || null,
			setInboxScope,
			refreshInboxes,
			counts,
			refreshCounts,
			lastList,
			pillSlot,
			setPillSlot,
			pillTaken: pillClaims > 0,
			claimPill,
			onboardingDone,
			setOnboardingDone,
			teammates,
			refreshTeammates,
		} ),
		[
			route,
			inboxes,
			inboxScope,
			setInboxScope,
			refreshInboxes,
			counts,
			refreshCounts,
			lastList,
			pillSlot,
			pillClaims,
			claimPill,
			onboardingDone,
			teammates,
			refreshTeammates,
		]
	);

	return (
		<ShellContext.Provider value={ value }>
			{ children }
		</ShellContext.Provider>
	);
}

/* Hold the bottom pill slot while `active`; the dock steps aside meanwhile. */
export function useClaimPill( active = true ) {
	const { claimPill } = useShell();
	useEffect(
		() => ( active ? claimPill() : undefined ),
		[ active, claimPill ]
	);
}

export function useShell() {
	const context = useContext( ShellContext );
	if ( ! context ) {
		throw new Error( 'useShell() needs a ShellProvider above it.' );
	}
	return context;
}
