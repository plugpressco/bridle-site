import { useEffect, useState } from 'react';
import { __ } from '@wordpress/i18n';
import { Search } from 'lucide-react';
import { cn } from 'cn';

import { Input } from '@/components/ui/input';
import { navigate } from '@/lib/router';
import { useShell } from './shell-context';

export const SEARCH_INPUT_ID = 'bridle-search';

/*
 * The top-bar search. `/` focuses it (see app.jsx), Enter opens `#/search`.
 * At rest it is a soft grey field with no border that says what it
 * searches; focused or holding a query it turns white, with a ring.
 */
export function SearchBox() {
	const { route } = useShell();
	const [ value, setValue ] = useState(
		route.name === 'search' ? route.params.q : ''
	);

	// The box mirrors the search route: it shows the query on `#/search` and
	// empties when you leave it, so stale terms never sit beside the Inbox.
	useEffect( () => {
		setValue( route.name === 'search' ? route.params.q : '' );
	}, [ route ] );

	const submit = ( event ) => {
		event.preventDefault();
		const q = value.trim();
		if ( q ) {
			navigate( '/search', { q } );
		}
	};

	return (
		<form role="search" onSubmit={ submit } className="relative">
			<Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
			<Input
				id={ SEARCH_INPUT_ID }
				type="search"
				value={ value }
				onChange={ ( event ) => setValue( event.target.value ) }
				onKeyDown={ ( event ) => {
					if ( event.key === 'Escape' ) {
						event.currentTarget.blur();
					}
				} }
				placeholder={ __( 'Search', 'bridle' ) }
				aria-label={ __( 'Search conversations', 'bridle' ) }
				className={ cn(
					'h-9 w-44 rounded-full border-transparent bg-secondary pl-9 text-sm text-foreground shadow-none transition-[width,background-color,border-color,box-shadow] duration-200 placeholder:text-muted-foreground hover:border-transparent hover:bg-accent motion-reduce:transition-none sm:w-64 md:text-sm',
					'focus-visible:bg-card focus-visible:hover:bg-card sm:focus-visible:w-80',
					'[&:not(:placeholder-shown)]:border-input [&:not(:placeholder-shown)]:bg-card sm:[&:not(:placeholder-shown)]:w-80'
				) }
			/>
		</form>
	);
}
