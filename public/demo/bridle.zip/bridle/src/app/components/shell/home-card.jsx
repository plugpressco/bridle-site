/*
 * One card on Home: a small heading, an optional link or action on its
 * right, then the content. Needs you and Agent health use it, and so do the
 * cards an add-on adds through `bridle.homeCards` (it's in the kit).
 */
export function HomeCard( { title, action, children } ) {
	return (
		<div className="surface">
			<div className="flex items-center justify-between gap-3 px-4 pt-3.5 pb-1">
				<h2 className="text-sm font-semibold">{ title }</h2>
				{ action }
			</div>
			{ children }
		</div>
	);
}
