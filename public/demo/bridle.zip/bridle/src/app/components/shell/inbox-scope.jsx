import { __ } from '@wordpress/i18n';
import { ChevronDown } from 'lucide-react';
import { cn } from 'cn';

import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuRadioGroup,
	DropdownMenuRadioItem,
	DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { inboxColor, useShell } from './shell-context';

export function InboxDot( { inbox, className } ) {
	return (
		<span
			aria-hidden="true"
			className={ cn(
				'inline-block size-2.5 shrink-0 rounded-full',
				className
			) }
			style={ { backgroundColor: inboxColor( inbox ) } }
		/>
	);
}

/*
 * Which inbox a list shows, beside the page's title (2026-11-02, #110): a
 * quiet "All inboxes ▾" that only appears with more than one inbox. With
 * one there is nothing to choose, so nothing shows. Connecting another lives
 * in Help and Settings.
 */
export function InboxFilter() {
	const { inboxes, inboxScope, currentInbox, setInboxScope } = useShell();
	if ( inboxes.length < 2 ) {
		return null;
	}

	return (
		<DropdownMenu>
			<DropdownMenuTrigger asChild>
				<button
					type="button"
					className="inline-flex h-8 shrink-0 items-center gap-1.5 rounded-full px-2.5 text-sm text-muted-foreground outline-none transition-colors hover:bg-accent hover:text-foreground focus-visible:ring-[3px] focus-visible:ring-ring/50 data-[state=open]:bg-accent data-[state=open]:text-foreground"
				>
					{ currentInbox && <InboxDot inbox={ currentInbox } /> }
					<span className="max-w-48 truncate">
						{ currentInbox
							? currentInbox.display_name
							: __( 'All inboxes', 'bridle' ) }
					</span>
					<ChevronDown className="size-3.5" />
				</button>
			</DropdownMenuTrigger>
			<DropdownMenuContent align="start" className="w-64">
				<DropdownMenuRadioGroup
					value={ String( inboxScope ) }
					onValueChange={ ( value ) =>
						setInboxScope( Number( value ) )
					}
				>
					<DropdownMenuRadioItem value="0">
						{ __( 'All inboxes', 'bridle' ) }
					</DropdownMenuRadioItem>
					{ inboxes.map( ( inbox ) => (
						<DropdownMenuRadioItem
							key={ inbox.id }
							value={ String( inbox.id ) }
						>
							<InboxDot inbox={ inbox } className="mr-1" />
							<span className="min-w-0 flex-1 truncate">
								{ inbox.display_name }
							</span>
							<span className="ml-2 truncate font-mono text-[11px] text-muted-foreground">
								{ inbox.email_address }
							</span>
						</DropdownMenuRadioItem>
					) ) }
				</DropdownMenuRadioGroup>
			</DropdownMenuContent>
		</DropdownMenu>
	);
}
