import { useState } from 'react';
import { __, sprintf } from '@wordpress/i18n';
import { CircleHelp, Command, Inbox, Keyboard, PlugZap } from 'lucide-react';

import {
	Dialog,
	DialogContent,
	DialogHeader,
	DialogTitle,
} from '@/components/ui/dialog';
import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuItem,
	DropdownMenuLabel,
	DropdownMenuSeparator,
	DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Kbd } from '@/components/ui/kbd';
import { appData } from '@/lib/app-data';
import { navigate } from '@/lib/router';
import { ICON_BUTTON } from './chrome';

// The keys that already work (AGENTS.md §7). They are listed here, in a
// dialog you open on purpose, and never printed on buttons or tooltips.
const SHORTCUTS = [
	[
		__( 'Anywhere', 'bridle' ),
		[
			[
				[ '1', '–', '5' ],
				__( 'Inbox, Updates, Resolved, Spam, Trash', 'bridle' ),
			],
			[ [ '/' ], __( 'Search', 'bridle' ) ],
			[ [ 'Esc' ], __( 'Back', 'bridle' ) ],
			[
				[ '⌘', 'K' ],
				__( 'WordPress commands, Bridle’s included', 'bridle' ),
			],
		],
	],
	[
		__( 'In a list', 'bridle' ),
		[
			[ [ 'j', 'k' ], __( 'Next and previous', 'bridle' ) ],
			[ [ '↵' ], __( 'Open', 'bridle' ) ],
			[ [ 'x' ], __( 'Select', 'bridle' ) ],
		],
	],
	[
		__( 'In a conversation', 'bridle' ),
		[
			[ [ 'r' ], __( 'Reply', 'bridle' ) ],
			[ [ 'n' ], __( 'Note', 'bridle' ) ],
			[ [ 'a' ], __( 'Edit the agent’s draft', 'bridle' ) ],
			[ [ 'e' ], __( 'Resolve', 'bridle' ) ],
			[ [ '⌘', '↵' ], __( 'Send', 'bridle' ) ],
			[ [ '⌘', '⇧', '↵' ], __( 'Send and resolve', 'bridle' ) ],
		],
	],
];

function ShortcutsDialog( { open, onOpenChange } ) {
	return (
		<Dialog open={ open } onOpenChange={ onOpenChange }>
			<DialogContent className="sm:max-w-md">
				<DialogHeader>
					<DialogTitle>
						{ __( 'Keyboard shortcuts', 'bridle' ) }
					</DialogTitle>
				</DialogHeader>
				<div className="space-y-5">
					{ SHORTCUTS.map( ( [ group, rows ] ) => (
						<section key={ group }>
							<h3 className="mb-1.5 text-xs font-medium text-muted-foreground">
								{ group }
							</h3>
							<dl className="divide-y divide-border/60">
								{ rows.map( ( [ keys, label ] ) => (
									<div
										key={ label }
										className="flex items-center justify-between gap-4 py-2 text-sm"
									>
										<dt>{ label }</dt>
										<dd className="flex shrink-0 items-center gap-1">
											{ keys.map( ( key, i ) =>
												key === '–' ? (
													<span
														key={ i }
														className="text-muted-foreground"
													>
														{ key }
													</span>
												) : (
													<Kbd key={ i }>{ key }</Kbd>
												)
											) }
										</dd>
									</div>
								) ) }
							</dl>
						</section>
					) ) }
				</div>
			</DialogContent>
		</Dialog>
	);
}

/*
 * WordPress's command palette (⌘K), where Bridle registers its boxes,
 * Settings pages and a search (src/commands). Null where WordPress has none.
 */
function wpCommands() {
	try {
		const actions = window.wp?.data?.dispatch?.( 'core/commands' );
		return actions?.open ? actions : null;
	} catch {
		return null;
	}
}

/*
 * The one menu in the top bar: help. What to set up next and the keys,
 * nothing that duplicates the dock or the WordPress menu. Its last line is
 * the version, in place of WordPress's footer, which Bridle's full-screen
 * page hides.
 */
export function HelpMenu() {
	const [ keysOpen, setKeysOpen ] = useState( false );
	const palette = wpCommands();

	return (
		<>
			<DropdownMenu>
				<DropdownMenuTrigger asChild>
					<button
						type="button"
						className={ ICON_BUTTON }
						aria-label={ __( 'Help', 'bridle' ) }
					>
						<CircleHelp className="size-[18px]" />
					</button>
				</DropdownMenuTrigger>
				<DropdownMenuContent align="end" className="w-56">
					<DropdownMenuItem
						onSelect={ () =>
							navigate( '/settings/inboxes', { connect: 1 } )
						}
					>
						<Inbox />
						{ __( 'Connect an inbox', 'bridle' ) }
					</DropdownMenuItem>
					<DropdownMenuItem
						onSelect={ () => navigate( '/settings/ai-apps' ) }
					>
						<PlugZap />
						{ __( 'Connect an AI app', 'bridle' ) }
					</DropdownMenuItem>
					<DropdownMenuItem onSelect={ () => setKeysOpen( true ) }>
						<Keyboard />
						{ __( 'Keyboard shortcuts', 'bridle' ) }
					</DropdownMenuItem>
					{ palette && (
						<DropdownMenuItem onSelect={ () => palette.open() }>
							<Command />
							{ __( 'Search and commands', 'bridle' ) }
						</DropdownMenuItem>
					) }
					{ appData.version && (
						<>
							<DropdownMenuSeparator />
							<DropdownMenuLabel className="text-xs font-normal text-muted-foreground">
								{ appData.pro
									? sprintf(
											/* translators: 1: Bridle's version, 2: Bridle Pro's version */
											__(
												'Bridle %1$s · Pro %2$s',
												'bridle'
											),
											appData.version,
											appData.pro
									  )
									: sprintf(
											/* translators: %s: Bridle's version */
											__( 'Bridle %s', 'bridle' ),
											appData.version
									  ) }
							</DropdownMenuLabel>
						</>
					) }
				</DropdownMenuContent>
			</DropdownMenu>
			<ShortcutsDialog open={ keysOpen } onOpenChange={ setKeysOpen } />
		</>
	);
}
