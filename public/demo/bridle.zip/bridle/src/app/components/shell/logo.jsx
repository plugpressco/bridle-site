import { useId } from 'react';

/*
 * The Bridle mark: a lowercase b drawn as tack. The bowl is a bit ring and
 * the stem a rein pulled taut, cut square like a strap. One filled path
 * with an even-odd hole. This is the small cut (heavier ring and rein),
 * because the app only shows the mark at 20–24px. Source and spec live in
 * rebrand/logo/ outside this repo.
 */
export function Logo( { className } ) {
	return (
		<svg
			viewBox="0 0 60 60"
			fill="none"
			xmlns="http://www.w3.org/2000/svg"
			aria-hidden="true"
			className={ className }
		>
			<path
				fillRule="evenodd"
				clipRule="evenodd"
				d="M12.61 41.42L4.65 3.98L14.91 1.8L19.06 21.36A21.18 21.18 0 1 1 12.61 41.42ZM23.05 37.02a10.28 10.28 0 1 0 20.55 0a10.28 10.28 0 1 0 -20.55 0Z"
				fill="currentColor"
			/>
		</svg>
	);
}

/*
 * The Bridle icon: the mark in white on a brand-blue circle, the same icon
 * bridle.to, the plugin directory and the app use everywhere (owner,
 * 2026-10-06, after paper.design's one icon). Size it with `className`.
 * Each instance gets its own gradient id, so several can share a page.
 */
export function BrandIcon( { className } ) {
	const id = useId();
	return (
		<svg
			viewBox="0 0 100 100"
			xmlns="http://www.w3.org/2000/svg"
			aria-hidden="true"
			className={ className }
		>
			<defs>
				<linearGradient id={ id } x1="0" y1="0" x2="0" y2="1">
					<stop offset="0" stopColor="#7fb0f3" />
					<stop offset="1" stopColor="#4c8eef" />
				</linearGradient>
			</defs>
			<circle cx="50" cy="50" r="50" fill={ `url(#${ id })` } />
			<path
				transform="translate(20.36 19.15) scale(0.95)"
				fillRule="evenodd"
				clipRule="evenodd"
				d="M13.31 41.92L5.18 3.67L13.97 1.8L18.57 23.43A20.56 20.56 0 1 1 13.31 41.92ZM22.27 37.64a11.15 11.36 0 1 0 22.3 0a11.15 11.36 0 1 0 -22.3 0Z"
				fill="#fff"
			/>
		</svg>
	);
}
