import { useEffect, useState } from 'react';
import { __, sprintf } from '@wordpress/i18n';
import { Check } from 'lucide-react';

import { Field, InlineError, Segmented } from '@/components/settings/field';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ai } from '@/lib/api';

const PROVIDERS = [
	[ 'off', __( 'Off', 'bridle' ) ],
	[ 'typesafe', __( 'TypeSafe', 'bridle' ) ],
	[ 'cloudflare', __( 'Cloudflare', 'bridle' ) ],
];

// Clef first: it runs on the free daily Workers AI allowance. Jev on
// Cloudflare is paid from AI Gateway credits (a 402 without them).
const CLOUDFLARE_MODELS = [
	[ '@cf/cloudflare/clef', __( 'Clef', 'bridle' ) ],
	[ '@cf/cloudflare/clef-flash', __( 'Clef flash', 'bridle' ) ],
	[ 'typesafe/jev', __( 'Jev', 'bridle' ) ],
];

const MODEL_NAMES = {
	'jev-latest': __( 'Jev', 'bridle' ),
	...Object.fromEntries( CLOUDFLARE_MODELS ),
};

// How the test result names the sample's box.
const BOX_NAMES = {
	customer_request: __( 'a customer writing in', 'bridle' ),
	automated: __( 'automated mail', 'bridle' ),
	sales_pitch: __( 'a sales pitch', 'bridle' ),
	spam: __( 'spam', 'bridle' ),
};

function ExternalLink( { href, children } ) {
	return (
		<a
			href={ href }
			target="_blank"
			rel="noopener noreferrer"
			className="text-brand-ink underline-offset-2 hover:underline"
		>
			{ children }
		</a>
	);
}

/*
 * Settings → Sorting: a decision model on the owner's own key reads
 * every inbound email (Services\Classifier). Credentials save with "Save and
 * test", which runs a sample pitch through it; the key never comes back from
 * the server, only its last four characters. Off forgets the credentials.
 */
export function Sorting() {
	const [ config, setConfig ] = useState( null );
	const [ provider, setProvider ] = useState( 'off' );
	const [ model, setModel ] = useState( CLOUDFLARE_MODELS[ 0 ][ 0 ] );
	const [ accountId, setAccountId ] = useState( '' );
	const [ key, setKey ] = useState( '' );
	const [ busy, setBusy ] = useState( false );
	const [ result, setResult ] = useState( null );
	const [ error, setError ] = useState( null );

	const adopt = ( next ) => {
		setConfig( next );
		setProvider( next.provider || 'off' );
		if ( 'cloudflare' === next.provider ) {
			setModel( next.model );
			setAccountId( next.account_id );
		}
	};

	useEffect( () => {
		ai.classifier()
			.then( adopt )
			.catch( () => setError( __( 'Couldn’t load this.', 'bridle' ) ) );
	}, [] );

	const choose = async ( next ) => {
		setProvider( next );
		setResult( null );
		setError( null );
		setKey( '' );
		if ( 'off' === next && config?.provider ) {
			setBusy( true );
			try {
				adopt( await ai.saveClassifier( { provider: '' } ) );
			} catch {
				setError( __( 'Couldn’t save. Try again.', 'bridle' ) );
			} finally {
				setBusy( false );
			}
		}
	};

	const saveAndTest = async () => {
		setBusy( true );
		setResult( null );
		setError( null );
		try {
			adopt(
				await ai.saveClassifier( {
					provider,
					model: 'cloudflare' === provider ? model : 'jev-latest',
					account_id: accountId,
					key,
				} )
			);
			setKey( '' );
			const test = await ai.testClassifier();
			adopt( test.config );
			setResult( test );
		} catch ( err ) {
			setError(
				err?.message || __( 'Couldn’t save. Try again.', 'bridle' )
			);
		} finally {
			setBusy( false );
		}
	};

	if ( ! config ) {
		return <InlineError>{ error }</InlineError>;
	}

	const saved = config.provider === provider && config.has_key;
	let keyPlaceholder = __( 'Paste your key', 'bridle' );
	if ( saved ) {
		keyPlaceholder = sprintf(
			/* translators: %s: last four characters of the saved key */
			__(
				'Saved, ending in %s. Paste a new one to replace it.',
				'bridle'
			),
			config.key_hint
		);
	} else if ( 'cloudflare' === provider ) {
		keyPlaceholder = __( 'Paste your token', 'bridle' );
	}
	const box = result?.classification?.box;

	return (
		<div className="space-y-5">
			<Segmented
				label={ __( 'Decision model', 'bridle' ) }
				value={ provider }
				options={ PROVIDERS }
				onChange={ choose }
				disabled={ busy }
			/>

			{ 'off' === provider && (
				<p className="text-sm text-muted-foreground">
					{ __(
						'Mail is sorted by its headers and sender only.',
						'bridle'
					) }
				</p>
			) }

			{ 'typesafe' === provider && (
				<Field
					label={ __( 'TypeSafe API key', 'bridle' ) }
					htmlFor="classifier-key"
					help={ __(
						'Uses Jev. Billed by TypeSafe, a fraction of a cent per email.',
						'bridle'
					) }
					hint={
						<ExternalLink href="https://console.typesafe.ai/keys">
							{ __( 'Create a key', 'bridle' ) }
						</ExternalLink>
					}
				>
					<Input
						id="classifier-key"
						type="password"
						autoComplete="off"
						className="max-w-md"
						value={ key }
						placeholder={ keyPlaceholder }
						onChange={ ( event ) => setKey( event.target.value ) }
					/>
				</Field>
			) }

			{ 'cloudflare' === provider && (
				<div className="space-y-4">
					<Field
						label={ __( 'Model', 'bridle' ) }
						help={ __(
							'Clef and Clef flash are Cloudflare’s own decision models and run on your free daily Workers AI allowance. Jev is TypeSafe’s; on Cloudflare it is paid from AI Gateway credits.',
							'bridle'
						) }
					>
						<div>
							<Segmented
								label={ __( 'Model', 'bridle' ) }
								value={ model }
								options={ CLOUDFLARE_MODELS }
								onChange={ setModel }
								disabled={ busy }
							/>
						</div>
					</Field>
					<Field
						label={ __( 'Account ID', 'bridle' ) }
						htmlFor="classifier-account"
						help={ __(
							'On your Cloudflare dashboard, under Account home.',
							'bridle'
						) }
					>
						<Input
							id="classifier-account"
							className="max-w-md font-mono"
							value={ accountId }
							onChange={ ( event ) =>
								setAccountId( event.target.value )
							}
						/>
					</Field>
					<Field
						label={ __( 'API token', 'bridle' ) }
						htmlFor="classifier-key"
						help={ __(
							'A token with the Workers AI permission. Billed by Cloudflare, a fraction of a cent per email.',
							'bridle'
						) }
						hint={
							<ExternalLink href="https://dash.cloudflare.com/profile/api-tokens">
								{ __( 'Create a token', 'bridle' ) }
							</ExternalLink>
						}
					>
						<Input
							id="classifier-key"
							type="password"
							autoComplete="off"
							className="max-w-md"
							value={ key }
							placeholder={ keyPlaceholder }
							onChange={ ( event ) =>
								setKey( event.target.value )
							}
						/>
					</Field>
				</div>
			) }

			{ 'off' !== provider && (
				<div className="space-y-3">
					<div className="flex flex-wrap items-center gap-3">
						<Button
							size="sm"
							onClick={ saveAndTest }
							disabled={ busy || ( ! saved && ! key.trim() ) }
						>
							{ busy
								? __( 'Testing…', 'bridle' )
								: __( 'Save and test', 'bridle' ) }
						</Button>
						<span className="text-xs text-muted-foreground">
							{ __(
								'Each email’s sender, subject and newest message are sent to the provider you choose.',
								'bridle'
							) }
						</span>
					</div>

					{ result?.ok && box && (
						<p className="flex items-start gap-2 text-sm">
							<Check className="mt-0.5 size-4 shrink-0 text-brand" />
							{ sprintf(
								/* translators: 1: what the sample email was read as, e.g. a sales pitch, 2: percent */
								__(
									'Working. It read the sample email as %1$s (%2$d%% sure).',
									'bridle'
								),
								BOX_NAMES[ box.value ] || box.value,
								Math.round( box.confidence * 100 )
							) }
						</p>
					) }
					{ result && ! result.ok && (
						<InlineError>{ result.error }</InlineError>
					) }
					{ ! result &&
						config.enabled &&
						config.provider === provider && (
							<p className="text-sm text-muted-foreground">
								{ config.status?.ok === false
									? sprintf(
											/* translators: %s: why the last call failed */
											__(
												'On, but the last email couldn’t be read: %s',
												'bridle'
											),
											config.status.error
									  )
									: sprintf(
											/* translators: %s: model name, e.g. Jev or Clef */
											__(
												'On. %s reads every new email.',
												'bridle'
											),
											MODEL_NAMES[ config.model ] ||
												config.model
									  ) }
							</p>
						) }
				</div>
			) }

			<InlineError>{ error }</InlineError>
		</div>
	);
}
