import { useEffect, useState } from 'react';
import { __, sprintf } from '@wordpress/i18n';
import { KeyRound, Zap } from 'lucide-react';

import { InlineError } from '@/components/settings/field';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ai } from '@/lib/api';
import { appData } from '@/lib/app-data';

const CONNECTORS = ( appData.adminUrl || '' ) + 'options-connectors.php';
const number = ( n ) => Number( n || 0 ).toLocaleString();

function Option( { icon: Icon, title, text, children } ) {
	return (
		<div className="grid content-start gap-3 rounded-xl border border-border/80 p-4">
			<div className="flex items-center gap-2.5">
				<span className="flex size-8 items-center justify-center rounded-lg bg-brand-soft text-brand-ink">
					<Icon className="size-4" />
				</span>
				<h3 className="text-sm font-semibold">{ title }</h3>
			</div>
			<p className="text-sm text-muted-foreground">{ text }</p>
			{ children }
		</div>
	);
}

/* Bridle AI switched on: what's left, the packs, and the way out. */
function Active( { state, onChange } ) {
	const [ error, setError ] = useState( null );
	const balance = state.balance || {};

	const buy = async ( pack ) => {
		setError( null );
		// Opened before the request so the browser doesn't block it.
		const tab = window.open( '', '_blank' );
		try {
			const { url } = await ai.bridleCheckout( pack );
			if ( tab ) {
				tab.location = url;
			} else {
				window.location = url;
			}
		} catch ( e ) {
			tab?.close();
			setError(
				e?.message || __( 'The checkout couldn’t start.', 'bridle' )
			);
		}
	};

	return (
		<div className="grid gap-4">
			<div className="flex flex-wrap items-baseline gap-x-6 gap-y-1">
				<span className="text-sm">
					<b className="text-2xl font-semibold tabular-nums">
						{ number( balance.free_left ) }
					</b>{ ' ' }
					{ sprintf(
						/* translators: %s: free answers a month, like 100 */
						__( 'of %s free left this month', 'bridle' ),
						number( balance.free_total )
					) }
				</span>
				<span className="text-sm">
					<b className="text-2xl font-semibold tabular-nums">
						{ number( balance.credits ) }
					</b>{ ' ' }
					{ __( 'bought answers', 'bridle' ) }
				</span>
			</div>
			<div className="flex flex-wrap items-center gap-2">
				{ Object.entries( state.packs || {} ).map(
					( [ pack, info ] ) => (
						<Button
							key={ pack }
							variant="outline"
							size="sm"
							onClick={ () => buy( pack ) }
						>
							{ sprintf(
								/* translators: 1: answers, like 1,000, 2: price, like $10 */
								__( '%1$s for %2$s', 'bridle' ),
								number( info.answers ),
								info.price
							) }
						</Button>
					)
				) }
				<span className="grow" />
				<Button
					variant="ghost"
					size="sm"
					onClick={ async () => onChange( await ai.bridleOff() ) }
				>
					{ __( 'Turn off', 'bridle' ) }
				</Button>
			</div>
			<p className="text-xs text-muted-foreground">
				{ __(
					'Only answers that pass Bridle’s checks count. Connect your own key any time; it’s used first.',
					'bridle'
				) }
			</p>
			<InlineError>{ error }</InlineError>
		</div>
	);
}

/*
 * Where the agent's answers come from (2026-11-02, hybrid): the owner's own
 * key in WordPress, free and unlimited, or Bridle AI with no key at all.
 */
export function AiSource( { canUseAi, wpVersionOk } ) {
	const [ state, setState ] = useState( null );
	const [ email, setEmail ] = useState( appData.user?.email || '' );
	const [ busy, setBusy ] = useState( false );
	const [ error, setError ] = useState( null );

	useEffect( () => {
		ai.bridle()
			.then( setState )
			.catch( () => setState( {} ) );
	}, [ canUseAi ] );

	if ( ! wpVersionOk ) {
		return (
			<p className="text-sm text-muted-foreground">
				{ __( 'The agent needs WordPress 7.0 or newer.', 'bridle' ) }
			</p>
		);
	}
	if ( ! state ) {
		return <div className="h-24" />;
	}
	if ( state.own_provider ) {
		return (
			<p className="flex items-center gap-2 text-sm">
				<span className="size-2 rounded-full bg-[#1f7a4d]" />
				{ __( 'Your own key, connected in WordPress.', 'bridle' ) }
			</p>
		);
	}
	if ( state.active ) {
		return <Active state={ state } onChange={ setState } />;
	}

	const turnOn = async () => {
		setBusy( true );
		setError( null );
		try {
			setState( await ai.bridleOn( email.trim() ) );
		} catch ( e ) {
			setError(
				e?.message || __( 'That didn’t work. Try again.', 'bridle' )
			);
		} finally {
			setBusy( false );
		}
	};

	return (
		<div className="grid gap-3 sm:grid-cols-2">
			<Option
				icon={ KeyRound }
				title={ __( 'Your own key', 'bridle' ) }
				text={ __(
					'Free and unlimited. Anthropic, OpenAI or Google, in WordPress.',
					'bridle'
				) }
			>
				<Button asChild variant="outline" size="sm" className="w-fit">
					<a href={ CONNECTORS }>
						{ __( 'Open Connectors', 'bridle' ) }
					</a>
				</Button>
			</Option>
			<Option
				icon={ Zap }
				title={ __( 'Bridle AI', 'bridle' ) }
				text={ __(
					'No key needed. 100 answers a month free, then packs from $10.',
					'bridle'
				) }
			>
				<div className="flex gap-2">
					<Input
						type="email"
						aria-label={ __( 'Email for receipts', 'bridle' ) }
						placeholder={ __( 'Email for receipts', 'bridle' ) }
						value={ email }
						onChange={ ( e ) => setEmail( e.target.value ) }
					/>
					<Button
						size="sm"
						className="h-9 shrink-0"
						disabled={ busy || ! email.trim() }
						onClick={ turnOn }
					>
						{ __( 'Turn on', 'bridle' ) }
					</Button>
				</div>
				<InlineError>{ error }</InlineError>
			</Option>
		</div>
	);
}
