import { Fragment } from 'react';
import { __ } from '@wordpress/i18n';
import {
	BookOpen,
	Database,
	ListFilter,
	Mail,
	MessageCircle,
	MessageSquareText,
	PlugZap,
	Send,
	Sparkles,
	UsersRound,
} from 'lucide-react';
import { cn } from 'cn';

import { HelpTip } from '@/components/ui/help-tip';
import { extend } from '@/lib/extend';
import { Link } from '@/lib/router';

/*
 * Settings' pages, in menu order. `gap` starts a new group in the menu: the
 * agent's pages first, then the site's. The router's SETTINGS_SECTIONS holds
 * the same keys.
 */
export const SETTINGS_PAGES = [
	{ key: 'inboxes', label: __( 'Inboxes', 'bridle' ), icon: Mail },
	{
		key: 'replies',
		label: __( 'Replies', 'bridle' ),
		icon: MessageSquareText,
	},
	{ key: 'knowledge', label: __( 'Knowledge', 'bridle' ), icon: BookOpen },
	{ key: 'chat', label: __( 'Chat', 'bridle' ), icon: MessageCircle },
	{ key: 'sorting', label: __( 'Sorting', 'bridle' ), icon: ListFilter },
	{ key: 'ai-apps', label: __( 'AI apps', 'bridle' ), icon: PlugZap },
	{ key: 'team', label: __( 'Team', 'bridle' ), icon: UsersRound, gap: true },
	{ key: 'emails', label: __( 'Emails', 'bridle' ), icon: Send },
	{ key: 'data', label: __( 'Data', 'bridle' ), icon: Database },
	// What Bridle Pro adds (one of its three quiet places); with Pro active,
	// Pro's licence screen takes this page over.
	{
		key: 'pro',
		label: __( 'Bridle Pro', 'bridle' ),
		icon: Sparkles,
		gap: true,
	},
];

/** Bridle's pages with any an add-on adds (`bridle.settingsPages`). */
export function settingsPages() {
	const pages = extend( 'settingsPages', SETTINGS_PAGES );
	return Array.isArray( pages ) ? pages : SETTINGS_PAGES;
}

/*
 * Settings is one panel (Mailpuff's layout, 2026-11-02): a menu of pages on
 * its left, inside the panel, and the open page beside it. The menu belongs to
 * Settings only, so the app keeps its no-sidebar rule; on a narrow screen it
 * becomes a scrolling row above the page.
 */
export function SettingsFrame( { current, children } ) {
	return (
		<div className="surface flex min-h-[34rem] overflow-hidden max-[781px]:flex-col">
			<nav
				aria-label={ __( 'Settings pages', 'bridle' ) }
				className="flex w-52 shrink-0 flex-col gap-0.5 border-r border-border/70 p-3 max-[781px]:w-auto max-[781px]:flex-row max-[781px]:overflow-x-auto max-[781px]:border-r-0 max-[781px]:border-b"
			>
				{ settingsPages().map( ( { key, label, icon: Icon, gap } ) => {
					const active = key === current;
					return (
						<Fragment key={ key }>
							{ gap && (
								<span
									aria-hidden="true"
									className="mx-3 my-2 border-t border-border/70 max-[781px]:hidden"
								/>
							) }
							<Link
								to={ `/settings/${ key }` }
								aria-current={ active ? 'page' : undefined }
								className={ cn(
									'flex h-9 shrink-0 items-center gap-2.5 rounded-lg px-3 text-sm whitespace-nowrap outline-none transition-colors duration-150 focus-visible:ring-[3px] focus-visible:ring-ring/50',
									active
										? 'bg-brand-soft font-medium text-foreground'
										: 'text-muted-foreground hover:bg-accent hover:text-foreground'
								) }
							>
								<Icon
									aria-hidden="true"
									className={ cn(
										'size-4 shrink-0',
										active ? 'text-brand-ink' : 'opacity-70'
									) }
								/>
								{ label }
							</Link>
						</Fragment>
					);
				} ) }
			</nav>
			<div className="min-w-0 flex-1 px-8 pt-6 pb-8 max-[781px]:px-5">
				{ children }
			</div>
		</div>
	);
}

/*
 * One settings page: its title and at most one action on the first line,
 * then its sections, split by hairlines. `back` is a small link above the
 * title for a page inside a page (one inbox).
 */
export function SettingsPanel( { title, actions, back, children } ) {
	return (
		<div>
			{ back }
			<div className="flex min-h-9 items-center justify-between gap-4 pb-4">
				<h2 className="flex min-w-0 items-center gap-2 text-lg font-semibold tracking-[-0.01em]">
					{ title }
				</h2>
				{ actions && (
					<div className="flex shrink-0 items-center gap-2">
						{ actions }
					</div>
				) }
			</div>
			<div className="divide-y divide-border/70 border-t border-border/70">
				{ children }
			</div>
		</div>
	);
}

/*
 * A block of a settings page: a small heading with its "?" and an optional
 * action, then the controls. No card of its own: the panel is the card.
 */
export function SettingsSection( { title, help, actions, children } ) {
	return (
		<section className="space-y-4 py-6 last:pb-0">
			{ ( title || actions ) && (
				<div className="flex items-center justify-between gap-4">
					{ title && (
						<h3 className="flex items-center gap-1.5 text-sm font-semibold">
							{ title }
							<HelpTip>{ help }</HelpTip>
						</h3>
					) }
					{ actions && (
						<div className="flex shrink-0 items-center gap-2">
							{ actions }
						</div>
					) }
				</div>
			) }
			{ children }
		</section>
	);
}
