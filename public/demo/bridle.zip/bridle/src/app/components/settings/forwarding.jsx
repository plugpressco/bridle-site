import { useEffect, useRef, useState } from 'react';
import { __ } from '@wordpress/i18n';
import { CheckCircle2, Loader2, RefreshCw } from 'lucide-react';

import { CopyBox } from '@/components/settings/copy-box';
import { Button } from '@/components/ui/button';
import { inboxes as inboxesApi } from '@/lib/api';

/*
 * The forwarding step for an inbox: the address to forward to, and whether
 * the first email has arrived. There is no verify endpoint; an inbox
 * counts as connected once `last_received_at` is set, so this polls
 * GET /inboxes every 8 seconds for up to 90 seconds, plus "Check now".
 */
export function ForwardingBlock( { inbox, onInboxChange } ) {
	const [ checking, setChecking ] = useState( false );
	const [ polling, setPolling ] = useState( ! inbox.last_received_at );
	const timer = useRef( null );
	const startedAt = useRef( Date.now() );

	const check = async () => {
		setChecking( true );
		try {
			const rows = await inboxesApi.list();
			const fresh = ( rows || [] ).find(
				( row ) => Number( row.id ) === Number( inbox.id )
			);
			if ( fresh ) {
				onInboxChange( fresh );
				if ( fresh.last_received_at ) {
					setPolling( false );
				}
			}
		} finally {
			setChecking( false );
		}
	};

	useEffect( () => {
		if ( ! polling ) {
			return undefined;
		}
		timer.current = setInterval( () => {
			if ( Date.now() - startedAt.current > 90000 ) {
				setPolling( false );
				return;
			}
			check();
		}, 8000 );
		return () => clearInterval( timer.current );
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [ polling ] );

	const connected = !! inbox.last_received_at;

	return (
		<div className="space-y-3">
			<CopyBox value={ inbox.forwarding_address } />
			<div className="flex items-center gap-3 text-sm">
				{ connected ? (
					<span className="inline-flex items-center gap-1.5 text-brand-ink">
						<CheckCircle2 className="size-4" />
						{ __( 'Connected, mail is arriving', 'bridle' ) }
					</span>
				) : (
					<span className="inline-flex items-center gap-1.5 text-muted-foreground">
						{ polling ? (
							<Loader2 className="size-4 animate-spin" />
						) : null }
						{ __( 'Waiting for your first email', 'bridle' ) }
					</span>
				) }
				{ ! connected && (
					<Button
						type="button"
						variant="ghost"
						size="sm"
						onClick={ check }
						disabled={ checking }
					>
						<RefreshCw
							className={ checking ? 'animate-spin' : undefined }
						/>
						{ __( 'Check now', 'bridle' ) }
					</Button>
				) }
			</div>
		</div>
	);
}
