import { __ } from '@wordpress/i18n';
import { cn } from 'cn';

import { Field } from '@/components/settings/field';
import { Input } from '@/components/ui/input';

export const INBOX_COLORS = [
	'#679EEE',
	'#181818',
	'#DB2777',
	'#D97706',
	'#0D9488',
	'#7C3AED',
	'#65A30D',
];

export function ColorPicker( { value, onChange } ) {
	return (
		<div className="flex flex-wrap gap-2">
			{ INBOX_COLORS.map( ( color ) => (
				<button
					key={ color }
					type="button"
					aria-label={ color }
					aria-pressed={ ( value || '' ).toUpperCase() === color }
					onClick={ () => onChange( color ) }
					className={ cn(
						'size-7 rounded-full ring-offset-2 ring-offset-background',
						( value || '' ).toUpperCase() === color &&
							'ring-2 ring-foreground'
					) }
					style={ { backgroundColor: color } }
				/>
			) ) }
		</div>
	);
}

/* Name, address and colour: shared by "connect an inbox" and the inbox page. */
export function InboxFields( { value, onChange, addressEditable = true } ) {
	const set = ( key ) => ( event ) =>
		onChange( { ...value, [ key ]: event.target.value } );
	return (
		<div className="space-y-4">
			<Field
				label={ __( 'Name', 'bridle' ) }
				htmlFor="inbox-name"
				hint={ __(
					'How the inbox appears in Bridle, e.g. “Support”.',
					'bridle'
				) }
			>
				<Input
					id="inbox-name"
					value={ value.display_name || '' }
					onChange={ set( 'display_name' ) }
					className="max-w-md"
				/>
			</Field>
			<Field
				label={ __( 'Support address', 'bridle' ) }
				htmlFor="inbox-address"
				hint={ __(
					'The address customers write to. Replies go out from it.',
					'bridle'
				) }
			>
				<Input
					id="inbox-address"
					type="email"
					value={ value.email_address || '' }
					onChange={ set( 'email_address' ) }
					className="max-w-md"
					disabled={ ! addressEditable }
				/>
			</Field>
			<Field
				label={ __( 'Colour', 'bridle' ) }
				hint={ __(
					'The marker on rows when you look across all inboxes.',
					'bridle'
				) }
			>
				<ColorPicker
					value={ value.color }
					onChange={ ( color ) => onChange( { ...value, color } ) }
				/>
			</Field>
		</div>
	);
}
