import { __ } from '@wordpress/i18n';
import { ArrowUpRight } from 'lucide-react';

import { appData } from '@/lib/app-data';

/*
 * A quiet text link to a guide on bridle.to (owner, 2026-11-09: grow with
 * helpful links, never admin notices). The guide explains the job with the
 * free plugin first and says what Bridle Pro adds. One per screen at most,
 * grey text, never a button, a badge or a locked control, and gone once Pro
 * is active. The UTM tags only say which screen the click came from.
 */
export const GUIDES = {
	'chat-on-other-sites': __( 'Put this chat on your other sites', 'bridle' ),
	'knowledge-gaps': __(
		'See what the agent couldn’t answer, and turn it into docs',
		'bridle'
	),
	workflows: __(
		'Remind the team about late replies and resolve quiet conversations',
		'bridle'
	),
	'store-lookups': __(
		'Let drafts read orders, items and tracking',
		'bridle'
	),
};

export function guideUrl( topic, screen ) {
	const query = new URLSearchParams( {
		utm_source: 'bridle-plugin',
		utm_medium: screen,
		utm_campaign: 'guides',
	} );
	return `https://bridle.to/guides/${ topic }/?${ query }`;
}

export function GuideLink( { topic, screen, className } ) {
	if ( appData.pro || ! GUIDES[ topic ] ) {
		return null;
	}
	return (
		<p className={ className ?? 'pt-4 text-sm' }>
			<a
				href={ guideUrl( topic, screen ) }
				target="_blank"
				rel="noopener noreferrer"
				className="inline-flex items-center gap-1 text-muted-foreground hover:text-foreground hover:underline"
			>
				{ GUIDES[ topic ] }
				<ArrowUpRight aria-hidden="true" className="size-3.5" />
			</a>
		</p>
	);
}
