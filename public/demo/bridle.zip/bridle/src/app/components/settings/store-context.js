import { createContext } from 'react';

export const SettingsStoreContext = createContext( null );
