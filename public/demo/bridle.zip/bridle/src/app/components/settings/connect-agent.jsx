import { useState } from 'react';
import { __ } from '@wordpress/i18n';
import { Check } from 'lucide-react';
import { cn } from 'cn';

import { Row } from '@/components/settings/field';
import { SettingsSection } from '@/components/settings/settings-frame';
import { useShell } from '@/components/shell/shell-context';
import { Switch } from '@/components/ui/switch';
import { ai } from '@/lib/api';

/* "found" or "not installed", for a connector plugin. */
function Found( { yes } ) {
	return (
		<span
			className={ cn(
				'ml-2 inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px]',
				yes
					? 'bg-brand-soft text-brand-ink'
					: 'bg-secondary text-muted-foreground'
			) }
		>
			{ yes && <Check className="size-3" /> }
			{ yes ? __( 'Found', 'bridle' ) : __( 'Not installed', 'bridle' ) }
		</span>
	);
}

/* A step number in the connect list. */
function Step( { n } ) {
	return (
		<span className="flex size-6 shrink-0 items-center justify-center rounded-full border bg-card text-xs font-semibold tabular-nums">
			{ n }
		</span>
	);
}

/*
 * Settings → AI apps: how ChatGPT, Claude, Codex or any MCP client gets into
 * the inbox, and whose app may send by itself.
 *
 * @param {Object}   props
 * @param {Object}   props.status    GET /ai/status (connect, senders).
 * @param {Function} props.setStatus Replace it after a change.
 */
export function ConnectAgent( { status, setStatus } ) {
	const { teammates } = useShell();
	const [ busy, setBusy ] = useState( null );
	const [ error, setError ] = useState( null );
	const connect = status?.connect || {};
	const senders = new Set(
		( status?.senders || [] ).map( ( s ) => Number( s.id ) )
	);

	const toggle = ( userId ) => async ( on ) => {
		setBusy( userId );
		setError( null );
		try {
			setStatus(
				await ( on
					? ai.allowSending( userId )
					: ai.stopSending( userId ) )
			);
		} catch ( err ) {
			setError(
				err?.message || __( 'Couldn’t save that. Try again.', 'bridle' )
			);
		} finally {
			setBusy( null );
		}
	};

	if ( status && ! connect.abilities ) {
		return (
			<SettingsSection>
				<p className="text-sm text-muted-foreground">
					{ __(
						'Connecting an AI app needs WordPress 7.0 or newer.',
						'bridle'
					) }
				</p>
			</SettingsSection>
		);
	}

	return (
		<>
			<SettingsSection
				title={ __( 'Connect', 'bridle' ) }
				help={ __(
					'Claude, ChatGPT, Codex or any MCP app can then read conversations, search your knowledge, write drafts, add notes and resolve. Its drafts are checked like Bridle’s own.',
					'bridle'
				) }
			>
				<ol className="space-y-4 text-sm">
					<li className="flex gap-3">
						<Step n={ 1 } />
						<div className="min-w-0 space-y-1.5">
							<div className="font-medium">
								{ __( 'Install an MCP connector', 'bridle' ) }
							</div>
							<div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
								<span>
									Saddle
									<Found yes={ !! connect.saddle } />
								</span>
								<span>
									{ __( 'WordPress MCP Adapter', 'bridle' ) }
									<Found yes={ !! connect.mcp_adapter } />
								</span>
							</div>
							{ connect.saddle && (
								<p className="text-xs text-muted-foreground">
									{ connect.saddle_on
										? __(
												'In Saddle, give the app Edit content under AI apps.',
												'bridle'
										  )
										: __(
												'In Saddle, switch Bridle on under Services, then give the app Edit content under AI apps.',
												'bridle'
										  ) }
								</p>
							) }
						</div>
					</li>
					<li className="flex gap-3">
						<Step n={ 2 } />
						<div className="min-w-0 space-y-1">
							<div className="font-medium">
								{ __(
									'Create an application password',
									'bridle'
								) }
							</div>
							<p className="text-xs text-muted-foreground">
								{ __(
									'Name it after the app, like “Claude”. Bridle shows that name on what it writes.',
									'bridle'
								) }{ ' ' }
								{ connect.profile_url && (
									<a
										href={ connect.profile_url }
										className="text-brand-ink underline-offset-2 hover:underline"
									>
										{ __( 'Open your profile', 'bridle' ) }
									</a>
								) }
							</p>
						</div>
					</li>
				</ol>
			</SettingsSection>

			<SettingsSection
				title={ __( 'Who may send', 'bridle' ) }
				help={ __(
					'Off until you turn it on. A teammate’s AI app can then send by itself in inboxes whose agent isn’t Off, after a 2-minute hold.',
					'bridle'
				) }
			>
				<div className="divide-y divide-border/60">
					{ teammates.map( ( person ) => (
						<Row key={ person.id } label={ person.display_name }>
							<Switch
								aria-label={ person.display_name }
								checked={ senders.has( Number( person.id ) ) }
								disabled={ ! status || busy === person.id }
								onCheckedChange={ toggle( person.id ) }
							/>
						</Row>
					) ) }
				</div>
				{ error && (
					<p role="alert" className="text-sm text-destructive">
						{ error }
					</p>
				) }
			</SettingsSection>
		</>
	);
}
