import { cn } from 'cn';

import { HelpTip } from '@/components/ui/help-tip';
import { Label } from '@/components/ui/label';

/* A native select that looks like the kit's inputs. */
export const SELECT =
	'h-9 w-full rounded-md border border-input bg-card px-3 text-sm outline-none hover:border-foreground/30 focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50';

/*
 * A labelled control. `help` is a "?" beside the label; `hint` is a short
 * fact under the control (a state, a count), never an explanation.
 */
export function Field( { label, help, hint, htmlFor, className, children } ) {
	return (
		<div className={ cn( 'space-y-1.5', className ) }>
			{ label && (
				<div className="flex h-5 items-center gap-1.5">
					<Label htmlFor={ htmlFor }>{ label }</Label>
					<HelpTip>{ help }</HelpTip>
				</div>
			) }
			{ children }
			{ hint && (
				<p className="text-xs text-muted-foreground">{ hint }</p>
			) }
		</div>
	);
}

/*
 * A row with the control on the right: for switches. Stack them in a
 * `divide-y`. `help` is the "?" beside the label; `hint` a short fact.
 */
export function Row( { label, help, hint, children } ) {
	return (
		<div className="flex items-center justify-between gap-6 py-3 first:pt-0 last:pb-0">
			<div className="min-w-0">
				<div className="flex items-center gap-1.5 text-sm font-medium">
					{ label }
					<HelpTip>{ help }</HelpTip>
				</div>
				{ hint && (
					<p className="mt-0.5 text-xs text-muted-foreground">
						{ hint }
					</p>
				) }
			</div>
			<div className="shrink-0">{ children }</div>
		</div>
	);
}

/* The short inline error under a choice that saves at once and didn't. */
export function InlineError( { children } ) {
	if ( ! children ) {
		return null;
	}
	return (
		<p role="alert" className="text-sm text-destructive">
			{ children }
		</p>
	);
}

/*
 * A small segmented choice (the agent mode's look): one radio group of
 * buttons on a muted track. `options` is [[ value, label ]].
 */
export function Segmented( {
	label,
	value,
	options,
	onChange,
	disabled,
	size = 'md',
} ) {
	return (
		<div
			role="radiogroup"
			aria-label={ label }
			className="inline-flex rounded-lg bg-muted p-0.5"
		>
			{ options.map( ( [ option, text ] ) => (
				<button
					key={ option }
					type="button"
					role="radio"
					aria-checked={ value === option }
					disabled={ disabled }
					onClick={ () => onChange( option ) }
					className={ cn(
						'cursor-pointer rounded-md font-medium outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50',
						size === 'sm'
							? 'px-3 py-1 text-[13px]'
							: 'px-4 py-1.5 text-sm',
						value === option
							? 'bg-card text-foreground shadow-sm'
							: 'text-muted-foreground hover:text-foreground'
					) }
				>
					{ text }
				</button>
			) ) }
		</div>
	);
}
