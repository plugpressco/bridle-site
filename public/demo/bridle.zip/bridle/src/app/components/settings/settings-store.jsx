import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { __, sprintf } from '@wordpress/i18n';

import { SavePill } from '@/components/settings/save-pill';
import { SettingsStoreContext } from '@/components/settings/store-context';
import { useShell } from '@/components/shell/shell-context';
import { inboxes as inboxesApi, settings } from '@/lib/api';

const same = ( a, b ) => String( a ?? '' ) === String( b ?? '' );
const without = ( patch, keys ) =>
	Object.fromEntries(
		Object.entries( patch || {} ).filter(
			( [ k ] ) => ! keys.includes( k )
		)
	);

/*
 * The one save model for Settings (AGENTS.md §7). Choices (switches, radios,
 * colour) save the moment they change, with a rollback and an inline error
 * if the server says no (`saveNow`). Typing is held here as unsaved edits and
 * saved together from the floating pill (`saveAll`).
 *
 * Edits live above the pages, so they survive a switch of tab or inbox:
 * nothing is lost by moving around Settings, and the pill stays until you
 * save or discard. `beforeunload` guards a reload or a closed tab.
 *
 * A scope is `site` (GET/POST /settings) or `inbox:{id}` (PATCH /inboxes/{id}).
 */
export function SettingsStore( { children } ) {
	const { inboxes, refreshInboxes } = useShell();
	const [ site, setSite ] = useState( null );
	const [ edits, setEdits ] = useState( {} );
	const [ live, setLive ] = useState( {} );
	const [ save, setSave ] = useState( { state: 'idle', error: null } );
	const asked = useRef( false );
	const timer = useRef( null );
	const latest = useRef( {} );
	latest.current = { site, inboxes, edits, refreshInboxes };

	const loadSite = useCallback( () => {
		if ( asked.current ) {
			return;
		}
		asked.current = true;
		settings
			.get()
			.then( ( all ) => setSite( all || {} ) )
			.catch( () => setSite( {} ) );
	}, [] );

	const persist = useCallback( async ( scope, patch ) => {
		if ( scope === 'site' ) {
			await settings.save( patch );
			setSite( ( s ) => ( { ...s, ...patch } ) );
			return;
		}
		await inboxesApi.update( Number( scope.slice( 6 ) ), patch );
		await latest.current.refreshInboxes();
	}, [] );

	const baseOf = ( scope ) =>
		scope === 'site'
			? latest.current.site
			: latest.current.inboxes.find(
					( row ) => 'inbox:' + row.id === scope
			  );

	// Record a typed value, or forget it when it is back to what is stored.
	const setField = useCallback( ( scope, key, value ) => {
		setEdits( ( prev ) => {
			const patch = { ...prev[ scope ] };
			if ( same( value, baseOf( scope )?.[ key ] ) ) {
				delete patch[ key ];
			} else {
				patch[ key ] = value;
			}
			const next = { ...prev };
			if ( Object.keys( patch ).length ) {
				next[ scope ] = patch;
			} else {
				delete next[ scope ];
			}
			return next;
		} );
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [] );

	// A choice: show it now, save it, put it back and throw if that fails.
	const saveNow = useCallback(
		async ( scope, patch ) => {
			setLive( ( l ) => ( {
				...l,
				[ scope ]: { ...l[ scope ], ...patch },
			} ) );
			try {
				await persist( scope, patch );
			} finally {
				setLive( ( l ) => ( {
					...l,
					[ scope ]: without( l[ scope ], Object.keys( patch ) ),
				} ) );
			}
		},
		[ persist ]
	);

	const saveAll = useCallback( async () => {
		window.clearTimeout( timer.current );
		setSave( { state: 'saving', error: null } );
		for ( const [ scope, patch ] of Object.entries(
			latest.current.edits
		) ) {
			try {
				await persist( scope, patch );
			} catch ( err ) {
				const row = baseOf( scope );
				setSave( {
					state: 'error',
					error: sprintf(
						/* translators: 1: what failed to save, 2: the reason */
						__( 'Couldn’t save %1$s. %2$s', 'bridle' ),
						scope === 'site'
							? __( 'general settings', 'bridle' )
							: row?.display_name || __( 'this inbox', 'bridle' ),
						err?.message || __( 'Try again.', 'bridle' )
					),
				} );
				return;
			}
			// Keep anything typed while it was saving.
			setEdits( ( prev ) => {
				const keep = Object.fromEntries(
					Object.entries( prev[ scope ] || {} ).filter(
						( [ k, v ] ) => v !== patch[ k ]
					)
				);
				const next = { ...prev };
				if ( Object.keys( keep ).length ) {
					next[ scope ] = keep;
				} else {
					delete next[ scope ];
				}
				return next;
			} );
		}
		setSave( { state: 'saved', error: null } );
		timer.current = window.setTimeout(
			() => setSave( { state: 'idle', error: null } ),
			1800
		);
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [ persist ] );

	const discard = useCallback( () => {
		setEdits( {} );
		setSave( { state: 'idle', error: null } );
	}, [] );

	useEffect( () => () => window.clearTimeout( timer.current ), [] );

	const dirty = Object.keys( edits ).length > 0;
	useEffect( () => {
		if ( ! dirty ) {
			return undefined;
		}
		const guard = ( event ) => {
			event.preventDefault();
			event.returnValue = '';
		};
		window.addEventListener( 'beforeunload', guard );
		return () => window.removeEventListener( 'beforeunload', guard );
	}, [ dirty ] );

	const value = useMemo(
		() => ( {
			site,
			edits,
			live,
			dirty,
			save,
			loadSite,
			setField,
			saveNow,
			saveAll,
			discard,
		} ),
		[
			site,
			edits,
			live,
			dirty,
			save,
			loadSite,
			setField,
			saveNow,
			saveAll,
			discard,
		]
	);

	return (
		<SettingsStoreContext.Provider value={ value }>
			{ children }
			<SavePill />
		</SettingsStoreContext.Provider>
	);
}
