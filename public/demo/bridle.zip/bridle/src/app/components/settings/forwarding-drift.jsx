import { useState } from 'react';
import { __, _n, sprintf } from '@wordpress/i18n';
import { TriangleAlert } from 'lucide-react';

import { useShell } from '@/components/shell/shell-context';
import { Button } from '@/components/ui/button';
import { inboxes as inboxesApi } from '@/lib/api';
import { appData } from '@/lib/app-data';

/*
 * Shown when an inbox's forwarding points at another site address (a
 * migrated or cloned site). One button re-registers them all. Nothing else
 * re-points a registered inbox (#104), so a staging copy never takes
 * production's mail unless someone presses it there.
 */
export function ForwardingDrift() {
	const { refreshInboxes } = useShell();
	const [ drift, setDrift ] = useState( appData.forwardingDrift || null );
	const [ fixing, setFixing ] = useState( false );
	const [ result, setResult ] = useState( null );
	const [ error, setError ] = useState( null );

	const fix = async () => {
		setFixing( true );
		setError( null );
		try {
			const fixed = await inboxesApi.fixForwarding();
			setResult( fixed );
			setDrift( fixed?.drift || null );
			refreshInboxes().catch( () => {} );
		} catch {
			setError( __( 'Couldn’t fix forwarding. Try again.', 'bridle' ) );
		} finally {
			setFixing( false );
		}
	};

	const failures = ( result?.results || [] ).filter( ( r ) => ! r.success );

	return (
		<>
			{ drift?.drifted > 0 && (
				<div className="flex flex-wrap items-center gap-3 rounded-lg bg-note px-3 py-2 text-sm text-note-foreground">
					<TriangleAlert className="size-4 shrink-0" />
					<span className="min-w-0 flex-1">
						{ sprintf(
							/* translators: %d: number of inboxes whose forwarding points at the wrong site */
							_n(
								'%d inbox forwards to a different site address. If this site moved, fix it. On a staging copy, leave it.',
								'%d inboxes forward to a different site address. If this site moved, fix them. On a staging copy, leave them.',
								drift.drifted,
								'bridle'
							),
							drift.drifted
						) }
					</span>
					<Button
						size="sm"
						variant="outline"
						onClick={ fix }
						disabled={ fixing }
					>
						{ fixing
							? __( 'Fixing…', 'bridle' )
							: __( 'Fix forwarding', 'bridle' ) }
					</Button>
				</div>
			) }
			{ error && (
				<p role="alert" className="text-sm text-destructive">
					{ error }
				</p>
			) }
			{ failures.length > 0 && (
				<p className="text-sm text-destructive">
					{ failures
						.map( ( r ) => `${ r.name }: ${ r.error }` )
						.join( ' · ' ) }
				</p>
			) }
		</>
	);
}
