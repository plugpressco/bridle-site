import { useEffect, useState } from 'react';
import { __ } from '@wordpress/i18n';
import { Plus } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { api } from '@/lib/api';

const firstLine = ( body ) =>
	( body || '' )
		.replace( /<\/(p|div|li|h\d)>|<br\s*\/?>/gi, '\n' )
		.replace( /<[^>]*>/g, '' )
		.split( '\n' )
		.map( ( l ) => l.trim() )
		.find( Boolean ) || '';

function SnippetForm( { initial, onSave, onCancel } ) {
	const [ title, setTitle ] = useState( initial?.title || '' );
	const [ body, setBody ] = useState( initial?.body || '' );
	const [ busy, setBusy ] = useState( false );
	const [ error, setError ] = useState( null );

	const submit = async ( event ) => {
		event.preventDefault();
		setBusy( true );
		setError( null );
		try {
			await onSave( { title, body } );
		} catch ( err ) {
			setError( err?.message || __( 'Could not save.', 'bridle' ) );
			setBusy( false );
		}
	};

	return (
		<form onSubmit={ submit } className="space-y-3 py-3">
			<Input
				aria-label={ __( 'Snippet title', 'bridle' ) }
				placeholder={ __( 'Title, e.g. Refund policy', 'bridle' ) }
				value={ title }
				onChange={ ( e ) => setTitle( e.target.value ) }
				className="max-w-md"
			/>
			<Textarea
				aria-label={ __( 'Snippet text', 'bridle' ) }
				placeholder={ __(
					'What the agent may say, and you may insert.',
					'bridle'
				) }
				rows={ 5 }
				value={ body }
				onChange={ ( e ) => setBody( e.target.value ) }
				className="max-w-md"
			/>
			{ error && <p className="text-sm text-destructive">{ error }</p> }
			<div className="flex gap-2">
				<Button
					type="submit"
					size="sm"
					disabled={ busy || ! title || ! body }
				>
					{ busy
						? __( 'Saving…', 'bridle' )
						: __( 'Save', 'bridle' ) }
				</Button>
				<Button
					type="button"
					size="sm"
					variant="ghost"
					onClick={ onCancel }
				>
					{ __( 'Cancel', 'bridle' ) }
				</Button>
			</div>
		</form>
	);
}

/*
 * The saved replies the agent cites and the composer inserts. The collection
 * is small, so we reload it after every change.
 */
export function Snippets() {
	const [ rows, setRows ] = useState( null );
	const [ editing, setEditing ] = useState( null ); // id | 'new' | null
	const [ deleting, setDeleting ] = useState( null ); // id awaiting Yes
	const [ busy, setBusy ] = useState( false );
	const [ error, setError ] = useState( null );

	const load = () =>
		api
			.get( '/saved-replies' )
			.then( ( list ) => setRows( Array.isArray( list ) ? list : [] ) )
			.catch( () => setRows( [] ) );
	useEffect( () => {
		load();
	}, [] );

	const done = async () => {
		setEditing( null );
		await load();
	};

	const remove = async ( id ) => {
		setBusy( true );
		setError( null );
		try {
			await api.del( `/saved-replies/${ id }` );
			setDeleting( null );
			await load();
		} catch {
			setError(
				__( 'Couldn’t delete the snippet. Try again.', 'bridle' )
			);
		} finally {
			setBusy( false );
		}
	};

	return (
		<div>
			{ rows === null && (
				<p className="text-sm text-muted-foreground">
					{ __( 'Loading…', 'bridle' ) }
				</p>
			) }
			<ul className="divide-y divide-border/60">
				{ ( rows || [] ).map( ( row ) =>
					editing === row.id ? (
						<li key={ row.id }>
							<SnippetForm
								initial={ row }
								onCancel={ () => setEditing( null ) }
								onSave={ async ( data ) => {
									await api.patch(
										`/saved-replies/${ row.id }`,
										data
									);
									await done();
								} }
							/>
						</li>
					) : (
						<li
							key={ row.id }
							className="flex items-center gap-4 py-2.5"
						>
							<div className="min-w-0 flex-1">
								<div className="truncate text-sm font-medium">
									{ row.title }
								</div>
								<div className="truncate text-xs text-muted-foreground">
									{ firstLine( row.body ) }
								</div>
							</div>
							{ deleting === row.id ? (
								<>
									<Button
										size="sm"
										variant="destructive"
										disabled={ busy }
										onClick={ () => remove( row.id ) }
									>
										{ busy
											? __( 'Deleting…', 'bridle' )
											: __( 'Yes, delete', 'bridle' ) }
									</Button>
									<Button
										size="sm"
										variant="ghost"
										onClick={ () => setDeleting( null ) }
									>
										{ __( 'Cancel', 'bridle' ) }
									</Button>
								</>
							) : (
								<>
									<Button
										size="sm"
										variant="ghost"
										onClick={ () => setEditing( row.id ) }
									>
										{ __( 'Edit', 'bridle' ) }
									</Button>
									<Button
										size="sm"
										variant="ghost"
										onClick={ () => {
											setError( null );
											setDeleting( row.id );
										} }
									>
										{ __( 'Delete', 'bridle' ) }
									</Button>
								</>
							) }
						</li>
					)
				) }
			</ul>
			{ error && (
				<p role="alert" className="py-2 text-sm text-destructive">
					{ error }
				</p>
			) }
			{ rows && ! rows.length && editing !== 'new' && (
				<p className="py-2 text-sm text-muted-foreground">
					{ __(
						'No snippets yet. Add the answers you give again and again.',
						'bridle'
					) }
				</p>
			) }
			{ editing === 'new' ? (
				<SnippetForm
					onCancel={ () => setEditing( null ) }
					onSave={ async ( data ) => {
						await api.post( '/saved-replies', data );
						await done();
					} }
				/>
			) : (
				<Button
					size="sm"
					variant="ghost"
					className="-ml-2 mt-1"
					onClick={ () => setEditing( 'new' ) }
				>
					<Plus />
					{ __( 'Add a snippet', 'bridle' ) }
				</Button>
			) }
		</div>
	);
}
