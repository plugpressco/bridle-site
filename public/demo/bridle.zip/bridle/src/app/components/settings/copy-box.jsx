import { useState } from 'react';
import { __ } from '@wordpress/i18n';
import { Copy } from 'lucide-react';
import { cn } from 'cn';

import { Button } from '@/components/ui/button';

/*
 * Text to copy somewhere else, with a Copy button: an inbox's forwarding
 * address, or (`multiline`) an embed code. The text stays selectable, so a
 * blocked clipboard still lets the owner copy it by hand.
 */
export function CopyBox( { value, multiline = false, label } ) {
	const [ copied, setCopied ] = useState( false );

	const copy = async () => {
		try {
			await window.navigator.clipboard.writeText( value || '' );
			setCopied( true );
			setTimeout( () => setCopied( false ), 2000 );
		} catch ( e ) {
			// Selectable: the owner can copy it by hand.
		}
	};

	return (
		<div
			className={ cn(
				'flex gap-2',
				multiline ? 'items-start' : 'items-center'
			) }
		>
			<code
				aria-label={ label }
				className={ cn(
					'min-w-0 flex-1 rounded-lg border bg-secondary px-3 py-2 font-mono text-sm select-all',
					multiline ? 'break-all whitespace-pre-wrap' : 'truncate'
				) }
			>
				{ value || '—' }
			</code>
			<Button type="button" variant="ghost" size="sm" onClick={ copy }>
				<Copy />
				{ copied ? __( 'Copied', 'bridle' ) : __( 'Copy', 'bridle' ) }
			</Button>
		</div>
	);
}
