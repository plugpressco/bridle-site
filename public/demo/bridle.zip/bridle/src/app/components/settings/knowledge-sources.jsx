import { __ } from '@wordpress/i18n';

import { InlineError, Row } from '@/components/settings/field';
import {
	truthy,
	useInstant,
	useSiteSettings,
} from '@/components/settings/use-draft';
import { Switch } from '@/components/ui/switch';

// [ source, setting key, label, help ].
const SOURCES = [
	[
		'kb',
		'knowledge_kb',
		__( 'Help docs', 'bridle' ),
		__( 'Published articles from Bridle KB.', 'bridle' ),
	],
	[
		'site',
		'knowledge_site',
		__( 'Pages and posts', 'bridle' ),
		__( 'Pricing, policies and posts from your site.', 'bridle' ),
	],
	[
		'products',
		'knowledge_products',
		__( 'Products', 'bridle' ),
		__( 'Names, prices and stock from WooCommerce.', 'bridle' ),
	],
	[
		'past',
		'knowledge_past',
		__( 'Past replies', 'bridle' ),
		__(
			'How your team answered similar questions, with names, emails, order numbers and outside links removed.',
			'bridle'
		),
	],
];

/*
 * What the agent may read besides the instructions and snippets. Each switch
 * saves at once. A source this site doesn't have (no WooCommerce, no Bridle
 * KB) is left out rather than shown disabled.
 *
 * @param {Object} props
 * @param {Object} props.status GET /ai/status `knowledge`: { kb: { available, enabled }, … }.
 */
export function KnowledgeSources( { status } ) {
	const { values, choose } = useSiteSettings();
	const [ error, run ] = useInstant();

	if ( ! status ) {
		return null;
	}

	return (
		<div className="space-y-2">
			<div className="divide-y divide-border/60">
				{ SOURCES.filter(
					( [ source ] ) => status[ source ]?.available !== false
				).map( ( [ , key, label, help ] ) => (
					<Row key={ key } label={ label } help={ help }>
						<Switch
							aria-label={ label }
							checked={
								!! values &&
								( values[ key ] === '' ||
									values[ key ] === undefined ||
									truthy( values[ key ] ) )
							}
							disabled={ ! values }
							onCheckedChange={ ( on ) =>
								run( () => choose( key, on ) )
							}
						/>
					</Row>
				) ) }
			</div>
			<InlineError>{ error }</InlineError>
		</div>
	);
}
