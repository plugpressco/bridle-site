import { useEffect, useState } from 'react';
import { __ } from '@wordpress/i18n';

import { Segmented } from '@/components/settings/field';
import {
	agentModeOf,
	forgetAgentMode,
} from '@/components/thread/agent-draft-card';
import { inboxAi } from '@/lib/api';

const AGENT_MODES = [
	[ 'off', __( 'Off', 'bridle' ) ],
	[ 'draft', __( 'Draft', 'bridle' ) ],
	[ 'auto', __( 'Auto', 'bridle' ) ],
];

// What each mode does, for the "?" beside Agent mode.
export const AGENT_MODE_HELP = __(
	'Off: the agent stays out. Draft: it drafts a reply to every new message and a person sends it. Auto: it sends the replies it is sure of after a 15-minute hold, at most twice per conversation and 30 an hour. Refunds, billing, legal, security, cancellations and upset customers always wait for a person. If you also answer from your mail app, keep Draft: Bridle can’t see those replies.',
	'bridle'
);

/*
 * Off / Draft / Auto for one inbox, saved on click (PATCH /inboxes/{id}/ai).
 * What the modes do lives in the "?" beside the heading (AGENT_MODE_HELP).
 */
export function AgentModeControl( { inboxId, label } ) {
	const [ mode, setMode ] = useState( null );
	const [ error, setError ] = useState( null );

	useEffect( () => {
		let cancelled = false;
		setMode( null );
		inboxAi
			.get( inboxId )
			.then( ( row ) => ! cancelled && setMode( agentModeOf( row ) ) )
			.catch( () => ! cancelled && setMode( 'off' ) );
		return () => {
			cancelled = true;
		};
	}, [ inboxId ] );

	const pick = async ( next ) => {
		const previous = mode;
		setMode( next );
		setError( null );
		try {
			await inboxAi.set( inboxId, next );
		} catch {
			setMode( previous );
			setError( __( 'Couldn’t save. Try again.', 'bridle' ) );
			return;
		}
		forgetAgentMode( inboxId );
	};

	return (
		<div className="flex flex-col items-end gap-1">
			<Segmented
				label={ label }
				value={ mode || 'off' }
				options={ AGENT_MODES }
				onChange={ pick }
				disabled={ mode === null }
				size="sm"
			/>
			{ error && (
				<p role="alert" className="text-xs text-destructive">
					{ error }
				</p>
			) }
		</div>
	);
}
