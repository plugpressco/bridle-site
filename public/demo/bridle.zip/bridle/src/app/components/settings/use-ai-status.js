import { useEffect, useState } from 'react';

import { ai } from '@/lib/api';

/*
 * GET /ai/status for a settings page: whether drafting can run, the agent's
 * numbers, the knowledge sources and the AI app connection. `null` until it
 * answers (or when it fails); `setStatus` replaces it after a change.
 */
export function useAiStatus() {
	const [ status, setStatus ] = useState( null );
	useEffect( () => {
		let cancelled = false;
		ai.status()
			.then( ( next ) => ! cancelled && setStatus( next ) )
			.catch( () => ! cancelled && setStatus( null ) );
		return () => {
			cancelled = true;
		};
	}, [] );
	return [ status, setStatus ];
}
