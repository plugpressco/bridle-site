import { useEffect, useState } from 'react';
import { __ } from '@wordpress/i18n';

import { Field, SELECT } from '@/components/settings/field';
import { api } from '@/lib/api';

const TASKS = [
	[ 'model_email', __( 'Email drafts', 'bridle' ) ],
	[ 'model_chat', __( 'Chat answers', 'bridle' ) ],
];

/*
 * Model per task (#133): which of the connection's models writes email
 * drafts and which answers the chat. Automatic is Bridle's own order
 * (AgentService::MODELS). Only for the owner's own AI key; Bridle AI picks
 * its model itself. Saves with the page's other text edits.
 */
export function ModelPicker( { values, edit } ) {
	const [ models, setModels ] = useState( null );

	useEffect( () => {
		api.get( '/ai/models' )
			.then( ( data ) => setModels( data.models || [] ) )
			.catch( () => setModels( [] ) );
	}, [] );

	if ( ! models || models.length < 2 ) {
		return null;
	}

	// Grouped by provider when there is more than one.
	const providers = [ ...new Set( models.map( ( m ) => m.provider_name ) ) ];
	const options = ( list ) =>
		list.map( ( model ) => (
			<option key={ model.id } value={ model.id }>
				{ model.name || model.model }
			</option>
		) );

	return (
		<div className="grid gap-5 sm:grid-cols-2">
			{ TASKS.map( ( [ key, label ] ) => (
				<Field
					key={ key }
					label={ label }
					htmlFor={ `bridle-${ key }` }
					help={
						key === 'model_chat'
							? __(
									'A visitor waits for this one, so a fast model is a good pick.',
									'bridle'
							  )
							: __(
									'A person reads every draft before it goes, unless Auto sends it, so the strongest model pays off here.',
									'bridle'
							  )
					}
				>
					<select
						id={ `bridle-${ key }` }
						className={ SELECT }
						value={ values[ key ] || '' }
						onChange={ edit( key ) }
					>
						<option value="">
							{ __( 'Automatic', 'bridle' ) }
						</option>
						{ providers.length > 1
							? providers.map( ( provider ) => (
									<optgroup
										key={ provider }
										label={ provider }
									>
										{ options(
											models.filter(
												( m ) =>
													m.provider_name === provider
											)
										) }
									</optgroup>
							  ) )
							: options( models ) }
					</select>
				</Field>
			) ) }
		</div>
	);
}
