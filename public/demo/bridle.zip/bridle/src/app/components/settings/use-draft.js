import { useContext, useEffect, useMemo, useState } from 'react';
import { __ } from '@wordpress/i18n';

import { SettingsStoreContext } from '@/components/settings/store-context';

export const truthy = ( v ) => v === true || v === 1 || v === '1';

function useStore() {
	const store = useContext( SettingsStoreContext );
	if ( ! store ) {
		throw new Error( 'Settings hooks need a <SettingsStore> above them.' );
	}
	return store;
}

/* A record's values with the unsaved edits and the choice being saved laid over. */
function overlay( base, ...layers ) {
	return Object.assign( {}, base, ...layers );
}

/*
 * The site's settings (GET /settings). `values` is null until loaded.
 * `edit( key )` is an onChange for a text field (held until the pill saves);
 * `choose( key, value )` saves at once and throws if it fails.
 */
export function useSiteSettings() {
	const store = useStore();
	const { site, edits, live, loadSite, setField, saveNow } = store;
	useEffect( loadSite, [ loadSite ] );
	return {
		values: useMemo(
			() => ( site ? overlay( site, live.site, edits.site ) : null ),
			[ site, live.site, edits.site ]
		),
		edit: ( key ) => ( event ) =>
			setField( 'site', key, event.target.value ),
		choose: ( key, value ) => saveNow( 'site', { [ key ]: value } ),
	};
}

/* The same for one inbox row (PATCH /inboxes/{id}). */
export function useInboxSettings( inbox ) {
	const store = useStore();
	const scope = 'inbox:' + inbox?.id;
	const { edits, live, setField, saveNow } = store;
	return {
		values: useMemo(
			() => overlay( inbox, live[ scope ], edits[ scope ] ),
			[ inbox, live, edits, scope ]
		),
		edit: ( key ) => ( event ) =>
			setField( scope, key, event.target.value ),
		choose: ( patch ) => saveNow( scope, patch ),
	};
}

/*
 * For a choice that saves at once: `run( fn )` calls it and keeps a short
 * inline error when it fails (the page has already rolled the value back).
 */
export function useInstant( message ) {
	const [ error, setError ] = useState( null );
	const run = async ( fn ) => {
		setError( null );
		try {
			await fn();
		} catch {
			setError(
				message || __( 'Couldn’t save that. Try again.', 'bridle' )
			);
		}
	};
	return [ error, run ];
}
