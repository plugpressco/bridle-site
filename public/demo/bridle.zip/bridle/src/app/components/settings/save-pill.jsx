import { useContext } from 'react';
import { __ } from '@wordpress/i18n';
import { Check, Loader2 } from 'lucide-react';

import { SettingsStoreContext } from '@/components/settings/store-context';
import { FloatingPill } from '@/components/shell/floating-pill';
import { useClaimPill, useShell } from '@/components/shell/shell-context';
import { Button } from '@/components/ui/button';

/*
 * Unsaved typing in Settings, in the dock's place: discard or save. While it
 * saves, then briefly after, it says so; then the dock comes back. A failed
 * save keeps the edits and says what failed.
 */
export function SavePill() {
	const { route } = useShell();
	const store = useContext( SettingsStoreContext );
	const { dirty, save, saveAll, discard } = store;
	const show =
		route.name === 'settings' && ( dirty || save.state !== 'idle' );
	useClaimPill( show );
	if ( ! show ) {
		return null;
	}
	const saving = save.state === 'saving';

	return (
		<FloatingPill className="pl-4">
			<span
				role="status"
				className="mr-2 flex min-w-0 items-center gap-1.5 text-sm"
			>
				{ saving && <Loader2 className="size-4 animate-spin" /> }
				{ save.state === 'saved' && (
					<Check className="size-4 text-brand-ink" />
				) }
				{ save.state === 'error' ? (
					<span className="truncate text-destructive">
						{ save.error }
					</span>
				) : (
					<span className="whitespace-nowrap">
						{ saving && __( 'Saving…', 'bridle' ) }
						{ save.state === 'saved' && __( 'Saved', 'bridle' ) }
						{ save.state === 'idle' &&
							__( 'Unsaved changes', 'bridle' ) }
					</span>
				) }
			</span>
			{ dirty && (
				<>
					<Button
						size="sm"
						variant="ghost"
						className="rounded-full"
						disabled={ saving }
						onClick={ discard }
					>
						{ __( 'Discard', 'bridle' ) }
					</Button>
					<Button
						size="sm"
						className="rounded-full"
						disabled={ saving }
						onClick={ saveAll }
					>
						{ save.state === 'error'
							? __( 'Try again', 'bridle' )
							: __( 'Save', 'bridle' ) }
					</Button>
				</>
			) }
		</FloatingPill>
	);
}
