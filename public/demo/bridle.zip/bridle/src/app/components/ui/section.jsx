import { cn } from 'cn';
import { withRef } from '@/lib/with-ref';

/*
 * A settings block: a white card with a border edge on the paper, the way
 * bridle.to sets its windows (rebrand/BRAND.md). Heading and hint on the
 * first line, actions on the right, then the content. `plain` drops the
 * card for blocks that already sit inside one.
 */
const Section = /* #__PURE__ */ withRef( function Section( {
	title,
	hint,
	actions,
	plain = false,
	className,
	children,
	...props
} ) {
	return (
		<section
			data-slot="section"
			className={ cn(
				plain ? 'space-y-4' : 'surface space-y-5 px-6 py-5',
				className
			) }
			{ ...props }
		>
			{ ( title || actions ) && (
				<div className="flex items-start justify-between gap-4">
					<div className="min-w-0">
						{ title && (
							<h2 className="text-[15px] font-semibold">
								{ title }
							</h2>
						) }
						{ hint && (
							<p className="mt-0.5 text-sm text-muted-foreground">
								{ hint }
							</p>
						) }
					</div>
					{ actions && (
						<div className="flex shrink-0 items-center gap-2">
							{ actions }
						</div>
					) }
				</div>
			) }
			{ children }
		</section>
	);
} );

/* The group label above a list: "New  3". Light, like the site's headlines. */
const SectionHeading = /* #__PURE__ */ withRef( function SectionHeading( {
	children,
	count,
	className,
	...props
} ) {
	return (
		<h2
			data-slot="section-heading"
			className={ cn(
				'flex items-baseline gap-2 text-lg font-medium tracking-[-0.01em]',
				className
			) }
			{ ...props }
		>
			{ children }
			{ count !== undefined && count !== null && (
				<span className="text-base font-normal text-muted-foreground tabular-nums">
					{ count }
				</span>
			) }
		</h2>
	);
} );

export { Section, SectionHeading };
