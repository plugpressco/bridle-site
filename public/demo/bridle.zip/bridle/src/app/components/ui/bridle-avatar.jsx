import { cn } from 'cn';

import { withRef } from '@/lib/with-ref';

/*
 * Dot-matrix faces, the same ones bridle.to draws for its sample customers
 * (rebrand/BRAND.md): a 7x7 LED grid on a pastel disc, features in
 * near-black, hair a shade darker than the disc. The seed (email or name)
 * picks the hue, the hair, the eyes and the mouth, so a sender always gets
 * the same face and a list reads as a crowd rather than a column of grey
 * initials. Bridle itself is a bot face with antennas, in the brand blue.
 */
const MOD = 2147483647; // 2^31 - 1, so every product stays an exact double.

function hash32( seed ) {
	let h = 7919;
	for ( const char of String( seed || '' )
		.trim()
		.toLowerCase() ) {
		h = ( h * 65599 + char.charCodeAt( 0 ) ) % MOD;
	}
	return h || 1;
}

// A tiny seeded stream (Park–Miller) so each trait draws its own number.
function stream( seed ) {
	let state = hash32( seed );
	const next = () => {
		state = ( state * 48271 ) % MOD;
		return state;
	};
	next();
	return ( n ) => Math.floor( ( next() / MOD ) * n );
}

// Grid specs as on the site: "row:cols", cols as a list with ranges.
const HAIR = [
	'',
	'0:2-4',
	'0:2-4 1:1-5',
	'0:1-5 1:0,6',
	'0:1-5 1:0,1,5,6',
	'0:1-4 1:1',
	'0:2-5 1:5',
	'1:1-5',
];
const EYES = [
	'2:2,4',
	'2:1,2,4,5',
	'1:2,4 2:2,4',
	'2:2,4 3:2,4',
	'2:1,5',
	'3:2,4',
];
const MOUTHS = [
	'5:2-4',
	'4:1,5 5:2-4',
	'5:3',
	'4:2-4',
	'4:2-4 5:1,5',
	'4:3 5:2,4',
	'5:1-5',
];

function cells( spec ) {
	const on = {};
	String( spec || '' )
		.split( ' ' )
		.filter( Boolean )
		.forEach( ( part ) => {
			const [ row, cols ] = part.split( ':' );
			cols.split( ',' ).forEach( ( col ) => {
				const [ from, to ] = col.split( '-' ).map( Number );
				for ( let i = from; i <= ( to ?? from ); i++ ) {
					on[ `${ row }:${ i }` ] = true;
				}
			} );
		} );
	return on;
}

/* The 7x7 grid on a 32 viewBox, corners skipped; `paint(key)` → [r, fill, opacity]. */
function Grid( { paint } ) {
	const dots = [];
	for ( let r = 0; r < 7; r++ ) {
		for ( let c = 0; c < 7; c++ ) {
			if ( ( r === 0 || r === 6 ) && ( c === 0 || c === 6 ) ) {
				continue;
			}
			const [ radius, fill, opacity ] = paint( `${ r }:${ c }` );
			dots.push(
				<circle
					key={ `${ r }-${ c }` }
					cx={ ( 5.2 + 3.6 * c ).toFixed( 1 ) }
					cy={ ( 5.2 + 3.6 * r ).toFixed( 1 ) }
					r={ radius }
					fill={ fill }
					fillOpacity={ opacity }
				/>
			);
		}
	}
	return dots;
}

/* A sender's face: deterministic from `seed` (their email or name). */
const BridleAvatar = /* #__PURE__ */ withRef( function BridleAvatar( {
	seed,
	className,
	...props
} ) {
	const pick = stream( seed );
	const hue = hash32( `${ seed }:hue` ) % 360;
	const hair = cells( HAIR[ pick( HAIR.length ) ] );
	const feat = cells(
		`${ EYES[ pick( EYES.length ) ] } ${ MOUTHS[ pick( MOUTHS.length ) ] }`
	);
	const paint = ( key ) => {
		if ( feat[ key ] ) {
			return [ 1.62, `hsl(${ hue } 45% 16%)`, 1 ];
		}
		if ( hair[ key ] ) {
			return [ 1.3, `hsl(${ hue } 45% 44%)`, 1 ];
		}
		return [ 0.9, `hsl(${ hue } 35% 45%)`, 0.16 ];
	};

	return (
		<svg
			viewBox="0 0 32 32"
			aria-hidden="true"
			data-slot="bridle-avatar"
			className={ cn( 'size-9 shrink-0 rounded-full', className ) }
			{ ...props }
		>
			<circle cx="16" cy="16" r="16" fill={ `hsl(${ hue } 70% 86%)` } />
			<Grid paint={ paint } />
		</svg>
	);
} );

// Bridle's own face: antennas, square eyes, a straight mouth.
const BOT_ANTENNA = cells( '0:1,5 1:1,5' );
const BOT_FEATURES = cells( '2:1,2,4,5 3:1,2,4,5 5:2-4' );

/* The agent, drawn the way the site draws its bots. */
const AgentAvatar = /* #__PURE__ */ withRef( function AgentAvatar( {
	className,
	...props
} ) {
	const paint = ( key ) => {
		if ( BOT_FEATURES[ key ] ) {
			return [ 1.62, 'var(--brand-ink)', 1 ];
		}
		if ( BOT_ANTENNA[ key ] ) {
			return [ 1.3, 'var(--brand)', 1 ];
		}
		return [ 0.9, 'var(--brand-ink)', 0.14 ];
	};
	return (
		<svg
			viewBox="0 0 32 32"
			aria-hidden="true"
			data-slot="agent-avatar"
			className={ cn( 'size-9 shrink-0 rounded-full', className ) }
			{ ...props }
		>
			<circle cx="16" cy="16" r="16" fill="var(--brand-soft)" />
			<Grid paint={ paint } />
		</svg>
	);
} );

export { BridleAvatar, AgentAvatar };
