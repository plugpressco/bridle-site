import { cn } from 'cn';
import { Check, Minus } from 'lucide-react';

/*
 * The selection box, drawn: empty, checked (ink, like a primary button) or
 * mixed (some of a list). It is only the picture; the button around it is the
 * control and carries role="checkbox" / aria-checked, so one click target
 * can also be an avatar (rows) or open a menu (the select-all box).
 */
export function CheckboxMark( { state = 'unchecked', className } ) {
	const on = state === 'checked' || state === 'mixed';
	return (
		<span
			aria-hidden="true"
			className={ cn(
				'flex size-[18px] shrink-0 items-center justify-center rounded-[5px] border-[1.5px] transition-colors duration-100',
				on
					? 'border-foreground bg-foreground text-background'
					: 'border-input bg-card',
				className
			) }
		>
			{ state === 'checked' && (
				<Check className="size-3.5" strokeWidth={ 3 } />
			) }
			{ state === 'mixed' && (
				<Minus className="size-3.5" strokeWidth={ 3 } />
			) }
		</span>
	);
}
