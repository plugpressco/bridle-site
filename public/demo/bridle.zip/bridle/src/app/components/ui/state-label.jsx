import { cn } from 'cn';
import { Check } from 'lucide-react';

import { STATE_LABELS } from '@/lib/conversation';
import { withRef } from '@/lib/with-ref';

/*
 * One conversation state as a small chip, in the same language as the
 * status chips on bridle.to (rebrand/BRAND.md): blue belongs to what is
 * new, ink to what is done, the quiet fills to everything in between.
 */
const CHIPS = {
	new: 'bg-brand-soft text-brand-ink',
	open: 'bg-secondary text-foreground',
	waiting: 'bg-accent text-muted-foreground',
	resolved: 'bg-foreground text-background',
	spam: 'bg-note text-note-foreground',
	trash: 'bg-accent text-muted-foreground',
};

const StateLabel = /* #__PURE__ */ withRef( function StateLabel( {
	state,
	className,
	...props
} ) {
	return (
		<span
			data-slot="state-label"
			data-state={ state }
			className={ cn(
				'inline-flex h-6 items-center gap-1.5 rounded-full px-2.5 text-xs font-medium whitespace-nowrap',
				CHIPS[ state ] || CHIPS.waiting,
				className
			) }
			{ ...props }
		>
			{ state === 'resolved' && (
				<Check className="size-3" aria-hidden="true" />
			) }
			{ state === 'new' && (
				<span
					className="size-1.5 rounded-full bg-brand"
					aria-hidden="true"
				/>
			) }
			{ STATE_LABELS[ state ] || state }
		</span>
	);
} );

export { StateLabel };
