'use client';

import * as React from 'react';
import { cn } from 'cn';
import { getPortalContainer } from '@/lib/portal';
import { XIcon } from 'lucide-react';
import { Dialog as DialogPrimitive } from 'radix-ui';

import { Button } from '@/components/ui/button';
import { withRef } from '@/lib/with-ref';

const Dialog = /* #__PURE__ */ withRef( function Dialog( { ...props } ) {
	return <DialogPrimitive.Root data-slot="dialog" { ...props } />;
} );

const DialogTrigger = /* #__PURE__ */ withRef( function DialogTrigger( {
	...props
} ) {
	return <DialogPrimitive.Trigger data-slot="dialog-trigger" { ...props } />;
} );

const DialogPortal = /* #__PURE__ */ withRef( function DialogPortal( {
	...props
} ) {
	return (
		<DialogPrimitive.Portal
			data-slot="dialog-portal"
			container={ getPortalContainer() }
			{ ...props }
		/>
	);
} );

const DialogClose = /* #__PURE__ */ withRef( function DialogClose( {
	...props
} ) {
	return <DialogPrimitive.Close data-slot="dialog-close" { ...props } />;
} );

const DialogOverlay = /* #__PURE__ */ withRef( function DialogOverlay( {
	className,
	...props
} ) {
	return (
		<DialogPrimitive.Overlay
			data-slot="dialog-overlay"
			className={ cn(
				'fixed inset-0 z-50 bg-black/50 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:animate-in data-[state=open]:fade-in-0',
				className
			) }
			{ ...props }
		/>
	);
} );

const DialogContent = /* #__PURE__ */ withRef( function DialogContent( {
	className,
	children,
	showCloseButton = true,
	...props
} ) {
	return (
		<DialogPortal data-slot="dialog-portal">
			<DialogOverlay />
			<DialogPrimitive.Content
				data-slot="dialog-content"
				className={ cn(
					'fixed top-[50%] left-[50%] z-50 grid w-full max-w-[calc(100%-2rem)] translate-x-[-50%] translate-y-[-50%] gap-4 rounded-lg border bg-card p-6 shadow-lg duration-200 outline-none data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[state=open]:animate-in data-[state=open]:fade-in-0 data-[state=open]:zoom-in-95 sm:max-w-lg',
					className
				) }
				{ ...props }
			>
				{ children }
				{ showCloseButton && (
					<DialogPrimitive.Close
						data-slot="dialog-close"
						className="absolute top-4 right-4 rounded-xs opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:ring-2 focus:ring-ring focus:ring-offset-2 focus:outline-hidden disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4"
					>
						<XIcon />
						<span className="sr-only">Close</span>
					</DialogPrimitive.Close>
				) }
			</DialogPrimitive.Content>
		</DialogPortal>
	);
} );

const DialogHeader = /* #__PURE__ */ withRef( function DialogHeader( {
	className,
	...props
} ) {
	return (
		<div
			data-slot="dialog-header"
			className={ cn(
				'flex flex-col gap-2 text-center sm:text-left',
				className
			) }
			{ ...props }
		/>
	);
} );

const DialogFooter = /* #__PURE__ */ withRef( function DialogFooter( {
	className,
	showCloseButton = false,
	children,
	...props
} ) {
	return (
		<div
			data-slot="dialog-footer"
			className={ cn(
				'flex flex-col-reverse gap-2 sm:flex-row sm:justify-end',
				className
			) }
			{ ...props }
		>
			{ children }
			{ showCloseButton && (
				<DialogPrimitive.Close asChild>
					<Button variant="outline">Close</Button>
				</DialogPrimitive.Close>
			) }
		</div>
	);
} );

const DialogTitle = /* #__PURE__ */ withRef( function DialogTitle( {
	className,
	...props
} ) {
	return (
		<DialogPrimitive.Title
			data-slot="dialog-title"
			className={ cn( 'text-lg leading-none font-semibold', className ) }
			{ ...props }
		/>
	);
} );

const DialogDescription = /* #__PURE__ */ withRef( function DialogDescription( {
	className,
	...props
} ) {
	return (
		<DialogPrimitive.Description
			data-slot="dialog-description"
			className={ cn( 'text-sm text-muted-foreground', className ) }
			{ ...props }
		/>
	);
} );

export {
	Dialog,
	DialogClose,
	DialogContent,
	DialogDescription,
	DialogFooter,
	DialogHeader,
	DialogOverlay,
	DialogPortal,
	DialogTitle,
	DialogTrigger,
};
