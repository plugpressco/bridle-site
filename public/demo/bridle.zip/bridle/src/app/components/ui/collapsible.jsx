'use client';

import * as React from 'react';
import { Collapsible as CollapsiblePrimitive } from 'radix-ui';
import { withRef } from '@/lib/with-ref';

const Collapsible = /* #__PURE__ */ withRef( function Collapsible( {
	...props
} ) {
	return <CollapsiblePrimitive.Root data-slot="collapsible" { ...props } />;
} );

const CollapsibleTrigger = /* #__PURE__ */ withRef(
	function CollapsibleTrigger( { ...props } ) {
		return (
			<CollapsiblePrimitive.CollapsibleTrigger
				data-slot="collapsible-trigger"
				{ ...props }
			/>
		);
	}
);

const CollapsibleContent = /* #__PURE__ */ withRef(
	function CollapsibleContent( { ...props } ) {
		return (
			<CollapsiblePrimitive.CollapsibleContent
				data-slot="collapsible-content"
				{ ...props }
			/>
		);
	}
);

export { Collapsible, CollapsibleTrigger, CollapsibleContent };
