import * as React from 'react';
import { cn } from 'cn';
import { getPortalContainer } from '@/lib/portal';
import { Tooltip as TooltipPrimitive } from 'radix-ui';
import { withRef } from '@/lib/with-ref';

const TooltipProvider = /* #__PURE__ */ withRef( function TooltipProvider( {
	delayDuration = 0,
	...props
} ) {
	return (
		<TooltipPrimitive.Provider
			data-slot="tooltip-provider"
			delayDuration={ delayDuration }
			{ ...props }
		/>
	);
} );

const Tooltip = /* #__PURE__ */ withRef( function Tooltip( { ...props } ) {
	return <TooltipPrimitive.Root data-slot="tooltip" { ...props } />;
} );

const TooltipTrigger = /* #__PURE__ */ withRef( function TooltipTrigger( {
	...props
} ) {
	return (
		<TooltipPrimitive.Trigger data-slot="tooltip-trigger" { ...props } />
	);
} );

const TooltipContent = /* #__PURE__ */ withRef( function TooltipContent( {
	className,
	sideOffset = 0,
	children,
	...props
} ) {
	return (
		<TooltipPrimitive.Portal container={ getPortalContainer() }>
			<TooltipPrimitive.Content
				data-slot="tooltip-content"
				sideOffset={ sideOffset }
				className={ cn(
					'z-50 w-fit origin-(--radix-tooltip-content-transform-origin) animate-in rounded-md bg-foreground px-3 py-1.5 text-xs text-balance text-background fade-in-0 zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95',
					className
				) }
				{ ...props }
			>
				{ children }
				<TooltipPrimitive.Arrow className="z-50 size-2.5 translate-y-[calc(-50%_-_2px)] rotate-45 rounded-[2px] bg-foreground fill-foreground" />
			</TooltipPrimitive.Content>
		</TooltipPrimitive.Portal>
	);
} );

export { Tooltip, TooltipTrigger, TooltipContent, TooltipProvider };
