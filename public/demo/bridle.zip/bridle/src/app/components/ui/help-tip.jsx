import { __ } from '@wordpress/i18n';
import { CircleHelp } from 'lucide-react';
import { cn } from 'cn';

import {
	Tooltip,
	TooltipContent,
	TooltipTrigger,
} from '@/components/ui/tooltip';

/*
 * A small "?" beside a label that shows a sentence or two of help on hover or
 * focus. Help goes here, never in a line under the field (Mailpuff's rule,
 * 2026-11-02): a line under something is a short fact, not an explanation.
 */
export function HelpTip( { children, label, className } ) {
	if ( ! children ) {
		return null;
	}
	return (
		<Tooltip>
			<TooltipTrigger asChild>
				<button
					type="button"
					aria-label={ label || __( 'More about this', 'bridle' ) }
					className={ cn(
						// A 24px target that takes a 16px place in the line.
						'-m-1 inline-flex size-6 shrink-0 cursor-help items-center justify-center rounded-full text-muted-foreground/70 outline-none transition-colors hover:text-foreground focus-visible:text-foreground focus-visible:ring-[3px] focus-visible:ring-ring/50',
						className
					) }
				>
					<CircleHelp className="size-[15px]" aria-hidden="true" />
				</button>
			</TooltipTrigger>
			<TooltipContent className="max-w-72 text-left leading-relaxed">
				{ children }
			</TooltipContent>
		</Tooltip>
	);
}
