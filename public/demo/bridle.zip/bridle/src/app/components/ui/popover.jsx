'use client';

import * as React from 'react';
import { cn } from 'cn';
import { getPortalContainer } from '@/lib/portal';
import { Popover as PopoverPrimitive } from 'radix-ui';
import { withRef } from '@/lib/with-ref';

const Popover = /* #__PURE__ */ withRef( function Popover( { ...props } ) {
	return <PopoverPrimitive.Root data-slot="popover" { ...props } />;
} );

const PopoverTrigger = /* #__PURE__ */ withRef( function PopoverTrigger( {
	...props
} ) {
	return (
		<PopoverPrimitive.Trigger data-slot="popover-trigger" { ...props } />
	);
} );

const PopoverContent = /* #__PURE__ */ withRef( function PopoverContent( {
	className,
	align = 'center',
	sideOffset = 4,
	...props
} ) {
	return (
		<PopoverPrimitive.Portal container={ getPortalContainer() }>
			<PopoverPrimitive.Content
				data-slot="popover-content"
				align={ align }
				sideOffset={ sideOffset }
				className={ cn(
					'z-50 w-72 origin-(--radix-popover-content-transform-origin) rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-hidden data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[state=open]:animate-in data-[state=open]:fade-in-0 data-[state=open]:zoom-in-95',
					className
				) }
				{ ...props }
			/>
		</PopoverPrimitive.Portal>
	);
} );

const PopoverAnchor = /* #__PURE__ */ withRef( function PopoverAnchor( {
	...props
} ) {
	return <PopoverPrimitive.Anchor data-slot="popover-anchor" { ...props } />;
} );

const PopoverHeader = /* #__PURE__ */ withRef( function PopoverHeader( {
	className,
	...props
} ) {
	return (
		<div
			data-slot="popover-header"
			className={ cn( 'flex flex-col gap-1 text-sm', className ) }
			{ ...props }
		/>
	);
} );

const PopoverTitle = /* #__PURE__ */ withRef( function PopoverTitle( {
	className,
	...props
} ) {
	return (
		<div
			data-slot="popover-title"
			className={ cn( 'font-medium', className ) }
			{ ...props }
		/>
	);
} );

const PopoverDescription = /* #__PURE__ */ withRef(
	function PopoverDescription( { className, ...props } ) {
		return (
			<p
				data-slot="popover-description"
				className={ cn( 'text-muted-foreground', className ) }
				{ ...props }
			/>
		);
	}
);

export {
	Popover,
	PopoverTrigger,
	PopoverContent,
	PopoverAnchor,
	PopoverHeader,
	PopoverTitle,
	PopoverDescription,
};
