'use client';

import * as React from 'react';
import { cn } from 'cn';
import { getPortalContainer } from '@/lib/portal';
import { XIcon } from 'lucide-react';
import { Dialog as SheetPrimitive } from 'radix-ui';
import { withRef } from '@/lib/with-ref';

const Sheet = /* #__PURE__ */ withRef( function Sheet( { ...props } ) {
	return <SheetPrimitive.Root data-slot="sheet" { ...props } />;
} );

const SheetTrigger = /* #__PURE__ */ withRef( function SheetTrigger( {
	...props
} ) {
	return <SheetPrimitive.Trigger data-slot="sheet-trigger" { ...props } />;
} );

const SheetClose = /* #__PURE__ */ withRef( function SheetClose( {
	...props
} ) {
	return <SheetPrimitive.Close data-slot="sheet-close" { ...props } />;
} );

function SheetPortal( { ...props } ) {
	return (
		<SheetPrimitive.Portal
			data-slot="sheet-portal"
			container={ getPortalContainer() }
			{ ...props }
		/>
	);
}

function SheetOverlay( { className, ...props } ) {
	return (
		<SheetPrimitive.Overlay
			data-slot="sheet-overlay"
			className={ cn(
				'fixed inset-0 z-50 bg-black/50 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:animate-in data-[state=open]:fade-in-0',
				className
			) }
			{ ...props }
		/>
	);
}

const SheetContent = /* #__PURE__ */ withRef( function SheetContent( {
	className,
	children,
	side = 'right',
	showCloseButton = true,
	...props
} ) {
	return (
		<SheetPortal>
			<SheetOverlay />
			<SheetPrimitive.Content
				data-slot="sheet-content"
				className={ cn(
					'fixed z-50 flex flex-col gap-4 bg-card shadow-lg transition ease-in-out data-[state=closed]:animate-out data-[state=closed]:duration-300 data-[state=open]:animate-in data-[state=open]:duration-500',
					side === 'right' &&
						'inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm',
					side === 'left' &&
						'inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm',
					side === 'top' &&
						'inset-x-0 top-0 h-auto border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top',
					side === 'bottom' &&
						'inset-x-0 bottom-0 h-auto border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom',
					className
				) }
				{ ...props }
			>
				{ children }
				{ showCloseButton && (
					<SheetPrimitive.Close className="absolute top-4 right-4 rounded-xs opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:ring-2 focus:ring-ring focus:ring-offset-2 focus:outline-hidden disabled:pointer-events-none data-[state=open]:bg-secondary">
						<XIcon className="size-4" />
						<span className="sr-only">Close</span>
					</SheetPrimitive.Close>
				) }
			</SheetPrimitive.Content>
		</SheetPortal>
	);
} );

const SheetHeader = /* #__PURE__ */ withRef( function SheetHeader( {
	className,
	...props
} ) {
	return (
		<div
			data-slot="sheet-header"
			className={ cn( 'flex flex-col gap-1.5 p-4', className ) }
			{ ...props }
		/>
	);
} );

const SheetFooter = /* #__PURE__ */ withRef( function SheetFooter( {
	className,
	...props
} ) {
	return (
		<div
			data-slot="sheet-footer"
			className={ cn( 'mt-auto flex flex-col gap-2 p-4', className ) }
			{ ...props }
		/>
	);
} );

const SheetTitle = /* #__PURE__ */ withRef( function SheetTitle( {
	className,
	...props
} ) {
	return (
		<SheetPrimitive.Title
			data-slot="sheet-title"
			className={ cn( 'font-semibold text-foreground', className ) }
			{ ...props }
		/>
	);
} );

const SheetDescription = /* #__PURE__ */ withRef( function SheetDescription( {
	className,
	...props
} ) {
	return (
		<SheetPrimitive.Description
			data-slot="sheet-description"
			className={ cn( 'text-sm text-muted-foreground', className ) }
			{ ...props }
		/>
	);
} );

export {
	Sheet,
	SheetTrigger,
	SheetClose,
	SheetContent,
	SheetHeader,
	SheetFooter,
	SheetTitle,
	SheetDescription,
};
