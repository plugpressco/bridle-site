import { cn } from 'cn';

import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { BridleAvatar } from '@/components/ui/bridle-avatar';

/* A contact's avatar: their gravatar when it loads, a Bridle creature otherwise. */
export function ContactAvatar( { name, email, src, className } ) {
	return (
		<Avatar className={ cn( 'size-9', className ) }>
			{ src && <AvatarImage src={ src } alt="" /> }
			<AvatarFallback className="bg-transparent">
				<BridleAvatar seed={ email || name } className="size-full" />
			</AvatarFallback>
		</Avatar>
	);
}
