import { useEffect, useState } from 'react';
import { __, _n, sprintf } from '@wordpress/i18n';
import { X } from 'lucide-react';

import { FloatingPill } from '@/components/shell/floating-pill';
import { useClaimPill } from '@/components/shell/shell-context';
import { Button } from '@/components/ui/button';

/*
 * The action pill that appears when rows are selected (AGENTS.md §6.3). It
 * takes the dock's place while there is a selection.
 * `actions` is [{ key, label, icon, variant, run, confirm? }]. An action with
 * `confirm: { prompt, label }` asks first, inline, the way Empty trash does:
 * the pill turns into the question with the destructive button and Cancel.
 */
export function BulkBar( { count, actions, onClear, busy } ) {
	useClaimPill( count > 0 );
	const [ confirming, setConfirming ] = useState( null );

	// A new selection (or none) drops a pending question.
	useEffect( () => setConfirming( null ), [ count ] );

	if ( ! count ) {
		return null;
	}
	const pending = confirming
		? actions.find( ( action ) => action.key === confirming )
		: null;
	if ( pending ) {
		return (
			<FloatingPill className="pl-4">
				<span role="alert" className="mr-2 text-sm">
					{ pending.confirm.prompt }
				</span>
				<Button
					size="sm"
					variant="destructive"
					onClick={ () => {
						setConfirming( null );
						pending.run();
					} }
					disabled={ busy }
					className="rounded-full"
				>
					{ pending.icon && <pending.icon /> }
					{ pending.confirm.label }
				</Button>
				<Button
					size="sm"
					variant="ghost"
					onClick={ () => setConfirming( null ) }
					className="rounded-full"
				>
					{ __( 'Cancel', 'bridle' ) }
				</Button>
			</FloatingPill>
		);
	}
	return (
		<FloatingPill className="pl-4">
			<span className="mr-2 text-sm tabular-nums">
				{ sprintf(
					/* translators: %d: number of selected conversations */
					_n( '%d selected', '%d selected', count, 'bridle' ),
					count
				) }
			</span>
			{ actions.map( ( action ) => (
				<Button
					key={ action.key }
					size="sm"
					variant={ action.variant || 'ghost' }
					onClick={
						action.confirm
							? () => setConfirming( action.key )
							: action.run
					}
					disabled={ busy }
					className="rounded-full"
				>
					{ action.icon && <action.icon /> }
					{ action.label }
				</Button>
			) ) }
			<Button
				size="icon-sm"
				variant="ghost"
				onClick={ onClear }
				aria-label={ __( 'Clear selection', 'bridle' ) }
				className="rounded-full"
			>
				<X />
			</Button>
		</FloatingPill>
	);
}
