import { __, sprintf } from '@wordpress/i18n';
import { CircleAlert, Clock, Mail, MailOpen, Sparkles } from 'lucide-react';
import { cn } from 'cn';

import { CheckboxMark } from '@/components/ui/checkbox';
import {
	Tooltip,
	TooltipContent,
	TooltipTrigger,
} from '@/components/ui/tooltip';
import {
	agentReview,
	chatPage,
	contactName,
	hasAgentDraft,
	isUrgent,
	reasonLabel,
	stateOf,
} from '@/lib/conversation';
import { Link } from '@/lib/router';
import { clockTime, fullDateTime, relativeTime } from '@/lib/time';
import { ContactAvatar } from './contact-avatar';

/*
 * The agent's verdict on a row, as a small chip (#108): Draft ready (blue),
 * Sends at 10:42 (blue, Auto's hold), or why a person should look (amber).
 */
export function ReviewChip( { conversation } ) {
	const review = agentReview( conversation );
	let icon = Sparkles;
	let text = __( 'Draft ready', 'bridle' );
	let tone = 'bg-brand-soft text-brand-ink';
	if ( review === 'sending' ) {
		icon = Clock;
		text = conversation.agent_send_at
			? sprintf(
					/* translators: %s: the time the agent will send, e.g. 10:42 */
					__( 'Sends at %s', 'bridle' ),
					clockTime( conversation.agent_send_at )
			  )
			: __( 'Sending soon', 'bridle' );
	} else if ( review === 'check' ) {
		icon = CircleAlert;
		text = reasonLabel( conversation ) || __( 'Check it', 'bridle' );
		tone = 'bg-note text-note-foreground';
	}
	const Icon = icon;
	return (
		<span
			className={ cn(
				'inline-flex h-5 shrink-0 items-center gap-1 rounded-full px-2 text-xs font-medium',
				tone
			) }
		>
			<Icon className="size-3" aria-hidden="true" />
			{ text }
		</span>
	);
}

/*
 * One list row: the avatar is the selection handle (given `onToggle`): it
 * turns into a checkbox under the pointer, and every row shows its checkbox
 * while `selecting`; shift-click selects a range. The rest of the row opens
 * the conversation. Name and subject share the first
 * line, the preview gets room to be read (two lines while the mail still
 * needs us), and the right edge carries only what changes the decision:
 * time, the agent's draft, urgency. On hover or focus that edge gives way
 * to the row's quick actions (`actions`, from the page, after "mark as read
 * / unread" when `onToggleRead` is given). Unread rows carry a blue dot in
 * the left gutter and a heavier name.
 */
export function ConversationRow( {
	conversation,
	inbox,
	active,
	selected,
	selecting,
	onToggle,
	actions,
	onToggleRead,
	showInbox,
} ) {
	// Rows from the REST list carry `unread` for the current teammate.
	const hasReadState = typeof conversation.unread === 'boolean';
	const unread = conversation.unread === true;
	const canToggleRead = !! onToggleRead && hasReadState;
	const hasActions = !! actions?.length || canToggleRead;
	const name = contactName( conversation );
	const state = stateOf( conversation );
	const live = state === 'new' || state === 'open';
	// The agent's draft says what to do next, but only while the mail
	// still needs us (#108); a leftover draft on a resolved row says nothing.
	const review = live ? agentReview( conversation ) : null;
	const avatar = (
		<ContactAvatar
			name={ name }
			email={ conversation.customer_email }
			src={ conversation.customer_avatar }
			className="size-9"
		/>
	);
	// The avatar turns into a checkbox under the pointer, and every row shows
	// its checkbox while anything is selected (Gmail's selection mode).
	const showBox = selected || selecting;

	return (
		<li
			data-active={ active || undefined }
			data-selected={ selected || undefined }
			className={ cn(
				'group relative flex items-start gap-3 px-5 py-4 transition-colors duration-150',
				'hover:bg-accent/70 data-active:bg-secondary data-selected:bg-brand-soft'
			) }
		>
			{ unread && (
				<span
					role="img"
					aria-label={ __( 'Unread', 'bridle' ) }
					className="absolute top-[30px] left-[7px] size-2 rounded-full bg-brand"
				/>
			) }
			{ onToggle ? (
				<button
					type="button"
					role="checkbox"
					aria-checked={ selected }
					// Shift-click selects a range; keep it from selecting text.
					onMouseDown={ ( event ) => {
						if ( event.shiftKey ) {
							event.preventDefault();
						}
					} }
					onClick={ ( event ) => {
						event.preventDefault();
						onToggle( conversation.id, { shift: event.shiftKey } );
					} }
					aria-label={ sprintf(
						/* translators: %s: the customer's name */
						__( 'Select conversation with %s', 'bridle' ),
						name
					) }
					className="group/select relative z-10 flex size-9 shrink-0 items-center justify-center rounded-full outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50"
				>
					<span
						className={ cn(
							'transition-opacity duration-100 motion-reduce:transition-none',
							showBox
								? 'opacity-0'
								: 'group-hover/select:opacity-0 group-focus-visible/select:opacity-0'
						) }
					>
						{ avatar }
					</span>
					<span
						className={ cn(
							'absolute inset-0 flex items-center justify-center transition-opacity duration-100 motion-reduce:transition-none',
							showBox
								? 'opacity-100'
								: 'opacity-0 group-hover/select:opacity-100 group-focus-visible/select:opacity-100'
						) }
					>
						<CheckboxMark
							state={ selected ? 'checked' : 'unchecked' }
						/>
					</span>
				</button>
			) : (
				<span className="shrink-0">{ avatar }</span>
			) }

			<Link
				to={ `/c/${ conversation.id }` }
				className="min-w-0 flex-1 outline-none after:absolute after:inset-0 focus-visible:after:ring-[3px] focus-visible:after:ring-ring/50"
			>
				<div className="flex min-w-0 items-baseline gap-2 text-[15px]">
					<span
						className={ cn(
							'shrink-0 max-w-[40%] truncate',
							( hasReadState ? unread : live )
								? 'font-semibold'
								: 'font-medium'
						) }
					>
						{ name }
					</span>
					{ conversation.channel === 'chat' && (
						<span className="shrink-0 max-w-[30%] truncate rounded-full bg-brand-soft px-1.5 py-px text-[11px] font-medium text-brand-ink">
							{ chatPage( conversation )?.other
								? sprintf(
										/* translators: %s: the other website the chat came from, e.g. shop.example.com */
										__( 'Chat · %s', 'bridle' ),
										chatPage( conversation ).host
								  )
								: __( 'Chat', 'bridle' ) }
						</span>
					) }
					<span
						className={ cn(
							'min-w-0 truncate',
							unread ? 'text-foreground' : 'text-muted-foreground'
						) }
					>
						{ conversation.subject ||
							__( '(no subject)', 'bridle' ) }
					</span>
				</div>
				{ review ? (
					<div className="mt-1 flex min-w-0 items-center gap-2 text-sm">
						<ReviewChip conversation={ conversation } />
						<span
							className={ cn(
								'min-w-0 truncate',
								review === 'check'
									? 'text-muted-foreground'
									: 'text-brand-ink'
							) }
						>
							{ review === 'check'
								? conversation.last_message_preview
								: conversation.agent_preview }
						</span>
					</div>
				) : (
					<p
						className={ cn(
							'mt-0.5 text-sm text-muted-foreground',
							live ? 'line-clamp-2' : 'line-clamp-1'
						) }
					>
						{ conversation.last_message_preview }
					</p>
				) }
			</Link>

			<div
				className={ cn(
					'relative z-10 flex shrink-0 items-center justify-end gap-2 pt-0.5 text-xs text-muted-foreground',
					// Room for the quick actions, so they never sit on the preview.
					hasActions &&
						'min-w-16 transition-opacity duration-150 group-focus-within:opacity-0 group-hover:opacity-0 motion-reduce:transition-none'
				) }
			>
				{ ! review && hasAgentDraft( conversation ) && (
					<Tooltip>
						<TooltipTrigger asChild>
							<span className="inline-flex">
								<Sparkles
									className="size-3.5 text-brand"
									aria-label={ __(
										'Bridle has a draft',
										'bridle'
									) }
								/>
							</span>
						</TooltipTrigger>
						<TooltipContent>
							{ __( 'Bridle has a draft', 'bridle' ) }
						</TooltipContent>
					</Tooltip>
				) }
				{ isUrgent( conversation ) && (
					<Tooltip>
						<TooltipTrigger asChild>
							<span
								role="img"
								aria-label={ __( 'Urgent', 'bridle' ) }
								className="size-2 rounded-full bg-destructive"
							/>
						</TooltipTrigger>
						<TooltipContent>
							{ __( 'Urgent', 'bridle' ) }
						</TooltipContent>
					</Tooltip>
				) }
				{ /* By name, not a coloured dot: a blue inbox dot read as "unread". */ }
				{ showInbox && inbox && (
					<span className="max-w-24 truncate">
						{ inbox.display_name }
					</span>
				) }
				<time
					dateTime={ conversation.last_activity_at }
					title={ fullDateTime( conversation.last_activity_at ) }
					className="min-w-9 text-right tabular-nums"
				>
					{ relativeTime( conversation.last_activity_at ) }
				</time>
			</div>

			{ hasActions && (
				<RowActions
					actions={ [
						...( canToggleRead
							? [
									{
										key: 'read',
										label: unread
											? __( 'Mark as read', 'bridle' )
											: __( 'Mark as unread', 'bridle' ),
										icon: unread ? MailOpen : Mail,
										run: ( id ) =>
											onToggleRead( id, unread ),
									},
							  ]
							: [] ),
						...( actions || [] ),
					] }
					id={ Number( conversation.id ) }
				/>
			) }
		</li>
	);
}

/* The quick actions: a small pill over the row's right edge. */
function RowActions( { actions, id } ) {
	return (
		<div className="pointer-events-none absolute top-1/2 right-4 z-20 flex -translate-y-1/2 items-center gap-0.5 rounded-full border bg-card p-0.5 opacity-0 shadow-xs transition-opacity duration-150 group-focus-within:pointer-events-auto group-focus-within:opacity-100 group-hover:pointer-events-auto group-hover:opacity-100 motion-reduce:transition-none">
			{ actions.map( ( { key, label, icon: Icon, run } ) => (
				<Tooltip key={ key }>
					<TooltipTrigger asChild>
						<button
							type="button"
							onClick={ ( event ) => {
								event.preventDefault();
								run( id );
							} }
							aria-label={ label }
							className="inline-flex size-7 items-center justify-center rounded-full text-muted-foreground outline-none transition-colors hover:bg-accent hover:text-foreground focus-visible:ring-[3px] focus-visible:ring-ring/50"
						>
							<Icon className="size-4" />
						</button>
					</TooltipTrigger>
					<TooltipContent>{ label }</TooltipContent>
				</Tooltip>
			) ) }
		</div>
	);
}
