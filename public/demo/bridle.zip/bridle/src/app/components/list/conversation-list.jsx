import { useEffect, useRef, useState } from 'react';
import { __ } from '@wordpress/i18n';

import { useShell } from '@/components/shell/shell-context';
import { Button } from '@/components/ui/button';
import { SectionHeading } from '@/components/ui/section';
import { Skeleton } from '@/components/ui/skeleton';
import { navigate } from '@/lib/router';
import { useShortcuts } from '@/lib/shortcuts';
import { ConversationRow } from './conversation-row';

function Rows( {
	list,
	selected,
	selecting,
	onToggle,
	rowActions,
	onToggleRead,
	cursorId,
	showInbox,
	inboxes,
} ) {
	if ( list.loading && ! list.items.length ) {
		return (
			<ul className="surface divide-y divide-border/60 overflow-hidden">
				{ [ 0, 1, 2 ].map( ( i ) => (
					<li key={ i } className="flex items-start gap-3 px-4 py-4">
						<Skeleton className="size-9 rounded-full" />
						<div className="flex-1 space-y-2">
							<Skeleton className="h-4 w-1/2" />
							<Skeleton className="h-3.5 w-4/5" />
							<Skeleton className="h-3.5 w-2/3" />
						</div>
					</li>
				) ) }
			</ul>
		);
	}
	return (
		<>
			<ul className="surface divide-y divide-border/60 overflow-hidden">
				{ list.items.map( ( row ) => (
					<ConversationRow
						key={ row.id }
						conversation={ row }
						inbox={ inboxes.find(
							( i ) => Number( i.id ) === Number( row.inbox_id )
						) }
						active={ Number( row.id ) === cursorId }
						selected={ !! selected?.has( Number( row.id ) ) }
						selecting={ selecting }
						onToggle={ onToggle }
						actions={ rowActions }
						onToggleRead={ onToggleRead }
						showInbox={ showInbox }
					/>
				) ) }
			</ul>
			{ list.hasMore && (
				<div className="mt-2 px-4">
					<Button
						variant="ghost"
						size="sm"
						onClick={ list.loadMore }
						disabled={ list.loading }
					>
						{ list.loading
							? __( 'Loading…', 'bridle' )
							: __( 'Load more', 'bridle' ) }
					</Button>
				</div>
			) }
		</>
	);
}

/*
 * Sections of rows with one keyboard cursor across all of them (§6.5):
 * j/k move, ↵ opens, x selects. Selection lives in the page so the bulk
 * bar can act on it; without `onToggle` rows can't be selected at all.
 * The select-all control lives on the page's title line (SelectHeader).
 * `rowActions` ([{ key, label, icon, run( id ) }]) appear on a row while it is
 * hovered or focused, after "mark as read / unread" when `onToggleRead`
 * ( id, unread ) is given.
 */
export function ConversationList( {
	sections,
	selected,
	onToggle,
	rowActions,
	onToggleRead,
	empty,
} ) {
	const { inboxes, inboxScope } = useShell();
	const showInbox = ! inboxScope && inboxes.length > 1;
	const ids = sections.flatMap( ( section ) =>
		section.list.items.map( ( row ) => Number( row.id ) )
	);
	const [ cursorId, setCursorId ] = useState( null );
	const idsRef = useRef( ids );
	idsRef.current = ids;

	useEffect( () => {
		if ( cursorId !== null && ! ids.includes( cursorId ) ) {
			setCursorId( null );
		}
	}, [ ids, cursorId ] );

	const move = ( step ) => {
		const all = idsRef.current;
		if ( ! all.length ) {
			return;
		}
		const at = all.indexOf( cursorId );
		let next = at + step;
		if ( at === -1 ) {
			next = step > 0 ? 0 : all.length - 1;
		}
		next = Math.min( all.length - 1, Math.max( 0, next ) );
		setCursorId( all[ next ] );
		document
			.querySelector( `[data-active] a[href*="/c/${ all[ next ] }"]` )
			?.scrollIntoView( { block: 'nearest' } );
	};

	useShortcuts( {
		j: () => move( 1 ),
		k: () => move( -1 ),
		enter: () => {
			if ( cursorId !== null ) {
				navigate( `/c/${ cursorId }` );
			}
		},
		x: onToggle
			? () => {
					if ( cursorId !== null ) {
						onToggle( cursorId );
					}
			  }
			: undefined,
	} );

	const allEmpty = sections.every(
		( section ) => ! section.list.loading && ! section.list.items.length
	);
	if ( allEmpty ) {
		return empty;
	}

	// Rows hand back shift; the list knows the order a range runs in.
	const toggleRow = onToggle
		? ( id, options = {} ) =>
				onToggle( id, { ...options, order: idsRef.current } )
		: undefined;
	const selecting = !! selected?.size;

	return (
		<div>
			{ sections.map( ( section ) =>
				! section.list.loading && ! section.list.items.length ? null : (
					<section key={ section.key } className="mt-10 first:mt-0">
						{ section.title && (
							<SectionHeading
								count={ section.count ?? section.list.total }
								className="mb-3 px-1"
							>
								{ section.title }
							</SectionHeading>
						) }
						<Rows
							list={ section.list }
							selected={ selected }
							selecting={ selecting }
							onToggle={ toggleRow }
							rowActions={ rowActions }
							onToggleRead={ onToggleRead }
							cursorId={ cursorId }
							showInbox={ showInbox }
							inboxes={ inboxes }
						/>
					</section>
				)
			) }
		</div>
	);
}
