import { __ } from '@wordpress/i18n';

import { BridleAvatar } from '@/components/ui/bridle-avatar';

/*
 * "You're all caught up": an empty box is a finish line, not a void. A few
 * of the dot-matrix faces keep it company; an icon can stand in instead.
 */
export function EmptyState( { title, hint, icon: Icon } ) {
	return (
		<div className="flex flex-col items-center px-6 py-16 text-center">
			{ Icon ? (
				<Icon className="mb-4 size-8 text-brand" />
			) : (
				<div className="mb-4 flex -space-x-2">
					{ [ 'maya', 'tom', 'priya' ].map( ( seed ) => (
						<BridleAvatar
							key={ seed }
							seed={ seed }
							className="size-10 ring-2 ring-background"
						/>
					) ) }
				</div>
			) }
			<p className="text-lg font-medium">{ title }</p>
			{ hint && (
				<p className="mt-1 max-w-sm text-sm text-muted-foreground">
					{ hint }
				</p>
			) }
		</div>
	);
}

/*
 * The line above a list that failed to load (or a bulk action that failed),
 * shown instead of pretending the list is empty.
 */
export function ListError( { message, onRetry } ) {
	return (
		<p role="alert" className="mb-4 text-sm text-destructive">
			{ message || __( 'The list could not be loaded.', 'bridle' ) }
			{ onRetry && (
				<>
					{ ' ' }
					<button
						type="button"
						className="underline"
						onClick={ onRetry }
					>
						{ __( 'Try again', 'bridle' ) }
					</button>
				</>
			) }
		</p>
	);
}
