import { __, sprintf } from '@wordpress/i18n';
import { ChevronDown } from 'lucide-react';

import { CheckboxMark } from '@/components/ui/checkbox';
import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuItem,
	DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { selectionState } from '@/lib/use-selection';

/*
 * Gmail's select-all, on the page's title line at the right (the owner
 * wanted it out of the way, not a row of its own): the box selects every
 * loaded row (or clears them), the arrow picks All, None, Read or Unread,
 * and while something is selected the line before it says how much, with
 * a link for every conversation the view holds, loaded or not.
 *
 * `lists` are the page's usePagedList results; `total` every conversation
 * the view holds. Renders nothing while the lists are empty.
 */
export function SelectHeader( {
	lists,
	selected,
	onSetMany,
	total,
	onAllMatching,
	matchingBusy,
} ) {
	const rows = lists.flatMap( ( list ) => list.items );
	if ( ! rows.length ) {
		return null;
	}
	const ids = rows.map( ( row ) => Number( row.id ) );
	const state = selectionState( selected, ids );
	const count = selected.size;
	const all = Math.max( total ?? ids.length, count );
	const hasReadState = rows.some(
		( row ) => typeof row.unread === 'boolean'
	);
	const pick = ( test ) =>
		onSetMany( rows.filter( test ).map( ( row ) => Number( row.id ) ) );
	const checked = { all: true, some: 'mixed', none: false }[ state ];
	const mark = { all: 'checked', some: 'mixed', none: 'unchecked' }[ state ];

	return (
		<div className="flex items-center gap-3 text-sm">
			{ count > 0 && (
				<p className="flex min-w-0 flex-wrap items-center justify-end gap-x-2 text-muted-foreground">
					<span className="tabular-nums">
						{ count >= all
							? sprintf(
									/* translators: %d: number of conversations */
									__( 'All %d selected', 'bridle' ),
									count
							  )
							: sprintf(
									/* translators: 1: selected, 2: all in this view */
									__( '%1$d of %2$d selected', 'bridle' ),
									count,
									all
							  ) }
					</span>
					{ onAllMatching && count < all && (
						<>
							<span aria-hidden="true">·</span>
							<button
								type="button"
								onClick={ onAllMatching }
								disabled={ matchingBusy }
								className="rounded-sm font-medium text-brand-ink outline-none hover:underline focus-visible:ring-[3px] focus-visible:ring-ring/50 disabled:opacity-50"
							>
								{ sprintf(
									/* translators: %d: every conversation in this view */
									__( 'Select all %d', 'bridle' ),
									all
								) }
							</button>
						</>
					) }
				</p>
			) }
			<div className="flex h-9 items-center rounded-full border bg-card pr-1 shadow-xs">
				<button
					type="button"
					role="checkbox"
					aria-checked={ checked }
					aria-label={
						state === 'none'
							? __( 'Select all', 'bridle' )
							: __( 'Clear selection', 'bridle' )
					}
					onClick={ () => onSetMany( state === 'none' ? ids : [] ) }
					className="flex size-9 items-center justify-center rounded-full outline-none transition-colors hover:bg-accent focus-visible:ring-[3px] focus-visible:ring-ring/50"
				>
					<CheckboxMark state={ mark } />
				</button>
				<DropdownMenu>
					<DropdownMenuTrigger asChild>
						<button
							type="button"
							aria-label={ __( 'Select by', 'bridle' ) }
							className="flex h-7 w-6 items-center justify-center rounded-full text-muted-foreground outline-none transition-colors hover:bg-accent hover:text-foreground focus-visible:ring-[3px] focus-visible:ring-ring/50 data-[state=open]:bg-accent data-[state=open]:text-foreground"
						>
							<ChevronDown className="size-3.5" />
						</button>
					</DropdownMenuTrigger>
					<DropdownMenuContent align="end" className="min-w-36">
						<DropdownMenuItem onSelect={ () => onSetMany( ids ) }>
							{ __( 'All', 'bridle' ) }
						</DropdownMenuItem>
						<DropdownMenuItem onSelect={ () => onSetMany( [] ) }>
							{ __( 'None', 'bridle' ) }
						</DropdownMenuItem>
						{ hasReadState && (
							<DropdownMenuItem
								onSelect={ () =>
									pick( ( row ) => row.unread === false )
								}
							>
								{ __( 'Read', 'bridle' ) }
							</DropdownMenuItem>
						) }
						{ hasReadState && (
							<DropdownMenuItem
								onSelect={ () =>
									pick( ( row ) => row.unread === true )
								}
							>
								{ __( 'Unread', 'bridle' ) }
							</DropdownMenuItem>
						) }
					</DropdownMenuContent>
				</DropdownMenu>
			</div>
		</div>
	);
}
