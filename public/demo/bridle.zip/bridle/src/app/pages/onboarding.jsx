import { useEffect, useRef, useState } from 'react';
import { __, sprintf } from '@wordpress/i18n';
import { cn } from 'cn';

import { ChatMessage, Composer, Typing } from '@/components/onboarding/chat';
import {
	CopyValue,
	ForwardingSteps,
	GmailConfirm,
	MailStatus,
} from '@/components/onboarding/forwarding-guide';
import { INBOX_COLORS } from '@/components/settings/inbox-form';
import { BrandIcon } from '@/components/shell/logo';
import { useShell } from '@/components/shell/shell-context';
import { forgetAgentMode } from '@/components/thread/agent-draft-card';
import {
	ai,
	conversations,
	inboxAi,
	inboxes as inboxesApi,
	settings,
	workspace,
} from '@/lib/api';
import { appData } from '@/lib/app-data';
import {
	gmailConfirmLink,
	gmailConfirmation,
	isEmail,
	looksLikeConfirmation,
	providerFromAnswer,
	suggestedAddress,
	wantsLater,
} from '@/lib/mail-setup';
import { navigate } from '@/lib/router';
import { saysYes } from '@/lib/answers';

const STAGES = [
	__( 'Name', 'bridle' ),
	__( 'Address', 'bridle' ),
	__( 'Forwarding', 'bridle' ),
	__( 'Voice', 'bridle' ),
];

const sleep = ( ms ) => new Promise( ( resolve ) => setTimeout( resolve, ms ) );

const reduceMotion = () =>
	!! window.matchMedia?.( '(prefers-reduced-motion: reduce)' ).matches;

// Bridle "types" a moment before each message; longer text, longer pause.
function typingDelay( content ) {
	if ( reduceMotion() ) {
		return 150;
	}
	const length = typeof content === 'string' ? content.length : 120;
	return Math.min( 1300, 350 + length * 9 );
}

/*
 * Onboarding as a conversation (#67). Bridle asks, you answer and press ↵:
 * business name, the support address, then forwarding, walked through for
 * the provider the address is hosted on (MX lookup, else asked). It watches
 * the new inbox and moves on by itself when the first email lands, showing
 * Gmail's confirmation code on the way. Then the agent's voice, Draft mode,
 * and the Inbox. A reload with an inbox already set up resumes at
 * forwarding instead of creating a second one.
 *
 * The flow is one async script; `ask()` resolves when the composer answers.
 */
export function OnboardingPage() {
	const { inboxes, refreshInboxes, setOnboardingDone } = useShell();
	const [ messages, setMessages ] = useState( [] );
	const [ typing, setTyping ] = useState( false );
	const [ prompt, setPrompt ] = useState( null );
	const [ stage, setStage ] = useState( 0 );
	const scroller = useRef( null );
	const pending = useRef( null );
	const seq = useRef( 0 );
	const started = useRef( false );
	const alive = useRef( true );

	useEffect(
		() => () => {
			alive.current = false;
		},
		[]
	);

	useEffect( () => {
		const el = scroller.current;
		if ( el ) {
			el.scrollTo( {
				top: el.scrollHeight,
				behavior: reduceMotion() ? 'auto' : 'smooth',
			} );
		}
	}, [ messages, typing ] );

	/* ── The conversation primitives ── */

	const push = ( from, content ) => {
		seq.current += 1;
		const id = seq.current;
		setMessages( ( list ) => [ ...list, { id, from, content } ] );
		return id;
	};

	const update = ( id, content ) =>
		setMessages( ( list ) =>
			list.map( ( m ) => ( m.id === id ? { ...m, content } : m ) )
		);

	const say = async ( content ) => {
		setTyping( true );
		await sleep( typingDelay( content ) );
		setTyping( false );
		return push( 'bridle', content );
	};

	const ask = ( config ) =>
		new Promise( ( resolve ) => {
			pending.current = { ...config, resolve };
			setPrompt( pending.current );
		} );

	const closePrompt = () => {
		pending.current = null;
		setPrompt( null );
	};

	const onAnswer = ( text ) => {
		const open = pending.current;
		if ( ! open ) {
			return;
		}
		closePrompt();
		if ( ! open.quiet ) {
			push( 'you', text || open.emptyLabel || __( 'Skip', 'bridle' ) );
		}
		open.resolve( text );
	};

	// Run a request; on failure say why and retry when the user presses ↵.
	const attempt = async ( fn ) => {
		for (;;) {
			try {
				setTyping( true );
				return await fn();
			} catch ( err ) {
				setTyping( false );
				await say(
					sprintf(
						/* translators: %s: the error message */
						__( 'That didn’t go through: %s', 'bridle' ),
						err?.message || __( 'Something went wrong.', 'bridle' )
					)
				);
				await ask( {
					placeholder: __( 'Press ↵ to try again', 'bridle' ),
					allowEmpty: true,
					quiet: true,
				} );
			} finally {
				setTyping( false );
			}
		}
	};

	/* ── Questions ── */

	const askName = async () => {
		const fallback = appData.siteName;
		const answer = await ask( {
			label: __( 'Business name', 'bridle' ),
			placeholder: fallback || __( 'Your business', 'bridle' ),
			hint: fallback
				? sprintf(
						/* translators: %s: the site name */
						__( '↵ to use “%s”', 'bridle' ),
						fallback
				  )
				: '',
			allowEmpty: !! fallback,
			emptyLabel: fallback,
			autoComplete: 'organization',
		} );
		return answer || fallback;
	};

	const askAddress = async () => {
		for (;;) {
			const answer = await ask( {
				label: __( 'Support address', 'bridle' ),
				placeholder: suggestedAddress( window.location.hostname ),
				inputMode: 'email',
				autoComplete: 'email',
			} );
			if ( isEmail( answer ) ) {
				return answer.trim();
			}
			await say(
				__(
					'That doesn’t look like an email address. Try something like support@yourstore.com.',
					'bridle'
				)
			);
		}
	};

	/*
	 * Watch the inbox until the first real email lands, or the user types
	 * "later". Gmail's confirmation is shown, not counted. Resolves with
	 * { row } (the conversation, or null if it was filed out of sight) or
	 * { later: true }.
	 */
	const waitForMail = ( inbox, statusId ) =>
		new Promise( ( resolve ) => {
			let done = false;
			let lastSeen = null;
			let timer = null;
			let inflight = null;
			const handled = new Set();
			const startedAt = Date.now();

			const finish = ( result ) => {
				if ( done ) {
					return;
				}
				done = true;
				clearTimeout( timer );
				closePrompt();
				update(
					statusId,
					<MailStatus
						address={ inbox.forwarding_address }
						state={ result.later ? 'paused' : 'arrived' }
					/>
				);
				resolve( result );
			};

			// Newest first. Returns the first conversation that isn't a
			// forwarding confirmation, after showing any Gmail one.
			const inspect = async () => {
				const { items } = await conversations.list( {
					inbox_id: inbox.id,
					status: 'allmail',
					per_page: 5,
				} );
				for ( const row of items ) {
					if ( handled.has( row.id ) ) {
						continue;
					}
					handled.add( row.id );
					const gmail = gmailConfirmation( row );
					if ( ! gmail ) {
						return row;
					}
					let link = null;
					try {
						const full = await conversations.get( row.id );
						link = gmailConfirmLink(
							( full?.threads || [] )
								.map( ( thread ) => thread.content || '' )
								.join( '\n' )
						);
					} catch ( e ) {
						// The code alone is enough.
					}
					await say(
						<GmailConfirm code={ gmail.code } link={ link } />
					);
					await say(
						sprintf(
							/* translators: %s: the Bridle forwarding address */
							__(
								'Then, back in Forwarding and POP/IMAP, choose “Forward a copy of incoming mail to %s”, keep Gmail’s copy in the inbox, and Save Changes. Send yourself a test from another address and I’ll see it.',
								'bridle'
							),
							inbox.forwarding_address
						)
					);
				}
				return null;
			};

			const check = () => {
				if ( done || ! alive.current ) {
					return Promise.resolve( false );
				}
				inflight =
					inflight ||
					( async () => {
						try {
							const rows = await inboxesApi.list();
							const fresh = ( rows || [] ).find(
								( row ) =>
									Number( row.id ) === Number( inbox.id )
							);
							const received = fresh?.last_received_at;
							if ( ! received || received === lastSeen ) {
								return false;
							}
							lastSeen = received;
							const before = handled.size;
							const row = await inspect();
							if ( row || handled.size === before ) {
								finish( { row } );
								return true;
							}
						} catch ( e ) {
							// A network blip; the next tick tries again.
						} finally {
							inflight = null;
						}
						return false;
					} )();
				return inflight;
			};

			const tick = async () => {
				await check();
				if ( done || ! alive.current ) {
					return;
				}
				const slow = Date.now() - startedAt > 180000;
				timer = setTimeout( tick, slow ? 10000 : 4000 );
			};
			timer = setTimeout( tick, 2500 );

			( async () => {
				while ( ! done ) {
					const text = await ask( {
						label: __( 'Reply to Bridle', 'bridle' ),
						placeholder: __(
							'Send a test email, then come back here',
							'bridle'
						),
						hint: __(
							'Type “later” to finish forwarding after setup.',
							'bridle'
						),
					} );
					if ( done ) {
						break;
					}
					if ( wantsLater( text ) ) {
						finish( { later: true } );
						break;
					}
					if ( ! ( await check() ) && ! done ) {
						await say(
							__(
								'Nothing yet. Forwarding can take a minute to kick in; I’m still watching.',
								'bridle'
							)
						);
					}
				}
			} )();
		} );

	/* ── The script ── */

	// Has real mail (not just a forwarding confirmation) reached the inbox?
	const hasRealMail = async ( inbox ) => {
		if ( ! inbox.last_received_at ) {
			return false;
		}
		try {
			const { items } = await conversations.list( {
				inbox_id: inbox.id,
				status: 'allmail',
				per_page: 5,
			} );
			return items.some( ( row ) => ! gmailConfirmation( row ) );
		} catch ( e ) {
			return false;
		}
	};

	const forwarding = async ( inbox, knownHost ) => {
		if ( await hasRealMail( inbox ) ) {
			await say(
				sprintf(
					/* translators: %s: the Bridle forwarding address */
					__( 'Mail is already coming through to %s.', 'bridle' ),
					inbox.forwarding_address
				)
			);
			return;
		}

		const host =
			knownHost ||
			( await inboxesApi
				.mailHost( inbox.email_address )
				.catch( () => null ) );
		let provider = host?.provider || null;
		if ( provider ) {
			await say(
				sprintf(
					/* translators: 1: the support address, 2: its mail host, e.g. Google Workspace */
					__(
						'%1$s runs on %2$s. Here’s how to send its mail my way.',
						'bridle'
					),
					inbox.email_address,
					host.label
				)
			);
		} else {
			await say(
				sprintf(
					/* translators: %s: the support address */
					__( 'Where does %s live?', 'bridle' ),
					inbox.email_address
				)
			);
			provider = providerFromAnswer(
				await ask( {
					label: __( 'Mail provider', 'bridle' ),
					placeholder: __(
						'Gmail, Outlook, Zoho, cPanel…',
						'bridle'
					),
					suggestions: [
						__( 'Gmail or Google Workspace', 'bridle' ),
						__( 'Outlook or Microsoft 365', 'bridle' ),
						__( 'Somewhere else', 'bridle' ),
					],
				} )
			);
		}

		await say(
			<>
				{ __(
					'This is your Bridle address. Click it to copy.',
					'bridle'
				) }
				<CopyValue
					value={ inbox.forwarding_address }
					className="mt-3"
				/>
			</>
		);
		if ( inbox.registration_warning ) {
			await say(
				__(
					'One snag: the mail service hasn’t confirmed this address yet. I’ll keep retrying in the background, so mail may take a few extra minutes to start.',
					'bridle'
				)
			);
		}
		await say(
			<ForwardingSteps
				provider={ provider }
				label={ host?.label }
				inbox={ inbox }
			/>
		);

		const statusId = await say(
			<MailStatus address={ inbox.forwarding_address } state="watching" />
		);
		const result = await waitForMail( inbox, statusId );
		if ( result.later ) {
			await say(
				__(
					'No problem. Your address and these steps are under Settings → Inbox whenever you’re ready.',
					'bridle'
				)
			);
			return;
		}
		const row = result.row;
		if ( ! row ) {
			await say( __( 'Mail is coming through.', 'bridle' ) );
			return;
		}
		const sender = row.customer_name || row.customer_email;
		await say(
			looksLikeConfirmation( row )
				? sprintf(
						/* translators: 1: email subject, 2: sender */
						__(
							'“%1$s” from %2$s just arrived. If it asks you to confirm forwarding, open it from your Inbox when we’re done.',
							'bridle'
						),
						row.subject,
						sender
				  )
				: sprintf(
						/* translators: 1: email subject, 2: sender */
						__(
							'It’s here: “%1$s” from %2$s. Your support mail now comes to me.',
							'bridle'
						),
						row.subject,
						sender
				  )
		);
	};

	const voice = async ( inbox ) => {
		setStage( 3 );
		await say(
			__(
				'Last thing. How should I sound when I write to your customers? A sentence or two is plenty.',
				'bridle'
			)
		);
		const tone = await ask( {
			label: __( 'How Bridle should sound', 'bridle' ),
			placeholder: __( 'Warm and direct. Sign off as Sam.', 'bridle' ),
			hint: __( '↵ to skip · Shift ↵ for a new line', 'bridle' ),
			multiline: true,
			allowEmpty: true,
		} );
		if ( tone ) {
			await attempt( () =>
				settings.save( { agent_instructions: tone } )
			);
		}

		// Asked once: a "Powered by Bridle" line under the emails Bridle
		// sends. Off unless they say yes (WordPress.org guideline 10).
		await say(
			__(
				'One small favour: may I add “Powered by Bridle” under the emails I send and the chat? It helps other people find Bridle. It stays off unless you say yes, and you can change it in Settings.',
				'bridle'
			)
		);
		const yes = __( 'Yes, add it', 'bridle' );
		const no = __( 'No thanks', 'bridle' );
		const credit = await ask( {
			label: __( 'Powered by Bridle', 'bridle' ),
			placeholder: __( 'Yes or no', 'bridle' ),
			suggestions: [ yes, no ],
			allowEmpty: true,
			emptyLabel: no,
		} );
		if ( saysYes( credit, yes ) ) {
			await attempt( () =>
				settings.save( {
					email_credit_enabled: true,
					chat_credit_enabled: true,
				} )
			);
		}

		const status = await ai.status().catch( () => null );
		if ( status?.can_use_ai ) {
			await attempt( () => inboxAi.set( inbox.id, 'draft' ) );
			forgetAgentMode( inbox.id );
			await say(
				__(
					'I’ll draft a reply to every customer email. Nothing goes out until you send it.',
					'bridle'
				)
			);
		} else {
			await say(
				__(
					'To write drafts I need an AI provider. Connect one under Settings → AI in WordPress, then switch me to Draft in Settings → Agent.',
					'bridle'
				)
			);
		}

		await attempt( () => workspace.completeOnboarding() );
		await say( __( 'You’re all set.', 'bridle' ) );
		await ask( {
			label: __( 'Open the Inbox', 'bridle' ),
			placeholder: __( 'Press ↵ to open your Inbox', 'bridle' ),
			allowEmpty: true,
			quiet: true,
		} );
		// The shell's inbox list predates the first email; refresh it so
		// Settings shows the inbox as connected.
		await refreshInboxes().catch( () => null );
		appData.onboardingDone = true;
		setOnboardingDone( true );
		navigate( '/inbox', {}, { replace: true } );
	};

	const run = async () => {
		let inbox = inboxes[ 0 ] || null;
		let host = null;

		if ( inbox ) {
			setStage( 2 );
			await say(
				sprintf(
					/* translators: %s: the support address */
					__( 'Welcome back. Let’s finish connecting %s.', 'bridle' ),
					inbox.email_address
				)
			);
		} else {
			await say(
				__(
					'Hi, I’m Bridle. I sort your support mail and draft the replies. You decide what gets sent.',
					'bridle'
				)
			);
			await say(
				__(
					'Setup takes about two minutes. First, what’s your business called? Customers see this name in the emails I send.',
					'bridle'
				)
			);
			const name = await askName();
			await attempt( () => settings.save( { business_name: name } ) );

			setStage( 1 );
			await say(
				sprintf(
					/* translators: %s: the business name */
					__(
						'Nice to meet you, %s. Which address do your customers write to?',
						'bridle'
					),
					name
				)
			);
			const email = await askAddress();
			const hostLookup = inboxesApi.mailHost( email ).catch( () => null );
			inbox = await attempt( () =>
				inboxesApi.create( {
					display_name: __( 'Support', 'bridle' ),
					email_address: email,
					color: INBOX_COLORS[ 0 ],
				} )
			);
			refreshInboxes();
			host = await hostLookup;
		}

		setStage( 2 );
		await forwarding( inbox, host );
		await voice( inbox );
	};

	useEffect( () => {
		if ( started.current ) {
			return;
		}
		started.current = true;
		run();
		// The script runs once; it reads the shell state it starts with.
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [] );

	return (
		<div className="flex min-h-0 flex-1 flex-col">
			<header className="mx-auto flex w-full max-w-3xl items-center gap-2 px-6 pt-8 pb-3">
				<BrandIcon className="size-6" />
				<span className="text-[15px] font-semibold tracking-tight">
					{ __( 'Bridle', 'bridle' ) }
				</span>
				<div
					className="ml-auto flex items-center gap-1.5"
					role="progressbar"
					aria-label={ __( 'Setup progress', 'bridle' ) }
					aria-valuemin={ 1 }
					aria-valuemax={ STAGES.length }
					aria-valuenow={ stage + 1 }
					aria-valuetext={ STAGES[ stage ] }
				>
					{ STAGES.map( ( label, i ) => (
						<span
							key={ label }
							title={ label }
							className={ cn(
								'h-1 w-6 rounded-full transition-colors duration-500',
								i <= stage ? 'bg-foreground' : 'bg-border'
							) }
						/>
					) ) }
				</div>
			</header>

			<div ref={ scroller } className="min-h-0 flex-1 overflow-y-auto">
				<div
					role="log"
					aria-live="polite"
					aria-relevant="additions"
					className="mx-auto w-full max-w-3xl px-6 pt-6 pb-10"
				>
					{ messages.map( ( message, i ) => {
						const previous = messages[ i - 1 ];
						const sameSpeaker = previous?.from === message.from;
						return (
							<div
								key={ message.id }
								className={ cn(
									i > 0 && ( sameSpeaker ? 'mt-3' : 'mt-7' )
								) }
							>
								<ChatMessage
									from={ message.from }
									first={ ! sameSpeaker }
								>
									{ message.content }
								</ChatMessage>
							</div>
						);
					} ) }
					{ typing && (
						<div className={ cn( messages.length > 0 && 'mt-3' ) }>
							<Typing
								first={
									messages[ messages.length - 1 ]?.from !==
									'bridle'
								}
							/>
						</div>
					) }
				</div>
			</div>

			<div className="mx-auto w-full max-w-3xl px-6 pt-2 pb-8">
				<Composer prompt={ prompt } onAnswer={ onAnswer } />
			</div>
		</div>
	);
}
