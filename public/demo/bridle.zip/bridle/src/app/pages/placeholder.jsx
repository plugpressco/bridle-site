import { __ } from '@wordpress/i18n';

import { Page } from '@/components/shell/page';
import { Button } from '@/components/ui/button';
import { Link } from '@/lib/router';

/* Any address the router doesn't know. */
export function NotFoundPage() {
	return (
		<Page title={ __( 'Nothing here', 'bridle' ) }>
			<p className="text-sm text-muted-foreground">
				{ __( 'That address doesn’t match a page.', 'bridle' ) }
			</p>
			<Button asChild variant="outline" className="mt-4">
				<Link to="/inbox">{ __( 'Go to the Inbox', 'bridle' ) }</Link>
			</Button>
		</Page>
	);
}
