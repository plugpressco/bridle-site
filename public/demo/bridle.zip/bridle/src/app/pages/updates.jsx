import { useMemo, useState } from 'react';
import { __, sprintf } from '@wordpress/i18n';
import { ArrowUpRight, ChevronDown, Inbox, Trash } from 'lucide-react';
import { cn } from 'cn';

import { ContactAvatar } from '@/components/list/contact-avatar';
import { EmptyState, ListError } from '@/components/list/empty-state';
import { Page } from '@/components/shell/page';
import { useShell } from '@/components/shell/shell-context';
import { MessageBody } from '@/components/thread/message-card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { conversations, customers } from '@/lib/api';
import { isExchange } from '@/lib/conversation';
import { Link } from '@/lib/router';
import { useShortcuts } from '@/lib/shortcuts';
import { dayLabel, fullDateTime, relativeTime } from '@/lib/time';
import { useConversation } from '@/lib/use-conversation';
import { usePagedList } from '@/lib/use-paged-list';

/* The newest message from the sender, read in place inside its card. */
function Reading( { id } ) {
	const { data, loading, error } = useConversation( id );
	if ( loading && ! data ) {
		return (
			<div className="space-y-2 pt-1">
				<Skeleton className="h-3.5 w-full" />
				<Skeleton className="h-3.5 w-11/12" />
				<Skeleton className="h-3.5 w-2/3" />
			</div>
		);
	}
	if ( error || ! data ) {
		return (
			<p className="text-sm text-muted-foreground">
				{ __( 'Couldn’t load this email.', 'bridle' ) }
			</p>
		);
	}
	const latest = [ ...( data.threads || [] ) ].reverse().find( isExchange );
	return latest ? <MessageBody thread={ latest } /> : null;
}

function UpdateCard( { row, open, busy, onToggle, onMove, onTrash } ) {
	const sender = row.customer_name || row.customer_email;
	const actions = (
		<>
			<Button
				size="sm"
				variant="ghost"
				className="rounded-full"
				disabled={ busy }
				onClick={ onMove }
			>
				<Inbox />
				{ __( 'Move to inbox', 'bridle' ) }
			</Button>
			<Button
				size="sm"
				variant="ghost"
				className="rounded-full"
				disabled={ busy }
				onClick={ onTrash }
			>
				<Trash />
				{ __( 'Trash', 'bridle' ) }
			</Button>
		</>
	);
	return (
		<article
			className={ cn(
				'surface group relative px-5 py-4 transition-shadow',
				! open && 'hover:shadow-[0_12px_32px_-20px_rgb(24_24_24/0.3)]'
			) }
		>
			<header className="flex items-start gap-3">
				<ContactAvatar
					name={ row.customer_name }
					email={ row.customer_email }
					src={ row.customer_avatar }
				/>
				<button
					type="button"
					onClick={ onToggle }
					aria-expanded={ open }
					className="min-w-0 flex-1 text-left text-[15px] outline-none after:absolute after:inset-0 after:rounded-card focus-visible:after:ring-[3px] focus-visible:after:ring-ring/50"
				>
					<span className="flex min-w-0 items-baseline gap-2">
						<span className="truncate font-semibold">
							{ sender }
						</span>
						<time
							dateTime={ row.last_activity_at }
							title={ fullDateTime( row.last_activity_at ) }
							className="ml-auto shrink-0 text-xs text-muted-foreground tabular-nums"
						>
							{ relativeTime( row.last_activity_at ) }
						</time>
					</span>
					<span className="mt-0.5 block truncate">
						{ row.subject || __( '(no subject)', 'bridle' ) }
					</span>
					{ ! open && row.last_message_preview && (
						<span className="mt-1 line-clamp-2 block text-sm text-muted-foreground">
							{ row.last_message_preview }
						</span>
					) }
				</button>
			</header>

			{ open ? (
				<>
					<div className="relative z-10 mt-4 border-t pt-4 pl-12">
						<Reading id={ row.id } />
					</div>
					<footer className="relative z-10 mt-4 flex flex-wrap items-center justify-end gap-1 pl-12">
						{ actions }
						<Button
							asChild
							size="sm"
							variant="ghost"
							className="rounded-full"
						>
							<Link to={ `/c/${ row.id }` }>
								<ArrowUpRight />
								{ __( 'Open', 'bridle' ) }
							</Link>
						</Button>
						<Button
							size="sm"
							variant="ghost"
							className="rounded-full"
							onClick={ onToggle }
							aria-expanded={ open }
						>
							{ __( 'Close', 'bridle' ) }
							<ChevronDown className="rotate-180" />
						</Button>
					</footer>
				</>
			) : (
				// Closed, the actions float over the corner on hover (where
				// the time sits), so a card is only as tall as its text.
				<div className="absolute top-2.5 right-3 z-10 flex items-center gap-0.5 rounded-full bg-card opacity-0 transition-opacity duration-150 group-focus-within:opacity-100 group-hover:opacity-100 [@media(hover:none)]:opacity-100">
					{ actions }
				</div>
			) }
		</article>
	);
}

/*
 * Updates (AGENTS.md §7): the mail a machine sent, receipts, newsletters,
 * notifications, as a calm feed you read in place instead of a second
 * inbox to work through. One card per email, grouped by day. Moving a card
 * to the Inbox is a decision about the sender: all their mail follows.
 */
export function UpdatesPage() {
	const { inboxScope, refreshCounts } = useShell();
	const list = usePagedList(
		( page ) =>
			conversations.list( { box: 'feed', inbox_id: inboxScope, page } ),
		[ inboxScope ]
	);
	const [ openId, setOpenId ] = useState( null );
	const [ busyId, setBusyId ] = useState( null );
	const [ moved, setMoved ] = useState( null ); // { customerId, name }
	const [ error, setError ] = useState( null );

	useShortcuts( {
		escape: () => {
			if ( ! openId ) {
				return false;
			}
			setOpenId( null );
		},
	} );

	// Consecutive rows that share a day share a heading (the list is newest first).
	const days = useMemo( () => {
		const groups = [];
		list.items.forEach( ( row ) => {
			const label = dayLabel( row.last_activity_at );
			const last = groups[ groups.length - 1 ];
			if ( last && last.label === label ) {
				last.rows.push( row );
			} else {
				groups.push( { label, rows: [ row ] } );
			}
		} );
		return groups;
	}, [ list.items ] );

	const moveToInbox = async ( row ) => {
		setBusyId( row.id );
		setError( null );
		try {
			await customers.setBox( row.customer_id, 'inbox' );
			list.remove(
				list.items
					.filter(
						( item ) =>
							Number( item.customer_id ) ===
							Number( row.customer_id )
					)
					.map( ( item ) => item.id )
			);
			setMoved( {
				customerId: row.customer_id,
				name: row.customer_name || row.customer_email,
			} );
			refreshCounts();
		} catch {
			setError( __( 'Couldn’t move that. Try again.', 'bridle' ) );
		} finally {
			setBusyId( null );
		}
	};

	// Undo hands the sender back to Automatic, which is where they came from.
	const undoMove = async () => {
		const { customerId } = moved;
		setMoved( null );
		try {
			await customers.setBox( customerId, null );
		} catch {
			setError( __( 'Couldn’t undo that. Try again.', 'bridle' ) );
		}
		list.reload();
		refreshCounts();
	};

	const trash = async ( row ) => {
		setBusyId( row.id );
		setError( null );
		try {
			await conversations.bulkTrash( [ row.id ] );
			list.remove( [ row.id ] );
			refreshCounts();
		} catch {
			setError( __( 'Couldn’t move that to the trash.', 'bridle' ) );
		} finally {
			setBusyId( null );
		}
	};

	return (
		<Page scope width="list" title={ __( 'Updates', 'bridle' ) }>
			{ moved && (
				<div
					role="status"
					className="mb-6 flex items-center gap-3 rounded-full bg-brand-soft py-1.5 pr-1.5 pl-4 text-sm"
				>
					<span className="min-w-0 flex-1 truncate">
						{ sprintf(
							/* translators: %s: sender name or email */
							__(
								'Mail from %s now goes to your Inbox',
								'bridle'
							),
							moved.name
						) }
					</span>
					<Button
						size="sm"
						variant="ghost"
						className="rounded-full"
						onClick={ undoMove }
					>
						{ __( 'Undo', 'bridle' ) }
					</Button>
				</div>
			) }
			{ error && <ListError message={ error } /> }
			{ list.error && <ListError onRetry={ list.reload } /> }

			{ list.loading && ! list.items.length && (
				<div className="space-y-3">
					{ [ 0, 1, 2 ].map( ( i ) => (
						<div key={ i } className="surface flex gap-3 px-5 py-4">
							<Skeleton className="size-9 rounded-full" />
							<div className="flex-1 space-y-2">
								<Skeleton className="h-3.5 w-1/3" />
								<Skeleton className="h-3.5 w-2/3" />
								<Skeleton className="h-3 w-full" />
							</div>
						</div>
					) ) }
				</div>
			) }

			{ ! list.loading && ! list.error && ! list.items.length && (
				<EmptyState
					title={ __( 'No updates yet.', 'bridle' ) }
					hint={ __(
						'Receipts, newsletters and notifications collect here, out of your way.',
						'bridle'
					) }
				/>
			) }

			{ days.map( ( day ) => (
				<section key={ day.label } className="mb-8">
					<h2 className="mb-3 text-sm text-muted-foreground">
						{ day.label }
					</h2>
					<div className="space-y-3">
						{ day.rows.map( ( row ) => (
							<UpdateCard
								key={ row.id }
								row={ row }
								open={ openId === row.id }
								busy={ busyId === row.id }
								onToggle={ () =>
									setOpenId( ( id ) =>
										id === row.id ? null : row.id
									)
								}
								onMove={ () => moveToInbox( row ) }
								onTrash={ () => trash( row ) }
							/>
						) ) }
					</div>
				</section>
			) ) }

			{ list.hasMore && (
				<div className="text-center">
					<Button
						variant="ghost"
						size="sm"
						className="rounded-full"
						onClick={ list.loadMore }
						disabled={ list.loading }
					>
						{ __( 'Load more', 'bridle' ) }
					</Button>
				</div>
			) }
		</Page>
	);
}
