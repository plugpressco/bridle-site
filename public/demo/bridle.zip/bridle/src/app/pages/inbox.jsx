import { useMemo, useState } from 'react';
import { __ } from '@wordpress/i18n';
import { Archive, Mail, MailOpen, ShieldAlert, Trash } from 'lucide-react';

import { BulkBar } from '@/components/list/bulk-bar';
import { ConversationList } from '@/components/list/conversation-list';
import { SelectHeader } from '@/components/list/select-header';
import { EmptyState, ListError } from '@/components/list/empty-state';
import { Page } from '@/components/shell/page';
import { useShell } from '@/components/shell/shell-context';
import { conversations } from '@/lib/api';
import { groupForReview, isNew } from '@/lib/conversation';
import {
	setStatusAll,
	useSelectAllMatching,
	useSelection,
} from '@/lib/use-selection';
import { usePagedList } from '@/lib/use-paged-list';
import { bulkRead, useReadToggle } from '@/lib/use-read-toggle';

/*
 * The Inbox: what needs you, grouped by what you do next instead of a
 * spreadsheet. Rows that need a reply come from one request split on the
 * client: Ready to send, Sending soon and Needs you while the agent drafts,
 * New and Open otherwise. Waiting (we spoke last) is its own. The other
 * boxes are in the dock.
 */
export function InboxPage() {
	const { inboxScope, refreshCounts } = useShell();
	const { selected, toggle, setMany, clear, drop } = useSelection();
	const [ busy, setBusy ] = useState( false );
	const [ bulkError, setBulkError ] = useState( null );

	const needs = usePagedList(
		( page ) =>
			conversations.list( {
				box: 'needs_reply',
				inbox_id: inboxScope,
				page,
			} ),
		[ inboxScope ]
	);
	const waiting = usePagedList(
		( page ) =>
			conversations.list( {
				box: 'waiting',
				inbox_id: inboxScope,
				page,
			} ),
		[ inboxScope ]
	);

	// While the agent drafts, needs-reply rows group by what you do next
	// (#108): Ready to send, Sending soon, Needs you. Without any draft the
	// Inbox keeps New and Open. Load-more belongs to the last of those
	// groups, the place more needs-reply rows land.
	const sections = useMemo( () => {
		const groups = groupForReview( needs.items );
		const part = ( items ) => ( {
			...needs,
			items,
			total: items.length,
			hasMore: false,
			loading: false,
		} );
		const waitingSection = {
			key: 'waiting',
			title: __( 'Waiting', 'bridle' ),
			// Wait for the first group before showing a second skeleton.
			list: {
				...waiting,
				loading:
					waiting.loading &&
					! ( needs.loading && ! needs.items.length ),
			},
		};

		if ( ! groups.byAgent ) {
			const fresh = groups.rest.filter( ( row ) => isNew( row ) );
			const open = groups.rest.filter( ( row ) => ! isNew( row ) );
			return [
				{
					key: 'new',
					title: __( 'New', 'bridle' ),
					list: part( fresh ),
				},
				{
					key: 'open',
					title: __( 'Open', 'bridle' ),
					list: { ...needs, items: open, total: open.length },
				},
				waitingSection,
			];
		}

		const placed = groups.ready.length + groups.sending.length;
		return [
			{
				key: 'ready',
				title: __( 'Ready to send', 'bridle' ),
				list: part( groups.ready ),
			},
			{
				key: 'sending',
				title: __( 'Sending soon', 'bridle' ),
				list: part( groups.sending ),
			},
			{
				key: 'needs',
				title: __( 'Needs you', 'bridle' ),
				list: {
					...needs,
					items: groups.rest,
					total: Math.max( groups.rest.length, needs.total - placed ),
				},
			},
			waitingSection,
		];
	}, [ needs, waiting ] );

	// One definition per action, used by the bulk bar (every selected row)
	// and by each row's quick actions (that row). Rows leave at once and come
	// back with a reload if the server says no.
	const apply = ( fn ) => async ( ids ) => {
		setBusy( true );
		setBulkError( null );
		// "Select all N" can reach past the loaded rows; then the lists reload
		// afterwards to fill the space.
		const loaded = new Set(
			[ ...needs.items, ...waiting.items ].map( ( row ) =>
				Number( row.id )
			)
		);
		const beyond = ids.some( ( id ) => ! loaded.has( Number( id ) ) );
		needs.remove( ids );
		waiting.remove( ids );
		drop( ids );
		try {
			await fn( ids );
			if ( beyond ) {
				needs.reload();
				waiting.reload();
			}
		} catch {
			// Some may have gone through: reload to show where things stand.
			setBulkError(
				__( 'Some conversations could not be updated.', 'bridle' )
			);
			needs.reload();
			waiting.reload();
		} finally {
			setBusy( false );
			refreshCounts();
		}
	};
	const defs = [
		{
			key: 'resolve',
			label: __( 'Resolve', 'bridle' ),
			icon: Archive,
			fn: ( list ) => setStatusAll( list, 'closed' ),
		},
		{
			key: 'spam',
			label: __( 'Spam', 'bridle' ),
			icon: ShieldAlert,
			fn: ( list ) => setStatusAll( list, 'spam' ),
			bulkOnly: true,
		},
		{
			key: 'trash',
			label: __( 'Trash', 'bridle' ),
			icon: Trash,
			fn: conversations.bulkTrash,
		},
	];
	const failed = () =>
		setBulkError( __( 'Couldn’t save that. Try again.', 'bridle' ) );
	const read = bulkRead( [ needs, waiting ], selected, failed );
	const actions = [
		...( read
			? [
					{
						key: 'read',
						label: read.markRead
							? __( 'Mark read', 'bridle' )
							: __( 'Mark unread', 'bridle' ),
						icon: read.markRead ? MailOpen : Mail,
						run: read.run,
					},
			  ]
			: [] ),
		...defs.map( ( def ) => ( {
			...def,
			run: () => apply( def.fn )( [ ...selected ] ),
		} ) ),
	];
	const [ selectAllMatching, matchingBusy ] = useSelectAllMatching(
		{ box: 'inbox', inbox_id: inboxScope },
		setMany,
		failed
	);
	const rowActions = defs
		.filter( ( def ) => ! def.bulkOnly )
		.map( ( def ) => ( {
			...def,
			run: ( id ) => apply( def.fn )( [ id ] ),
		} ) );

	const toggleRead = useReadToggle( [ needs, waiting ], failed );

	const loadFailed = !! ( needs.error || waiting.error );

	return (
		<Page
			scope
			width="list"
			title={ __( 'Inbox', 'bridle' ) }
			actions={
				<SelectHeader
					lists={ [ needs, waiting ] }
					selected={ selected }
					onSetMany={ setMany }
					total={ needs.total + waiting.total }
					onAllMatching={ selectAllMatching }
					matchingBusy={ matchingBusy }
				/>
			}
		>
			{ bulkError && <ListError message={ bulkError } /> }
			{ loadFailed && (
				<ListError
					onRetry={ () => {
						if ( needs.error ) {
							needs.reload();
						}
						if ( waiting.error ) {
							waiting.reload();
						}
					} }
				/>
			) }
			<ConversationList
				sections={ sections }
				selected={ selected }
				onToggle={ toggle }
				rowActions={ rowActions }
				onToggleRead={ toggleRead }
				empty={
					loadFailed ? null : (
						<EmptyState
							title={ __( 'You’re all caught up.', 'bridle' ) }
							hint={ __(
								'New mail lands here the moment it arrives.',
								'bridle'
							) }
						/>
					)
				}
			/>
			<BulkBar
				count={ selected.size }
				actions={ actions }
				onClear={ clear }
				busy={ busy }
			/>
		</Page>
	);
}
