import { __ } from '@wordpress/i18n';

import { Field, InlineError, Row } from '@/components/settings/field';
import {
	SettingsPanel,
	SettingsSection,
} from '@/components/settings/settings-frame';
import { useInstant, useSiteSettings } from '@/components/settings/use-draft';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';

/*
 * Settings → Emails: what is true of every email Bridle sends for you. The
 * closing note and the new-conversation notifications stay hidden until
 * something reads them (#104). Switches save as you flip them; typing waits
 * for the floating Save.
 */
export function EmailsSettings() {
	const { values, edit, choose } = useSiteSettings();
	const [ error, run ] = useInstant();

	if ( ! values ) {
		return (
			<p className="text-sm text-muted-foreground">
				{ __( 'Loading…', 'bridle' ) }
			</p>
		);
	}

	const credit = __( 'Add “Powered by Bridle”', 'bridle' );

	return (
		<SettingsPanel title={ __( 'Emails', 'bridle' ) }>
			<SettingsSection>
				<div className="grid gap-5 sm:grid-cols-2">
					<Field
						label={ __( 'Business name', 'bridle' ) }
						help={ __(
							'Used in the emails Bridle sends for you.',
							'bridle'
						) }
						htmlFor="business-name"
					>
						<Input
							id="business-name"
							value={ values.business_name ?? '' }
							onChange={ edit( 'business_name' ) }
						/>
					</Field>
					<Field
						label={ __( 'BCC every reply to', 'bridle' ) }
						help={ __(
							'For an archive or a CRM. Empty for none.',
							'bridle'
						) }
						htmlFor="bcc"
					>
						<Input
							id="bcc"
							type="email"
							placeholder="archive@example.com"
							value={ values.auto_bcc_email ?? '' }
							onChange={ edit( 'auto_bcc_email' ) }
						/>
					</Field>
				</div>
			</SettingsSection>
			<SettingsSection>
				<Row
					label={ credit }
					help={ __(
						'A small grey line under the emails Bridle sends, linking to bridle.to, so customers can find Bridle. Off unless you turn it on.',
						'bridle'
					) }
				>
					<Switch
						aria-label={ credit }
						checked={ !! values.email_credit_enabled }
						onCheckedChange={ ( on ) =>
							run( () => choose( 'email_credit_enabled', !! on ) )
						}
					/>
				</Row>
				<InlineError>{ error }</InlineError>
			</SettingsSection>
		</SettingsPanel>
	);
}
