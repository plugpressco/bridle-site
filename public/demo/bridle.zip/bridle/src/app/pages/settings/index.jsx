import { useEffect, useState } from 'react';
import { __ } from '@wordpress/i18n';

import { ConnectInboxDialog } from '@/components/settings/connect-inbox-dialog';
import {
	settingsPages,
	SettingsFrame,
} from '@/components/settings/settings-frame';
import { Page } from '@/components/shell/page';
import { useShell } from '@/components/shell/shell-context';
import { extend } from '@/lib/extend';
import { kit } from '@/lib/kit';
import { navigate } from '@/lib/router';
import { AiAppsSettings } from './ai-apps';
import { ChatSettings } from './chat';
import { DataSettings } from './data';
import { EmailsSettings } from './emails';
import { InboxesSettings } from './inboxes';
import { KnowledgeSettings } from './knowledge';
import { ProSettings } from './pro';
import { RepliesSettings } from './replies';
import { SortingSettings } from './sorting';
import { TeamSettings } from './team';

/*
 * Settings (2026-11-02, #106): one panel with a menu of pages inside it and
 * the open page beside it, Mailpuff's layout in Bridle's look. Unsaved typing
 * lives in SettingsStore above, so moving between pages loses nothing.
 */
export function SettingsPage( { section, inboxId } ) {
	const { route, refreshInboxes } = useShell();
	const [ connectOpen, setConnectOpen ] = useState( false );
	const current = settingsPages().some( ( page ) => page.key === section )
		? section
		: 'inboxes';

	// Other places that offer "Connect an inbox" arrive as `?connect=1`.
	useEffect( () => {
		if ( route.query.connect ) {
			setConnectOpen( true );
			navigate( route.path, { connect: null }, { replace: true } );
		}
	}, [ route.query.connect, route.path ] );

	const connect = () => setConnectOpen( true );
	const content = {
		inboxes: <InboxesSettings inboxId={ inboxId } onConnect={ connect } />,
		replies: <RepliesSettings />,
		knowledge: <KnowledgeSettings />,
		chat: <ChatSettings />,
		sorting: <SortingSettings />,
		'ai-apps': <AiAppsSettings />,
		team: <TeamSettings />,
		emails: <EmailsSettings />,
		data: <DataSettings />,
		pro: <ProSettings />,
	}[ current ];
	// A page an add-on adds or takes over (bridle.settingsScreens: key → component).
	const Added = ( extend( 'settingsScreens', {} ) || {} )[ current ];

	return (
		<Page width="list" title={ __( 'Settings', 'bridle' ) }>
			<SettingsFrame current={ current }>
				{ Added ? <Added ui={ kit } /> : content }
			</SettingsFrame>
			<ConnectInboxDialog
				open={ connectOpen }
				onOpenChange={ setConnectOpen }
				onCreated={ () => refreshInboxes() }
			/>
		</Page>
	);
}
