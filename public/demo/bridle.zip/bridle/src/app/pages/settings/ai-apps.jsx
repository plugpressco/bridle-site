import { __ } from '@wordpress/i18n';

import { ConnectAgent } from '@/components/settings/connect-agent';
import { SettingsPanel } from '@/components/settings/settings-frame';
import { useAiStatus } from '@/components/settings/use-ai-status';

/* Settings → AI apps: Claude, ChatGPT, Codex or any MCP app in the inbox. */
export function AiAppsSettings() {
	const [ status, setStatus ] = useAiStatus();

	return (
		<SettingsPanel title={ __( 'AI apps', 'bridle' ) }>
			<ConnectAgent status={ status } setStatus={ setStatus } />
		</SettingsPanel>
	);
}
