import { __ } from '@wordpress/i18n';

import {
	AGENT_MODE_HELP,
	AgentModeControl,
} from '@/components/settings/agent-mode';
import { AiSource } from '@/components/settings/bridle-ai';
import { Field } from '@/components/settings/field';
import { GuideLink } from '@/components/settings/guide-link';
import { ModelPicker } from '@/components/settings/model-picker';
import {
	SettingsPanel,
	SettingsSection,
} from '@/components/settings/settings-frame';
import { useAiStatus } from '@/components/settings/use-ai-status';
import { useSiteSettings } from '@/components/settings/use-draft';
import { InboxDot } from '@/components/shell/inbox-scope';
import { useShell } from '@/components/shell/shell-context';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

// The numbers worth a glance; the rest of GET /ai/status `stats` stays in the API.
const STAT_LABELS = [
	[ 'drafted', __( 'Drafted', 'bridle' ) ],
	[ 'sent_unedited', __( 'Sent as written', 'bridle' ) ],
	[ 'sent_edited', __( 'Sent after edits', 'bridle' ) ],
	[ 'sent_by_agent', __( 'Sent by the agent', 'bridle' ) ],
];

/* Settings → Replies: how much the agent does, how it writes, how it has done. */
export function RepliesSettings() {
	const { inboxes } = useShell();
	const { values, edit } = useSiteSettings();
	const [ status ] = useAiStatus();

	const stats = status?.stats || {};
	const worked = STAT_LABELS.some(
		( [ key ] ) => Number( stats[ key ] ) > 0
	);

	return (
		<SettingsPanel title={ __( 'Replies', 'bridle' ) }>
			<SettingsSection
				title={ __( 'AI', 'bridle' ) }
				help={ __(
					'The agent writes with your own AI key when one is connected in WordPress. Without one, Bridle AI can answer instead.',
					'bridle'
				) }
			>
				{ status && (
					<AiSource
						canUseAi={ status.can_use_ai }
						wpVersionOk={ status.wp_version_ok }
					/>
				) }
				{ status?.ai_source === 'own' && (
					<ModelPicker values={ values } edit={ edit } />
				) }
			</SettingsSection>

			<SettingsSection
				title={ __( 'Agent mode', 'bridle' ) }
				help={ AGENT_MODE_HELP }
			>
				<ul className="divide-y divide-dashed divide-border">
					{ inboxes.map( ( inbox ) => (
						<li
							key={ inbox.id }
							className="flex items-center justify-between gap-4 py-2.5 first:pt-0 last:pb-0"
						>
							<div className="flex min-w-0 items-center gap-2.5 text-sm">
								<InboxDot inbox={ inbox } />
								<span className="truncate font-medium">
									{ inbox.display_name }
								</span>
								<span className="hidden truncate font-mono text-xs text-muted-foreground sm:inline">
									{ inbox.forwarding_address ||
										inbox.email_address }
								</span>
							</div>
							<AgentModeControl
								inboxId={ inbox.id }
								label={ inbox.display_name }
							/>
						</li>
					) ) }
				</ul>
			</SettingsSection>

			<SettingsSection>
				<div className="grid gap-5 sm:grid-cols-2">
					<Field
						label={ __( 'Name on its replies', 'bridle' ) }
						help={ __(
							'Goes in your signature when the agent sends. Empty uses your business name.',
							'bridle'
						) }
						htmlFor="agent-name"
					>
						<Input
							id="agent-name"
							value={ values?.agent_name ?? '' }
							placeholder={ values?.business_name || '' }
							onChange={ edit( 'agent_name' ) }
							disabled={ ! values }
						/>
					</Field>
					<Field
						label={ __( 'Instructions', 'bridle' ) }
						help={ __(
							'Tone, products, policies, what to never promise. Every draft is grounded in this, your snippets and your knowledge.',
							'bridle'
						) }
						htmlFor="agent-instructions"
						className="sm:col-span-2"
					>
						<Textarea
							id="agent-instructions"
							value={ values?.agent_instructions ?? '' }
							onChange={ edit( 'agent_instructions' ) }
							rows={ 8 }
							className="min-h-40"
							disabled={ ! values }
							placeholder={ __(
								'You support customers of … Be warm and direct. Refunds within 30 days are always fine. Never promise a release date.',
								'bridle'
							) }
						/>
					</Field>
				</div>
			</SettingsSection>

			{ worked && (
				<SettingsSection title={ __( 'Track record', 'bridle' ) }>
					<dl className="grid grid-cols-2 gap-3 sm:grid-cols-4">
						{ STAT_LABELS.map( ( [ key, label ] ) => (
							<div
								key={ key }
								className="rounded-lg bg-muted px-4 py-3"
							>
								<dd className="text-xl font-semibold tabular-nums tracking-tight">
									{ Number( stats[ key ] ) || 0 }
								</dd>
								<dt className="text-xs text-muted-foreground">
									{ label }
								</dt>
							</div>
						) ) }
					</dl>
				</SettingsSection>
			) }
			<GuideLink topic="workflows" screen="settings-replies" />
		</SettingsPanel>
	);
}
