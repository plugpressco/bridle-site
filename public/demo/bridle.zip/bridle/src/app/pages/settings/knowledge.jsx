import { __ } from '@wordpress/i18n';

import { KnowledgeSources } from '@/components/settings/knowledge-sources';
import { GuideLink } from '@/components/settings/guide-link';
import {
	SettingsPanel,
	SettingsSection,
} from '@/components/settings/settings-frame';
import { Snippets } from '@/components/settings/snippets';
import { useAiStatus } from '@/components/settings/use-ai-status';

/* Settings → Knowledge: what the agent reads, and the answers it may quote. */
export function KnowledgeSettings() {
	const [ status ] = useAiStatus();

	return (
		<SettingsPanel title={ __( 'Knowledge', 'bridle' ) }>
			<SettingsSection
				title={ __( 'Sources', 'bridle' ) }
				help={ __(
					'What the agent reads for every message. Each quote and link in a draft is checked against it.',
					'bridle'
				) }
			>
				<KnowledgeSources status={ status?.knowledge } />
			</SettingsSection>
			<SettingsSection
				title={ __( 'Snippets', 'bridle' ) }
				help={ __(
					'Answers the agent may quote and you can insert into a reply.',
					'bridle'
				) }
			>
				<Snippets />
			</SettingsSection>
			<GuideLink topic="knowledge-gaps" screen="settings-knowledge" />
		</SettingsPanel>
	);
}
