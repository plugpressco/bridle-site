import { __ } from '@wordpress/i18n';
import { ExternalLink, Globe, Hand, Package, SearchCheck } from 'lucide-react';

import {
	SettingsPanel,
	SettingsSection,
} from '@/components/settings/settings-frame';
import { Button } from '@/components/ui/button';

const PRO_URL =
	'https://bridle.to/pro/?utm_source=plugin&utm_medium=settings&utm_campaign=pro';

const FEATURES = [
	{
		icon: Globe,
		title: __( 'Chat on your other sites', 'bridle' ),
		text: __( 'One line of code, every chat in this Inbox.', 'bridle' ),
	},
	{
		icon: Hand,
		title: __( 'Take over a chat', 'bridle' ),
		text: __( 'Answer visitors live while you’re online.', 'bridle' ),
	},
	{
		icon: Package,
		title: __( 'Order lookups', 'bridle' ),
		text: __(
			'WooCommerce orders and licences, in email and chat.',
			'bridle'
		),
	},
	{
		icon: SearchCheck,
		title: __( 'Knowledge gaps', 'bridle' ),
		text: __( 'What it couldn’t answer, with Write a doc.', 'bridle' ),
	},
];

/*
 * Settings → Bridle Pro (#118): what Pro adds, and where to get it. One of
 * Pro's three quiet places (with the Plugins row link and the readme); no
 * notices, badges or locked buttons anywhere else. With Pro active, Pro's
 * licence screen replaces this page.
 */
export function ProSettings() {
	return (
		<SettingsPanel title={ __( 'Bridle Pro', 'bridle' ) }>
			<SettingsSection>
				<ul className="grid gap-3 sm:grid-cols-2">
					{ FEATURES.map( ( { icon: Icon, title, text } ) => (
						<li
							key={ title }
							className="flex gap-3 rounded-xl border border-border/80 p-4"
						>
							<span className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-brand-soft text-brand-ink">
								<Icon aria-hidden="true" className="size-4" />
							</span>
							<span className="grid gap-0.5">
								<span className="text-sm font-semibold">
									{ title }
								</span>
								<span className="text-sm text-muted-foreground">
									{ text }
								</span>
							</span>
						</li>
					) ) }
				</ul>
				<div className="mt-5 flex flex-wrap items-center gap-3">
					<Button asChild>
						<a href={ PRO_URL } target="_blank" rel="noreferrer">
							{ __( 'Get Bridle Pro', 'bridle' ) }
							<ExternalLink
								aria-hidden="true"
								className="size-3.5"
							/>
						</a>
					</Button>
					<span className="text-sm text-muted-foreground">
						{ __(
							'Pay once. Everything here stays free.',
							'bridle'
						) }
					</span>
				</div>
			</SettingsSection>
		</SettingsPanel>
	);
}
