import { __ } from '@wordpress/i18n';

import {
	SettingsPanel,
	SettingsSection,
} from '@/components/settings/settings-frame';
import { Sorting } from '@/components/settings/sorting';

/* Settings → Sorting: the decision model that reads each email on arrival. */
export function SortingSettings() {
	return (
		<SettingsPanel title={ __( 'Sorting', 'bridle' ) }>
			<SettingsSection
				title={ __( 'Decision model', 'bridle' ) }
				help={ __(
					'Bridle files mail by its headers. Add a decision model on your own key and it reads each email too: pitches and spam from ordinary addresses stay out of the Inbox, and the agent holds back when a person should answer.',
					'bridle'
				) }
			>
				<Sorting />
			</SettingsSection>
		</SettingsPanel>
	);
}
