import { useEffect, useState } from 'react';
import { __ } from '@wordpress/i18n';
import { UserMinus, UserPlus } from 'lucide-react';

import { ContactAvatar } from '@/components/list/contact-avatar';
import { InlineError, Row } from '@/components/settings/field';
import { useInstant, useSiteSettings } from '@/components/settings/use-draft';
import {
	SettingsPanel,
	SettingsSection,
} from '@/components/settings/settings-frame';
import { useShell } from '@/components/shell/shell-context';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { teammates as teammatesApi, users as usersApi } from '@/lib/api';

function Person( { person, children } ) {
	return (
		<li className="flex items-center gap-3 py-2.5">
			<ContactAvatar
				name={ person.display_name }
				email={ person.email }
				src={ person.avatar_url }
				className="size-9"
			/>
			<div className="min-w-0 flex-1">
				<div className="truncate text-sm font-medium">
					{ person.display_name }
				</div>
				<div className="truncate text-xs text-muted-foreground">
					{ person.email }
				</div>
			</div>
			{ children }
		</li>
	);
}

/*
 * Settings → Team: who works conversations and how they are handed out.
 * "Teammates can assign" and "Email people when assigned" stay hidden until
 * something reads them (#104).
 */
export function TeamSettings() {
	const { refreshTeammates } = useShell();
	const [ team, setTeam ] = useState( null );
	const [ users, setUsers ] = useState( null );
	const [ busy, setBusy ] = useState( null );
	const [ error, setError ] = useState( null );
	const { values, choose } = useSiteSettings();
	const [ toggleError, run ] = useInstant();

	const load = () => {
		teammatesApi
			.list()
			.then( ( rows ) => setTeam( Array.isArray( rows ) ? rows : [] ) )
			.catch( () => setTeam( [] ) );
		usersApi
			.list()
			.then( ( rows ) => setUsers( Array.isArray( rows ) ? rows : [] ) )
			.catch( () => setUsers( [] ) );
	};
	useEffect( load, [] );

	const change = ( action, failed ) => async ( person ) => {
		setBusy( person.id );
		setError( null );
		try {
			await action( person.id );
			load();
			refreshTeammates().catch( () => {} );
		} catch {
			setError( failed );
		} finally {
			setBusy( null );
		}
	};
	const add = change(
		teammatesApi.add,
		__( 'Couldn’t add them. Try again.', 'bridle' )
	);
	const remove = change(
		teammatesApi.remove,
		__( 'Couldn’t remove them. Try again.', 'bridle' )
	);

	// Each switch is one yes/no, so it saves as you flip it.
	const toggle = ( key ) => ( value ) => run( () => choose( key, !! value ) );

	const candidates = ( users || [] ).filter( ( u ) => ! u.is_teammate );

	return (
		<SettingsPanel title={ __( 'Team', 'bridle' ) }>
			<SettingsSection
				title={ __( 'Teammates', 'bridle' ) }
				help={ __(
					'Teammates can read and reply in every inbox. Administrators always can.',
					'bridle'
				) }
			>
				{ team === null && (
					<p className="text-sm text-muted-foreground">
						{ __( 'Loading…', 'bridle' ) }
					</p>
				) }
				<InlineError>{ error }</InlineError>
				<ul className="-my-2.5 divide-y divide-border/60">
					{ ( team || [] ).map( ( member ) => (
						<Person key={ member.id } person={ member }>
							{ ! users?.find( ( u ) => u.id === member.id )
								?.is_admin && (
								<Button
									size="sm"
									variant="ghost"
									disabled={ busy === member.id }
									onClick={ () => remove( member ) }
								>
									<UserMinus />
									{ __( 'Remove', 'bridle' ) }
								</Button>
							) }
						</Person>
					) ) }
				</ul>
			</SettingsSection>

			{ candidates.length > 0 && (
				<SettingsSection
					title={ __( 'Add from this site', 'bridle' ) }
					help={ __( 'They get the support-agent role.', 'bridle' ) }
				>
					<ul className="-my-2.5 divide-y divide-border/60">
						{ candidates.map( ( user ) => (
							<Person key={ user.id } person={ user }>
								<Button
									size="sm"
									variant="ghost"
									disabled={ busy === user.id }
									onClick={ () => add( user ) }
								>
									<UserPlus />
									{ __( 'Add', 'bridle' ) }
								</Button>
							</Person>
						) ) }
					</ul>
				</SettingsSection>
			) }

			{ ( team || [] ).length > 1 && (
				<SettingsSection>
					<Row
						label={ __(
							'Assign to whoever replies first',
							'bridle'
						) }
						help={ __(
							'Whoever answers a conversation owns it.',
							'bridle'
						) }
					>
						<Switch
							aria-label={ __(
								'Assign to whoever replies first',
								'bridle'
							) }
							disabled={ ! values }
							checked={ !! values?.auto_assign_on_reply }
							onCheckedChange={ toggle( 'auto_assign_on_reply' ) }
						/>
					</Row>
					<InlineError>{ toggleError }</InlineError>
				</SettingsSection>
			) }
		</SettingsPanel>
	);
}
