import { useState } from 'react';
import { __, _n, sprintf } from '@wordpress/i18n';

import { Field, InlineError, Row } from '@/components/settings/field';
import {
	SettingsPanel,
	SettingsSection,
} from '@/components/settings/settings-frame';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { workspace } from '@/lib/api';
import { appData } from '@/lib/app-data';

/* Erase all data: one button, then a typed DELETE before anything happens. */
function EraseAll() {
	const [ open, setOpen ] = useState( false );
	const [ confirm, setConfirm ] = useState( '' );
	const [ busy, setBusy ] = useState( false );
	const [ error, setError ] = useState( null );

	const erase = async () => {
		setBusy( true );
		setError( null );
		try {
			await workspace.eraseAllData();
			window.location.reload();
		} catch {
			setError( __( 'Couldn’t erase the data. Try again.', 'bridle' ) );
		} finally {
			setBusy( false );
		}
	};

	return (
		<div className="space-y-4">
			<Row
				label={ __( 'Erase all data', 'bridle' ) }
				help={ __(
					'Deletes every inbox, conversation, contact, snippet and setting, then starts Bridle again at setup. Forwarding stops. Files in the Media Library and Bridle KB stay. There is no undo.',
					'bridle'
				) }
			>
				{ ! open && (
					<Button
						size="sm"
						variant="outline"
						className="text-destructive hover:text-destructive"
						onClick={ () => setOpen( true ) }
					>
						{ __( 'Erase…', 'bridle' ) }
					</Button>
				) }
			</Row>
			{ open && (
				<div className="space-y-3 rounded-lg border border-destructive/40 p-4">
					<Field
						label={ __( 'Type DELETE to confirm', 'bridle' ) }
						htmlFor="erase-confirm"
					>
						<Input
							id="erase-confirm"
							value={ confirm }
							onChange={ ( event ) =>
								setConfirm( event.target.value )
							}
							className="max-w-xs"
							autoComplete="off"
						/>
					</Field>
					<div className="flex items-center gap-2">
						<Button
							size="sm"
							variant="destructive"
							disabled={ confirm !== 'DELETE' || busy }
							onClick={ erase }
						>
							{ busy
								? __( 'Erasing…', 'bridle' )
								: __( 'Erase everything', 'bridle' ) }
						</Button>
						<Button
							size="sm"
							variant="ghost"
							onClick={ () => {
								setOpen( false );
								setConfirm( '' );
							} }
						>
							{ __( 'Cancel', 'bridle' ) }
						</Button>
					</div>
					<InlineError>{ error }</InlineError>
				</div>
			) }
		</div>
	);
}

/* Settings → Data: how long Trash keeps things, and erasing everything. */
export function DataSettings() {
	return (
		<SettingsPanel title={ __( 'Data', 'bridle' ) }>
			{ appData.trashDays > 0 && (
				<SettingsSection>
					<Row label={ __( 'Trash', 'bridle' ) }>
						<span className="text-sm text-muted-foreground">
							{ sprintf(
								/* translators: %d: days before Trash deletes a conversation */
								_n(
									'Deleted for good after %d day',
									'Deleted for good after %d days',
									appData.trashDays,
									'bridle'
								),
								appData.trashDays
							) }
						</span>
					</Row>
				</SettingsSection>
			) }
			<SettingsSection>
				<EraseAll />
			</SettingsSection>
		</SettingsPanel>
	);
}
