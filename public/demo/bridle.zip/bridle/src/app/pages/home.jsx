import { useEffect, useState } from 'react';
import { __, _n, sprintf } from '@wordpress/i18n';
import { Inbox, Mail, PlugZap, Sparkles } from 'lucide-react';
import { cn } from 'cn';

import { ContactAvatar } from '@/components/list/contact-avatar';
import { ReviewChip } from '@/components/list/conversation-row';
import { HomeCard } from '@/components/shell/home-card';
import { Page } from '@/components/shell/page';
import { useShell } from '@/components/shell/shell-context';
import { Button } from '@/components/ui/button';
import { conversations, home as homeApi } from '@/lib/api';
import { appData } from '@/lib/app-data';
import { contactName, groupForReview } from '@/lib/conversation';
import { extend } from '@/lib/extend';
import { kit } from '@/lib/kit';
import { Link, navigate } from '@/lib/router';
import { relativeTime } from '@/lib/time';

function greeting() {
	const hour = new Date().getHours();
	const first = String( appData.user?.name || '' ).split( /\s+/ )[ 0 ];
	let text = __( 'Good evening', 'bridle' );
	if ( hour < 12 ) {
		text = __( 'Good morning', 'bridle' );
	} else if ( hour < 18 ) {
		text = __( 'Good afternoon', 'bridle' );
	}
	/* translators: 1: good morning/afternoon/evening, 2: the person's first name */
	return first ? sprintf( __( '%1$s, %2$s', 'bridle' ), text, first ) : text;
}

function duration( minutes ) {
	if ( minutes === null || minutes === undefined ) {
		return '—';
	}
	if ( minutes <= 0 ) {
		/* translators: %d: minutes */
		return sprintf( __( '%d min', 'bridle' ), 0 );
	}
	if ( minutes < 60 ) {
		return sprintf(
			/* translators: %d: minutes */
			__( '%d min', 'bridle' ),
			Math.max( 1, Math.round( minutes ) )
		);
	}
	if ( minutes < 48 * 60 ) {
		return sprintf(
			/* translators: %s: hours, one decimal */
			__( '%s h', 'bridle' ),
			( minutes / 60 ).toFixed( minutes < 600 ? 1 : 0 )
		);
	}
	/* translators: %d: days */
	return sprintf( __( '%d d', 'bridle' ), Math.round( minutes / 1440 ) );
}

const MODEL_NAMES = {
	'@cf/cloudflare/clef': 'Clef',
	'@cf/cloudflare/clef-flash': 'Clef flash',
	'typesafe/jev': 'Jev',
	'jev-latest': 'Jev',
};

/*
 * Next up: the one most useful thing, in this order: set up what's missing,
 * then drafts ready to send, then mail that needs you, else caught up.
 */
function nextUp( { inboxes, health, ready, rest } ) {
	if ( ! inboxes.length ) {
		return {
			icon: Mail,
			title: __( 'Connect your support inbox', 'bridle' ),
			text: __(
				'Forward it to Bridle and every email lands here.',
				'bridle'
			),
			action: __( 'Connect an inbox', 'bridle' ),
			go: () => navigate( '/settings/inboxes', { connect: 1 } ),
		};
	}
	if ( health && ! health.forwarding.arriving ) {
		return {
			icon: Mail,
			title: __( 'Forward your support address', 'bridle' ),
			text: __( 'No mail has arrived yet.', 'bridle' ),
			action: __( 'Show me how', 'bridle' ),
			go: () => navigate( '/settings/inboxes' ),
		};
	}
	if ( health && ! health.ai.ready ) {
		return {
			icon: PlugZap,
			title: __( 'Choose how the agent writes', 'bridle' ),
			text: __( 'Your own AI key, or Bridle AI with no key.', 'bridle' ),
			action: __( 'Choose', 'bridle' ),
			go: () => navigate( '/settings/replies' ),
		};
	}
	const left = health?.ai.bridle;
	if ( left && left.free_left + left.credits <= 0 ) {
		return {
			icon: PlugZap,
			title: __( 'Bridle AI is out of answers', 'bridle' ),
			text: __(
				'Drafts and chat answers pause until you add more.',
				'bridle'
			),
			action: __( 'Add answers', 'bridle' ),
			go: () => navigate( '/settings/replies' ),
		};
	}
	if ( ready.length ) {
		return {
			icon: Sparkles,
			title: sprintf(
				/* translators: %d: drafts ready to send */
				_n(
					'%d reply is ready to send',
					'%d replies are ready to send',
					ready.length,
					'bridle'
				),
				ready.length
			),
			text: __(
				'Each answers the newest message, and every fact checked out.',
				'bridle'
			),
			action: __( 'Review them', 'bridle' ),
			go: () => navigate( '/inbox' ),
			faces: ready.slice( 0, 4 ),
		};
	}
	if ( rest.length ) {
		return {
			icon: Inbox,
			title: sprintf(
				/* translators: %d: conversations waiting for a person */
				_n(
					'%d conversation needs you',
					'%d conversations need you',
					rest.length,
					'bridle'
				),
				rest.length
			),
			text: '',
			action: __( 'Open Inbox', 'bridle' ),
			go: () => navigate( '/inbox' ),
		};
	}
	return {
		icon: Sparkles,
		title: __( 'You’re caught up.', 'bridle' ),
		text: __(
			'New mail lands in the Inbox the moment it arrives.',
			'bridle'
		),
	};
}

function NextUp( props ) {
	const next = nextUp( props );
	const Icon = next.icon;
	return (
		<div className="surface grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-4 px-5 py-4 max-sm:grid-cols-[auto_minmax(0,1fr)]">
			<span className="flex size-10 items-center justify-center rounded-xl bg-brand-soft text-brand-ink">
				<Icon className="size-5" />
			</span>
			<div className="min-w-0">
				<h2 className="text-[15px] font-semibold">{ next.title }</h2>
				{ next.text && (
					<p className="text-sm text-muted-foreground">
						{ next.text }
					</p>
				) }
				{ next.faces && (
					<div className="mt-2 flex -space-x-2">
						{ next.faces.map( ( row ) => (
							<ContactAvatar
								key={ row.id }
								name={ contactName( row ) }
								email={ row.customer_email }
								src={ row.customer_avatar }
								className="size-7 ring-2 ring-card"
							/>
						) ) }
					</div>
				) }
			</div>
			{ next.action && (
				<div className="max-sm:col-span-2">
					{ next.href ? (
						<Button asChild>
							<a href={ next.href }>{ next.action }</a>
						</Button>
					) : (
						<Button onClick={ next.go }>{ next.action }</Button>
					) }
				</div>
			) }
		</div>
	);
}

function Tile( { label, value, note, good } ) {
	return (
		<div className="surface grid content-start gap-1 px-4 py-3.5">
			<span className="text-xs text-muted-foreground">{ label }</span>
			<span className="text-2xl font-semibold tracking-tight tabular-nums">
				{ value }
			</span>
			<span
				className={ cn(
					'text-xs',
					good ? 'text-[#1f7a4d]' : 'text-muted-foreground'
				) }
			>
				{ note }
			</span>
		</div>
	);
}

function Tiles( { week } ) {
	const change = week?.change;
	let changeNote = sprintf(
		/* translators: %d: replies sent the week before */
		__( '%d last week', 'bridle' ),
		week?.answered_before || 0
	);
	if ( change !== null && change !== undefined ) {
		changeNote = sprintf(
			/* translators: %s: signed percent, like +12% */
			__( '%s on last week', 'bridle' ),
			( change > 0 ? '+' : '' ) + change + '%'
		);
	}
	return (
		<div className="grid grid-cols-4 gap-3 max-md:grid-cols-2">
			<Tile
				label={ __( 'Answered this week', 'bridle' ) }
				value={ week ? week.answered : '—' }
				note={ changeNote }
				good={ change > 0 }
			/>
			<Tile
				label={ __( 'Sent as written', 'bridle' ) }
				value={
					week?.as_written === null || week?.as_written === undefined
						? '—'
						: week.as_written + '%'
				}
				note={ __( 'of the agent’s drafts', 'bridle' ) }
			/>
			<Tile
				label={ __( 'First reply', 'bridle' ) }
				value={ duration( week?.first_reply_minutes ) }
				note={ __( 'median, last 30 days', 'bridle' ) }
			/>
			<Tile
				label={ __( 'Time back', 'bridle' ) }
				value={ week ? duration( week.time_back_minutes || 0 ) : '—' }
				note={ __( '5 min a reply you didn’t write', 'bridle' ) }
				good={ week?.time_back_minutes > 0 }
			/>
		</div>
	);
}

function NeedsYou( { rows, loading } ) {
	return (
		<HomeCard
			title={ __( 'Needs you', 'bridle' ) }
			action={
				<Link
					to="/inbox"
					className="text-xs text-brand-ink hover:underline"
				>
					{ __( 'Open Inbox', 'bridle' ) }
				</Link>
			}
		>
			{ ! loading && ! rows.length && (
				<p className="px-4 pt-1 pb-4 text-sm text-muted-foreground">
					{ __( 'Nothing needs you right now.', 'bridle' ) }
				</p>
			) }
			<ul className="divide-y divide-border/60">
				{ rows.slice( 0, 4 ).map( ( row ) => (
					<li key={ row.id }>
						<Link
							to={ `/c/${ row.id }` }
							className="flex items-center gap-3 px-4 py-2.5 outline-none hover:bg-accent/70 focus-visible:bg-accent"
						>
							<ContactAvatar
								name={ contactName( row ) }
								email={ row.customer_email }
								src={ row.customer_avatar }
								className="size-7"
							/>
							<span className="min-w-0 flex-1 truncate text-sm">
								<b className="font-medium">
									{ contactName( row ) }
								</b>{ ' ' }
								<span className="text-muted-foreground">
									{ row.subject ||
										__( '(no subject)', 'bridle' ) }
								</span>
							</span>
							{ row.agent_review && (
								<ReviewChip conversation={ row } />
							) }
						</Link>
					</li>
				) ) }
			</ul>
		</HomeCard>
	);
}

function HealthRow( { state, label, children } ) {
	return (
		<li className="flex items-center gap-2.5 px-4 py-2 text-[13px]">
			<span
				aria-hidden="true"
				className={ cn(
					'size-2 shrink-0 rounded-full',
					state === 'ok' && 'bg-[#1f7a4d]',
					state === 'warn' && 'bg-amber',
					state === 'off' && 'bg-muted-foreground/40'
				) }
			/>
			<span className="w-24 shrink-0 font-medium">{ label }</span>
			<span className="min-w-0 flex-1 truncate text-muted-foreground">
				{ children }
			</span>
		</li>
	);
}

function knowledgeText( { kb, site, products, past } ) {
	const has = ( n ) => n !== null && n !== undefined;
	return [
		has( kb ) &&
			/* translators: %d: published help docs */
			sprintf( _n( '%d doc', '%d docs', kb, 'bridle' ), kb ),
		has( site ) &&
			/* translators: %d: published pages */
			sprintf( _n( '%d page', '%d pages', site, 'bridle' ), site ),
		has( products ) &&
			sprintf(
				/* translators: %d: published products */
				_n( '%d product', '%d products', products, 'bridle' ),
				products
			),
		has( past ) &&
			sprintf(
				/* translators: %d: resolved conversations the agent learns from */
				_n( '%d past reply', '%d past replies', past, 'bridle' ),
				past
			),
	]
		.filter( Boolean )
		.join( ' · ' );
}

function Health( { health } ) {
	if ( ! health ) {
		return <div className="surface min-h-40" />;
	}
	const { ai, forwarding, knowledge, sorting, modes } = health;
	const read = knowledgeText( knowledge );

	let fwdState = 'ok';
	let fwdText = forwarding.latest
		? sprintf(
				/* translators: %s: how long ago, like 4m */
				__( 'Mail arriving, last %s ago', 'bridle' ),
				relativeTime( forwarding.latest )
		  )
		: __( 'Mail arriving', 'bridle' );
	if ( ! forwarding.inboxes ) {
		fwdState = 'warn';
		fwdText = __( 'No inbox connected', 'bridle' );
	} else if ( forwarding.drifted ) {
		fwdState = 'warn';
		fwdText = __( 'Points at another site address', 'bridle' );
	} else if ( forwarding.arriving < forwarding.inboxes ) {
		fwdState = 'warn';
		fwdText = sprintf(
			/* translators: 1: inboxes receiving mail, 2: all inboxes */
			__( '%1$d of %2$d inboxes receiving mail', 'bridle' ),
			forwarding.arriving,
			forwarding.inboxes
		);
	}

	let agentState = 'off';
	let agentText = __( 'Off in every inbox', 'bridle' );
	if ( modes.auto ) {
		agentState = 'ok';
		agentText = sprintf(
			/* translators: %d: inboxes on Auto */
			_n(
				'Auto in %d inbox',
				'Auto in %d inboxes',
				modes.auto,
				'bridle'
			),
			modes.auto
		);
	} else if ( modes.draft ) {
		agentState = 'ok';
		agentText = sprintf(
			/* translators: %d: inboxes on Draft */
			_n(
				'Drafts in %d inbox',
				'Drafts in %d inboxes',
				modes.draft,
				'bridle'
			),
			modes.draft
		);
	}

	let sortState = 'off';
	let sortText = __( 'By headers only', 'bridle' );
	if ( sorting.on ) {
		sortState = sorting.ok ? 'ok' : 'warn';
		sortText = sorting.ok
			? sprintf(
					/* translators: %s: model name, like Clef */
					__( '%s reads every email', 'bridle' ),
					MODEL_NAMES[ sorting.model ] || sorting.model
			  )
			: __( 'The last email couldn’t be read', 'bridle' );
	}

	let aiText = __( 'Your own key', 'bridle' );
	if ( ai.source === 'bridle' && ai.bridle ) {
		aiText = sprintf(
			/* translators: 1: free answers left this month, 2: bought answers left */
			__( 'Bridle AI · %1$d free left · %2$d bought', 'bridle' ),
			ai.bridle.free_left,
			ai.bridle.credits
		);
	}
	if ( ! ai.ready ) {
		aiText = ai.wp_version_ok
			? __( 'Not connected', 'bridle' )
			: __( 'Needs WordPress 7.0', 'bridle' );
	}

	return (
		<HomeCard
			title={ __( 'Agent health', 'bridle' ) }
			action={
				<Link
					to="/settings"
					className="text-xs text-brand-ink hover:underline"
				>
					{ __( 'Settings', 'bridle' ) }
				</Link>
			}
		>
			<ul className="pb-2">
				<HealthRow
					state={
						ai.ready &&
						! (
							ai.bridle &&
							ai.bridle.free_left + ai.bridle.credits <= 0
						)
							? 'ok'
							: 'warn'
					}
					label={ __( 'AI provider', 'bridle' ) }
				>
					{ aiText }
				</HealthRow>
				<HealthRow
					state={ fwdState }
					label={ __( 'Forwarding', 'bridle' ) }
				>
					{ fwdText }
				</HealthRow>
				<HealthRow
					state={ read ? 'ok' : 'warn' }
					label={ __( 'Knowledge', 'bridle' ) }
				>
					{ read || __( 'Nothing to read yet', 'bridle' ) }
				</HealthRow>
				<HealthRow
					state={ sortState }
					label={ __( 'Sorting', 'bridle' ) }
				>
					{ sortText }
				</HealthRow>
				<HealthRow
					state={ agentState }
					label={ __( 'Agent', 'bridle' ) }
				>
					{ agentText }
				</HealthRow>
			</ul>
		</HomeCard>
	);
}

/*
 * Cards an add-on puts on Home, under the rest (`bridle.homeCards`): each
 * is { key, component }, drawn with the design kit as `ui`.
 */
function homeCards() {
	const cards = extend( 'homeCards', [] );
	return Array.isArray( cards )
		? cards.filter( ( card ) => card?.key && card?.component )
		: [];
}

/*
 * Home (#112): the first screen. One Next up action, this week's numbers,
 * the mail that needs you and the agent's health. The lists come from the
 * same GET /conversations the Inbox uses; GET /home adds the numbers.
 */
export function HomePage() {
	const { inboxes, inboxScope } = useShell();
	const [ summary, setSummary ] = useState( null );
	const [ rows, setRows ] = useState( null );

	useEffect( () => {
		let cancelled = false;
		homeApi
			.get()
			.then( ( data ) => ! cancelled && setSummary( data ) )
			.catch( () => ! cancelled && setSummary( {} ) );
		conversations
			.list( { box: 'needs_reply', inbox_id: inboxScope, page: 1 } )
			.then( ( data ) => ! cancelled && setRows( data?.items || [] ) )
			.catch( () => ! cancelled && setRows( [] ) );
		return () => {
			cancelled = true;
		};
	}, [ inboxScope ] );

	const groups = groupForReview( rows || [] );
	const date = new Date().toLocaleDateString( undefined, {
		weekday: 'long',
		day: 'numeric',
		month: 'long',
	} );

	return (
		<Page width="list" eyebrow={ date } title={ greeting() }>
			<div className="grid gap-4">
				<NextUp
					inboxes={ inboxes }
					health={ summary?.health }
					ready={ groups.ready }
					rest={ groups.rest }
				/>
				<Tiles week={ summary?.week } />
				<div className="grid grid-cols-[minmax(0,1.25fr)_minmax(0,1fr)] gap-4 max-md:grid-cols-1">
					<NeedsYou rows={ groups.rest } loading={ rows === null } />
					<Health health={ summary?.health } />
				</div>
				{ homeCards().map( ( { key, component: Card } ) => (
					<Card key={ key } ui={ kit } />
				) ) }
			</div>
		</Page>
	);
}
