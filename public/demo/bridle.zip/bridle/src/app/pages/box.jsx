import { useMemo, useState } from 'react';
import { __, _n, sprintf } from '@wordpress/i18n';
import {
	ArchiveRestore,
	Mail,
	MailOpen,
	RotateCcw,
	ShieldAlert,
	ShieldCheck,
	Trash,
	Trash2,
} from 'lucide-react';

import { BulkBar } from '@/components/list/bulk-bar';
import { ConversationList } from '@/components/list/conversation-list';
import { SelectHeader } from '@/components/list/select-header';
import { EmptyState, ListError } from '@/components/list/empty-state';
import { Page } from '@/components/shell/page';
import { useShell } from '@/components/shell/shell-context';
import { Button } from '@/components/ui/button';
import { conversations } from '@/lib/api';
import { appData } from '@/lib/app-data';
import { usePagedList } from '@/lib/use-paged-list';
import { bulkRead, useReadToggle } from '@/lib/use-read-toggle';
import {
	setStatusAll,
	useSelectAllMatching,
	useSelection,
} from '@/lib/use-selection';

// One-line titles, the same height on every box (#112). Trash keeps its
// one fact beside the title.
const TITLES = {
	resolved: [ __( 'Resolved', 'bridle' ) ],
	spam: [ __( 'Spam', 'bridle' ) ],
	trash: [
		__( 'Trash', 'bridle' ),
		appData.trashDays > 0
			? sprintf(
					/* translators: %d: days before Trash deletes a conversation */
					_n(
						'Deleted for good after %d day',
						'Deleted for good after %d days',
						appData.trashDays,
						'bridle'
					),
					appData.trashDays
			  )
			: '',
	],
};

// The REST `box` for each view: Resolved is stored as `closed`.
const REST_BOX = { resolved: 'closed' };

const EMPTY = {
	resolved: [
		__( 'Nothing resolved yet.', 'bridle' ),
		__( 'Conversations you resolve are kept here.', 'bridle' ),
	],
	spam: [
		__( 'No spam.', 'bridle' ),
		__(
			'Mail Bridle blocks lands here. Not spam? Move it back.',
			'bridle'
		),
	],
	trash: [ __( 'The trash is empty.', 'bridle' ) ],
};

/*
 * Empty trash, behind an inline confirm like Deactivate in Settings. The
 * route clears every inbox's trash, so a scoped view says so.
 */
function EmptyTrash( { scoped, onEmptied } ) {
	const [ confirming, setConfirming ] = useState( false );
	const [ busy, setBusy ] = useState( false );
	const [ error, setError ] = useState( null );

	const empty = async () => {
		setBusy( true );
		setError( null );
		try {
			await conversations.emptyTrash();
			setConfirming( false );
			onEmptied();
		} catch {
			setError( __( 'Couldn’t empty the trash. Try again.', 'bridle' ) );
		} finally {
			setBusy( false );
		}
	};

	if ( ! confirming ) {
		return (
			<Button
				variant="outline"
				size="sm"
				onClick={ () => setConfirming( true ) }
			>
				<Trash />
				{ __( 'Empty trash', 'bridle' ) }
			</Button>
		);
	}
	return (
		<div className="flex flex-wrap items-center justify-end gap-2">
			<span
				role={ error ? 'alert' : undefined }
				className={
					error
						? 'text-sm text-destructive'
						: 'text-sm text-muted-foreground'
				}
			>
				{ error ||
					( scoped
						? __(
								'This empties the trash of every inbox. There is no undo.',
								'bridle'
						  )
						: __(
								'Everything here is deleted. There is no undo.',
								'bridle'
						  ) ) }
			</span>
			<Button
				variant="destructive"
				size="sm"
				disabled={ busy }
				onClick={ empty }
			>
				{ busy
					? __( 'Emptying…', 'bridle' )
					: __( 'Yes, empty trash', 'bridle' ) }
			</Button>
			<Button
				variant="ghost"
				size="sm"
				onClick={ () => setConfirming( false ) }
			>
				{ __( 'Cancel', 'bridle' ) }
			</Button>
		</div>
	);
}

/*
 * The views that are one flat list: Resolved, Spam and Trash. The Inbox is
 * `pages/inbox.jsx` and Updates is `pages/updates.jsx`.
 */
export function BoxPage( { box } ) {
	const { inboxScope, refreshCounts } = useShell();
	const { selected, toggle, setMany, clear, drop } = useSelection();
	const [ busy, setBusy ] = useState( false );
	const [ bulkError, setBulkError ] = useState( null );

	const list = usePagedList(
		( page ) =>
			conversations.list( {
				box: REST_BOX[ box ] || box,
				inbox_id: inboxScope,
				page,
			} ),
		[ box, inboxScope ]
	);

	// One definition per action, for the bulk bar (every selected row) and
	// each row's quick actions (that row). Rows leave at once and come back
	// with a reload if the server says no.
	const apply = ( fn ) => async ( ids ) => {
		setBusy( true );
		setBulkError( null );
		// "Select all N" can reach past the loaded rows; then the list reloads
		// afterwards to fill the space.
		const loaded = new Set( list.items.map( ( row ) => Number( row.id ) ) );
		const beyond = ids.some( ( id ) => ! loaded.has( Number( id ) ) );
		list.remove( ids );
		drop( ids );
		try {
			await fn( ids );
			if ( beyond ) {
				list.reload();
			}
		} catch {
			// Some may have gone through: reload to show where things stand.
			setBulkError(
				__( 'Some conversations could not be updated.', 'bridle' )
			);
			list.reload();
		} finally {
			setBusy( false );
			refreshCounts();
		}
	};

	const defs = useMemo( () => {
		const reopen = {
			key: 'reopen',
			label: __( 'Reopen', 'bridle' ),
			icon: ArchiveRestore,
			fn: ( rows ) => setStatusAll( rows, 'active' ),
		};
		const spam = {
			key: 'spam',
			label: __( 'Spam', 'bridle' ),
			icon: ShieldAlert,
			fn: ( rows ) => setStatusAll( rows, 'spam' ),
			bulkOnly: true,
		};
		const notSpam = {
			key: 'not-spam',
			label: __( 'Not spam', 'bridle' ),
			icon: ShieldCheck,
			fn: ( rows ) => setStatusAll( rows, 'active' ),
		};
		const trash = {
			key: 'trash',
			label: __( 'Trash', 'bridle' ),
			icon: Trash,
			fn: conversations.bulkTrash,
		};
		const restore = {
			key: 'restore',
			label: __( 'Restore', 'bridle' ),
			icon: RotateCcw,
			fn: conversations.bulkRestore,
		};
		// Gmail's "Delete forever": only from Trash, only after a yes.
		const deleteForever = {
			key: 'delete-forever',
			label: __( 'Delete forever', 'bridle' ),
			icon: Trash2,
			fn: conversations.bulkDeleteForever,
			bulkOnly: true,
			confirm: true,
		};
		switch ( box ) {
			case 'spam':
				return [ notSpam, trash ];
			case 'trash':
				return [ restore, deleteForever ];
			default:
				return [ reopen, spam, trash ];
		}
	}, [ box ] );
	const failed = () =>
		setBulkError( __( 'Couldn’t save that. Try again.', 'bridle' ) );
	const read = bulkRead( [ list ], selected, failed );
	const actions = [
		...( read
			? [
					{
						key: 'read',
						label: read.markRead
							? __( 'Mark read', 'bridle' )
							: __( 'Mark unread', 'bridle' ),
						icon: read.markRead ? MailOpen : Mail,
						run: read.run,
					},
			  ]
			: [] ),
		...defs.map( ( def ) => ( {
			...def,
			run: () => apply( def.fn )( [ ...selected ] ),
			confirm: def.confirm
				? {
						prompt: sprintf(
							/* translators: %d: number of selected conversations */
							_n(
								'Delete %d conversation forever? There is no undo.',
								'Delete %d conversations forever? There is no undo.',
								selected.size,
								'bridle'
							),
							selected.size
						),
						label: __( 'Delete forever', 'bridle' ),
				  }
				: undefined,
		} ) ),
	];
	const [ selectAllMatching, matchingBusy ] = useSelectAllMatching(
		{ box: REST_BOX[ box ] || box, inbox_id: inboxScope },
		setMany,
		failed
	);
	const rowActions = defs
		.filter( ( def ) => ! def.bulkOnly )
		.map( ( def ) => ( {
			...def,
			run: ( id ) => apply( def.fn )( [ id ] ),
		} ) );

	const toggleRead = useReadToggle( [ list ], failed );

	const [ emptyTitle, emptyHint ] = EMPTY[ box ] || EMPTY.resolved;
	const [ title, note ] = TITLES[ box ] || TITLES.resolved;

	return (
		<Page
			scope
			width="list"
			title={ title }
			note={ note }
			actions={
				<div className="flex items-center gap-2">
					<SelectHeader
						lists={ [ list ] }
						selected={ selected }
						onSetMany={ setMany }
						total={ list.total }
						onAllMatching={ selectAllMatching }
						matchingBusy={ matchingBusy }
					/>
					{ box === 'trash' && list.items.length > 0 && (
						<EmptyTrash
							scoped={ !! inboxScope }
							onEmptied={ () => {
								clear();
								list.reload();
							} }
						/>
					) }
				</div>
			}
		>
			{ bulkError && <ListError message={ bulkError } /> }
			{ list.error && <ListError onRetry={ list.reload } /> }
			<ConversationList
				sections={ [ { key: box, list } ] }
				selected={ selected }
				onToggle={ toggle }
				rowActions={ rowActions }
				onToggleRead={ toggleRead }
				empty={
					list.error ? null : (
						<EmptyState title={ emptyTitle } hint={ emptyHint } />
					)
				}
			/>
			<BulkBar
				count={ selected.size }
				actions={ actions }
				onClear={ clear }
				busy={ busy }
			/>
		</Page>
	);
}
