import { useEffect, useMemo, useState } from 'react';
import { __ } from '@wordpress/i18n';
import { ArrowLeft, ChevronDown, Inbox, UserRound } from 'lucide-react';

import { ContactAvatar } from '@/components/list/contact-avatar';
import { DOCK_ITEMS } from '@/components/shell/dock';
import { InboxDot } from '@/components/shell/inbox-scope';
import { Page } from '@/components/shell/page';
import { useShell } from '@/components/shell/shell-context';
import { ActionPill } from '@/components/thread/action-pill';
import {
	AgentDraftCard,
	useAgentMode,
} from '@/components/thread/agent-draft-card';
import { Composer, preloadEditor } from '@/components/thread/composer';
import { ContactDrawer } from '@/components/thread/contact-drawer';
import { MergeDialog } from '@/components/thread/merge-dialog';
import { MessageCard } from '@/components/thread/message-card';
import { SendReceipt } from '@/components/thread/send-receipt';
import { AgentAvatar } from '@/components/ui/bridle-avatar';
import { Button } from '@/components/ui/button';
import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuRadioGroup,
	DropdownMenuRadioItem,
	DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Skeleton } from '@/components/ui/skeleton';
import { StateLabel } from '@/components/ui/state-label';
import {
	agentDrafts,
	ai,
	conversations,
	customers,
	postKeepalive,
	threads as threadsApi,
} from '@/lib/api';
import { appData } from '@/lib/app-data';
import { textOf } from '@/lib/body-split';
import { isExchange, needsReply, stateOf } from '@/lib/conversation';
import { extend } from '@/lib/extend';
import { Link, navigate } from '@/lib/router';
import { useShortcuts } from '@/lib/shortcuts';
import { parseUtc } from '@/lib/time';
import { useConversation } from '@/lib/use-conversation';
import { useDelayedSend } from '@/lib/use-delayed-send';

/*
 * Which messages start expanded (AGENTS.md §6.3): with fewer than three,
 * all of them; otherwise the newest, everything after our last reply, and
 * every note. Anything else collapses to a one-liner until clicked.
 */
export function expandedByDefault( threads ) {
	if ( threads.length < 3 ) {
		return new Set( threads.map( ( t ) => t.id ) );
	}
	let lastOurs = -1;
	threads.forEach( ( t, i ) => {
		if ( t.author_type !== 'customer' && t.thread_type !== 'note' ) {
			lastOurs = i;
		}
	} );
	return new Set(
		threads
			.filter(
				( t, i ) =>
					i === threads.length - 1 ||
					i > lastOurs ||
					t.thread_type === 'note'
			)
			.map( ( t ) => t.id )
	);
}

const isNotFound = ( error ) =>
	error?.data?.status === 404 || error?.code === 'bridle_not_found';

const STATUS_ERRORS = {
	closed: __( 'Couldn’t resolve. Try again.', 'bridle' ),
	spam: __( 'Couldn’t mark as spam. Try again.', 'bridle' ),
	trash: __( 'Couldn’t move to the trash. Try again.', 'bridle' ),
	active: __( 'Couldn’t reopen. Try again.', 'bridle' ),
};

export function ConversationPage( { id } ) {
	const { inboxes, teammates: team, lastList } = useShell();
	const [ moving, setMoving ] = useState( false );
	const {
		data: conversation,
		loading,
		error,
		refresh,
		patch,
	} = useConversation( id );
	const [ mode, setMode ] = useState( null ); // null = composer collapsed
	const [ seedHtml, setSeedHtml ] = useState( '' );
	// What "Undo rewrite" puts back when seedHtml is a rewritten draft (#130).
	const [ seedUndo, setSeedUndo ] = useState( '' );
	const [ rewriting, setRewriting ] = useState( false );
	const [ drawer, setDrawer ] = useState( false );
	const [ mergeOpen, setMergeOpen ] = useState( false );
	const [ opened, setOpened ] = useState( () => new Set() );
	const [ pendingThreads, setPendingThreads ] = useState( [] );
	const { pending, schedule, undo, retry } = useDelayedSend( 8000 );
	const [ draft, setDraft ] = useState( null );
	const [ draftBusy, setDraftBusy ] = useState( false );
	const [ actionError, setActionError ] = useState( null );
	const agentMode = useAgentMode( conversation?.inbox_id );

	useEffect( () => {
		let cancelled = false;
		agentDrafts
			.get( id )
			.then( ( row ) => ! cancelled && setDraft( row || null ) )
			.catch( () => {} );
		return () => {
			cancelled = true;
		};
	}, [ id ] );

	// When a scheduled send is due, look again: the reply should be in the thread.
	const sendAt =
		draft?.meta?.auto?.state === 'scheduled'
			? draft.meta.auto.send_at
			: null;
	useEffect( () => {
		const due = sendAt ? parseUtc( sendAt ) : null;
		if ( ! due ) {
			return undefined;
		}
		const timer = setTimeout(
			() => {
				agentDrafts
					.get( id )
					.then( ( row ) => setDraft( row || null ) )
					.catch( () => {} );
				refresh();
			},
			Math.max( 0, due - Date.now() ) + 20000
		);
		return () => clearTimeout( timer );
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [ sendAt, id ] );

	useEffect( () => {
		preloadEditor();
	}, [] );

	// Opening a conversation reads it for this teammate, and so does a new
	// customer message arriving while it's open.
	const loadedId = conversation?.id;
	const lastCustomerThread = ( conversation?.threads || [] )
		.filter( ( t ) => t.author_type === 'customer' )
		.at( -1 )?.id;
	useEffect( () => {
		if ( loadedId ) {
			conversations.markRead( loadedId ).catch( () => {} );
		}
	}, [ loadedId, lastCustomerThread ] );

	const threads = useMemo(
		() => conversation?.threads || [],
		[ conversation ]
	);
	const defaults = useMemo( () => expandedByDefault( threads ), [ threads ] );
	const inbox = inboxes.find(
		( i ) => Number( i.id ) === Number( conversation?.inbox_id )
	);

	const setStatus = async ( status, leave ) => {
		const previous = conversation?.status;
		setActionError( null );
		patch( { status } );
		try {
			await conversations.setStatus( id, status );
		} catch {
			patch( { status: previous } );
			setActionError( STATUS_ERRORS[ status ] || STATUS_ERRORS.active );
			return;
		}
		if ( leave ) {
			navigate( '/inbox' );
		} else {
			refresh();
		}
	};

	const send = async ( {
		html,
		text,
		mode: kind,
		attachmentIds,
		mentionedIds,
		andClose,
		fromAgentDraft,
	} ) => {
		const payload = {
			content: text,
			content_html: html,
			thread_type: kind,
			is_private: kind === 'note',
			attachment_ids: attachmentIds,
			mentioned_user_ids: mentionedIds,
			// From the agent's draft, as is or after edits: ReplyService records which.
			from_agent_draft: !! (
				fromAgentDraft ||
				( kind === 'reply' &&
					seedHtml &&
					draft?.meta?.status === 'ready' )
			),
		};
		if ( kind === 'note' ) {
			// A failure throws back to the composer, which keeps the text.
			await threadsApi.create( id, payload );
			setMode( null );
			refresh();
			return;
		}
		// Replies are held for eight seconds with Undo (AGENTS.md §6.3).
		const optimistic = {
			id: `pending-${ Date.now() }`,
			author_type: 'teammate',
			author_name: appData.user.name,
			author_email: appData.user.email,
			author_avatar: appData.user.avatar,
			thread_type: 'reply',
			content: text,
			content_html: html,
			created_at: new Date().toISOString(),
		};
		setPendingThreads( ( list ) => [ ...list, optimistic ] );
		setMode( null );
		setSeedHtml( '' );
		setSeedUndo( '' );
		const forget = () =>
			setPendingThreads( ( list ) =>
				list.filter( ( t ) => t.id !== optimistic.id )
			);
		schedule( {
			label: andClose
				? __( 'Reply sent, conversation resolved', 'bridle' )
				: __( 'Reply sent', 'bridle' ),
			// Only a failed post throws (the receipt offers Retry), so a
			// retry never posts the reply twice.
			execute: async () => {
				try {
					await threadsApi.create( id, payload );
				} finally {
					// Sent, the letter returns with the refresh; failed, no phantom.
					forget();
				}
				if ( payload.from_agent_draft ) {
					setDraft( null );
				}
				if ( andClose ) {
					try {
						await conversations.setStatus( id, 'closed' );
						navigate( '/inbox' );
						return;
					} catch {
						setActionError(
							__(
								'Reply sent, but couldn’t resolve. Try again.',
								'bridle'
							)
						);
					}
				}
				refresh();
			},
			flush: () => {
				postKeepalive( `/conversations/${ id }/threads`, payload );
				if ( andClose ) {
					postKeepalive(
						`/conversations/${ id }`,
						{ status: 'closed' },
						'PATCH'
					);
				}
			},
			restore: () => {
				forget();
				setSeedUndo( '' );
				setSeedHtml( html );
				setMode( 'reply' );
			},
		} );
	};

	const editDraft = ( html = '', before = '' ) => {
		if ( draft?.meta?.status === 'ready' ) {
			// Editing means a person has it now: an automatic send stops.
			if ( draft.meta.auto?.state === 'scheduled' ) {
				agentDrafts
					.stop( id )
					.then( ( row ) => setDraft( row || null ) )
					.catch( () => {} );
			}
			setSeedUndo( before );
			setSeedHtml( html || draft.content );
			setMode( 'reply' );
		}
	};
	// The draft rewritten (#130) opens in the composer like Edit, with Undo
	// back to the draft as Bridle wrote it.
	const rewriteDraft = async ( choice ) => {
		if ( draft?.meta?.status !== 'ready' ) {
			return;
		}
		setRewriting( true );
		setActionError( null );
		try {
			const result = await ai.rewrite( {
				html: draft.content,
				conversation_id: Number( id ),
				...choice,
			} );
			editDraft( result.html, draft.content );
		} catch ( err ) {
			setActionError(
				err?.message ||
					__( 'Couldn’t rewrite the draft. Try again.', 'bridle' )
			);
		} finally {
			setRewriting( false );
		}
	};
	const draftReady = draft?.meta?.status === 'ready';
	const draftActions = {
		send: () =>
			send( {
				html: draft.content,
				text: textOf( draft.content ),
				mode: 'reply',
				attachmentIds: [],
				mentionedIds: [],
				andClose: false,
				fromAgentDraft: true,
			} ),
		edit: () => editDraft(),
		rewrite: rewriteDraft,
		discard: async () => {
			setDraftBusy( true );
			setActionError( null );
			try {
				await agentDrafts.discard( id );
				setDraft( null );
			} catch {
				setActionError(
					__( 'Couldn’t discard the draft. Try again.', 'bridle' )
				);
			} finally {
				setDraftBusy( false );
			}
		},
		stop: async () => {
			setDraftBusy( true );
			setActionError( null );
			try {
				setDraft( ( await agentDrafts.stop( id ) ) || null );
			} catch {
				setActionError(
					__( 'Couldn’t stop the send. Try again.', 'bridle' )
				);
			} finally {
				setDraftBusy( false );
			}
		},
		retry: async () => {
			setDraftBusy( true );
			try {
				setDraft( await agentDrafts.retry( id ) );
			} catch ( err ) {
				setDraft( {
					content: '',
					meta: { status: 'failed', error: err?.message || '' },
				} );
			} finally {
				setDraftBusy( false );
			}
		},
	};

	useShortcuts( {
		r: () => setMode( 'reply' ),
		n: () => setMode( 'note' ),
		a: () => editDraft(),
		e: () =>
			conversation &&
			conversation.status === 'active' &&
			setStatus( 'closed', true ),
	} );

	if ( loading && ! conversation ) {
		return (
			<Page>
				<Skeleton className="mb-6 h-8 w-2/3" />
				<Skeleton className="h-40" />
			</Page>
		);
	}
	// A failed quiet refresh keeps the conversation on screen.
	if ( ! conversation ) {
		const failed = error && ! isNotFound( error );
		return (
			<Page
				title={
					failed
						? __( 'This conversation couldn’t be loaded', 'bridle' )
						: __( 'Conversation not found', 'bridle' )
				}
			>
				<div className="flex gap-2">
					{ failed && (
						<Button onClick={ refresh }>
							{ __( 'Try again', 'bridle' ) }
						</Button>
					) }
					<Button asChild variant="outline">
						<Link to="/inbox">
							{ __( 'Back to the Inbox', 'bridle' ) }
						</Link>
					</Button>
				</div>
			</Page>
		);
	}

	const actions = {
		reply: () => setMode( 'reply' ),
		note: () => setMode( 'note' ),
		resolve: () => setStatus( 'closed', true ),
		reopen: () => setStatus( 'active', false ),
		spam: () => setStatus( 'spam', true ),
		notSpam: () => setStatus( 'active', false ),
		trash: () => setStatus( 'trash', true ),
		restore: () => setStatus( 'active', false ),
		assign: async ( userId ) => {
			const previous = conversation.assigned_to;
			setActionError( null );
			patch( { assigned_to: userId } );
			try {
				await conversations.assign( id, userId );
			} catch {
				patch( { assigned_to: previous } );
				setActionError( __( 'Couldn’t assign. Try again.', 'bridle' ) );
			}
		},
		contact: () => setDrawer( true ),
		merge: () => setMergeOpen( true ),
	};

	const assignee = team.find(
		( t ) => Number( t.id ) === Number( conversation.assigned_to )
	);
	const showAssignee = team.length > 0;
	// The detail payload has no last_author_type; read it from the thread.
	const lastPublic = threads.filter( isExchange ).at( -1 );
	const state = stateOf( {
		...conversation,
		last_author_type: lastPublic?.author_type,
	} );

	// Updates mail Bridle filed by itself (the sender has no override yet or
	// is set to Updates): say so, and offer the way out.
	const inUpdates =
		conversation.status === 'active' && conversation.box === 'feed';
	const moveToInbox = async () => {
		setMoving( true );
		try {
			await customers.setBox( conversation.customer_id, 'inbox' );
			await refresh();
		} finally {
			setMoving( false );
		}
	};

	// Back goes to the list this was opened from; a direct link falls back
	// to the box the conversation is in.
	const back = lastList || {
		path: inUpdates ? '/updates' : '/inbox',
		query: {},
		box: inUpdates ? 'updates' : 'inbox',
	};
	const backLabel = back.box
		? DOCK_ITEMS.find( ( item ) => item.box === back.box )?.label
		: __( 'Search', 'bridle' );

	return (
		<Page className="pb-40">
			<header className="mb-8">
				<div className="mb-3 flex items-center gap-3 text-xs text-muted-foreground">
					<Link
						to={ back.path }
						query={ back.query }
						className="inline-flex items-center gap-1 hover:text-foreground"
					>
						<ArrowLeft className="size-3" />
						{ backLabel }
					</Link>
					{ inboxes.length > 1 && inbox && (
						<span className="inline-flex items-center gap-1.5">
							<InboxDot inbox={ inbox } />
							{ inbox.display_name }
						</span>
					) }
					<StateLabel state={ state } />
				</div>
				<h1 className="text-[1.75rem] leading-tight font-[450] tracking-[-0.02em] text-balance">
					{ conversation.subject || __( '(no subject)', 'bridle' ) }
				</h1>
				<div className="mt-4 flex items-center gap-3">
					<button
						type="button"
						onClick={ () => setDrawer( true ) }
						className="shrink-0 rounded-full outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50"
						aria-label={ __( 'Open contact', 'bridle' ) }
					>
						<MessageAvatar conversation={ conversation } />
					</button>
					<div className="min-w-0 flex-1">
						<div className="truncate font-medium">
							{ conversation.customer_name ||
								conversation.customer_email }
						</div>
						{ conversation.customer_name && (
							<div className="truncate font-mono text-xs text-muted-foreground">
								{ conversation.customer_email }
							</div>
						) }
					</div>
					{ showAssignee && (
						<AssigneeControl
							assignee={ assignee }
							team={ team }
							value={ conversation.assigned_to }
							onChange={ actions.assign }
						/>
					) }
				</div>
				<AgentPresence mode={ agentMode } />
			</header>

			{ inUpdates && (
				<div className="mb-6 flex flex-wrap items-center gap-x-3 gap-y-2 rounded-card border bg-accent/60 py-2 pr-2 pl-4 text-sm">
					<span className="min-w-0 flex-1 text-muted-foreground">
						{ __(
							'Bridle filed this in Updates because it looks automated.',
							'bridle'
						) }
					</span>
					<Button
						size="sm"
						variant="outline"
						className="rounded-full"
						disabled={ moving }
						onClick={ moveToInbox }
					>
						<Inbox />
						{ __( 'Move to inbox', 'bridle' ) }
					</Button>
				</div>
			) }

			<div className="space-y-3">
				{ threads.map( ( thread ) => (
					<MessageCard
						key={ thread.id }
						thread={ thread }
						conversation={ conversation }
						inbox={ inbox }
						collapsed={
							! defaults.has( thread.id ) &&
							! opened.has( thread.id )
						}
						onExpand={ () =>
							setOpened( ( set ) =>
								new Set( set ).add( thread.id )
							)
						}
					/>
				) ) }
				{ pendingThreads.map( ( thread ) => (
					<MessageCard
						key={ thread.id }
						thread={ thread }
						conversation={ conversation }
						inbox={ inbox }
						pending
					/>
				) ) }
			</div>

			{ /* The draft reads as the answer to the last message (#108). */ }
			<div className="mt-3">
				<AgentDraftCard
					draft={ draft }
					agentMode={ agentMode }
					canDraft={
						conversation.status === 'active' &&
						needsReply( {
							last_author_type: threads
								.filter( isExchange )
								.at( -1 )?.author_type,
						} )
					}
					busy={ draftBusy }
					onSend={ draftActions.send }
					onEdit={ draftActions.edit }
					onRewrite={ draftActions.rewrite }
					rewriting={ rewriting }
					onDiscard={ draftActions.discard }
					onRetry={ draftActions.retry }
					onStop={ draftActions.stop }
				/>
			</div>
			<div className="mt-4">
				{ /* An add-on's line about the chat, e.g. "The visitor is typing…". */ }
				{ extend( 'conversationStatus', null, {
					conversation,
					refresh,
				} ) }
				{ mode && (
					<Composer
						conversationId={ Number( id ) }
						channel={ conversation.channel }
						customerName={ conversation.customer_name }
						teammates={ team }
						mode={ mode }
						onModeChange={ setMode }
						seedHtml={ seedHtml }
						undoHtml={ seedUndo }
						onSend={ send }
						onCancel={ () => setMode( null ) }
					/>
				) }
				{ /* A draft ready to send is the reply; the pill still offers Reply. */ }
				{ ! mode && ! draftReady && (
					<button
						type="button"
						onClick={ () => setMode( 'reply' ) }
						className="flex w-full items-center justify-between rounded-xl border bg-card px-4 py-3 text-left text-sm text-muted-foreground hover:bg-muted/60"
					>
						{ __( 'Reply…', 'bridle' ) }
					</button>
				) }
			</div>

			<ActionPill
				conversation={ conversation }
				teammates={ team }
				on={ actions }
			/>
			<SendReceipt
				pending={ pending }
				onUndo={ undo }
				onRetry={ retry }
				onEdit={ undo }
				error={ actionError }
				onDismissError={ () => setActionError( null ) }
			/>
			<ContactDrawer
				open={ drawer }
				onOpenChange={ setDrawer }
				conversation={ conversation }
				onCustomerChange={ ( customer ) => patch( { customer } ) }
			/>
			<MergeDialog
				open={ mergeOpen }
				onOpenChange={ setMergeOpen }
				conversation={ conversation }
				onMerged={ ( targetId ) => navigate( `/c/${ targetId }` ) }
			/>
		</Page>
	);
}

function MessageAvatar( { conversation } ) {
	return (
		<ContactAvatar
			name={ conversation.customer_name }
			email={ conversation.customer_email }
			src={ conversation.customer_avatar }
			className="size-10"
		/>
	);
}

/* Who has this conversation: a quiet dropdown, "Nobody" first. */
function AssigneeControl( { assignee, team, value, onChange } ) {
	return (
		<DropdownMenu>
			<DropdownMenuTrigger asChild>
				<Button
					variant="ghost"
					size="sm"
					className="gap-2 text-xs text-muted-foreground"
				>
					{ assignee ? (
						<ContactAvatar
							name={ assignee.display_name }
							email={ assignee.email }
							src={ assignee.avatar_url }
							className="size-5"
						/>
					) : (
						<UserRound />
					) }
					{ assignee
						? assignee.display_name
						: __( 'Unassigned', 'bridle' ) }
					<ChevronDown />
				</Button>
			</DropdownMenuTrigger>
			<DropdownMenuContent align="end" className="w-52">
				<DropdownMenuRadioGroup
					value={ String( value || '' ) }
					onValueChange={ ( v ) => onChange( Number( v ) || null ) }
				>
					<DropdownMenuRadioItem value="">
						{ __( 'Nobody', 'bridle' ) }
					</DropdownMenuRadioItem>
					{ team.map( ( t ) => (
						<DropdownMenuRadioItem
							key={ t.id }
							value={ String( t.id ) }
						>
							{ t.display_name }
						</DropdownMenuRadioItem>
					) ) }
				</DropdownMenuRadioGroup>
			</DropdownMenuContent>
		</DropdownMenu>
	);
}

/* The agent's presence on this inbox, so its drafts read as a colleague's. */
function AgentPresence( { mode } ) {
	if ( mode !== 'draft' && mode !== 'auto' ) {
		return null;
	}
	return (
		<Link
			to="/settings/replies"
			className="mt-3 inline-flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground"
		>
			<AgentAvatar className="size-5" />
			{ mode === 'auto'
				? __( 'Bridle replies here when it’s sure', 'bridle' )
				: __( 'Bridle drafts replies here', 'bridle' ) }
		</Link>
	);
}
