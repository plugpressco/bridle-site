import { __, sprintf } from '@wordpress/i18n';
import { SearchX } from 'lucide-react';

import { ConversationList } from '@/components/list/conversation-list';
import { EmptyState, ListError } from '@/components/list/empty-state';
import { Page } from '@/components/shell/page';
import { useShell } from '@/components/shell/shell-context';
import { conversations } from '@/lib/api';
import { usePagedList } from '@/lib/use-paged-list';
import { useReadToggle } from '@/lib/use-read-toggle';

/*
 * `#/search?q=`: everything except spam and trash, newest first. No bulk
 * actions here, so rows have no selection; read/unread still toggles.
 */
export function SearchPage( { q } ) {
	const { inboxScope } = useShell();
	const list = usePagedList(
		( page ) =>
			conversations.list( {
				search: q,
				status: 'allmail',
				inbox_id: inboxScope,
				page,
			} ),
		[ q, inboxScope ]
	);
	const toggleRead = useReadToggle( [ list ] );

	return (
		<Page
			scope
			width="list"
			eyebrow={ __( 'Search', 'bridle' ) }
			/* translators: %s: the search terms */
			title={ sprintf( __( '“%s”', 'bridle' ), q ) }
		>
			{ list.error && <ListError onRetry={ list.reload } /> }
			<ConversationList
				sections={ [
					{ key: 'results', title: __( 'Results', 'bridle' ), list },
				] }
				onToggleRead={ toggleRead }
				empty={
					list.error ? null : (
						<EmptyState
							icon={ SearchX }
							title={ __( 'No conversations match.', 'bridle' ) }
							hint={ __(
								'Search looks at subjects, contacts and message text. Spam and trash are left out.',
								'bridle'
							) }
						/>
					)
				}
			/>
		</Page>
	);
}
