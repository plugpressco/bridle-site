/*
 * Bridle in WordPress's own command palette (⌘K, the one in the admin bar),
 * on every admin screen, instead of a palette of its own (BRIDLE-NEXT.md).
 * WordPress already offers "Go to: Bridle > Home / Inbox / Docs / Settings"
 * from the admin menu; this adds the other boxes, each Settings page,
 * Connect an inbox, and a conversation search as you type. Loaded by Admin\AdminPage::enqueue_commands() for
 * people who manage conversations, after `wp-commands`; without the
 * commands store it does nothing.
 */
import { useEffect, useState } from 'react';
import apiFetch from '@wordpress/api-fetch';
import {
	Archive,
	Inbox,
	Mail,
	Newspaper,
	Search,
	Settings,
	ShieldAlert,
	Trash,
} from 'lucide-react';

import { searchCommands, staticCommands, target } from './list';

const config = window.bridleCommands || {};

const ICONS = {
	inbox: Inbox,
	updates: Newspaper,
	resolved: Archive,
	spam: ShieldAlert,
	trash: Trash,
	settings: Settings,
	search: Search,
	conversation: Mail,
};

function store() {
	try {
		const actions = window.wp?.data?.dispatch?.( 'core/commands' );
		return actions?.registerCommand ? actions : null;
	} catch {
		return null;
	}
}

function go( path ) {
	const to = target( config.base, path, window.location );
	if ( to.hash ) {
		window.location.hash = to.hash;
	} else {
		window.location.href = to.href;
	}
}

function command( { path, icon, ...entry } ) {
	const Icon = ICONS[ icon ] || Mail;
	return {
		...entry,
		// The palette fills its icons (WordPress's are solid); Lucide's are
		// strokes, so keep them unfilled, at WordPress's weight.
		icon: <Icon strokeWidth={ 1.5 } style={ { fill: 'none' } } />,
		callback: ( { close } = {} ) => {
			close?.();
			go( path );
		},
	};
}

function useSearch( { search } ) {
	const [ state, setState ] = useState( {
		commands: [],
		isLoading: false,
	} );
	useEffect( () => {
		const term = String( search || '' ).trim();
		if ( term.length < 2 ) {
			setState( { commands: [], isLoading: false } );
			return undefined;
		}
		let live = true;
		setState( {
			commands: searchCommands( term, [] ).map( command ),
			isLoading: true,
		} );
		const timer = setTimeout( () => {
			apiFetch( {
				path: `/bridle/v1/conversations?${ new URLSearchParams( {
					search: term,
					status: 'allmail',
					per_page: 5,
				} ) }`,
			} )
				.then( ( rows ) => {
					if ( live ) {
						setState( {
							commands: searchCommands( term, rows ).map(
								command
							),
							isLoading: false,
						} );
					}
				} )
				.catch( () => {
					if ( live ) {
						setState( ( s ) => ( { ...s, isLoading: false } ) );
					}
				} );
		}, 250 );
		return () => {
			live = false;
			clearTimeout( timer );
		};
	}, [ search ] );
	return state;
}

const actions = store();
if ( actions && config.base ) {
	staticCommands( { settings: !! config.settings } ).forEach( ( entry ) =>
		actions.registerCommand( command( entry ) )
	);
	actions.registerCommandLoader( {
		name: 'bridle/search-conversations',
		hook: useSearch,
	} );
}
