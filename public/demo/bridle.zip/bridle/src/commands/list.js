/*
 * What Bridle puts in WordPress's command palette (⌘K), as plain data:
 * the boxes, the Settings pages, Connect an inbox and, as you type, a search. index.js turns
 * each entry into a `core/commands` command. Kept free of the store so it
 * can be tested on its own.
 */
import { __, sprintf } from '@wordpress/i18n';

/*
 * Labels follow WordPress's own "Go to: Bridle > Inbox" commands, which it
 * already makes from Bridle's admin menu (Home, Inbox, Docs, Settings), so
 * Bridle adds only what that menu doesn't reach.
 */
function goTo( place ) {
	return sprintf(
		/* translators: %s: where the command goes, such as "Bridle > Updates". */
		__( 'Go to: %s', 'bridle' ),
		place
	);
}

/** The boxes after Inbox, in dock order. */
export function boxes() {
	return [
		[ 'updates', __( 'Updates', 'bridle' ), [ 'feed', 'newsletters' ] ],
		[ 'resolved', __( 'Resolved', 'bridle' ), [ 'closed', 'done' ] ],
		[ 'spam', __( 'Spam', 'bridle' ), [ 'junk' ] ],
		[ 'trash', __( 'Trash', 'bridle' ), [ 'deleted' ] ],
	].map( ( [ key, label, keywords ] ) => ( {
		name: `bridle/go/${ key }`,
		label: goTo(
			sprintf(
				/* translators: %s: a Bridle box, such as "Updates". */
				__( 'Bridle > %s', 'bridle' ),
				label
			)
		),
		keywords: [ 'bridle', 'support', ...keywords ],
		icon: key,
		category: 'view',
		path: '/' + key,
	} ) );
}

/** The Settings pages, for people who may change settings. */
export function settingsPages() {
	return [
		[ 'chat', __( 'Chat', 'bridle' ), [ 'bubble', 'widget', 'website' ] ],
		[ 'inboxes', __( 'Inboxes', 'bridle' ), [ 'forwarding', 'address' ] ],
		[ 'replies', __( 'Replies', 'bridle' ), [ 'agent', 'auto', 'draft' ] ],
		[ 'knowledge', __( 'Knowledge', 'bridle' ), [ 'docs', 'snippets' ] ],
		[ 'sorting', __( 'Sorting', 'bridle' ), [ 'classifier', 'spam' ] ],
		[
			'ai-apps',
			__( 'AI apps', 'bridle' ),
			[ 'mcp', 'claude', 'chatgpt' ],
		],
		[ 'team', __( 'Team', 'bridle' ), [ 'teammates', 'people' ] ],
		[ 'emails', __( 'Emails', 'bridle' ), [ 'signature', 'bcc' ] ],
		[ 'data', __( 'Data', 'bridle' ), [ 'erase', 'trash' ] ],
		[ 'pro', __( 'Bridle Pro', 'bridle' ), [ 'licence', 'license' ] ],
	].map( ( [ key, label, keywords ] ) => ( {
		name: `bridle/settings/${ key }`,
		label: goTo(
			sprintf(
				/* translators: %s: a Bridle Settings page, such as "Chat". */
				__( 'Bridle > Settings > %s', 'bridle' ),
				label
			)
		),
		keywords: [ 'bridle', 'settings', ...keywords ],
		icon: 'settings',
		category: 'view',
		path: '/settings/' + key,
	} ) );
}

/**
 * Every static command.
 *
 * @param {Object}  input
 * @param {boolean} input.settings Whether the user may change settings.
 * @return {Array} Entries with name, label, keywords, icon, category, path.
 */
export function staticCommands( { settings } ) {
	const list = boxes();
	if ( settings ) {
		list.push(
			{
				name: 'bridle/connect-inbox',
				label: __( 'Connect an inbox to Bridle', 'bridle' ),
				keywords: [ 'bridle', 'forward', 'gmail', 'outlook', 'setup' ],
				icon: 'inbox',
				category: 'command',
				path: '/settings/inboxes?connect=1',
			},
			...settingsPages()
		);
	}
	return list;
}

/**
 * The search as you type: "Search Bridle for …", then the conversations
 * that match. `searchLabel` carries the term so the palette, which filters
 * by label, keeps a match found in the body.
 *
 * @param {string} term The palette's search.
 * @param {Array}  rows Conversations from GET /conversations.
 * @return {Array} Entries.
 */
export function searchCommands( term, rows ) {
	const query = String( term || '' ).trim();
	if ( query.length < 2 ) {
		return [];
	}
	const list = [
		{
			name: 'bridle/search',
			label: sprintf(
				/* translators: %s: what the person typed. */
				__( 'Search Bridle for “%s”', 'bridle' ),
				query
			),
			searchLabel: query,
			icon: 'search',
			category: 'command',
			path: '/search?q=' + encodeURIComponent( query ),
		},
	];
	( Array.isArray( rows ) ? rows : [] ).forEach( ( row ) => {
		const id = parseInt( row?.id, 10 );
		if ( ! id ) {
			return;
		}
		const who =
			row.customer_name ||
			row.customer_email ||
			( row.channel === 'chat' ? __( 'Website visitor', 'bridle' ) : '' );
		const subject = row.subject || __( '(no subject)', 'bridle' );
		const label = who ? `${ subject } · ${ who }` : subject;
		list.push( {
			name: `bridle/conversation/${ id }`,
			label,
			searchLabel: `${ label } ${ query }`,
			icon: 'conversation',
			category: 'view',
			path: '/c/' + id,
		} );
	} );
	return list;
}

/**
 * Where a Bridle path opens: on Bridle's page only the hash changes (its
 * router follows), anywhere else the page loads.
 *
 * @param {string} base     admin.php?page=bridle, absolute.
 * @param {string} path     A route such as /inbox.
 * @param {Object} location window.location.
 * @return {{hash: string}|{href: string}} What to set.
 */
export function target( base, path, location ) {
	let onBridle = false;
	try {
		const here = new URL( location.href );
		const there = new URL( base, location.href );
		onBridle =
			here.origin === there.origin &&
			here.pathname === there.pathname &&
			here.searchParams.get( 'page' ) === 'bridle';
	} catch {}
	return onBridle ? { hash: '#' + path } : { href: base + '#' + path };
}
