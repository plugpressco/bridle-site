/*
 * Bridle Chat's icons (#142): drawn for the bubble on a 24px grid, 2px round
 * strokes, so the set reads as one family at 26px on the launcher and 18px
 * in the window. The launcher's is the owner's pick (Settings → Chat → Icon,
 * ChatWidget::ICONS); it turns into the chevron while the window is open.
 */
const svg = ( paths, extra = '' ) =>
	`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"${ extra }>${ paths }</svg>`;

export const LAUNCHER_ICONS = {
	// A round speech bubble.
	bubble: svg(
		'<path d="M20.5 11.6a8.4 8.4 0 0 1-12.2 7.5L4 20.4l1.3-4.1A8.4 8.4 0 1 1 20.5 11.6Z"/>'
	),
	// A message card with two lines of text.
	message: svg(
		'<path d="M5 4.5h14a1.5 1.5 0 0 1 1.5 1.5v9a1.5 1.5 0 0 1-1.5 1.5h-7.5L7 20v-3.5H5A1.5 1.5 0 0 1 3.5 15V6A1.5 1.5 0 0 1 5 4.5Z"/><path d="M8 9h8M8 12h5"/>'
	),
	// The AI's spark: one large four-point star and a small one.
	sparkle: svg(
		'<path d="M10.5 3.5 12 8.2l4.7 1.5-4.7 1.6-1.5 4.7L9 11.3 4.3 9.7 9 8.2Z"/><path d="M17.5 14.5l.8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8Z"/>'
	),
	// A question in a circle, for help.
	question: svg(
		'<circle cx="12" cy="12" r="8.75"/><path d="M9.6 9.4a2.5 2.5 0 0 1 4.8.9c0 1.6-2.4 2.1-2.4 3.6"/><path d="M12 17.2h.01"/>'
	),
	// A headset, for a person on the line.
	headset: svg(
		'<path d="M4 15v-3a8 8 0 0 1 16 0v3"/><path d="M4 14.5h2.5a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1ZM20 14.5h-2.5a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1H19a1 1 0 0 0 1-1Z"/><path d="M18 19.5c0 1.1-2 1.5-4.5 1.5"/>'
	),
};

export const ICON_DOWN = svg( '<path d="m6 9.5 6 6 6-6"/>' );
export const ICON_CLOSE = svg( '<path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/>' );
export const ICON_MENU = svg(
	'<circle cx="5.5" cy="12" r="1.3" fill="currentColor"/><circle cx="12" cy="12" r="1.3" fill="currentColor"/><circle cx="18.5" cy="12" r="1.3" fill="currentColor"/>'
);
export const ICON_SEND = svg( '<path d="M12 18.5V6M6.5 11.5 12 6l5.5 5.5"/>' );
export const ICON_OUT = svg( '<path d="M9 6h9v9M18 6 7 17"/>' );
