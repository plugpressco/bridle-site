// Bridle Chat's styles, inside its shadow root: the theme's CSS never reaches
// them and they never reach the theme. --bc-accent is the owner's colour.
export const STYLES = `
:host { all: initial; }
* { box-sizing: border-box; }
.bc { --bc-ink: #181818; --bc-muted: #6b6b66; --bc-line: #e6e6e1; --bc-soft: #f5f5f2;
	font: 15px/1.5 system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; color: var(--bc-ink);
	position: fixed; right: 20px; bottom: 20px; z-index: 2147483000; }
button, input, textarea { font: inherit; color: inherit; }
.launcher { width: 56px; height: 56px; border-radius: 50%; border: 0; cursor: pointer;
	background: var(--bc-accent); color: #fff; display: grid; place-items: center;
	box-shadow: 0 8px 24px rgb(24 24 24 / 0.18); transition: transform .15s ease-out; }
.launcher:active { transform: scale(.94); }
.launcher { position: relative; }
.badge { position: absolute; top: -2px; right: -2px; min-width: 20px; height: 20px; padding: 0 5px; border-radius: 10px;
	background: #e5484d; color: #fff; font-size: 12px; font-weight: 700; line-height: 16px; border: 2px solid #fff; text-align: center; }
.badge[hidden] { display: none; }
.from { margin: 0 0 4px; font-size: 12px; font-weight: 600; color: var(--bc-muted); }
.launcher svg { width: 26px; height: 26px; }
.panel { position: absolute; right: 0; bottom: 72px; width: 380px; height: min(600px, calc(100vh - 112px));
	background: #fff; border-radius: 16px; border: 1px solid var(--bc-line); overflow: hidden;
	box-shadow: 0 16px 48px rgb(24 24 24 / 0.18); display: flex; flex-direction: column;
	transform-origin: bottom right; animation: bc-in .18s ease-out; }
.panel[hidden] { display: none; }
@keyframes bc-in { from { opacity: 0; transform: translateY(8px) scale(.98); } }
header { display: flex; align-items: center; gap: 10px; padding: 14px 14px 12px 16px; border-bottom: 1px solid var(--bc-line); }
header .who { flex: 1; min-width: 0; }
header h2 { margin: 0; font-size: 15px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
header p { margin: 0; font-size: 12px; color: var(--bc-muted); }
.icon { width: 32px; height: 32px; border-radius: 8px; border: 0; background: transparent; cursor: pointer; color: var(--bc-muted); display: grid; place-items: center; }
.icon:hover { background: var(--bc-soft); color: var(--bc-ink); }
.log { flex: 1; overflow-y: auto; padding: 16px; display: flex; flex-direction: column; gap: 10px; background: var(--bc-soft); }
.msg { max-width: 86%; padding: 9px 12px; border-radius: 14px; overflow-wrap: anywhere; }
.msg p { margin: 0 0 8px; } .msg p:last-child { margin: 0; }
.msg ul, .msg ol { margin: 0 0 8px; padding-left: 20px; }
.msg a { color: var(--bc-accent); }
.msg code { font-size: 13px; background: var(--bc-soft); padding: 1px 4px; border-radius: 4px; }
.bot { align-self: flex-start; background: #fff; border: 1px solid var(--bc-line); border-bottom-left-radius: 4px; }
.visitor { align-self: flex-end; background: var(--bc-accent); color: #fff; border-bottom-right-radius: 4px; white-space: pre-wrap; }
.note { align-self: center; max-width: 100%; font-size: 13px; color: var(--bc-muted); text-align: center; }
.sources { margin-top: 8px; padding-top: 8px; border-top: 1px solid var(--bc-line); font-size: 12.5px; color: var(--bc-muted); }
.sources a { display: block; color: var(--bc-accent); text-decoration: none; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.sources a:hover { text-decoration: underline; }
.thinking { color: var(--bc-muted); font-size: 14px; }
form.handoff { display: grid; gap: 8px; padding: 12px 16px; border-top: 1px solid var(--bc-line); background: #fff; }
form.handoff[hidden] { display: none; }
input, textarea { width: 100%; border: 1px solid var(--bc-line); border-radius: 10px; padding: 9px 11px; background: #fff; outline: none; }
input:focus, textarea:focus { border-color: var(--bc-accent); box-shadow: 0 0 0 3px color-mix(in srgb, var(--bc-accent) 20%, transparent); }
.row { display: flex; gap: 8px; justify-content: flex-end; }
.btn { border: 0; border-radius: 10px; padding: 8px 14px; cursor: pointer; background: var(--bc-ink); color: #fff; font-weight: 500; }
.btn.quiet { background: transparent; color: var(--bc-muted); }
.btn:disabled { opacity: .5; cursor: default; }
.composer[hidden], .note[hidden] { display: none; }
.composer { display: flex; align-items: flex-end; gap: 8px; padding: 10px 12px; border-top: 1px solid var(--bc-line); background: #fff; }
.composer textarea { resize: none; max-height: 120px; line-height: 1.4; }
.send { flex: none; width: 38px; height: 38px; border-radius: 10px; border: 0; background: var(--bc-accent); color: #fff; cursor: pointer; display: grid; place-items: center; }
.send:disabled { opacity: .45; cursor: default; }
footer { display: flex; align-items: center; gap: 12px; padding: 8px 16px 10px; font-size: 12px; color: var(--bc-muted); background: #fff; }
footer .grow { flex: 1; }
footer button { border: 0; background: none; padding: 0; color: var(--bc-ink); font-weight: 500; cursor: pointer; font-size: 12px; }
footer a { color: var(--bc-muted); text-decoration: none; }
footer a:hover, footer button:hover { text-decoration: underline; }
.hp { position: absolute; left: -9999px; width: 1px; height: 1px; opacity: 0; }
:focus-visible { outline: 2px solid var(--bc-accent); outline-offset: 2px; }
@media (max-width: 480px) {
	.bc { right: 16px; bottom: 16px; }
	.panel { position: fixed; inset: 0; width: auto; height: auto; border-radius: 0; border: 0; }
}
@media (prefers-reduced-motion: reduce) { .panel { animation: none; } .launcher { transition: none; } }
`;
