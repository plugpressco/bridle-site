/*
 * Bridle Chat (#114): the bubble on the site's front end. No dependencies; it
 * draws itself in a shadow root. Config and every word come from PHP
 * (Services\ChatWidget::config()) as window.bridleChat. The chat survives page
 * loads in localStorage: its id, its token and what was said, for a day, or
 * for 30 days once it's with a person. Then the bubble checks for the team's
 * replies (#120): every 15 seconds while open, every minute while closed,
 * with a badge on the launcher for unread ones.
 *
 * Live (#131, only with `config.live`, which Bridle Pro sets): when a person
 * is here, a handoff stays in the bubble without an email, the checks speed
 * up to what the server asks (`poll`), and "Typing…" shows both ways.
 */
import { STYLES } from './styles';

const config = window.bridleChat;
const KEY = 'bridle-chat-v1';
const DAY = 24 * 60 * 60 * 1000;

const ICON_CHAT =
	'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12Z"/></svg>';
const ICON_CLOSE =
	'<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>';
const ICON_SEND =
	'<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>';

function load() {
	try {
		const saved = JSON.parse(
			window.localStorage.getItem( KEY ) || 'null'
		);
		if ( saved && Date.now() - saved.at < ( saved.email ? 30 : 1 ) * DAY ) {
			return saved;
		}
	} catch {}
	return null;
}

function fresh() {
	return {
		id: 0,
		token: '',
		messages: [],
		mode: 'chat',
		email: '',
		live: false,
		lastTeam: 0,
		unread: 0,
		at: 0,
	};
}

function el( tag, attrs = {}, text ) {
	const node = document.createElement( tag );
	Object.entries( attrs ).forEach( ( [ name, value ] ) => {
		if ( value !== false && value !== null && value !== undefined ) {
			node.setAttribute( name, value === true ? '' : value );
		}
	} );
	if ( text ) {
		node.textContent = text;
	}
	return node;
}

class BridleChat extends window.HTMLElement {
	connectedCallback() {
		if ( this.shadowRoot ) {
			return;
		}
		this.s = config.strings;
		this.state = load() || fresh();
		this.turnstileToken = '';
		this.render();
		this.listen();
	}

	/*
	 * The team's replies: checked while the chat is with a person, every 15
	 * seconds open (or as fast as a live chat asks) and every minute closed.
	 */
	listen() {
		window.clearTimeout( this.timer );
		if ( ! this.state.id || ! ( this.state.email || this.state.live ) ) {
			return;
		}
		const next = () => {
			window.clearTimeout( this.timer );
			const delay = this.panel.hidden ? 60000 : this.fast || 15000;
			this.timer = window.setTimeout(
				() => this.poll( ! this.panel.hidden ).then( next ),
				delay
			);
		};
		this.poll( ! this.panel.hidden ).then( next );
	}

	typing() {
		return (
			Date.now() - ( this.typedAt || 0 ) < 5000 &&
			this.input.value.trim() !== ''
		);
	}

	showTyping( on ) {
		if ( on && ! this.typingNode.isConnected ) {
			this.log.append( this.typingNode );
			this.scroll();
		} else if ( ! on ) {
			this.typingNode.remove();
		}
	}

	async poll( open ) {
		if ( this.polling || ! this.state.id ) {
			return;
		}
		this.polling = true;
		this.polledAt = Date.now();
		try {
			const data = await this.post( '/messages', {
				id: this.state.id,
				token: this.state.token,
				after: this.state.lastTeam || 0,
				open,
				typing: open && this.typing(),
			} );
			this.fast = data.poll ? Math.max( 2000, Number( data.poll ) ) : 0;
			if ( data.live ) {
				this.state.live = true;
			}
			this.showTyping( !! data.typing );
			( data.messages || [] ).forEach( ( message ) => {
				this.state.lastTeam = Math.max(
					this.state.lastTeam || 0,
					message.id
				);
				this.add( {
					who: 'team',
					name: message.name,
					html: message.html,
				} );
				if ( ! open ) {
					this.state.unread = ( this.state.unread || 0 ) + 1;
				}
			} );
			this.badge();
			this.save();
		} catch ( error ) {
			if ( error.code === 'bridle_chat_gone' ) {
				window.clearTimeout( this.timer );
			}
		} finally {
			this.polling = false;
		}
	}

	badge() {
		const count = this.state.unread || 0;
		this.badgeNode.hidden = ! count;
		this.badgeNode.textContent = count > 9 ? '9+' : String( count );
	}

	save() {
		this.state.at = Date.now();
		try {
			window.localStorage.setItem( KEY, JSON.stringify( this.state ) );
		} catch {}
	}

	render() {
		const s = this.s;
		const root = this.attachShadow( { mode: 'open' } );
		root.innerHTML = `<style>${ STYLES }</style>`;

		const wrap = el( 'div', { class: 'bc' } );
		wrap.style.setProperty( '--bc-accent', config.color );

		this.panel = el( 'section', {
			class: 'panel',
			role: 'dialog',
			'aria-label': config.title,
			hidden: true,
		} );

		const header = el( 'header' );
		const who = el( 'div', { class: 'who' } );
		who.append( el( 'h2', {}, config.title ), el( 'p', {}, s.subtitle ) );
		const close = el( 'button', {
			class: 'icon',
			type: 'button',
			'aria-label': s.close,
		} );
		close.innerHTML = ICON_CLOSE;
		close.addEventListener( 'click', () => this.toggle( false ) );
		header.append( who, close );

		this.log = el( 'div', {
			class: 'log',
			role: 'log',
			'aria-live': 'polite',
		} );

		this.form = this.handoffForm();

		const composer = el( 'form', { class: 'composer' } );
		this.composer = composer;
		this.input = el( 'textarea', {
			rows: 1,
			placeholder: s.placeholder,
			'aria-label': s.placeholder,
			maxlength: 1000,
		} );
		this.hp = el( 'input', {
			class: 'hp',
			name: 'website',
			tabindex: '-1',
			autocomplete: 'off',
			'aria-hidden': 'true',
		} );
		this.sendButton = el( 'button', {
			class: 'send',
			type: 'submit',
			'aria-label': s.send,
		} );
		this.sendButton.innerHTML = ICON_SEND;
		composer.append( this.input, this.hp, this.sendButton );
		composer.addEventListener( 'submit', ( event ) => {
			event.preventDefault();
			this.send();
		} );
		this.input.addEventListener( 'keydown', ( event ) => {
			if ( event.key === 'Enter' && ! event.shiftKey ) {
				event.preventDefault();
				this.send();
			}
		} );
		this.input.addEventListener( 'input', () => {
			this.grow();
			this.typedAt = Date.now();
			// Live: tell the person at once rather than at the next check.
			if (
				this.state.live &&
				! this.panel.hidden &&
				Date.now() - ( this.polledAt || 0 ) > 2500
			) {
				this.poll( true );
			}
		} );
		this.typingNode = el(
			'div',
			{ class: 'msg bot thinking' },
			this.s.typing || '…'
		);

		const footer = el( 'footer' );
		this.personButton = el( 'button', { type: 'button' }, s.person );
		this.personButton.addEventListener( 'click', () => this.askPerson() );
		this.restartButton = el( 'button', { type: 'button' }, s.restart );
		this.restartButton.addEventListener( 'click', () => this.restart() );
		footer.append( this.personButton, this.restartButton );
		footer.append( el( 'span', { class: 'grow' } ) );
		if ( config.privacy ) {
			footer.append(
				el(
					'a',
					{ href: config.privacy, target: '_blank', rel: 'noopener' },
					s.privacy
				)
			);
		}
		// Only when the owner said yes (Settings → Chat).
		if ( config.powered ) {
			footer.append(
				el(
					'a',
					{ href: config.powered, target: '_blank', rel: 'noopener' },
					s.powered
				)
			);
		}

		// Turnstile can't draw inside a shadow root: it renders into a light
		// DOM child slotted into the panel.
		const slot = el( 'slot', { name: 'turnstile' } );
		this.panel.append(
			header,
			this.log,
			slot,
			this.form,
			composer,
			footer
		);

		this.launcher = el( 'button', {
			class: 'launcher',
			type: 'button',
			'aria-label': s.open,
			'aria-expanded': 'false',
		} );
		this.launcher.innerHTML = ICON_CHAT;
		this.badgeNode = el( 'span', {
			class: 'badge',
			'aria-hidden': 'true',
			hidden: true,
		} );
		this.launcher.append( this.badgeNode );
		this.launcher.addEventListener( 'click', () => this.toggle() );

		wrap.append( this.panel, this.launcher );
		root.append( wrap );

		wrap.addEventListener( 'keydown', ( event ) => {
			if ( event.key === 'Escape' && ! this.panel.hidden ) {
				this.toggle( false );
			}
		} );

		this.paint();
	}

	handoffForm() {
		const s = this.s;
		const form = el( 'form', { class: 'handoff', hidden: true } );
		this.formText = el( 'p', { class: 'note' } );
		this.email = el( 'input', {
			type: 'email',
			required: true,
			placeholder: s.email,
			'aria-label': s.email,
			autocomplete: 'email',
		} );
		this.name = el( 'input', {
			type: 'text',
			placeholder: s.name,
			'aria-label': s.name,
			autocomplete: 'name',
		} );
		this.noteInput = el( 'textarea', {
			rows: 2,
			placeholder: s.note,
			'aria-label': s.note,
			maxlength: 1000,
		} );
		const row = el( 'div', { class: 'row' } );
		const cancel = el(
			'button',
			{ class: 'btn quiet', type: 'button' },
			s.cancel
		);
		cancel.addEventListener( 'click', () => this.setMode( 'chat' ) );
		this.submitButton = el(
			'button',
			{ class: 'btn', type: 'submit' },
			s.submit
		);
		row.append( cancel, this.submitButton );
		form.append(
			this.formText,
			this.email,
			this.name,
			this.noteInput,
			row
		);
		form.addEventListener( 'submit', ( event ) => {
			event.preventDefault();
			this.handoff();
		} );
		return form;
	}

	toggle( open = this.panel.hidden ) {
		this.panel.hidden = ! open;
		this.launcher.setAttribute( 'aria-expanded', String( open ) );
		this.launcher.setAttribute(
			'aria-label',
			open ? this.s.close : this.s.open
		);
		if ( open ) {
			if ( this.state.unread ) {
				// Opened to read them: they count as seen, so they aren't emailed.
				this.state.unread = 0;
				this.badge();
				this.save();
			}
			// Check now, and at the open pace rather than the closed one.
			this.listen();
			this.loadTurnstile();
			this.scroll();
			( this.state.mode === 'form' ? this.email : this.input ).focus();
		} else {
			this.launcher.focus();
		}
	}

	grow() {
		this.input.style.height = 'auto';
		this.input.style.height =
			Math.min( this.input.scrollHeight, 120 ) + 'px';
	}

	scroll() {
		this.log.scrollTop = this.log.scrollHeight;
	}

	bubble( message ) {
		if ( message.who === 'visitor' ) {
			return el( 'div', { class: 'msg visitor' }, message.text );
		}
		if ( message.who === 'note' ) {
			return el( 'p', { class: 'msg note' }, message.text );
		}
		const node = el( 'div', { class: 'msg bot' } );
		if ( message.who === 'team' ) {
			node.append(
				el( 'p', { class: 'from' }, message.name || this.s.team )
			);
		}
		if ( message.html ) {
			// Sanitized on the server (wp_kses, AgentService::REPLY_TAGS).
			const body = el( 'div' );
			body.innerHTML = message.html;
			node.append( body );
			node.querySelectorAll( 'a' ).forEach( ( a ) => {
				a.target = '_blank';
				a.rel = 'noopener';
			} );
		} else {
			node.textContent = message.text;
		}
		if ( message.sources && message.sources.length ) {
			const list = el( 'div', { class: 'sources' }, this.s.sources );
			message.sources.forEach( ( source ) => {
				list.append(
					el(
						'a',
						{ href: source.url, target: '_blank', rel: 'noopener' },
						source.title || source.url
					)
				);
			} );
			node.append( list );
		}
		return node;
	}

	paint() {
		this.log.replaceChildren(
			this.bubble( { who: 'bot', text: config.greeting } ),
			...this.state.messages.map( ( message ) => this.bubble( message ) )
		);
		this.setMode( this.state.mode );
		this.scroll();
	}

	setMode( mode ) {
		this.state.mode = mode;
		this.form.hidden = mode !== 'form';
		// The form replaces the composer while it's open.
		this.composer.hidden = mode === 'form';
		// Live, the button offers to leave an email too.
		this.personButton.textContent =
			this.state.live && ! this.state.email
				? this.s.email
				: this.s.person;
		this.personButton.hidden =
			! this.state.id ||
			mode !== 'chat' ||
			( this.state.live && !! this.state.email );
		this.restartButton.hidden = ! this.state.id || mode === 'form';
		this.save();
	}

	add( message ) {
		this.state.messages.push( message );
		this.log.insertBefore(
			this.bubble( message ),
			this.typingNode.isConnected ? this.typingNode : null
		);
		this.save();
		this.scroll();
	}

	showForm( text ) {
		// After the agent's own handoff line the form needs no words of its own.
		this.formText.textContent = text;
		this.formText.hidden = ! text;
		this.setMode( 'form' );
		this.email.focus();
		window.requestAnimationFrame( () => this.scroll() );
	}

	restart() {
		this.state = fresh();
		this.save();
		this.paint();
		this.input.focus();
	}

	async post( path, body ) {
		const response = await window.fetch( config.rest + path, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			credentials: 'omit',
			body: JSON.stringify( body ),
		} );
		const data = await response.json().catch( () => ( {} ) );
		if ( ! response.ok ) {
			const error = new Error( data.message || this.s.error );
			error.code = data.code;
			throw error;
		}
		return data;
	}

	async send() {
		const text = this.input.value.trim();
		if ( ! text || this.busy ) {
			return;
		}
		this.busy = true;
		this.sendButton.disabled = true;
		this.input.value = '';
		this.grow();
		this.add( { who: 'visitor', text } );

		const thinking = el(
			'div',
			{ class: 'msg bot thinking' },
			this.s.thinking
		);
		this.log.append( thinking );
		this.scroll();

		try {
			const data = await this.post( '', {
				message: text,
				id: this.state.id,
				token: this.state.token,
				hp: this.hp.value,
				turnstile: this.state.id ? '' : this.turnstileToken,
				// Where a new chat started; the team sees it beside the chat.
				page: this.state.id ? '' : window.location.href,
			} );
			thinking.remove();
			this.state.id = data.id;
			this.state.token = data.token;
			const wasLive = this.state.live;
			if ( data.live ) {
				this.state.live = true;
			}
			if ( data.answer ) {
				this.add( {
					who: 'bot',
					html: data.answer.html,
					sources: data.answer.sources,
				} );
			} else if ( data.waiting ) {
				// Live, the person reads along; no note on every message.
				if ( ! data.live ) {
					this.add( { who: 'note', text: this.s.waiting } );
				}
			} else if ( data.handoff && data.live ) {
				this.add( { who: 'bot', text: this.s.live } );
			} else if ( data.handoff ) {
				const words =
					this.s[
						data.handoff === 'person' ? 'handoff' : data.handoff
					] || this.s.unsure;
				this.add( {
					who: 'bot',
					text: data.promise ? words + ' ' + data.promise : words,
				} );
				this.showForm( this.s.replyTo );
			}
			this.setMode( this.state.mode );
			if ( this.state.live && ! wasLive ) {
				this.listen();
			}
		} catch ( error ) {
			thinking.remove();
			if ( error.code === 'bridle_chat_gone' ) {
				this.state = fresh();
				this.paint();
			}
			this.add( { who: 'note', text: error.message } );
		} finally {
			this.busy = false;
			this.sendButton.disabled = false;
			this.resetTurnstile();
		}
	}

	/*
	 * "Talk to a person": live when a person is here (config.live and the
	 * server agrees), else the email form. Live already, it asks for an
	 * email in case the visitor leaves.
	 */
	async askPerson() {
		if ( ! config.live || this.state.live ) {
			this.showForm( this.state.live ? this.s.leaveEmail : this.s.ask );
			return;
		}
		if ( this.busy ) {
			return;
		}
		this.busy = true;
		try {
			const data = await this.post( '/handoff', {
				id: this.state.id,
				token: this.state.token,
				live: true,
			} );
			if ( ! data.live ) {
				throw new Error( 'offline' );
			}
			this.state.live = true;
			this.add( { who: 'bot', text: this.s.live } );
			this.setMode( 'chat' );
			this.listen();
			this.input.focus();
		} catch {
			this.showForm( this.s.ask );
		} finally {
			this.busy = false;
		}
	}

	async handoff() {
		if ( this.busy ) {
			return;
		}
		this.busy = true;
		this.submitButton.disabled = true;
		try {
			const data = await this.post( '/handoff', {
				id: this.state.id,
				token: this.state.token,
				email: this.email.value.trim(),
				name: this.name.value.trim(),
				message: this.noteInput.value.trim(),
			} );
			this.state.email = data.email;
			this.noteInput.value = '';
			this.setMode( 'done' );
			this.add( {
				who: 'note',
				text: this.s.sent
					.replace( '%1$s', data.promise || '' )
					.replace( '%2$s', data.email ),
			} );
			this.listen();
		} catch ( error ) {
			this.formText.textContent = error.message;
		} finally {
			this.busy = false;
			this.submitButton.disabled = false;
		}
	}

	loadTurnstile() {
		if ( ! config.turnstile || this.turnstileLoaded ) {
			return;
		}
		this.turnstileLoaded = true;
		const box = el( 'div', { slot: 'turnstile' } );
		this.append( box );
		window.bridleChatTurnstile = () => {
			this.turnstileId = window.turnstile.render( box, {
				sitekey: config.turnstile,
				appearance: 'interaction-only',
				callback: ( token ) => ( this.turnstileToken = token ),
			} );
		};
		const script = el( 'script', {
			src: 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit&onload=bridleChatTurnstile',
			async: true,
			defer: true,
		} );
		document.head.append( script );
	}

	resetTurnstile() {
		if ( window.turnstile && this.turnstileId !== undefined ) {
			this.turnstileToken = '';
			window.turnstile.reset( this.turnstileId );
		}
	}
}

if ( config && ! window.customElements.get( 'bridle-chat' ) ) {
	window.customElements.define( 'bridle-chat', BridleChat );
	const mount = () => document.body.append( el( 'bridle-chat' ) );
	if ( document.body ) {
		mount();
	} else {
		document.addEventListener( 'DOMContentLoaded', mount );
	}
}
