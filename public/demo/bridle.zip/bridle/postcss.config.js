/**
 * PostCSS for the @wordpress/scripts build.
 *
 * Tailwind v4 compiles src/app/styles/app.css, the admin app's one stylesheet.
 */
module.exports = {
	plugins: {
		'@tailwindcss/postcss': {},
	},
};
