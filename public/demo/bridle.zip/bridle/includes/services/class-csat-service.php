<?php

namespace Bridle\Services;

use Bridle\Models\Conversation;
use Bridle\Models\Rating;
use Bridle\Models\Inbox;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CSAT collection. When a conversation closes, we send the customer a
 * short email with four one-click rating links (Great / Good / Okay /
 * Bad). Each link is a token-signed URL hitting the public rating page
 * (?bridle_rate=<id>&t=<token>&r=<1..4>), which records the rating and
 * displays a small confirmation.
 *
 * Disable per-inbox via `inboxes.satisfaction_enabled = 0`.
 */
class CsatService {

	public const ENDPOINT_QUERY = 'bridle_rate';

	public static function init_hooks(): void {
		add_action( 'bridle_conversation_closed', [ self::class, 'send_request' ] );

		// Public-facing rating endpoint. Hooked early so it runs before
		// theme template loading and exits without rendering theme chrome.
		add_action( 'init',           [ self::class, 'register_endpoint' ] );
		add_action( 'parse_request',  [ self::class, 'maybe_handle_request' ] );
	}

	public static function send_request( int $conversation_id ): void {
		$conv = ( new Conversation() )->get_by_id( $conversation_id );
		if ( ! $conv || ! $conv->customer_id ) {
			return;
		}

		$inbox = $conv->inbox_id ? ( new Inbox() )->get_by_id( (int) $conv->inbox_id ) : null;
		if ( $inbox && isset( $inbox->satisfaction_enabled ) && ! (int) $inbox->satisfaction_enabled ) {
			return;
		}

		// Already rated? Don't pester.
		if ( ( new Rating() )->get_for_conversation( $conversation_id ) ) {
			return;
		}

		global $wpdb;
		$customer_email = (string) $wpdb->get_var( $wpdb->prepare(
			'SELECT email FROM %i WHERE id = %d',
			$wpdb->prefix . 'bridle_customers',
			$conv->customer_id
		) );
		if ( ! is_email( $customer_email ) ) {
			return;
		}

		$token   = Rating::make_token( $conversation_id );
		$subject = sprintf(
			/* translators: %s conversation subject. */
			__( 'How did we do? — %s', 'bridle' ),
			$conv->subject ?: __( 'your support request', 'bridle' )
		);

		$body = self::render_email( $conversation_id, $token, $inbox );

		$headers = [ 'Content-Type: text/html; charset=UTF-8' ];
		wp_mail( $customer_email, $subject, $body, $headers );
	}

	private static function render_email( int $conversation_id, string $token, ?object $inbox ): string {
		$labels = [
			4 => '😍 ' . __( 'Great', 'bridle' ),
			3 => '🙂 ' . __( 'Good',  'bridle' ),
			2 => '😐 ' . __( 'Okay',  'bridle' ),
			1 => '☹️ '  . __( 'Bad',   'bridle' ),
		];

		$buttons = '';
		foreach ( $labels as $score => $label ) {
			$url = add_query_arg( [
				self::ENDPOINT_QUERY => $conversation_id,
				't'                  => $token,
				'r'                  => $score,
			], home_url( '/' ) );
			$buttons .= sprintf(
				'<a href="%s" style="display:inline-block;margin:0 6px;padding:10px 18px;border-radius:8px;background:#F8F8F6;border:1px solid #E5E5E5;color:#0F1A14;text-decoration:none;font-family:-apple-system,BlinkMacSystemFont,Inter,sans-serif;font-size:14px;font-weight:600;">%s</a>',
				esc_url( $url ),
				esc_html( $label )
			);
		}

		$intro = __( 'Could you take a second to tell us how it went? One click is enough.', 'bridle' );

		return '<div style="font-family:-apple-system,BlinkMacSystemFont,Inter,sans-serif;color:#0F1A14;line-height:1.55;">'
			. '<p>' . esc_html( $intro ) . '</p>'
			. '<p style="margin:24px 0;">' . $buttons . '</p>'
			. '<p style="color:#9C9C9C;font-size:12px;">'
			. esc_html__( 'If this rating link wasn\'t for you, just ignore this email.', 'bridle' )
			. '</p></div>';
	}

	/** Register the query var WP uses to route /?bridle_rate=… requests. */
	public static function register_endpoint(): void {
		add_rewrite_endpoint( self::ENDPOINT_QUERY, EP_ROOT );
	}

	/**
	 * If the public URL carries our query string, record the rating and
	 * show a short confirmation page.
	 */
	public static function maybe_handle_request(): void {
		// A customer clicks this link from their mailbox, so there is no
		// session or nonce to check. The HMAC token in `t`, bound to the
		// conversation id and verified with hash_equals() below, authenticates it.
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- see above.
		if ( ! isset( $_GET[ self::ENDPOINT_QUERY ] ) ) {
			return;
		}

		$conversation_id = absint( $_GET[ self::ENDPOINT_QUERY ] );
		$token           = isset( $_GET['t'] ) ? sanitize_text_field( wp_unslash( $_GET['t'] ) ) : '';
		$rating          = isset( $_GET['r'] ) ? absint( $_GET['r'] ) : 0;

		if ( ! $conversation_id || ! Rating::verify_token( $conversation_id, $token ) ) {
			self::render_page( __( 'This rating link isn\'t valid.', 'bridle' ), false );
		}

		// phpcs:enable WordPress.Security.NonceVerification.Recommended
		if ( $rating >= 1 && $rating <= 4 ) {
			( new Rating() )->record( $conversation_id, $rating );
		}

		self::render_page( __( 'Thanks for the feedback. We appreciate it.', 'bridle' ), true );
	}

	/** WordPress's own message page; it ends the request. */
	private static function render_page( string $message, bool $ok ): void {
		nocache_headers();
		wp_die(
			esc_html( $message ),
			esc_html__( 'Rating', 'bridle' ),
			[ 'response' => $ok ? 200 : 403 ]
		);
	}
}
