<?php
/**
 * Bridle AI: answers without the site's own AI key, from PlugPress's service
 * (owner decisions, 2026-11-02). Opt-in; the site's own key always wins.
 *
 * @package Bridle
 */

namespace Bridle\Services;

use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * The client for the bridle-ai worker: sign up (the site proves itself by
 * echoing a nonce), ask for an answer, give back one that failed Bridle's
 * checks, read the balance and start a checkout for a pack.
 */
class BridleAi {

	/** { key, email, on, balance, balance_at }. The key never leaves the server. */
	public const OPTION = 'bridle_ai';

	private const NONCE = 'bridle_ai_signup_nonce';

	/** Packs and their prices, as the worker and Polar sell them. */
	public const PACKS = [
		'1k'  => [
			'answers' => 1000,
			'price'   => '$10',
		],
		'5k'  => [
			'answers' => 5000,
			'price'   => '$45',
		],
		'25k' => [
			'answers' => 25000,
			'price'   => '$200',
		],
	];

	/** The service's address; BRIDLE_AI_URL in wp-config.php points at a dev worker. */
	public static function url(): string {
		return untrailingslashit( defined( 'BRIDLE_AI_URL' ) ? (string) BRIDLE_AI_URL : 'https://bridle-ai.plugpress.workers.dev' );
	}

	private static function stored(): array {
		$stored = get_option( self::OPTION, [] );
		return is_array( $stored ) ? $stored : [];
	}

	/** Signed up and switched on. */
	public static function active(): bool {
		$stored = self::stored();
		return ! empty( $stored['on'] ) && '' !== (string) ( $stored['key'] ?? '' );
	}

	/** What Settings shows. */
	public static function status(): array {
		$stored = self::stored();
		return [
			'active'  => self::active(),
			'email'   => (string) ( $stored['email'] ?? '' ),
			'balance' => self::active() ? self::balance() : null,
			'packs'   => self::PACKS,
		];
	}

	/**
	 * Sign up (or sign in again) and switch Bridle AI on.
	 *
	 * @return array|WP_Error status()
	 */
	public static function sign_up( string $email ) {
		$email = sanitize_email( $email );
		if ( ! is_email( $email ) ) {
			return new WP_Error( 'bridle_ai_email', __( 'Enter an email for receipts.', 'bridle' ), [ 'status' => 400 ] );
		}

		$nonce = wp_generate_password( 32, false );
		set_transient( self::NONCE, $nonce, 5 * MINUTE_IN_SECONDS );
		$response = self::post(
			'/v1/sites',
			[
				'site_url'   => home_url(),
				'email'      => $email,
				'verify_url' => rest_url( BRIDLE_REST_NAMESPACE . '/ai/bridle/verify' ),
				'nonce'      => $nonce,
			],
			''
		);
		delete_transient( self::NONCE );
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		update_option(
			self::OPTION,
			[
				'key'        => (string) ( $response['key'] ?? '' ),
				'email'      => $email,
				'on'         => true,
				'balance'    => self::balance_of( $response ),
				'balance_at' => time(),
			],
			false
		);
		self::forget_ai_cache();
		return self::status();
	}

	/** Switch off; the key and balance stay, so switching on again needs no sign-up. */
	public static function turn_off(): array {
		$stored       = self::stored();
		$stored['on'] = false;
		update_option( self::OPTION, $stored, false );
		self::forget_ai_cache();
		return self::status();
	}

	/** Switch on again with the stored key, or sign up. */
	public static function turn_on( string $email ) {
		$stored = self::stored();
		if ( '' !== (string) ( $stored['key'] ?? '' ) && ( '' === $email || ( $stored['email'] ?? '' ) === $email ) ) {
			$stored['on'] = true;
			update_option( self::OPTION, $stored, false );
			self::forget_ai_cache();
			return self::status();
		}
		return self::sign_up( $email );
	}

	/** The nonce a pending sign-up is waiting to be asked for, or ''. */
	public static function pending_nonce(): string {
		return (string) get_transient( self::NONCE );
	}

	/**
	 * Free answers left, the free total and paid credits; cached ten minutes.
	 *
	 * @return array{month: string, free_left: int, free_total: int, credits: int}|null
	 */
	public static function balance( bool $refresh = false ): ?array {
		$stored = self::stored();
		if ( '' === (string) ( $stored['key'] ?? '' ) ) {
			return null;
		}
		if ( ! $refresh && ! empty( $stored['balance'] ) && time() - (int) ( $stored['balance_at'] ?? 0 ) < 10 * MINUTE_IN_SECONDS ) {
			return $stored['balance'];
		}
		$response = self::request( 'GET', '/v1/balance' );
		if ( is_wp_error( $response ) ) {
			return $stored['balance'] ?? null;
		}
		self::remember_balance( $response );
		return self::balance_of( $response );
	}

	/** Whether there is anything left to answer with (as last seen). */
	public static function has_answers(): bool {
		$balance = self::balance();
		return null === $balance || (int) $balance['free_left'] + (int) $balance['credits'] > 0;
	}

	/**
	 * Ask for an answer.
	 *
	 * @param array|null $schema JSON schema for the answer.
	 * @return array{id: string, text: string}|WP_Error
	 */
	public static function generate( string $system, string $prompt, ?array $schema = null ) {
		$response = self::request(
			'POST',
			'/v1/answer',
			[
				'system' => $system,
				'prompt' => $prompt,
				'schema' => $schema,
			],
			60
		);
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		self::remember_balance( $response );
		return [
			'id'   => (string) ( $response['id'] ?? '' ),
			'text' => (string) ( $response['text'] ?? '' ),
		];
	}

	/** Give back an answer that failed Bridle's checks ("only checked answers count"). */
	public static function refund( string $answer_id ): void {
		if ( '' === $answer_id || ! preg_match( '/^[0-9a-f-]{36}$/', $answer_id ) ) {
			return;
		}
		self::request( 'POST', '/v1/answers/' . $answer_id . '/refund', [], 5, false );
	}

	/**
	 * A Polar checkout for a pack, for this site.
	 *
	 * @return string|WP_Error The checkout URL.
	 */
	public static function checkout( string $pack ) {
		if ( ! isset( self::PACKS[ $pack ] ) ) {
			return new WP_Error( 'bridle_ai_pack', __( 'Unknown pack.', 'bridle' ), [ 'status' => 400 ] );
		}
		$response = self::request( 'POST', '/v1/checkout', [ 'pack' => $pack ] );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$url = esc_url_raw( (string) ( $response['url'] ?? '' ) );
		return '' !== $url ? $url : new WP_Error( 'bridle_ai_checkout', __( 'The checkout couldn’t start.', 'bridle' ), [ 'status' => 502 ] );
	}

	private static function balance_of( array $data ): array {
		return [
			'month'      => (string) ( $data['month'] ?? '' ),
			'free_left'  => (int) ( $data['free_left'] ?? 0 ),
			'free_total' => (int) ( $data['free_total'] ?? 0 ),
			'credits'    => (int) ( $data['credits'] ?? 0 ),
		];
	}

	private static function remember_balance( array $data ): void {
		if ( ! isset( $data['free_left'] ) ) {
			return;
		}
		$stored               = self::stored();
		$stored['balance']    = self::balance_of( $data );
		$stored['balance_at'] = time();
		update_option( self::OPTION, $stored, false );
	}

	/** can_use_ai() caches its answer for the request; a switch changes it. */
	private static function forget_ai_cache(): void {
		AiService::reset();
	}

	private static function post( string $path, array $body, string $key ) {
		return self::request( 'POST', $path, $body, 20, true, $key );
	}

	/**
	 * One call to the service, with the site key unless another is given.
	 *
	 * @return array|WP_Error The decoded JSON body.
	 */
	private static function request( string $method, string $path, array $body = [], int $timeout = 20, bool $blocking = true, ?string $key = null ) {
		$key  = $key ?? (string) ( self::stored()['key'] ?? '' );
		$args = [
			'method'   => $method,
			'timeout'  => $timeout,
			'blocking' => $blocking,
			'headers'  => array_filter(
				[
					'Content-Type'  => 'application/json',
					'Authorization' => '' !== $key ? 'Bearer ' . $key : '',
				]
			),
		];
		if ( 'GET' !== $method ) {
			$args['body'] = wp_json_encode( $body );
		}
		$response = wp_remote_request( self::url() . $path, $args );
		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'bridle_ai_unreachable', __( 'Bridle AI can’t be reached right now.', 'bridle' ), [ 'status' => 502 ] );
		}
		if ( ! $blocking ) {
			return [];
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		$data = is_array( $data ) ? $data : [];
		if ( $code >= 200 && $code < 300 ) {
			return $data;
		}
		if ( 402 === $code ) {
			self::remember_balance( $data );
			return new WP_Error( 'bridle_ai_empty', __( 'No Bridle AI answers left this month.', 'bridle' ), [ 'status' => 402 ] );
		}
		return new WP_Error(
			'bridle_ai_' . sanitize_key( (string) ( $data['code'] ?? 'failed' ) ),
			sanitize_text_field( (string) ( $data['message'] ?? __( 'Bridle AI didn’t answer.', 'bridle' ) ) ),
			[ 'status' => $code ? $code : 502 ]
		);
	}
}
