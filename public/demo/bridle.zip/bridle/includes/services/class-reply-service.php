<?php

namespace Bridle\Services;

use Bridle\Models\Attachment;
use Bridle\Models\Conversation;
use Bridle\Models\Draft;
use Bridle\Models\Thread;
use WP_Error;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The one way a reply or note is added to a conversation: the composer
 * (REST), the agent and external agents (Abilities) all come through here,
 * so storing, draft clean-up, the thread hook (which sends the email) and
 * agent-draft bookkeeping happen identically for all of them.
 */
class ReplyService {

	/**
	 * @param array $args {
	 *     @type string $content          Plain text. Required.
	 *     @type string $content_html     HTML body.
	 *     @type string $thread_type      'reply' (default) or 'note'. Notes are always private.
	 *     @type bool   $is_private       Store a reply without emailing it.
	 *     @type string $author_type      'teammate' (default) or 'agent'.
	 *     @type int    $author_id        WP user id; defaults to the current user. For the
	 *                                    agent: 0 (Bridle's own) or the user an external agent acts for.
	 *     @type int[]  $attachment_ids   Uploaded attachment rows to claim.
	 *     @type bool   $from_agent_draft The reply started from the agent draft.
	 *     @type array  $agent            Who wrote it, for agent threads: [ source, client, via, auto ].
	 * }
	 * @return object|WP_Error The stored thread.
	 */
	public static function add( int $conversation_id, array $args ) {
		$conversation = ( new Conversation() )->get_by_id( $conversation_id );
		if ( ! $conversation ) {
			return new WP_Error( 'bridle_not_found', __( 'Conversation not found.', 'bridle' ), [ 'status' => 404 ] );
		}

		$content = (string) ( $args['content'] ?? '' );
		if ( '' === trim( $content ) ) {
			return new WP_Error( 'bridle_missing_content', __( 'Content is required.', 'bridle' ), [ 'status' => 400 ] );
		}

		$is_note     = 'note' === ( $args['thread_type'] ?? 'reply' );
		$is_agent    = 'agent' === ( $args['author_type'] ?? '' );
		$author_id   = (int) ( $args['author_id'] ?? ( $is_agent ? 0 : get_current_user_id() ) );
		$html        = isset( $args['content_html'] ) ? (string) $args['content_html'] : null;
		$from_draft  = ! $is_note && ! empty( $args['from_agent_draft'] ) ? AgentService::get_draft( $conversation_id ) : null;
		$agent_draft = $from_draft && 'ready' === ( $from_draft['meta']['status'] ?? '' ) ? $from_draft : null;
		$agent       = $is_agent ? (array) ( $args['agent'] ?? [] ) : null;
		$sent        = (string) ( $html ?? $content );

		$thread_model = new Thread();
		$thread_id    = $thread_model->create(
			[
				'conversation_id' => $conversation_id,
				'author_type'     => $is_agent ? 'agent' : 'teammate',
				'author_id'       => $author_id ? $author_id : null,
				'thread_type'     => $is_note ? 'note' : 'reply',
				'content'         => $content,
				'content_html'    => $html,
				'is_private'      => $is_note || ! empty( $args['is_private'] ) ? 1 : 0,
				'ai_generated'    => $agent_draft || $is_agent ? 1 : 0,
				'ai_sources'      => $agent_draft || $is_agent ? self::provenance( $agent_draft, $sent, $agent ) : null,
			]
		);

		if ( ! $thread_id ) {
			return new WP_Error( 'bridle_create_error', __( 'Could not create thread.', 'bridle' ), [ 'status' => 500 ] );
		}

		if ( ! empty( $args['attachment_ids'] ) && is_array( $args['attachment_ids'] ) ) {
			( new Attachment() )->link_to_thread( $args['attachment_ids'], $thread_id );
		}

		( new Conversation() )->update( $conversation_id, [ 'last_activity_at' => current_time( 'mysql', true ) ] );

		// An external agent acting for a teammate must not wipe that
		// teammate's own half-written reply.
		if ( $author_id && ! $is_agent ) {
			( new Draft() )->delete( $conversation_id, $author_id );
		}
		if ( $agent_draft ) {
			( new Draft() )->delete( $conversation_id, AgentService::USER_ID );
		}
		if ( ! $is_note ) {
			$outcome = self::outcome( $agent_draft, $sent, $agent );
			if ( $outcome ) {
				AgentService::record( $outcome );
			}
		}

		$thread = $thread_model->get_by_id( $thread_id );

		/**
		 * Fires after a thread is added to a conversation.
		 *
		 * @param int    $thread_id       The thread ID.
		 * @param int    $conversation_id The conversation ID.
		 * @param object $thread          The thread object.
		 */
		do_action( 'bridle_thread_added', $thread_id, $conversation_id, $thread );

		return $thread;
	}

	/** Throw away the agent draft (a teammate chose not to use it). */
	public static function discard_agent_draft( int $conversation_id ): bool {
		$draft = AgentService::get_draft( $conversation_id );
		if ( ! $draft ) {
			return false;
		}

		( new Draft() )->delete( $conversation_id, AgentService::USER_ID );
		if ( 'ready' === ( $draft['meta']['status'] ?? '' ) ) {
			AgentService::record( 'discarded' );
		}

		return true;
	}

	/**
	 * Did the teammate change the agent's words before sending? Compares
	 * visible text only, so formatting-only differences don't count.
	 */
	public static function is_edited( string $sent, string $drafted ): bool {
		// Tags become spaces first, so "<p>a</p><p>b</p>" reads "a b", not "ab".
		$flatten = static fn( string $html ): string => mb_strtolower( trim( (string) preg_replace(
			'/\s+/u',
			' ',
			html_entity_decode( wp_strip_all_tags( (string) preg_replace( '/<[^>]*>/', ' ', $html ) ), ENT_QUOTES | ENT_HTML5, 'UTF-8' )
		) ) );

		return $flatten( $sent ) !== $flatten( $drafted );
	}

	/**
	 * What threads.ai_sources records about a reply or note an AI had a hand
	 * in: who sent it (a teammate starting from the draft, Bridle's own
	 * agent, or an external agent and through what), and what it stood on.
	 *
	 * @param array|null $draft The agent draft it came from, if any.
	 * @param string     $sent  What was actually stored.
	 * @param array|null $agent For agent threads: [ source, client, via, auto ].
	 */
	public static function provenance( ?array $draft, string $sent, ?array $agent = null ): array {
		$meta = $draft['meta'] ?? [];
		$out  = [
			'sent_by' => null === $agent ? 'teammate' : ( 'external' === ( $agent['source'] ?? $meta['source'] ?? '' ) ? 'external' : 'agent' ),
		];

		if ( $draft ) {
			$out += [
				'edited'      => self::is_edited( $sent, (string) $draft['content'] ),
				'confidence'  => $meta['confidence'] ?? null,
				'verified'    => $meta['verified'] ?? null,
				'grounded_in' => $meta['grounded_in'] ?? [],
			];
		}

		if ( null !== $agent ) {
			$out += array_filter(
				[
					'client'  => (string) ( $agent['client'] ?? $meta['client'] ?? '' ),
					'via'     => (string) ( $agent['via'] ?? $meta['via'] ?? '' ),
					'user_id' => (int) ( $agent['user_id'] ?? $meta['user_id'] ?? 0 ),
					'auto'    => $agent['auto'] ?? null,
				],
				static fn( $v ) => null !== $v && '' !== $v && 0 !== $v
			);
		}

		return $out;
	}

	/**
	 * The track-record outcome of a reply, or null when the agent had no
	 * part in it.
	 */
	public static function outcome( ?array $draft, string $sent, ?array $agent ): ?string {
		if ( null !== $agent ) {
			return 'external' === ( $agent['source'] ?? $draft['meta']['source'] ?? '' ) ? 'sent_by_external' : 'sent_by_agent';
		}
		if ( ! $draft ) {
			return null;
		}

		return self::is_edited( $sent, (string) $draft['content'] ) ? 'sent_edited' : 'sent_unedited';
	}
}
