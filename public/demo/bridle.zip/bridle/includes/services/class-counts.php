<?php

namespace Bridle\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Conversation counts for the WordPress admin chrome.
 *
 * These drive the bubble on the Bridle menu item and the admin-bar node — the
 * only way an agent learns mail is waiting without already being inside the
 * workspace.
 *
 * Cached, and deliberately so. "Awaiting reply" needs the last thread's author,
 * which is not a column but a correlated subquery (Models\Conversation::list()),
 * and this runs on EVERY admin page load for every logged-in agent. Comments
 * has the same problem and solves it the same way (wp_count_comments is
 * cached). The cache is busted on the four events that can change a count, with
 * a short TTL as a backstop for anything writing to the tables directly.
 */
class Counts {

	/** Per-user, because "assigned to me" is. */
	private const CACHE_PREFIX = 'bridle_chrome_counts_';

	/** Backstop only — the hooks below do the real invalidation. */
	private const TTL = 300;

	/**
	 * Wire cache invalidation. Called from Plugin::init().
	 */
	public static function init_hooks(): void {
		foreach ( [
			'bridle_conversation_created',
			'bridle_conversation_updated',
			'bridle_conversation_closed',
			'bridle_thread_added',
		] as $hook ) {
			add_action( $hook, [ self::class, 'flush' ], 10, 0 );
		}
	}

	/**
	 * Counts for the current user's admin chrome.
	 *
	 * @return array{open:int,awaiting:int,unassigned:int,mine:int}
	 */
	public static function for_chrome( ?int $user_id = null ): array {
		$user_id = $user_id ?: get_current_user_id();
		if ( ! $user_id ) {
			return self::empty_counts();
		}

		$key    = self::CACHE_PREFIX . $user_id;
		$cached = get_transient( $key );
		if ( is_array( $cached ) ) {
			/** This filter is documented below. */
			return (array) apply_filters( 'bridle_chrome_counts', $cached, $user_id );
		}

		$counts = self::query( $user_id );
		set_transient( $key, $counts, self::TTL );

		/**
		 * Filter the counts shown in the admin bar and menu bubble.
		 *
		 * @param array $counts  open / awaiting / unassigned / mine.
		 * @param int   $user_id User the counts were computed for.
		 */
		return (array) apply_filters( 'bridle_chrome_counts', $counts, $user_id );
	}

	/**
	 * Drop every user's cached counts.
	 *
	 * A conversation changing state can affect any agent's numbers, not just
	 * the one who changed it, so this cannot be scoped to the current user.
	 */
	public static function flush(): void {
		global $wpdb;

		// Transients live in options (or an object cache). With a persistent
		// object cache there is nothing to scan, so bump a namespace instead —
		// but WordPress gives no portable way to enumerate transients, and the
		// TTL keeps the worst case bounded at five minutes either way.
		$like = $wpdb->esc_like( '_transient_' . self::CACHE_PREFIX ) . '%';
		$keys = $wpdb->get_col( $wpdb->prepare( 'SELECT option_name FROM %i WHERE option_name LIKE %s', $wpdb->options, $like ) );

		foreach ( (array) $keys as $option_name ) {
			delete_transient( str_replace( '_transient_', '', $option_name ) );
		}

		if ( wp_using_ext_object_cache() ) {
			// Nothing enumerable; the current user is the common case and the
			// TTL covers the rest.
			delete_transient( self::CACHE_PREFIX . get_current_user_id() );
		}
	}

	private static function empty_counts(): array {
		return [
			'open'       => 0,
			'awaiting'   => 0,
			'unassigned' => 0,
			'mine'       => 0,
		];
	}

	/**
	 * One round trip for all four numbers.
	 *
	 * "Awaiting" means the newest thread came from the customer — i.e. the ball
	 * is in our court. That is the same rule the workspace's "Needs reply" sort
	 * uses, so the bubble and the list agree.
	 */
	private static function query( int $user_id ): array {
		global $wpdb;

		$feed = \Bridle\Models\Conversation::FEED_SQL;

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- FEED_SQL is a constant fragment; the tables and values are bound.
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT
				COUNT(*) AS open_count,
				SUM( CASE WHEN c.assigned_to IS NULL THEN 1 ELSE 0 END ) AS unassigned_count,
				SUM( CASE WHEN c.assigned_to = %d THEN 1 ELSE 0 END ) AS mine_count,
				SUM( CASE WHEN (
					SELECT t.author_type FROM %i t
					WHERE t.conversation_id = c.id AND t.is_private = 0
					ORDER BY t.id DESC LIMIT 1
				) = 'customer' THEN 1 ELSE 0 END ) AS awaiting_count
			FROM %i c
			LEFT JOIN %i cu ON c.customer_id = cu.id
			WHERE c.status = %s AND NOT ( {$feed} )",
			$user_id,
			$wpdb->prefix . 'bridle_threads',
			$wpdb->prefix . 'bridle_conversations',
			$wpdb->prefix . 'bridle_customers',
			'active'
		) );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter

		if ( ! $row ) {
			return self::empty_counts();
		}

		return [
			'open'       => (int) $row->open_count,
			'awaiting'   => (int) $row->awaiting_count,
			'unassigned' => (int) $row->unassigned_count,
			'mine'       => (int) $row->mine_count,
		];
	}
}
