<?php

namespace Bridle\Services;

use Bridle\Models\Conversation;
use Bridle\Models\Draft;
use Bridle\Models\Thread;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Runs the agent in the background: every new customer message in an inbox
 * whose agent mode isn't "off" gets a reply draft, without slowing the
 * webhook that delivered the mail.
 *
 * - Scheduling: Action Scheduler when it's installed, else WP-Cron. Both
 *   de-duplicate identical pending jobs.
 * - Locking: one job per conversation at a time (MySQL GET_LOCK). A busy
 *   lock re-queues the job a minute later. Where GET_LOCK isn't available
 *   (SQLite dev sites) the de-duplication above is the only guard.
 * - Retries: transient failures retry after 1, 5 and 15 minutes; then the
 *   agent draft is stored as failed so a teammate sees why.
 * - Freshness: if another customer message lands while drafting, the job
 *   runs again so the draft answers the newest message.
 *
 * In "auto" mode each fresh draft goes to AutoSend, which sends it after a
 * hold when it clears every guardrail.
 */
class AgentQueue {

	const HOOK = 'bridle_agent_draft';

	/** Seconds before retry 1, 2 and 3. */
	const RETRY_DELAYS = [ 60, 300, 900 ];

	/** Errors retrying can't fix. */
	const PERMANENT_ERRORS = [ 'bridle_ai_unavailable', 'bridle_not_found', 'bridle_ai_empty' ];

	public static function init_hooks(): void {
		add_action( 'bridle_thread_added', [ self::class, 'on_thread_added' ], 20, 2 );
		add_action( self::HOOK, [ self::class, 'run' ], 10, 2 );
	}

	/** Hook: a thread was stored. Queue a draft if the agent should answer it. */
	public static function on_thread_added( $thread_id, $conversation_id ): void {
		$thread = ( new Thread() )->get_by_id( (int) $thread_id );
		if ( ! $thread || 'customer' !== $thread->author_type ) {
			return;
		}

		if ( self::wants_draft( (int) $conversation_id ) ) {
			self::schedule( (int) $conversation_id );
		}
	}

	/**
	 * Should the agent draft for this conversation? Pure: all state comes in.
	 *
	 * @param string      $status      Conversation status.
	 * @param bool        $is_feed     Whether the conversation is in the Feed.
	 * @param string      $mode        The inbox's agent mode.
	 * @param string|null $last_author author_type of the newest public thread.
	 */
	public static function should_draft( string $status, bool $is_feed, string $mode, ?string $last_author ): bool {
		return 'active' === $status
			&& ! $is_feed
			&& in_array( $mode, [ 'draft', 'auto' ], true )
			&& 'customer' === $last_author;
	}

	/**
	 * Seconds to wait before retrying after an error, or null to give up.
	 *
	 * @param string $error_code WP_Error code.
	 * @param int    $attempt    Attempts already made (0 = the first run).
	 */
	public static function retry_delay( string $error_code, int $attempt ): ?int {
		if ( in_array( $error_code, self::PERMANENT_ERRORS, true ) ) {
			return null;
		}

		return self::RETRY_DELAYS[ $attempt ] ?? null;
	}

	/**
	 * @param bool $unique Skip if an identical job is already queued. A job
	 *                     re-queuing itself passes false: Action Scheduler
	 *                     counts the running job as identical, so a unique
	 *                     re-queue from inside it would be silently dropped.
	 */
	public static function schedule( int $conversation_id, int $attempt = 0, int $delay = 0, bool $unique = true ): void {
		$args = [ $conversation_id, $attempt ];

		if ( function_exists( 'as_schedule_single_action' ) ) {
			as_schedule_single_action( time() + $delay, self::HOOK, $args, 'bridle', $unique );
			return;
		}

		if ( ! $unique || ! wp_next_scheduled( self::HOOK, $args ) ) {
			wp_schedule_single_event( time() + $delay, self::HOOK, $args );
		}
	}

	/** Job: draft a reply for one conversation. */
	public static function run( $conversation_id, $attempt = 0 ): void {
		$conversation_id = (int) $conversation_id;
		$attempt         = (int) $attempt;

		$lock = self::lock( $conversation_id );
		if ( false === $lock ) {
			self::schedule( $conversation_id, $attempt, MINUTE_IN_SECONDS, false );
			return;
		}

		try {
			// Re-check: the mode, status or last speaker may have changed
			// since the job was queued.
			if ( ! self::wants_draft( $conversation_id ) ) {
				return;
			}

			$before = AgentService::newest_public_thread_id( $conversation_id );
			$result = AgentService::draft( $conversation_id );

			if ( is_wp_error( $result ) ) {
				$delay = self::retry_delay( (string) $result->get_error_code(), $attempt );
				if ( null === $delay ) {
					self::store_failure( $conversation_id, $result->get_error_message(), $attempt + 1 );
				} else {
					self::schedule( $conversation_id, $attempt + 1, $delay );
				}
				return;
			}

			if ( AgentService::newest_public_thread_id( $conversation_id ) !== $before ) {
				self::schedule( $conversation_id, 0, 0, false );
			} else {
				AutoSend::after_draft( $conversation_id );
			}
		} finally {
			self::unlock( $conversation_id, $lock );
		}
	}

	private static function wants_draft( int $conversation_id ): bool {
		global $wpdb;

		$conversation = ( new Conversation() )->get_by_id( $conversation_id );
		if ( ! $conversation || ! $conversation->inbox_id ) {
			return false;
		}

		$joins = Conversation::box_joins();
		$feed  = Conversation::box_sql( 'feed' );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- $feed and $joins are constant fragments (box_sql(), box_joins()); the tables and the id are bound.
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT ( {$feed} ) AS is_feed, lt.author_type AS last_author
			FROM %i c {$joins}
			WHERE c.id = %d",
			array_merge( [ $wpdb->prefix . 'bridle_conversations' ], Conversation::box_join_tables(), [ $conversation_id ] )
		) );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber

		return self::should_draft(
			(string) $conversation->status,
			! empty( $row->is_feed ),
			InboxAiSettings::agent_mode( (int) $conversation->inbox_id ),
			$row->last_author ?? null
		);
	}

	/** Keep the reason on the agent draft so the UI can show it and offer Retry. */
	private static function store_failure( int $conversation_id, string $message, int $attempts ): void {
		AgentService::record( 'failed' );
		( new Draft() )->upsert( $conversation_id, AgentService::USER_ID, '', 'reply', wp_json_encode( [
			'source'     => 'agent',
			'status'     => 'failed',
			'error'      => $message,
			'attempts'   => $attempts,
			'created_at' => current_time( 'mysql', true ),
		] ) );
	}

	/**
	 * @return bool|null True when locked, false when another job holds it,
	 *                   null when the database has no real GET_LOCK.
	 */
	public static function lock( int $conversation_id ): ?bool {
		global $wpdb;

		// The SQLite drop-in answers GET_LOCK with junk ("1=1"), so only a
		// genuine 1 or 0 counts.
		if ( defined( 'DB_ENGINE' ) && 'sqlite' === DB_ENGINE ) {
			return null;
		}

		$suppress = $wpdb->suppress_errors( true );
		$result   = $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK( %s, 0 )', self::lock_name( $conversation_id ) ) );
		$wpdb->suppress_errors( $suppress );

		if ( '1' === (string) $result ) {
			return true;
		}

		return '0' === (string) $result ? false : null;
	}

	public static function unlock( int $conversation_id, ?bool $lock ): void {
		global $wpdb;

		if ( true === $lock ) {
			$wpdb->query( $wpdb->prepare( 'SELECT RELEASE_LOCK( %s )', self::lock_name( $conversation_id ) ) );
		}
	}

	private static function lock_name( int $conversation_id ): string {
		return 'bridle_agent_' . get_current_blog_id() . '_' . $conversation_id;
	}
}
