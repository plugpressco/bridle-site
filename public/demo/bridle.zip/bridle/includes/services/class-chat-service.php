<?php
/**
 * Bridle Chat (#114): a visitor's chat on the website, answered by the agent
 * from the same knowledge as email drafts, handed to a person when it isn't sure.
 *
 * @package Bridle
 */

namespace Bridle\Services;

use Bridle\Models\Conversation;
use Bridle\Models\Customer;
use Bridle\Models\Inbox;
use Bridle\Models\Thread;
use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * Every chat is a conversation (channel `chat`) in the chosen inbox. It starts
 * Resolved, so an answered chat never waits in the Inbox; a handoff gives it
 * the visitor's email and reopens it, and the team replies by email. Rules
 * live in ChatPolicy; this class does the reading and writing.
 */
class ChatService {

	/** Cloudflare Turnstile keys, kept out of bridle_settings so the secret never reaches the app. */
	public const TURNSTILE_OPTION = 'bridle_chat_turnstile';

	// phpcs:ignore PluginCheck.CodeAnalysis.Offloading.OffloadedContent -- Turnstile's server-side verify API (readme, External services), called only when the owner adds keys; no asset is loaded from it.
	private const TURNSTILE_VERIFY = 'https://challenges.cloudflare.com/turnstile/v0/siteverify';

	/** The limits after the `bridle_chat_limits` filter. */
	public static function limits(): array {
		/**
		 * Filter Bridle Chat's limits (ChatPolicy::LIMITS). 0 turns one off.
		 *
		 * @param array $limits max_chars, per_chat, per_visitor_hour, chats_per_visitor_hour,
		 *                      handoffs_per_hour, answers_per_hour.
		 */
		return array_map( 'intval', array_merge( ChatPolicy::LIMITS, (array) apply_filters( 'bridle_chat_limits', ChatPolicy::LIMITS ) ) );
	}

	/** The inbox chats file into: the chosen one while active, else the first active inbox, else 0. */
	public static function inbox_id(): int {
		$inboxes = ( new Inbox() )->list( [ 'is_active' => 1 ] );
		$chosen  = absint( Settings::get( 'chat_inbox_id', 0 ) );
		foreach ( $inboxes as $inbox ) {
			if ( (int) $inbox->id === $chosen ) {
				return $chosen;
			}
		}
		return $inboxes ? (int) $inboxes[0]->id : 0;
	}

	/** Chat shows when it is switched on, has an inbox and an AI provider. */
	public static function ready(): bool {
		return (bool) Settings::get( 'chat_enabled', false ) && AiService::can_use_ai() && self::inbox_id() > 0;
	}

	/**
	 * Whether a browser on this origin may chat. Bridle answers its own
	 * site; an add-on (Bridle Pro) adds the other sites an owner lists.
	 *
	 * @param string $origin The request's Origin header ('' when none).
	 */
	public static function origin_allowed( string $origin ): bool {
		if ( ChatPolicy::same_site( $origin, self::hosts() ) ) {
			return true;
		}
		/**
		 * Whether Bridle Chat answers a browser on another site.
		 *
		 * @param bool   $allowed False: Bridle answers only its own site's pages.
		 * @param string $origin  The Origin header, e.g. https://shop.example.com.
		 */
		return (bool) apply_filters( 'bridle_chat_origin_allowed', false, $origin );
	}

	/** This site's hosts, as ChatPolicy::host() writes them. */
	public static function hosts(): array {
		return array_values( array_unique( array_filter( [ ChatPolicy::host( home_url() ), ChatPolicy::host( site_url() ) ] ) ) );
	}

	/** The request's Origin header, or ''. */
	public static function origin(): string {
		return (string) get_http_origin();
	}

	/**
	 * A chat the visitor's token opens, or null.
	 */
	public static function find( int $id, string $token ): ?object {
		$conversation = $id ? ( new Conversation() )->get_by_id( $id ) : null;
		if ( ! $conversation || 'chat' !== $conversation->channel || in_array( $conversation->status, [ 'spam', 'trash' ], true ) ) {
			return null;
		}
		return ChatPolicy::check_token( (string) $conversation->thread_id, $token, wp_salt( 'auth' ) ) ? $conversation : null;
	}

	/**
	 * A visitor's message: starts a chat or continues one, then answers it.
	 *
	 * @param array $input message, id, token, hp (honeypot), turnstile, page (where a new chat started).
	 * @return array|WP_Error { id, token, answer: {html, sources}|null, handoff: string|null, waiting: bool }
	 */
	public static function send( array $input ) {
		$limits = self::limits();
		$text   = ChatPolicy::clean( (string) ( $input['message'] ?? '' ), $limits['max_chars'], (string) ( $input['hp'] ?? '' ) );
		if ( null === $text ) {
			return new WP_Error( 'bridle_chat_message', __( 'That message can’t be sent.', 'bridle' ), [ 'status' => 400 ] );
		}
		if ( ChatPolicy::over( self::count( 'message' ), $limits['per_visitor_hour'] ) ) {
			return self::slow_down();
		}

		$conversation = null;
		if ( ! empty( $input['id'] ) ) {
			$conversation = self::find( absint( $input['id'] ), (string) ( $input['token'] ?? '' ) );
			if ( ! $conversation ) {
				return new WP_Error( 'bridle_chat_gone', __( 'This chat has ended. Start a new one.', 'bridle' ), [ 'status' => 403 ] );
			}
			if ( ChatPolicy::over( self::visitor_messages( (int) $conversation->id ), $limits['per_chat'] ) ) {
				return self::slow_down();
			}
		} else {
			if ( ChatPolicy::over( self::count( 'chat' ), $limits['chats_per_visitor_hour'] ) ) {
				return self::slow_down();
			}
			if ( ! self::turnstile_passes( (string) ( $input['turnstile'] ?? '' ) ) ) {
				return new WP_Error( 'bridle_chat_check', __( 'Please confirm you’re human and try again.', 'bridle' ), [ 'status' => 403 ] );
			}
			$conversation = self::start( $text, ChatPolicy::page( (string) ( $input['page'] ?? '' ), self::origin() ) );
			if ( ! $conversation ) {
				return new WP_Error( 'bridle_chat_failed', __( 'The chat couldn’t start. Try again.', 'bridle' ), [ 'status' => 500 ] );
			}
			self::bump( 'chat' );
		}

		self::bump( 'message' );
		self::add_visitor_message( $conversation, $text );

		$out = [
			'id'      => (int) $conversation->id,
			'token'   => ChatPolicy::token( (string) $conversation->thread_id, wp_salt( 'auth' ) ),
			'answer'  => null,
			'handoff' => null,
			'waiting' => false,
		];

		// Handed to a person already: the message waits for them (or, live,
		// they are reading along).
		if ( 'active' === $conversation->status ) {
			$out['waiting'] = true;
			$out['live']    = self::live( $conversation );
			return $out;
		}

		if ( ChatPolicy::over( self::count( 'answer', 'site' ), $limits['answers_per_hour'] ) ) {
			$out['handoff'] = 'busy';
		} else {
			self::bump( 'answer', 'site' );
			$out = array_merge( $out, self::answer( $conversation, $text ) );
		}
		// What a person will do and when, said at the moment of handing over (#120).
		if ( null !== $out['handoff'] ) {
			// A person is here (an add-on says so): they take it in the chat.
			if ( self::live( $conversation ) ) {
				self::go_live( $conversation );
				$out['live'] = true;
			}
			$out['promise'] = ChatFollowUp::promise();
		}
		return $out;
	}

	/**
	 * Whether a person is here to take this chat live, in the bubble,
	 * instead of asking the visitor for an email first.
	 */
	public static function live( object $conversation ): bool {
		/**
		 * Whether a person can answer this chat live right now. Bridle has
		 * no live chat; Bridle Pro says yes while a teammate is online and
		 * within business hours.
		 *
		 * @param bool   $live         False.
		 * @param object $conversation The chat.
		 */
		return (bool) apply_filters( 'bridle_chat_live', false, $conversation );
	}

	/**
	 * Move a chat to the Inbox without a contact, for a person to answer in
	 * the bubble. The agent drafts a reply the teammate can send there.
	 */
	private static function go_live( object $conversation ): void {
		$id = (int) $conversation->id;
		( new Conversation() )->update(
			$id,
			[
				'status'    => 'active',
				'closed_at' => null,
			]
		);
		$conversation = (object) array_merge( (array) $conversation, [ 'status' => 'active' ] );
		if ( 'customer' === self::last_public_author( $id ) ) {
			AgentQueue::on_thread_added( self::last_public_thread( $id ), $id );
		} else {
			self::add_visitor_message( $conversation, __( '(Asked for a person in the chat.)', 'bridle' ) );
		}
		Counts::flush();

		/**
		 * A chat went to a person live, in the bubble.
		 *
		 * @param int $conversation_id The chat.
		 */
		do_action( 'bridle_chat_went_live', $id );
	}

	/**
	 * The visitor leaves their email: the chat gets a contact and moves to
	 * the Inbox, where the team answers by email.
	 *
	 * With `live` and no email, a person who is here takes the chat in the
	 * bubble instead (an add-on decides, see live()).
	 *
	 * @param object $conversation From find().
	 * @param array  $input        email, name, message (optional), live.
	 * @return array|WP_Error { email, promise, live? }
	 */
	public static function handoff( object $conversation, array $input ) {
		$email = sanitize_email( (string) ( $input['email'] ?? '' ) );
		if ( '' === $email && ! empty( $input['live'] ) ) {
			if ( ! self::live( $conversation ) ) {
				return new WP_Error( 'bridle_chat_offline', __( 'Leave your email and a person will reply.', 'bridle' ), [ 'status' => 409 ] );
			}
			if ( ChatPolicy::over( self::count( 'handoff' ), self::limits()['handoffs_per_hour'] ) ) {
				return self::slow_down();
			}
			self::bump( 'handoff' );
			if ( 'active' !== $conversation->status ) {
				self::go_live( $conversation );
			}
			return [
				'email'   => '',
				'live'    => true,
				'promise' => '',
			];
		}
		if ( ! is_email( $email ) || ! self::domain_takes_mail( $email ) ) {
			return new WP_Error( 'bridle_chat_email', __( 'That email address doesn’t look right.', 'bridle' ), [ 'status' => 400 ] );
		}
		if ( ChatPolicy::over( self::count( 'handoff' ), self::limits()['handoffs_per_hour'] ) ) {
			return self::slow_down();
		}
		self::bump( 'handoff' );

		$customers = new Customer();
		$name      = sanitize_text_field( mb_substr( (string) ( $input['name'] ?? '' ), 0, 80 ) );
		$customer  = $customers->find_by_email( $email );
		if ( $customer ) {
			$customer_id = (int) $customer->id;
			if ( '' !== $name && '' === (string) $customer->name ) {
				$customers->update( $customer_id, [ 'name' => $name ] );
			}
		} else {
			$customer_id = (int) $customers->create(
				[
					'email' => $email,
					'name'  => '' !== $name ? $name : null,
				]
			);
		}
		if ( ! $customer_id ) {
			return new WP_Error( 'bridle_chat_failed', __( 'That didn’t work. Try again.', 'bridle' ), [ 'status' => 500 ] );
		}

		$id = (int) $conversation->id;
		// Already with a person by email; a live chat getting its first
		// email still gets the confirmation and counts for the contact.
		$already = 'active' === $conversation->status && (int) $conversation->customer_id > 0;
		( new Conversation() )->update(
			$id,
			[
				'customer_id' => $customer_id,
				'status'      => 'active',
				'closed_at'   => null,
			]
		);
		if ( ! $already ) {
			$customers->increment_conversations( $customer_id );
		}

		$note = ChatPolicy::clean( (string) ( $input['message'] ?? '' ), self::limits()['max_chars'] );
		if ( null !== $note ) {
			// Open now, so the agent drafts an email reply for the team.
			self::add_visitor_message( (object) array_merge( (array) $conversation, [ 'status' => 'active' ] ), $note );
		} elseif ( 'customer' === self::last_public_author( $id ) ) {
			AgentQueue::on_thread_added( self::last_public_thread( $id ), $id );
		} else {
			self::add_visitor_message( $conversation, __( '(Asked for a person in the chat.)', 'bridle' ) );
		}
		Counts::flush();
		if ( ! $already ) {
			ChatFollowUp::after_handoff( $id );
		}

		return [
			'email'   => $email,
			'promise' => ChatFollowUp::promise(),
		];
	}

	/** Start a chat: a Resolved conversation with no contact yet, and the page it started on. */
	private static function start( string $text, string $page ): ?object {
		$model = new Conversation();
		$id    = $model->create(
			[
				'subject'     => ChatPolicy::subject( $text ),
				'status'      => 'closed',
				'channel'     => 'chat',
				'source_url'  => $page,
				'inbox_id'    => self::inbox_id(),
				'customer_id' => 0,
			]
		);
		if ( ! $id ) {
			return null;
		}
		$model->update( $id, [ 'closed_at' => current_time( 'mysql', true ) ] );
		$conversation = $model->get_by_id( $id );

		/** This action is documented in includes/rest-api/class-inbound-email-controller.php */
		do_action( 'bridle_conversation_created', $id, $conversation, [] );

		return $conversation;
	}

	/**
	 * Ask the agent and decide whether its answer is shown.
	 *
	 * @return array{answer: ?array, handoff: ?string}
	 */
	private static function answer( object $conversation, string $text ): array {
		$composed = AgentService::compose( $conversation, 'chat' );
		if ( is_wp_error( $composed ) ) {
			self::note( $conversation, __( 'Bridle Chat couldn’t answer: the AI provider returned an error.', 'bridle' ) );
			return [
				'answer'  => null,
				'handoff' => 'busy',
			];
		}

		$draft    = $composed['draft'];
		$decision = ChatPolicy::decide( $draft, $composed['problems'], $text );

		/** This action is documented in includes/services/class-agent-service.php */
		do_action(
			'bridle_agent_answered',
			(int) $conversation->id,
			$draft,
			[
				'kind'     => 'chat',
				'terms'    => (array) ( $composed['found']['terms'] ?? [] ),
				'verified' => empty( $composed['problems'] ),
				'shown'    => (bool) $decision['answer'],
				'reason'   => (string) $decision['reason'],
			]
		);
		if ( ! $decision['answer'] ) {
			$why  = trim( (string) $draft['needs_human_reason'] );
			$code = [
				'unverified' => 'not_verified',
				'unsure'     => 'needs_human',
				'tripwire'   => 'tripwire',
			][ $decision['reason'] ] ?? 'flag';
			self::note(
				$conversation,
				sprintf(
					/* translators: 1: why, in Auto's words (e.g. "not every fact checked out"), 2: the agent's note for the team */
					__( 'Bridle Chat handed this to a person: %1$s. %2$s', 'bridle' ),
					AutoSend::reason_text( [ $code ] ),
					'' !== $why ? $why : (string) $draft['summary']
				)
			);
			return [
				'answer'  => null,
				'handoff' => in_array( $decision['reason'], [ 'unsure', 'unverified' ], true ) ? 'unsure' : 'person',
			];
		}

		ReplyService::add(
			(int) $conversation->id,
			[
				'content'      => wp_strip_all_tags( str_replace( '</p>', "</p>\n\n", $draft['reply_html'] ) ),
				'content_html' => $draft['reply_html'],
				'author_type'  => 'agent',
				'agent'        => [
					'source' => 'agent',
					'via'    => 'chat',
				],
			]
		);

		$sources = [];
		foreach ( AgentPrompt::cite( $draft['grounded_in'], $composed['knowledge'] ) as $cited ) {
			$url = (string) ( $cited['url'] ?? '' );
			if ( '' !== $url && ! isset( $sources[ $url ] ) && count( $sources ) < 3 ) {
				$sources[ $url ] = [
					'title' => (string) ( $cited['title'] ?? '' ),
					'url'   => $url,
				];
			}
		}

		return [
			'answer'  => [
				'html'    => $draft['reply_html'],
				'sources' => array_values( $sources ),
			],
			'handoff' => null,
		];
	}

	/** Store a visitor's message as a customer thread. */
	private static function add_visitor_message( object $conversation, string $text ): void {
		$thread_model = new Thread();
		$thread_id    = $thread_model->create(
			[
				'conversation_id' => (int) $conversation->id,
				'author_type'     => 'customer',
				'content'         => $text,
				'content_html'    => wpautop( esc_html( $text ) ),
			]
		);
		if ( ! $thread_id ) {
			return;
		}
		( new Conversation() )->update( (int) $conversation->id, [ 'last_activity_at' => current_time( 'mysql', true ) ] );

		/** This action is documented in includes/services/class-reply-service.php */
		do_action( 'bridle_thread_added', $thread_id, (int) $conversation->id, $thread_model->get_by_id( $thread_id ) );
	}

	/** A private note for the team, from the agent. */
	private static function note( object $conversation, string $text ): void {
		ReplyService::add(
			(int) $conversation->id,
			[
				'content'     => $text,
				'thread_type' => 'note',
				'author_type' => 'agent',
			]
		);
	}

	private static function visitor_messages( int $conversation_id ): int {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- a live count for the per-chat limit.
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i WHERE conversation_id = %d AND author_type = 'customer'", $wpdb->prefix . 'bridle_threads', $conversation_id ) );
	}

	private static function last_public_thread( int $conversation_id ): int {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- the newest message, read once at handoff.
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT MAX( id ) FROM %i WHERE conversation_id = %d AND is_private = 0', $wpdb->prefix . 'bridle_threads', $conversation_id ) );
	}

	private static function last_public_author( int $conversation_id ): string {
		$thread = ( new Thread() )->get_by_id( self::last_public_thread( $conversation_id ) );
		return $thread ? (string) $thread->author_type : '';
	}

	/** Whether the address's domain can receive mail (MX, or an A record as mail servers fall back to). */
	private static function domain_takes_mail( string $email ): bool {
		$domain = MailHost::domain( $email );
		if ( '' === $domain || ! function_exists( 'checkdnsrr' ) ) {
			return '' !== $domain;
		}
		return checkdnsrr( $domain, 'MX' ) || checkdnsrr( $domain, 'A' );
	}

	private static function slow_down(): WP_Error {
		return new WP_Error( 'bridle_chat_limit', __( 'Too many messages. Please wait a little and try again.', 'bridle' ), [ 'status' => 429 ] );
	}

	/**
	 * Who is asking, as a hash of their address: enough to count, nothing to store.
	 */
	private static function visitor(): string {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		/**
		 * Filter the visitor address Bridle Chat counts limits by, for sites
		 * behind a proxy that puts the real one in a header.
		 *
		 * @param string $ip REMOTE_ADDR.
		 */
		$ip = (string) apply_filters( 'bridle_chat_visitor_ip', $ip );
		return substr( hash_hmac( 'sha256', $ip, wp_salt( 'nonce' ) ), 0, 20 );
	}

	/** This hour's count of one kind, for this visitor or the whole site. */
	private static function count( string $kind, string $who = '' ): int {
		return (int) get_transient( self::counter( $kind, $who ) );
	}

	private static function bump( string $kind, string $who = '' ): void {
		set_transient( self::counter( $kind, $who ), self::count( $kind, $who ) + 1, HOUR_IN_SECONDS + MINUTE_IN_SECONDS );
	}

	private static function counter( string $kind, string $who ): string {
		return 'bridle_chat_' . $kind . '_' . ( '' !== $who ? $who : self::visitor() ) . '_' . gmdate( 'YmdH' );
	}

	/** Turnstile keys without the secret: what Settings and the widget may see. */
	public static function turnstile_config(): array {
		$stored = (array) get_option( self::TURNSTILE_OPTION, [] );
		$secret = (string) ( $stored['secret'] ?? '' );
		return [
			'site_key'    => (string) ( $stored['site_key'] ?? '' ),
			'has_secret'  => '' !== $secret,
			'secret_hint' => '' !== $secret ? substr( $secret, -4 ) : '',
		];
	}

	/**
	 * Save Turnstile keys. An empty secret keeps the stored one; an empty
	 * site key turns Turnstile off and forgets both.
	 */
	public static function save_turnstile( array $input ): array {
		$site_key = sanitize_text_field( (string) ( $input['site_key'] ?? '' ) );
		$stored   = (array) get_option( self::TURNSTILE_OPTION, [] );
		if ( '' === $site_key ) {
			delete_option( self::TURNSTILE_OPTION );
			return self::turnstile_config();
		}
		$secret = sanitize_text_field( (string) ( $input['secret'] ?? '' ) );
		update_option(
			self::TURNSTILE_OPTION,
			[
				'site_key' => $site_key,
				'secret'   => '' !== $secret ? $secret : (string) ( $stored['secret'] ?? '' ),
			],
			false
		);
		return self::turnstile_config();
	}

	/** True without Turnstile keys; with them, Cloudflare must accept the token. */
	private static function turnstile_passes( string $token ): bool {
		$stored = (array) get_option( self::TURNSTILE_OPTION, [] );
		$secret = (string) ( $stored['secret'] ?? '' );
		if ( '' === (string) ( $stored['site_key'] ?? '' ) || '' === $secret ) {
			return true;
		}
		if ( '' === $token ) {
			return false;
		}
		$response = wp_remote_post(
			self::TURNSTILE_VERIFY,
			[
				'timeout' => 5,
				'body'    => [
					'secret'   => $secret,
					'response' => $token,
				],
			]
		);
		if ( is_wp_error( $response ) ) {
			return false;
		}
		$body = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		return is_array( $body ) && ! empty( $body['success'] );
	}
}
