<?php
/**
 * What Home shows (#112): this week's numbers and the agent's health.
 *
 * @package Bridle
 */

namespace Bridle\Services;

use Bridle\Models\Inbox;

defined( 'ABSPATH' ) || exit;

/**
 * Home's numbers: replies this week against last week, how often the agent's
 * drafts go out as written, the median first reply, the time the agent saved,
 * and whether each part the agent depends on is working. The arithmetic is
 * pure and unit-tested; build() runs the queries.
 */
class HomeSummary {

	/** Minutes a person saves for each reply they didn't have to write. */
	public const MINUTES_SAVED = 5;

	/** Days the first-reply median looks back over. */
	public const FIRST_REPLY_DAYS = 30;

	/**
	 * Everything Home needs in one answer.
	 *
	 * @param int|null $now Unix time; defaults to now.
	 * @return array{week: array, health: array}
	 */
	public static function build( ?int $now = null ): array {
		$now = $now ?? time();

		return [
			'week'   => self::week( $now ),
			'health' => self::health(),
		];
	}

	/**
	 * This week's numbers.
	 *
	 * @return array{answered:int, answered_before:int, change:?int, as_written:?int, first_reply_minutes:?float, time_back_minutes:int}
	 */
	private static function week( int $now ): array {
		global $wpdb;

		$threads       = $wpdb->prefix . 'bridle_threads';
		$conversations = $wpdb->prefix . 'bridle_conversations';
		$week_ago      = gmdate( 'Y-m-d H:i:s', $now - 7 * DAY_IN_SECONDS );
		$two_weeks_ago = gmdate( 'Y-m-d H:i:s', $now - 14 * DAY_IN_SECONDS );
		$month_ago     = gmdate( 'Y-m-d H:i:s', $now - self::FIRST_REPLY_DAYS * DAY_IN_SECONDS );

		// Public replies by a person or the agent, this week and the week before.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- live numbers for Home.
		$answered = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT
					SUM( CASE WHEN created_at >= %s THEN 1 ELSE 0 END ) AS this_week,
					SUM( CASE WHEN created_at < %s THEN 1 ELSE 0 END ) AS week_before
				FROM %i
				WHERE thread_type = 'reply' AND is_private = 0
					AND author_type IN ( 'teammate', 'agent' ) AND created_at >= %s",
				$week_ago,
				$week_ago,
				$threads,
				$two_weeks_ago
			)
		);

		// Replies nobody had to write: sent by the agent, or a person sent the
		// agent's draft as it was (threads.ai_sources, ReplyService::provenance()).
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- live numbers for Home.
		$unwritten = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM %i
				WHERE thread_type = 'reply' AND is_private = 0 AND created_at >= %s
					AND ( author_type = 'agent' OR ( author_type = 'teammate' AND ai_sources LIKE %s ) )",
				$threads,
				$week_ago,
				'%' . $wpdb->esc_like( '"edited":false' ) . '%'
			)
		);

		// First replies in the last 30 days, for the median.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- live numbers for Home.
		$firsts = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT created_at, first_responded_at FROM %i
				WHERE first_responded_at IS NOT NULL AND first_responded_at >= %s
				ORDER BY first_responded_at DESC LIMIT 1000',
				$conversations,
				$month_ago
			)
		);
		$firsts = is_array( $firsts ) ? $firsts : [];

		$minutes = [];
		foreach ( $firsts as $row ) {
			$wait = strtotime( $row->first_responded_at . ' UTC' ) - strtotime( $row->created_at . ' UTC' );
			if ( $wait >= 0 ) {
				$minutes[] = $wait / 60;
			}
		}

		$this_week   = (int) ( $answered->this_week ?? 0 );
		$week_before = (int) ( $answered->week_before ?? 0 );

		return [
			'answered'            => $this_week,
			'answered_before'     => $week_before,
			'change'              => self::change( $this_week, $week_before ),
			'as_written'          => self::as_written( (array) get_option( 'bridle_agent_stats', [] ) ),
			'first_reply_minutes' => self::median( $minutes ),
			'time_back_minutes'   => $unwritten * self::MINUTES_SAVED,
		];
	}

	/**
	 * Whether each part the agent depends on works.
	 *
	 * @return array{ai: array, forwarding: array, knowledge: array, sorting: array, modes: array}
	 */
	private static function health(): array {
		global $wpdb;

		$inboxes  = ( new Inbox() )->list( [ 'is_active' => 1 ] );
		$arriving = array_filter( $inboxes, static fn( $row ) => ! empty( $row->last_received_at ) );
		$latest   = '';
		foreach ( $arriving as $row ) {
			$latest = max( $latest, (string) $row->last_received_at );
		}

		$modes = [
			'off'   => 0,
			'draft' => 0,
			'auto'  => 0,
		];
		foreach ( $inboxes as $row ) {
			++$modes[ InboxAiSettings::agent_mode( (int) $row->id ) ];
		}

		$status    = KnowledgeSearch::status();
		$knowledge = [];
		foreach ( [
			'kb'       => 'docs',
			'site'     => 'page',
			'products' => 'product',
		] as $source => $post_type ) {
			$on                   = ! empty( $status[ $source ]['available'] ) && ! empty( $status[ $source ]['enabled'] );
			$knowledge[ $source ] = $on && post_type_exists( $post_type ) ? (int) ( wp_count_posts( $post_type )->publish ?? 0 ) : null;
		}
		$past = ! empty( $status['past']['enabled'] );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- live numbers for Home.
		$knowledge['past'] = $past ? (int) $wpdb->get_var(
			$wpdb->prepare( "SELECT COUNT(*) FROM %i WHERE status = 'closed'", $wpdb->prefix . 'bridle_conversations' )
		) : null;

		$classifier = Classifier::public_config();

		return [
			'ai'         => [
				'ready'         => AiService::can_use_ai(),
				'source'        => AiService::source(),
				'bridle'        => 'bridle' === AiService::source() ? BridleAi::balance() : null,
				'wp_version_ok' => function_exists( 'wp_ai_client_prompt' ),
			],
			'forwarding' => [
				'inboxes'  => count( $inboxes ),
				'arriving' => count( $arriving ),
				'latest'   => '' !== $latest ? $latest : null,
				// Registered for another site address: a moved site, or a staging copy (#104).
				'drifted'  => WorkerSyncService::get_drift()['drifted'],
			],
			'knowledge'  => $knowledge,
			'sorting'    => [
				'on'    => (bool) $classifier['enabled'],
				'model' => (string) $classifier['model'],
				'ok'    => ( $classifier['status']['ok'] ?? true ) !== false,
			],
			'modes'      => $modes,
		];
	}

	/**
	 * Percent change from one week to the next, or null with nothing to compare.
	 */
	public static function change( int $now, int $before ): ?int {
		if ( $before <= 0 ) {
			return null;
		}
		return (int) round( ( $now - $before ) / $before * 100 );
	}

	/**
	 * The share of the agent's sent drafts that went out unchanged, in percent,
	 * or null before any went out.
	 *
	 * @param array $stats bridle_agent_stats.
	 */
	public static function as_written( array $stats ): ?int {
		$unedited = (int) ( $stats['sent_unedited'] ?? 0 );
		$edited   = (int) ( $stats['sent_edited'] ?? 0 );
		if ( $unedited + $edited <= 0 ) {
			return null;
		}
		return (int) round( $unedited / ( $unedited + $edited ) * 100 );
	}

	/**
	 * The median of a list of numbers, or null for an empty list.
	 *
	 * @param float[] $values
	 */
	public static function median( array $values ): ?float {
		if ( ! $values ) {
			return null;
		}
		sort( $values );
		$count = count( $values );
		$mid   = intdiv( $count, 2 );
		return (float) ( $count % 2 ? $values[ $mid ] : ( $values[ $mid - 1 ] + $values[ $mid ] ) / 2 );
	}
}
