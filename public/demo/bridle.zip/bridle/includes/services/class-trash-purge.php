<?php

namespace Bridle\Services;

use Bridle\Models\Conversation;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Trash empties itself, the way Gmail's does: a conversation that has sat in
 * Trash longer than days() (30 by default) is deleted for good by the daily
 * `bridle_purge_trash` job, with its messages, attachments and drafts
 * (Conversation::hard_delete()).
 *
 * `trashed_at` is stamped when a conversation enters Trash
 * (Conversation::update()). Rows trashed before that column existed have it
 * empty; the first run starts their clock, so nothing older than the feature
 * disappears without its full grace period.
 */
class TrashPurge {

	/** Days a conversation stays in Trash before it is deleted for good. */
	public const DAYS = 30;

	/** Most conversations one run deletes; the next day picks up the rest. */
	public const BATCH = 200;

	/**
	 * Retention in days. 0 keeps Trash until someone empties it.
	 */
	public static function days(): int {
		/**
		 * Filter how many days a conversation stays in Trash before the daily
		 * job deletes it for good. Return 0 to keep Trash until it is emptied.
		 *
		 * @param int $days Default 30.
		 */
		return max( 0, (int) apply_filters( 'bridle_trash_days', self::DAYS ) );
	}

	/**
	 * The UTC datetime before which trashed conversations go.
	 *
	 * @param int $now  Unix time.
	 * @param int $days Retention.
	 */
	public static function cutoff( int $now, int $days ): string {
		return gmdate( 'Y-m-d H:i:s', $now - ( $days * DAY_IN_SECONDS ) );
	}

	/**
	 * The daily job. Returns how many conversations it deleted.
	 */
	public static function run(): int {
		global $wpdb;

		$days = self::days();
		if ( $days < 1 ) {
			return 0;
		}

		$table = $wpdb->prefix . 'bridle_conversations';
		$now   = time();

		// Start the clock for rows trashed before trashed_at existed.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- our own table.
		$wpdb->query( $wpdb->prepare( 'UPDATE %i SET trashed_at = %s WHERE status = %s AND trashed_at IS NULL', $table, gmdate( 'Y-m-d H:i:s', $now ), 'trash' ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- as above.
		$ids = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM %i WHERE status = %s AND trashed_at < %s ORDER BY trashed_at ASC LIMIT %d', $table, 'trash', self::cutoff( $now, $days ), self::BATCH ) ) );

		if ( ! $ids ) {
			return 0;
		}

		return ( new Conversation() )->hard_delete( $ids );
	}
}
