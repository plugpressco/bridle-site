<?php

namespace Bridle\Services;

use Bridle\Models\Attachment;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AttachmentService {

	/** @var int Max single file size accepted by WP side (10 MB). */
	const MAX_FILE_BYTES = 10485760;

	/** @var int Max total attachment bytes per thread (25 MB). */
	const MAX_TOTAL_BYTES = 26214400;

	/** @var array MIME types we refuse to store, regardless of filename. */
	const BLOCKED_MIMES = [
		'application/x-msdownload',
		'application/x-dosexec',
		'application/x-msdos-program',
		'application/x-sh',
		'application/x-executable',
		'application/javascript',
		'text/javascript',
	];

	/**
	 * Accept array of attachment payloads from the email worker,
	 * sideload each into the WP media library, and record in md_attachments.
	 *
	 * @param int   $thread_id          Parent thread row id.
	 * @param array $attachments_input  [ { filename, mime_type, size_bytes, is_inline, content_id, content_base64 } ]
	 * @return array  content_id => public URL   (for cid: rewriting in HTML)
	 */
	public static function store_for_thread( int $thread_id, array $attachments_input ): array {
		if ( ! function_exists( 'wp_handle_sideload' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
			require_once ABSPATH . 'wp-admin/includes/media.php';
		}

		$attachment_model = new Attachment();
		$cid_url_map      = [];
		$total_bytes      = 0;

		/**
		 * Filter the list of MIME types blocked from being stored as attachments.
		 *
		 * The default list covers executable and script types. You may add entries
		 * to tighten security but should not remove the defaults.
		 *
		 * @param string[] $blocked_mimes Indexed array of blocked MIME type strings.
		 */
		$blocked_mimes = (array) apply_filters( 'bridle_blocked_attachment_mimes', self::BLOCKED_MIMES );

		foreach ( $attachments_input as $att ) {
			if ( ! is_array( $att ) || empty( $att['filename'] ) || empty( $att['content_base64'] ) ) {
				continue;
			}

			$mime = isset( $att['mime_type'] ) ? strtolower( sanitize_text_field( $att['mime_type'] ) ) : 'application/octet-stream';
			if ( in_array( $mime, $blocked_mimes, true ) ) {
				continue;
			}

			$bytes = isset( $att['size_bytes'] ) ? (int) $att['size_bytes'] : 0;
			if ( $bytes > self::MAX_FILE_BYTES ) {
				continue;
			}
			if ( $total_bytes + $bytes > self::MAX_TOTAL_BYTES ) {
				break;
			}

			// The relay sends each attachment's bytes as base64 (file data, never code).
			$binary = base64_decode( $att['content_base64'], true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
			if ( false === $binary || strlen( $binary ) === 0 ) {
				continue;
			}

			// Double-check actual decoded size.
			$actual_bytes = strlen( $binary );
			if ( $actual_bytes > self::MAX_FILE_BYTES ) {
				continue;
			}
			if ( $total_bytes + $actual_bytes > self::MAX_TOTAL_BYTES ) {
				break;
			}

			$filename = sanitize_file_name( $att['filename'] );

			// Write to temp file so wp_handle_sideload can process it.
			$tmp_path = wp_tempnam( $filename );
			if ( ! $tmp_path ) {
				continue;
			}
			// A wp_tempnam() file handed straight to wp_handle_sideload(). The webhook
			// runs unattended, so not WP_Filesystem, which may want FTP credentials.
			$written = file_put_contents( $tmp_path, $binary ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			if ( false === $written ) {
				wp_delete_file( $tmp_path );
				continue;
			}

			// wp_handle_sideload validates MIME against WP's allowed list via wp_check_filetype.
			$file_array = [
				'name'     => $filename,
				'tmp_name' => $tmp_path,
				'size'     => $actual_bytes,
				'error'    => 0,
			];

			$overrides  = [ 'test_form' => false ];
			$sideloaded = wp_handle_sideload( $file_array, $overrides );

			if ( isset( $sideloaded['error'] ) ) {
				wp_delete_file( $tmp_path );
				continue;
			}

			// Create WP attachment post.
			$wp_attachment_id = wp_insert_attachment( [
				'post_mime_type' => $sideloaded['type'],
				'post_title'     => pathinfo( $filename, PATHINFO_FILENAME ),
				'post_content'   => '',
				'post_status'    => 'inherit',
			], $sideloaded['file'] );

			if ( is_wp_error( $wp_attachment_id ) || ! $wp_attachment_id ) {
				continue;
			}
			update_post_meta( $wp_attachment_id, Attachment::OWNED_META, 1 );

			// Generate image metadata for thumbnails.
			$metadata = wp_generate_attachment_metadata( $wp_attachment_id, $sideloaded['file'] );
			wp_update_attachment_metadata( $wp_attachment_id, $metadata );

			$content_id = isset( $att['content_id'] ) ? sanitize_text_field( $att['content_id'] ) : '';

			$attachment_model->create( [
				'thread_id'        => $thread_id,
				'wp_attachment_id' => $wp_attachment_id,
				'filename'         => $filename,
				'mime_type'        => $sideloaded['type'],
				'size_bytes'       => $actual_bytes,
				'is_inline'        => ! empty( $att['is_inline'] ),
				'content_id'       => $content_id,
			] );

			if ( $content_id ) {
				$url = wp_get_attachment_url( $wp_attachment_id );
				if ( $url ) {
					$cid_url_map[ $content_id ] = $url;
				}
			}

			$total_bytes += $actual_bytes;
		}

		return $cid_url_map;
	}

	/**
	 * Browser-side multipart upload path.
	 *
	 * Called from the REST controller when a teammate drags / pastes / picks
	 * a file in the reply composer. Stores it in the WP media library, drops
	 * an orphan row in bridle_attachments (thread_id = 0), and returns the
	 * row data the React chip needs to render. The orphan row is later
	 * adopted by the threads controller when the message is sent — or
	 * reaped by the daily cron if the user abandons the draft.
	 *
	 * @return array|\WP_Error  { id, url, filename, mime, size } on success.
	 */
	public static function store_uploaded_file( array $file ): array|\WP_Error {
		// We need wp_handle_sideload (file.php), wp_generate_attachment_metadata
		// (image.php), and wp_insert_attachment (media.php). Each lives in a
		// separate admin include; require all three regardless of whether
		// some of them are already loaded.
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';

		if ( empty( $file ) || ! is_array( $file ) || empty( $file['name'] ) || empty( $file['tmp_name'] ) ) {
			return new \WP_Error( 'bridle_no_file', __( 'No file uploaded.', 'bridle' ), [ 'status' => 400 ] );
		}

		// Reject anything over the per-file cap before WP touches the disk.
		$size_in = isset( $file['size'] ) ? (int) $file['size'] : (int) ( filesize( $file['tmp_name'] ) ?: 0 );
		if ( $size_in > self::MAX_FILE_BYTES ) {
			return new \WP_Error(
				'bridle_file_too_large',
				/* translators: %s: human-readable max size, e.g. "10 MB". */
				sprintf( __( 'File exceeds the %s limit.', 'bridle' ), size_format( self::MAX_FILE_BYTES ) ),
				[ 'status' => 413 ]
			);
		}

		// Block executable / script MIMEs based on the declared type. The
		// real type check happens again inside wp_handle_sideload via
		// wp_check_filetype_and_ext, which sniffs the file contents.
		$declared_mime = isset( $file['type'] ) ? strtolower( sanitize_text_field( $file['type'] ) ) : '';
		if ( $declared_mime && in_array( $declared_mime, self::BLOCKED_MIMES, true ) ) {
			return new \WP_Error( 'bridle_blocked_mime', __( 'This file type is not allowed.', 'bridle' ), [ 'status' => 400 ] );
		}

		// Use wp_handle_sideload (not wp_handle_upload) — the REST controller
		// already verified the request via permission_callback, and sideload
		// runs the same wp_check_filetype_and_ext sniffer that protects us
		// against extension-spoofing. wp_handle_upload would additionally
		// require is_uploaded_file(), which is correct for raw $_FILES but
		// makes the path untestable from CLI / unit tests / WP-CLI.
		$file_array = [
			'name'     => sanitize_file_name( $file['name'] ),
			'tmp_name' => $file['tmp_name'],
			'size'     => $size_in,
			'error'    => 0,
		];

		$uploaded = wp_handle_sideload( $file_array, [ 'test_form' => false ] );
		if ( isset( $uploaded['error'] ) ) {
			return new \WP_Error( 'bridle_upload_failed', $uploaded['error'], [ 'status' => 400 ] );
		}

		// Double-check the sniffed MIME isn't something we've blocked.
		if ( in_array( strtolower( (string) $uploaded['type'] ), self::BLOCKED_MIMES, true ) ) {
			wp_delete_file( $uploaded['file'] );
			return new \WP_Error( 'bridle_blocked_mime', __( 'This file type is not allowed.', 'bridle' ), [ 'status' => 400 ] );
		}

		$filename = sanitize_file_name( basename( $uploaded['file'] ) );

		$wp_attachment_id = wp_insert_attachment( [
			'post_mime_type' => $uploaded['type'],
			'post_title'     => pathinfo( $filename, PATHINFO_FILENAME ),
			'post_content'   => '',
			'post_status'    => 'inherit',
		], $uploaded['file'] );

		if ( is_wp_error( $wp_attachment_id ) || ! $wp_attachment_id ) {
			wp_delete_file( $uploaded['file'] );
			return new \WP_Error( 'bridle_attachment_post_failed', __( 'Could not store attachment.', 'bridle' ), [ 'status' => 500 ] );
		}
		update_post_meta( $wp_attachment_id, Attachment::OWNED_META, 1 );

		$metadata = wp_generate_attachment_metadata( $wp_attachment_id, $uploaded['file'] );
		wp_update_attachment_metadata( $wp_attachment_id, $metadata );

		$size_bytes = (int) ( filesize( $uploaded['file'] ) ?: ( $file['size'] ?? 0 ) );

		// Orphan row — thread_id = 0 means "uploaded but not yet attached
		// to a sent message". The threads controller adopts it on send.
		$row_id = ( new Attachment() )->create( [
			'thread_id'        => 0,
			'wp_attachment_id' => $wp_attachment_id,
			'filename'         => $filename,
			'mime_type'        => $uploaded['type'],
			'size_bytes'       => $size_bytes,
			'is_inline'        => false,
		] );

		if ( ! $row_id ) {
			wp_delete_attachment( $wp_attachment_id, true );
			return new \WP_Error( 'bridle_attachment_db_failed', __( 'Could not store attachment.', 'bridle' ), [ 'status' => 500 ] );
		}

		return [
			'id'       => $row_id,
			'url'      => $uploaded['url'],
			'filename' => $filename,
			'mime'     => $uploaded['type'],
			'size'     => $size_bytes,
		];
	}

	/**
	 * Adopt an existing WordPress media-library item into an orphan
	 * bridle_attachments row. The reply composer's "Attach" button uses the WP
	 * Media Library (window.wp.media), which hands us a wp_attachment_id rather
	 * than a raw file, so the file is already stored + type-validated by WP; we
	 * only re-check the blocked-MIME / size caps and drop the orphan row.
	 *
	 * @return array|\WP_Error  { id, url, filename, mime, size } on success.
	 */
	public static function store_from_media_id( int $wp_attachment_id ): array|\WP_Error {
		$wp_attachment_id = absint( $wp_attachment_id );
		if ( ! $wp_attachment_id || 'attachment' !== get_post_type( $wp_attachment_id ) ) {
			return new \WP_Error( 'bridle_bad_media', __( 'Invalid media item.', 'bridle' ), [ 'status' => 400 ] );
		}

		$mime = strtolower( (string) get_post_mime_type( $wp_attachment_id ) );
		if ( $mime && in_array( $mime, self::BLOCKED_MIMES, true ) ) {
			return new \WP_Error( 'bridle_blocked_mime', __( 'This file type is not allowed.', 'bridle' ), [ 'status' => 400 ] );
		}

		$path = get_attached_file( $wp_attachment_id );
		$size = ( $path && file_exists( $path ) ) ? (int) filesize( $path ) : 0;
		if ( $size > self::MAX_FILE_BYTES ) {
			return new \WP_Error(
				'bridle_file_too_large',
				/* translators: %s: human-readable max size, e.g. "10 MB". */
				sprintf( __( 'File exceeds the %s limit.', 'bridle' ), size_format( self::MAX_FILE_BYTES ) ),
				[ 'status' => 413 ]
			);
		}

		$filename = $path
			? sanitize_file_name( basename( $path ) )
			: sanitize_file_name( get_the_title( $wp_attachment_id ) ?: 'attachment' );

		$row_id = ( new Attachment() )->create( [
			'thread_id'        => 0,
			'wp_attachment_id' => $wp_attachment_id,
			'filename'         => $filename,
			'mime_type'        => $mime ?: 'application/octet-stream',
			'size_bytes'       => $size,
			'is_inline'        => false,
		] );

		if ( ! $row_id ) {
			return new \WP_Error( 'bridle_attachment_db_failed', __( 'Could not store attachment.', 'bridle' ), [ 'status' => 500 ] );
		}

		return [
			'id'       => $row_id,
			'url'      => wp_get_attachment_url( $wp_attachment_id ) ?: '',
			'filename' => $filename,
			'mime'     => $mime ?: 'application/octet-stream',
			'size'     => $size,
		];
	}

	/**
	 * Daily cron sweep: delete orphan attachments older than 24 hours and
	 * the media files Bridle uploaded for them. A file picked from the
	 * Media Library stays in the library.
	 */
	public static function purge_stale_orphans(): void {
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS );
		$model  = new Attachment();
		$rows   = $model->purge_orphans_older_than( $cutoff );

		$model->delete_media( array_map( static fn( $row ) => (int) $row->wp_attachment_id, $rows ) );
	}

	/**
	 * Replace cid:XYZ references in HTML with real attachment URLs.
	 */
	public static function rewrite_cid_refs( string $html, array $cid_url_map ): string {
		if ( empty( $cid_url_map ) || false === stripos( $html, 'cid:' ) ) {
			return $html;
		}

		foreach ( $cid_url_map as $cid => $url ) {
			if ( ! $cid || ! $url ) {
				continue;
			}
			// Match `cid:xxx` inside attribute quotes (src="cid:xxx", src='cid:xxx').
			$pattern = '#(["\'])cid:' . preg_quote( $cid, '#' ) . '\1#i';
			$html    = preg_replace( $pattern, '$1' . esc_url( $url ) . '$1', $html );
		}

		return $html;
	}
}
