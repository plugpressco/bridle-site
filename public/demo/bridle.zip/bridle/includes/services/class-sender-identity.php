<?php

namespace Bridle\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Works out who actually wrote an inbound email.
 *
 * The From header is often not the person: contact forms send FROM the site
 * (wordpress@, noreply@, or a configured sender) and put the real customer in
 * Reply-To or in the body. Shared by the inbound REST controller and the
 * `wp bridle repair-customer-names` command so both agree on what counts as a
 * real name.
 */
class SenderIdentity {

	/**
	 * How far into a body to look for a contact form's `Name:`/`Email:` block.
	 * Kept short on purpose so a quoted pair deeper in a thread never qualifies.
	 */
	private const FORM_IDENTITY_SCAN_LINES = 12;

	/**
	 * Extract a bare address from `"Name" <a@b.com>`, `Name <a@b.com>`, or `a@b.com`.
	 */
	public static function address( string $header ): string {
		$header = trim( wp_unslash( $header ) );
		if ( '' === $header ) {
			return '';
		}
		if ( preg_match( '/<([^>]+)>/', $header, $m ) ) {
			return trim( $m[1] );
		}

		return $header;
	}

	/**
	 * Extract the display name from `"Name" <a@b.com>` or `Name <a@b.com>`.
	 */
	public static function display_name( string $header ): string {
		$header = trim( wp_unslash( $header ) );
		if ( '' === $header || false === strpos( $header, '<' ) ) {
			return '';
		}
		$name = trim( substr( $header, 0, strpos( $header, '<' ) ) );

		return trim( $name, " \t\n\r\0\x0B\"'" );
	}

	/**
	 * Last-resort name built from the address's local part: `a.baker@x.com` → `A Baker`.
	 */
	public static function name_from_email( string $email ): string {
		$local = explode( '@', $email )[0] ?? '';
		$name  = str_replace( [ '.', '_', '-', '+' ], ' ', $local );

		return ucwords( $name );
	}

	/**
	 * Parse the identity block a WordPress contact form puts at the top of its
	 * notification body:
	 *
	 *     Name: Elisabet g
	 *     Email: egonzalez@projects-design.net
	 *     Topic: Technical issue
	 *
	 * Those emails are sent FROM the site, so the From header names the site
	 * rather than the person — this block is frequently the only place the real
	 * sender appears.
	 *
	 * Deliberately conservative: the labels must appear within the first few
	 * lines and the address must be valid, so a `Name:`/`Email:` pair quoted
	 * further down an ordinary email never qualifies.
	 *
	 * @return array{email:string,name:string}|null
	 */
	public static function parse_form_identity( string $body ): ?array {
		$body = trim( $body );
		if ( '' === $body ) {
			return null;
		}

		$name  = '';
		$email = '';
		$lines = preg_split( '/\r\n|\r|\n/', $body );

		foreach ( array_slice( (array) $lines, 0, self::FORM_IDENTITY_SCAN_LINES ) as $line ) {
			$line = self::normalize_line( (string) $line );
			if ( '' === $line ) {
				continue;
			}
			if ( '' === $name && preg_match( '/^(?:your\s+)?(?:full\s+)?name\s*:\s*(.+)$/i', $line, $m ) ) {
				$name = trim( $m[1] );
				continue;
			}
			if ( '' === $email && preg_match( '/^(?:your\s+)?e-?mail(?:\s+address)?\s*:\s*(.+)$/i', $line, $m ) ) {
				$email = sanitize_email( self::address( trim( $m[1] ) ) );
			}
		}

		if ( ! $email || ! is_email( $email ) ) {
			return null;
		}

		return [
			'email' => $email,
			'name'  => sanitize_text_field( $name ),
		];
	}

	/**
	 * Flatten one body line for label matching.
	 *
	 * Strips markup, but deliberately NOT with wp_strip_all_tags(): that would
	 * eat `<addr@host>` as if it were a tag, so `Email: Jo <jo@x.com>` would
	 * lose the address entirely. Anything containing an `@` is kept.
	 */
	private static function normalize_line( string $line ): string {
		$line = (string) preg_replace( '/<[^>@]*>/', '', $line );
		$line = html_entity_decode( $line, ENT_QUOTES, 'UTF-8' );
		// Non-breaking spaces survive trim(); forms and Outlook emit them freely.
		$line = str_replace( "\xC2\xA0", ' ', $line );

		return trim( $line );
	}

	/**
	 * Is this stored name a stand-in rather than a real person?
	 *
	 * True when it is empty, when it is just the address's local part (however
	 * we derived it), or when it is the sending site's own name — "DiviTorque"
	 * for support@divitorque.com. Those are the values a misaddressed contact
	 * form leaves behind, and they should yield to a real display name as soon
	 * as one arrives.
	 */
	public static function is_placeholder_name( string $name, string $email ): bool {
		$name = trim( $name );
		if ( '' === $name ) {
			return true;
		}

		$name_lc = strtolower( $name );
		$local   = strtolower( explode( '@', $email )[0] ?? '' );

		if ( $local === $name_lc || strtolower( self::name_from_email( $email ) ) === $name_lc ) {
			return true;
		}

		// "DiviTorque" vs divitorque.com — compare letters only, so spacing and
		// punctuation differences ("Divi Torque", "divi-torque") still match.
		$domain = strtolower( explode( '@', $email )[1] ?? '' );
		$host   = preg_replace( '/^www\./', '', $domain );
		$host   = (string) preg_replace( '/[^a-z0-9]/', '', (string) strstr( $host . '.', '.', true ) );
		$bare   = (string) preg_replace( '/[^a-z0-9]/', '', $name_lc );

		return '' !== $bare && '' !== $host && $bare === $host;
	}
}
