<?php

namespace Bridle\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Single source for avatar URLs. Always requests `default => '404'` so
 * addresses without a Gravatar 404 and the React <Avatar> falls back to
 * coloured initials instead of showing Gravatar's mystery-person image.
 */
class Avatars {

	/**
	 * Gravatar URL for an email address or WP user ID. Empty string when
	 * nothing resolvable is passed.
	 *
	 * @param int|string $who  Email address or user ID.
	 * @param int        $size Pixel size (request 2× the render size for retina).
	 */
	public static function url( $who, int $size = 96 ): string {
		if ( empty( $who ) ) {
			return '';
		}

		$url = get_avatar_url( $who, [ 'size' => $size, 'default' => '404' ] );

		return $url ? $url : '';
	}
}
