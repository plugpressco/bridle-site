<?php

namespace Bridle\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Who hosts a mailbox: Google, Microsoft, Zoho…
 *
 * Onboarding uses it to show the right forwarding steps without asking.
 * Free-mail domains are known by name; for a company domain the MX records
 * say who receives its mail. `provider` is a short key the UI has a guide
 * for, or null when we can't tell; `label` is what we call it to the user.
 */
class MailHost {

	/** Free-mail domains, matched exactly. */
	private const DOMAINS = [
		'gmail.com'      => [ 'google', 'Gmail' ],
		'googlemail.com' => [ 'google', 'Gmail' ],
		'outlook.com'    => [ 'microsoft', 'Outlook.com' ],
		'hotmail.com'    => [ 'microsoft', 'Outlook.com' ],
		'live.com'       => [ 'microsoft', 'Outlook.com' ],
		'msn.com'        => [ 'microsoft', 'Outlook.com' ],
		'icloud.com'     => [ 'icloud', 'iCloud Mail' ],
		'me.com'         => [ 'icloud', 'iCloud Mail' ],
		'mac.com'        => [ 'icloud', 'iCloud Mail' ],
		'yahoo.com'      => [ 'yahoo', 'Yahoo Mail' ],
		'proton.me'      => [ 'proton', 'Proton Mail' ],
		'protonmail.com' => [ 'proton', 'Proton Mail' ],
		'zohomail.com'   => [ 'zoho', 'Zoho Mail' ],
		'fastmail.com'   => [ 'fastmail', 'Fastmail' ],
	];

	/** MX host patterns, first match wins. */
	private const MX = [
		'/(^|\.)(google|googlemail)\.com$/'     => [ 'google', 'Google Workspace' ],
		'/\.olc\.protection\.outlook\.com$/'    => [ 'microsoft', 'Outlook.com' ],
		'/\.protection\.outlook\.(com|de|cn)$/' => [ 'microsoft', 'Microsoft 365' ],
		'/(^|\.)zoho(mail)?\.(com|eu|in|jp|com\.au|com\.cn)$/' => [ 'zoho', 'Zoho Mail' ],
		'/(^|\.)messagingengine\.com$/'         => [ 'fastmail', 'Fastmail' ],
		'/(^|\.)mail\.icloud\.com$/'            => [ 'icloud', 'iCloud Mail' ],
		'/(^|\.)protonmail\.ch$/'               => [ 'proton', 'Proton Mail' ],
		'/(^|\.)yahoodns\.net$/'                => [ 'yahoo', 'Yahoo Mail' ],
		'/(^|\.)mx\.cloudflare\.net$/'          => [ 'cloudflare', 'Cloudflare Email Routing' ],
	];

	/**
	 * @return array{provider: ?string, label: ?string}
	 */
	public static function detect( string $email ): array {
		$domain = self::domain( $email );
		if ( '' === $domain ) {
			return self::unknown();
		}
		if ( isset( self::DOMAINS[ $domain ] ) ) {
			return self::known( self::DOMAINS[ $domain ] );
		}
		if ( preg_match( '/^(hotmail|live|outlook)\.[a-z.]+$/', $domain ) ) {
			return self::known( [ 'microsoft', 'Outlook.com' ] );
		}
		if ( preg_match( '/^yahoo\.[a-z.]+$/', $domain ) ) {
			return self::known( [ 'yahoo', 'Yahoo Mail' ] );
		}
		return self::from_mx( self::mx_hosts( $domain ) );
	}

	/**
	 * Map MX hosts (lowest priority first) to a provider.
	 *
	 * @param string[] $hosts
	 * @return array{provider: ?string, label: ?string}
	 */
	public static function from_mx( array $hosts ): array {
		foreach ( $hosts as $host ) {
			$host = strtolower( rtrim( trim( (string) $host ), '.' ) );
			foreach ( self::MX as $pattern => $host_match ) {
				if ( preg_match( $pattern, $host ) ) {
					return self::known( $host_match );
				}
			}
		}
		return self::unknown();
	}

	public static function domain( string $email ): string {
		$at = strrpos( $email, '@' );
		if ( false === $at ) {
			return '';
		}
		$domain = strtolower( trim( substr( $email, $at + 1 ) ) );
		return preg_match( '/^[a-z0-9-]+(\.[a-z0-9-]+)+$/', $domain ) ? $domain : '';
	}

	/**
	 * MX hosts sorted by priority. Empty when the host can't do DNS
	 * lookups (some disable them) or the domain has no MX.
	 *
	 * @return string[]
	 */
	private static function mx_hosts( string $domain ): array {
		if ( ! function_exists( 'getmxrr' ) ) {
			return [];
		}
		$hosts   = [];
		$weights = [];
		// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- a failed lookup is an expected outcome, not an error.
		if ( ! @getmxrr( $domain, $hosts, $weights ) ) {
			return [];
		}
		array_multisort( $weights, SORT_ASC, SORT_NUMERIC, $hosts );
		return $hosts;
	}

	private static function known( array $found ): array {
		return [
			'provider' => $found[0],
			'label'    => $found[1],
		];
	}

	private static function unknown(): array {
		return [
			'provider' => null,
			'label'    => null,
		];
	}
}
