<?php
/**
 * Bridle Chat's rules (#114): what a visitor may send, when the agent may
 * answer, and the token that ties a visitor to their chat. Pure, unit-tested.
 *
 * @package Bridle
 */

namespace Bridle\Services;

defined( 'ABSPATH' ) || exit;

/**
 * Everything here takes its state as arguments, so it runs without WordPress.
 */
class ChatPolicy {

	/**
	 * Default limits. ChatService::limits() passes them through the
	 * `bridle_chat_limits` filter.
	 */
	public const LIMITS = [
		'max_chars'              => 1000, // One message.
		'per_chat'               => 20,   // Visitor messages in one chat.
		'per_visitor_hour'       => 30,   // Messages from one visitor in an hour.
		'chats_per_visitor_hour' => 6,    // New chats from one visitor in an hour.
		'handoffs_per_hour'      => 3,    // Emails left by one visitor in an hour.
		'answers_per_hour'       => 120,  // AI answers for the whole site in an hour.
	];

	/**
	 * Topics a person always answers in a chat. Auto's list (AutoSend::TRIPWIRE)
	 * without "password", "discount" and "guarantee", which visitors ask about
	 * every day; the model's own flags still catch security and billing.
	 */
	public const TRIPWIRE = '/\b(refund\w*|chargeback\w*|cancel\w*|billing|invoice\w*|charged|overcharg\w*|dispute\w*|lawyer\w*|legal|lawsuit|gdpr|privacy|delete my (data|account)|hack\w*|breach\w*|fraud\w*|scam\w*|compensat\w*|money back)\b/i';

	/** Longest subject a chat gets in the Inbox, in characters. */
	public const SUBJECT_CHARS = 80;

	/**
	 * A visitor's message, tidied, or null when it can't be sent: empty,
	 * too long, or the honeypot field was filled in.
	 *
	 * @param string $text      What the visitor typed.
	 * @param int    $max_chars Longest allowed.
	 * @param string $honeypot  The hidden field only bots fill in.
	 */
	public static function clean( string $text, int $max_chars, string $honeypot = '' ): ?string {
		if ( '' !== trim( $honeypot ) ) {
			return null;
		}
		// Keep line breaks, drop control characters, squeeze blank lines.
		$text = (string) preg_replace( '/[^\P{C}\n]+/u', '', str_replace( "\r\n", "\n", $text ) );
		$text = trim( (string) preg_replace( "/\n{3,}/", "\n\n", $text ) );
		if ( '' === $text || mb_strlen( $text ) > $max_chars ) {
			return null;
		}
		return $text;
	}

	/**
	 * Whether the agent may show its answer, or why a person takes over.
	 *
	 * @param array  $draft    AgentPrompt::parse() output.
	 * @param array  $problems AgentPrompt::verify() output.
	 * @param string $visitor  The visitor's newest message.
	 * @return array{answer: bool, reason: string} reason: '' | a model flag | tripwire | unverified | unsure.
	 */
	public static function decide( array $draft, array $problems, string $visitor ): array {
		$flags = array_values( array_filter( (array) ( $draft['flags'] ?? [] ) ) );
		if ( $flags ) {
			return [
				'answer' => false,
				'reason' => (string) $flags[0],
			];
		}
		$reply = AgentPrompt::flatten( (string) ( $draft['reply_html'] ?? '' ) );
		if ( preg_match( self::TRIPWIRE, $visitor . "\n" . $reply ) ) {
			return [
				'answer' => false,
				'reason' => 'tripwire',
			];
		}
		if ( $problems ) {
			return [
				'answer' => false,
				'reason' => 'unverified',
			];
		}
		if ( 'low' === ( $draft['confidence'] ?? 'low' ) || '' !== trim( (string) ( $draft['needs_human_reason'] ?? '' ) ) ) {
			return [
				'answer' => false,
				'reason' => 'unsure',
			];
		}
		return [
			'answer' => true,
			'reason' => '',
		];
	}

	/**
	 * The secret a visitor's browser keeps to continue its chat. Bound to the
	 * conversation's random thread id, so it can't be guessed from the id.
	 *
	 * @param string $thread_id The conversation's thread_id.
	 * @param string $key       A site secret (wp_salt).
	 */
	public static function token( string $thread_id, string $key ): string {
		return hash_hmac( 'sha256', 'bridle-chat|' . $thread_id, $key );
	}

	public static function check_token( string $thread_id, string $token, string $key ): bool {
		return '' !== $thread_id && '' !== $token && hash_equals( self::token( $thread_id, $key ), $token );
	}

	/**
	 * The chat's subject in the Inbox: the visitor's first line, cut at a word.
	 */
	public static function subject( string $text ): string {
		$line = trim( (string) strtok( trim( $text ), "\n" ) );
		if ( mb_strlen( $line ) <= self::SUBJECT_CHARS ) {
			return $line;
		}
		$cut   = mb_substr( $line, 0, self::SUBJECT_CHARS );
		$space = mb_strrpos( $cut, ' ' );
		return rtrim( false !== $space && $space > 40 ? mb_substr( $cut, 0, $space ) : $cut, ' ,.;:-' ) . '…';
	}

	/** Conversations needed before a reply time is promised (Intercom's rule). */
	public const REPLY_TIME_MIN_SAMPLES = 5;

	/**
	 * What to promise a visitor at handoff, from the minutes each recent
	 * conversation waited for its first reply from a person.
	 *
	 * @param float[] $minutes One value per conversation.
	 * @return array{kind: string, n: int} kind: unknown | minutes | hour | hours | day | days.
	 */
	public static function reply_time( array $minutes ): array {
		if ( count( $minutes ) < self::REPLY_TIME_MIN_SAMPLES ) {
			return [ 'kind' => 'unknown', 'n' => 0 ];
		}
		sort( $minutes );
		$mid    = intdiv( count( $minutes ), 2 );
		$median = count( $minutes ) % 2 ? $minutes[ $mid ] : ( $minutes[ $mid - 1 ] + $minutes[ $mid ] ) / 2;

		if ( $median < 15 ) {
			return [ 'kind' => 'minutes', 'n' => 0 ];
		}
		if ( $median < 90 ) {
			return [ 'kind' => 'hour', 'n' => 1 ];
		}
		if ( $median < 20 * 60 ) {
			return [ 'kind' => 'hours', 'n' => (int) ceil( $median / 60 ) ];
		}
		if ( $median < 36 * 60 ) {
			return [ 'kind' => 'day', 'n' => 1 ];
		}
		return [ 'kind' => 'days', 'n' => (int) ceil( $median / 1440 ) ];
	}

	/** Longest page address a chat keeps, in characters. */
	public const PAGE_CHARS = 500;

	/**
	 * The host a URL or browser origin names, lowercased, without a leading
	 * "www.", or '' when there is none.
	 */
	public static function host( string $url ): string {
		$host = strtolower( (string) wp_parse_url( trim( $url ), PHP_URL_HOST ) );
		return (string) preg_replace( '/^www\./', '', $host );
	}

	/**
	 * Whether a browser's Origin header is this site. No header (a server, or
	 * an old browser) passes; the limits still apply. "www." and the scheme
	 * don't count, so http/https and www/apex twins of the site pass.
	 *
	 * @param string   $origin The Origin header, e.g. https://example.com.
	 * @param string[] $hosts  This site's hosts, from host().
	 */
	public static function same_site( string $origin, array $hosts ): bool {
		$origin = trim( $origin );
		if ( '' === $origin ) {
			return true;
		}
		$host = self::host( $origin );
		return '' !== $host && in_array( $host, array_filter( $hosts ), true );
	}

	/**
	 * The page a chat started on, as the team sees it: http(s) only, without
	 * the query or fragment (where addresses and tokens hide), and only when
	 * it is on the origin that sent the request. '' when it isn't.
	 *
	 * @param string $url    location.href from the visitor's browser.
	 * @param string $origin The request's Origin header ('' when none).
	 */
	public static function page( string $url, string $origin ): string {
		$parts  = wp_parse_url( trim( $url ) );
		$scheme = strtolower( (string) ( $parts['scheme'] ?? '' ) );
		$host   = strtolower( (string) ( $parts['host'] ?? '' ) );
		if ( ! in_array( $scheme, [ 'http', 'https' ], true ) || '' === $host || preg_match( '/[^a-z0-9.\-]/', $host ) ) {
			return '';
		}
		if ( '' !== trim( $origin ) && self::host( $origin ) !== self::host( $url ) ) {
			return '';
		}
		$port = isset( $parts['port'] ) ? ':' . (int) $parts['port'] : '';
		$path = (string) preg_replace( '/[^\x21-\x7e]/', '', (string) ( $parts['path'] ?? '/' ) );
		$page = $scheme . '://' . $host . $port . ( '' !== $path ? $path : '/' );
		return strlen( $page ) <= self::PAGE_CHARS ? $page : '';
	}

	/**
	 * Whether a limit is reached, given how many there were so far.
	 */
	public static function over( int $count, int $limit ): bool {
		return $limit > 0 && $count >= $limit;
	}
}
