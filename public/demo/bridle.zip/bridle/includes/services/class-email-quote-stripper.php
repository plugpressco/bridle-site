<?php

namespace Bridle\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Strips quoted reply history from incoming emails so threads don't show
 * the same message twice. Handles Gmail, Outlook, Apple Mail, Yahoo.
 *
 * We strip from the first matching marker onward — everything above that
 * line is the new content the customer actually wrote.
 */
class EmailQuoteStripper {

	/**
	 * Localised Outlook reply-header labels.
	 *
	 * Outlook writes the header in the sender's own language, so an English-only
	 * pattern leaves every non-English quote sitting in the thread. Note some
	 * locales put a word between the label and the colon — Spanish "Enviado el:",
	 * Portuguese "Enviada em:" — which SENT_LABEL allows for.
	 */
	private const L_FROM = 'From|Van|Da|Von|De|Fra|Från|Od';
	private const L_SENT = 'Sent|Verzonden|Inviato|Gesendet|Envoyé|Enviado|Enviada|Skickat|Wysłano';

	/** `From:` and `Sent:` label patterns, in any supported language. */
	private static function from_label(): string {
		return '(?:' . self::L_FROM . ')\s*:';
	}

	private static function sent_label(): string {
		return '(?:' . self::L_SENT . ')(?:\s+\w{1,12})?\s*:';
	}

	/**
	 * Strip quoted history from a plain-text email body.
	 */
	public static function strip_text( string $text ): string {
		if ( '' === trim( $text ) ) {
			return $text;
		}

		// Match the FIRST occurrence of any common quote marker.
		// Each pattern anchored to start of a line.
		$markers = [
			// Gmail: "On Mon, Jan 1, 2024 at 3:45 PM John Doe <john@example.com> wrote:"
			'/^[ \t>]*On\s.{1,200}\s+wrote:\s*$/im',
			// Gmail (shorter/wrapped): "On ... wrote:" as standalone line
			'/^[ \t>]*On .{1,500}?wrote:\s*$/im',
			// Outlook: "-----Original Message-----"
			'/^[ \t>]*-{2,}\s*Original Message\s*-{2,}\s*$/im',
			// Outlook: "From: X\nSent: ...\nTo: ..." block, in any language.
			'/^[ \t>]*' . self::from_label() . '\s*.+?[\r\n]+[ \t>]*' . self::sent_label() . '/imu',
			// Yahoo: "On ..., ... wrote:" variant with colon
			'/^[ \t>]*On .{1,300},.{1,200}wrote:\s*$/im',
			// Generic "Sent from my iPhone" etc. — do NOT strip (that's new content)
			// NOTE: "Begin forwarded message:" is intentionally NOT here. A forwarded
			// email is new content the customer is sharing with us, not a reply chain
			// we already have stored. Stripping it would silently discard the message.
		];

		$earliest = null;
		foreach ( $markers as $pattern ) {
			if ( preg_match( $pattern, $text, $m, PREG_OFFSET_CAPTURE ) ) {
				$offset = $m[0][1];
				if ( null === $earliest || $offset < $earliest ) {
					$earliest = $offset;
				}
			}
		}

		if ( null !== $earliest ) {
			$text = substr( $text, 0, $earliest );
		}

		// Also strip trailing blocks of '>'-quoted lines (fallback when no header line).
		$lines = preg_split( '/\r\n|\r|\n/', $text );
		$trailing_quote_start = null;
		for ( $i = count( $lines ) - 1; $i >= 0; $i-- ) {
			$line = ltrim( $lines[ $i ] );
			if ( '' === $line ) {
				continue;
			}
			if ( '>' === substr( $line, 0, 1 ) ) {
				$trailing_quote_start = $i;
			} else {
				break;
			}
		}
		if ( null !== $trailing_quote_start ) {
			$lines = array_slice( $lines, 0, $trailing_quote_start );
			$text  = implode( "\n", $lines );
		}

		return rtrim( $text );
	}

	/**
	 * Prepare an inbound HTML body for storage without discarding anything the
	 * sender wrote.
	 *
	 * This is what `content_html` gets. `strip_html()` below still exists and is
	 * still destructive, but it is now only used to derive a hint for sender
	 * resolution — never for what we keep.
	 *
	 * The distinction matters: quoted history is *noise in a list preview* but
	 * it is *evidence in a conversation*. Deleting it at ingest meant a customer
	 * who quoted a shipping address, an error message or a prior promise had
	 * that content silently removed from the record, with no way to get it back.
	 * The client now folds quotes behind a toggle instead, which is reversible.
	 *
	 * The one thing still removed here is the external-sender warning banner:
	 * that is injected by the *recipient's* mail system, was never part of the
	 * message, and is never useful.
	 */
	public static function clean_html( string $html ): string {
		if ( '' === trim( $html ) ) {
			return $html;
		}

		return trim( self::strip_external_sender_banner( $html ) );
	}

	/**
	 * Strip quoted history from an HTML email body.
	 *
	 * Targets the standard containers mail clients use for quoted content:
	 * - <blockquote type="cite"> (Apple Mail, Gmail)
	 * - <div class="gmail_quote">
	 * - <div class="gmail_attr">
	 * - Outlook's <div id="divRplyFwdMsg">, <div id="appendonsend">
	 * - Word-generated "<hr>" + from/sent/to block
	 */
	public static function strip_html( string $html ): string {
		if ( '' === trim( $html ) ) {
			return $html;
		}

		// Defender / Exchange Online "You don't often get email from…" banner.
		$html = self::strip_external_sender_banner( $html );

		// Detect forwarded messages BEFORE stripping any quote containers.
		// "Forwarded message" appears in Gmail's gmail_attr div; "Begin forwarded
		// message" appears in Apple Mail. Either means the blockquote / gmail_quote
		// div IS the message, not old thread history — do not strip it.
		$is_forward = stripos( $html, 'forwarded message' ) !== false;

		if ( ! $is_forward ) {
			// Remove known quote containers. Non-greedy, dot-all, case-insensitive.
			$patterns = [
				// Gmail wrapper div (contains the "On ... wrote:" + blockquote).
				'#<div[^>]*class="[^"]*gmail_quote[^"]*"[^>]*>.*?</div>\s*(?=<|$)#is',
				// Apple Mail / Gmail blockquote with cite.
				'#<blockquote[^>]*type=["\']cite["\'][^>]*>.*?</blockquote>#is',
				// Outlook reply wrapper.
				'#<div[^>]*id=["\']divRplyFwdMsg["\'][^>]*>.*?</div>#is',
				'#<div[^>]*id=["\']appendonsend["\'][^>]*>.*?</div>#is',
				// Any remaining <blockquote> (conservative last pass).
				'#<blockquote[^>]*>.*?</blockquote>#is',
			];

			foreach ( $patterns as $pattern ) {
				$html = preg_replace( $pattern, '', $html );
			}
		}

		// Outlook Classic "Word-style" reply header — no blockquote, no <hr>,
		// just a styled <div>/<p> containing <b>From:</b>…<b>Sent:</b>…
		$html = self::strip_outlook_reply_header( $html );

		// Remove trailing empty containers / <br> left behind by stripping.
		$html = preg_replace( '#(<div[^>]*>\s*</div>\s*)+$#i', '', $html );
		$html = preg_replace( '#(<br\s*/?>\s*){2,}$#i', '', $html );

		return trim( $html );
	}

	/**
	 * Strip Outlook Classic "Word-style" reply header and everything after it.
	 *
	 * Outlook wraps the quoted reply in a styled <div> + <p class="MsoNormal">
	 * containing <b>From:</b>/<b>Sent:</b>/<b>To:</b>/<b>Subject:</b> labels
	 * — no blockquote, so our other patterns miss it. Strategy: locate the
	 * first From:/Sent: label pair, then walk back to the nearest block-level
	 * opening tag and cut to end.
	 */
	private static function strip_outlook_reply_header( string $html ): string {
		// The match must START at (or immediately before) the From label: the
		// caller walks back from $m[0][1] to the nearest block-level tag. Allow
		// only inline formatting here — swallowing the enclosing <div>/<p> would
		// push the match start above the real message and strip the lot.
		$inline = '(?:<(?:b|strong|span|font|i|em)[^>]{0,160}>\s*)*';

		if ( ! preg_match(
			'#' . $inline . self::from_label() . '[\s\S]{0,600}?' . $inline . self::sent_label() . '#iu',
			$html,
			$m,
			PREG_OFFSET_CAPTURE
		) ) {
			return $html;
		}

		$pos    = $m[0][1];
		$before = substr( $html, 0, $pos );

		$candidates = [];
		foreach ( [ '<div', '<p', '<table', '<hr' ] as $tag ) {
			$p = strripos( $before, $tag );
			if ( false !== $p ) {
				$candidates[] = $p;
			}
		}

		if ( empty( $candidates ) ) {
			return $html;
		}

		return substr( $html, 0, max( $candidates ) );
	}

	/**
	 * Strip Microsoft Defender / Exchange Online external-sender warning
	 * banners ("You don't often get email from X. Learn why this is important").
	 */
	private static function strip_external_sender_banner( string $html ): string {
		$marker = "You don't often get email from";

		// id="x_TMU_Banner" / id="TMU_Banner" wrapper (most reliable).
		$html = preg_replace(
			'#<(div|table)\b[^>]*id=["\']x?_?TMU_Banner["\'][^>]*>[\s\S]*?</\1>\s*#i',
			'',
			$html
		);

		// Fallback — any <table> or <div> that contains the banner text.
		if ( false !== stripos( $html, $marker ) ) {
			$html = preg_replace(
				'#<table\b[^>]*>(?:(?!</table>)[\s\S])*?' . preg_quote( $marker, '#' ) . '[\s\S]*?</table>\s*#i',
				'',
				$html
			);
			$html = preg_replace(
				'#<div\b[^>]*>(?:(?!</div>)[\s\S])*?' . preg_quote( $marker, '#' ) . '[\s\S]*?</div>\s*#i',
				'',
				$html
			);
		}

		return $html;
	}
}
