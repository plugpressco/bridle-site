<?php

namespace Bridle\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Is this email from a person or a machine, and where does it belong?
 *
 * Two sources of evidence:
 * - Headers the worker forwards (Precedence, Auto-Submitted, List-Id,
 *   List-Unsubscribe) and the sender address. Deterministic, always there.
 * - The owner's decision model (Services\Classifier: Jev or Clef on their own
 *   key). Calibrated confidences, but best-effort, so it can be missing.
 *
 * The rule when in doubt is the Inbox: a receipt left in the Inbox costs a
 * glance, a customer hidden in the Feed costs a customer.
 *
 * Pure logic, no WordPress state, so it's unit-tested directly.
 */
class AutomatedMail {

	/** Classifier confidence needed to file mail in the Feed. */
	const FEED_CONFIDENCE = 0.8;

	/** Classifier confidence needed to file mail as spam. */
	const SPAM_CONFIDENCE = 0.9;

	/** Classifier confidence that overrides a machine-looking sender (contact forms). */
	const PERSON_CONFIDENCE = 0.8;

	private const BOXES      = [ 'customer_request', 'automated', 'sales_pitch', 'spam' ];
	private const INTENTS    = [ 'bug_report', 'how_to', 'billing', 'refund', 'presale', 'account', 'feature_request', 'general' ];
	private const URGENCIES  = [ 'low', 'normal', 'high' ];
	private const SENTIMENTS = [ 'positive', 'neutral', 'frustrated', 'angry' ];

	/**
	 * Where a new conversation from this email goes.
	 *
	 * @param string     $sender         Resolved sender address (after Reply-To / contact-form recovery).
	 * @param array      $headers        precedence, auto_submitted, list_id, list_unsubscribe.
	 * @param array|null $classification Output of sanitize_classification(), or null.
	 * @return array{status: string, is_automated: bool, urgency: ?string}
	 */
	public static function route( string $sender, array $headers, ?array $classification ): array {
		$box        = $classification['box']['value'] ?? null;
		$confidence = (float) ( $classification['box']['confidence'] ?? 0 );

		$is_spam = 'spam' === $box && $confidence >= self::SPAM_CONFIDENCE;

		// A bulk header is decisive. A machine-looking sender is not on its
		// own: contact forms send as noreply@ — unless the classifier is sure a person
		// wrote it, that's still Feed.
		$vouched_person = 'customer_request' === $box && $confidence >= self::PERSON_CONFIDENCE;
		$is_automated   = self::is_bulk( $headers )
			|| self::is_auto_reply( $headers )
			|| ( in_array( $box, [ 'automated', 'sales_pitch' ], true ) && $confidence >= self::FEED_CONFIDENCE )
			|| ( self::is_machine_sender( $sender ) && ! $vouched_person );

		return [
			'status'       => $is_spam ? 'spam' : 'active',
			'is_automated' => $is_automated && ! $is_spam,
			'urgency'      => $classification['urgency']['value'] ?? null,
		];
	}

	/**
	 * Headers that only bulk or machine-sent mail carries.
	 */
	public static function is_bulk( array $headers ): bool {
		$auto_submitted = strtolower( trim( (string) ( $headers['auto_submitted'] ?? '' ) ) );
		$precedence     = strtolower( trim( (string) ( $headers['precedence'] ?? '' ) ) );

		return ( '' !== $auto_submitted && 'no' !== $auto_submitted )
			|| in_array( $precedence, [ 'bulk', 'list', 'junk', 'auto_reply' ], true )
			|| '' !== trim( (string) ( $headers['list_id'] ?? '' ) )
			|| '' !== trim( (string) ( $headers['list_unsubscribe'] ?? '' ) );
	}

	/**
	 * Headers that mean "never auto-reply to this" (RFC 3834 plus
	 * out-of-office subjects). Broader than is_bulk(): a loop costs more
	 * than a missed acknowledgement.
	 */
	public static function has_loop_headers( array $headers ): bool {
		if ( self::is_bulk( $headers ) || self::is_auto_reply( $headers ) || ! empty( $headers['x_auto_response_suppress'] ) ) {
			return true;
		}

		$subject = strtolower( (string) ( $headers['subject'] ?? '' ) );
		foreach ( [ 'out of office', 'out-of-office', 'auto reply', 'auto-reply', 'autoreply', 'automatic reply', 'vacation' ] as $marker ) {
			if ( false !== strpos( $subject, $marker ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Subject openings an auto-responder writes (out of office, vacation,
	 * "we got your message"), in the languages customers write in. Matched
	 * at the start only, after any Re:/Fwd:, so a customer asking about a
	 * "vacation rental" is still a customer.
	 */
	private const AUTO_REPLY_SUBJECTS = [
		'automatic reply',
		'auto reply',
		'auto-reply',
		'autoreply',
		'auto response',
		'auto-response',
		'autoresponse',
		'auto:',
		'out of office',
		'out-of-office',
		'out of the office',
		'ooo:',
		'away from the office',
		'on vacation',
		'abwesenheitsnotiz',
		'automatische antwort',
		'réponse automatique',
		'absence du bureau',
		'respuesta automática',
		'fuera de la oficina',
		'risposta automatica',
		'fuori ufficio',
		'automatisch antwoord',
		'afwezig',
		'resposta automática',
		'fora do escritório',
		'autosvar',
		'automaattinen vastaus',
	];

	/**
	 * An auto-responder's answer: an out-of-office or vacation reply, or a
	 * "we received your message" receipt. RFC 3834 headers (Auto-Submitted
	 * other than "no", Precedence auto_reply, bulk or junk), X-Autoreply or
	 * X-Autorespond, or a subject that opens like one. Stricter than
	 * has_loop_headers(): X-Auto-Response-Suppress alone does not count,
	 * since a person's Exchange mail can carry it, and an auto-reply is kept
	 * out of "needs reply", which a person's message must never be.
	 */
	public static function is_auto_reply( array $headers ): bool {
		$auto_submitted = strtolower( trim( (string) ( $headers['auto_submitted'] ?? '' ) ) );
		$precedence     = strtolower( trim( (string) ( $headers['precedence'] ?? '' ) ) );

		if ( ( '' !== $auto_submitted && 'no' !== $auto_submitted )
			|| in_array( $precedence, [ 'auto_reply', 'bulk', 'junk' ], true )
			|| '' !== trim( (string) ( $headers['x_autoreply'] ?? '' ) )
			|| '' !== trim( (string) ( $headers['x_autorespond'] ?? '' ) ) ) {
			return true;
		}

		$subject = strtolower( trim( (string) ( $headers['subject'] ?? '' ) ) );
		// Drop any number of Re:/Fwd:/AW:/SV: and a ticket tag in front.
		$subject = (string) preg_replace( '/^(?:(?:re|fwd?|aw|sv|wg|tr)\s*:\s*|\[#[a-z0-9\-]+\]\s*)+/iu', '', $subject );
		foreach ( self::AUTO_REPLY_SUBJECTS as $opening ) {
			if ( 0 === strpos( $subject, $opening ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Addresses no person reads: noreply@, bounces@, notifications@, …
	 */
	public static function is_machine_sender( string $email ): bool {
		$at    = strpos( $email, '@' );
		$local = strtolower( false === $at ? $email : substr( $email, 0, $at ) );

		$exact = [
			'noreply',
			'no-reply',
			'donotreply',
			'do-not-reply',
			'mailer-daemon',
			'postmaster',
			'mail-daemon',
			'bounce',
			'bounces',
			'return',
			'returns',
			'notifications',
			'notification',
			'alert',
			'alerts',
			'system',
			'root',
			'daemon',
			'cron',
		];
		foreach ( $exact as $needle ) {
			if ( $local === $needle || str_contains( $local, $needle . '+' ) || str_contains( $local, $needle . '-' ) ) {
				return true;
			}
		}

		foreach ( [ 'noreply', 'no-reply', 'bounce', 'donotreply' ] as $needle ) {
			if ( str_contains( $local, $needle ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * A classification reduced to known keys and values. Anything unexpected
	 * is dropped; null if there's no box answer.
	 *
	 * @param mixed $raw Classifier::normalize()'s reading of a provider's answer.
	 */
	public static function sanitize_classification( $raw ): ?array {
		if ( ! is_array( $raw ) ) {
			return null;
		}

		$box = self::answer( $raw['box'] ?? null, self::BOXES );
		if ( ! $box ) {
			return null;
		}

		$needs_human = $raw['needs_human'] ?? null;

		return [
			'model'       => substr( preg_replace( '/[^A-Za-z0-9@._\/-]/', '', (string) ( $raw['model'] ?? '' ) ), 0, 64 ),
			'box'         => $box,
			'intent'      => self::answer( $raw['intent'] ?? null, self::INTENTS ),
			'urgency'     => self::answer( $raw['urgency'] ?? null, self::URGENCIES ),
			'sentiment'   => self::answer( $raw['sentiment'] ?? null, self::SENTIMENTS ),
			'needs_human' => is_numeric( $needs_human ) ? self::unit( $needs_human ) : null,
		];
	}

	/** @return array{value: string, confidence: float}|null */
	private static function answer( $answer, array $allowed ): ?array {
		if ( ! is_array( $answer ) || ! in_array( $answer['value'] ?? null, $allowed, true ) ) {
			return null;
		}

		return [
			'value'      => $answer['value'],
			'confidence' => self::unit( $answer['confidence'] ?? 0 ),
		];
	}

	/** Clamp to 0–1. */
	private static function unit( $n ): float {
		return max( 0.0, min( 1.0, (float) $n ) );
	}
}
