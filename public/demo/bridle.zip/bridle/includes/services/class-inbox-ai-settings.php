<?php

namespace Bridle\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Per-inbox agent settings, stored in wp_options.
 *
 * Key:   bridle_inbox_ai_{id}
 * Value: JSON { agent_mode: "off" | "draft" | "auto" }
 *
 * - off:   the agent does nothing in this inbox.
 * - draft: the agent drafts a reply for every new customer message; a
 *          teammate sends, edits or discards it.
 * - auto:  as draft, and the agent may send a draft itself when it passes
 *          every guardrail (#20, design section e).
 *
 * Off by default: an inbox never gets AI replies until someone turns it on.
 * Keys from earlier versions (ai_classify, ai_auto_draft, ai_summarize) are
 * ignored.
 */
class InboxAiSettings {

	private const OPTION_PREFIX = 'bridle_inbox_ai_';

	public const MODES = [ 'off', 'draft', 'auto' ];

	private const DEFAULTS = [
		'agent_mode' => 'off',
	];

	public static function get( int $inbox_id ): array {
		$data = json_decode( (string) get_option( self::OPTION_PREFIX . $inbox_id, '' ), true );
		$mode = is_array( $data ) ? ( $data['agent_mode'] ?? '' ) : '';

		return [
			'agent_mode' => in_array( $mode, self::MODES, true ) ? $mode : self::DEFAULTS['agent_mode'],
		];
	}

	public static function update( int $inbox_id, array $data ): array {
		$current = self::get( $inbox_id );

		if ( in_array( $data['agent_mode'] ?? null, self::MODES, true ) ) {
			$current['agent_mode'] = $data['agent_mode'];
		}

		update_option( self::OPTION_PREFIX . $inbox_id, wp_json_encode( $current ), false );

		return $current;
	}

	public static function agent_mode( int $inbox_id ): string {
		return self::get( $inbox_id )['agent_mode'];
	}
}
