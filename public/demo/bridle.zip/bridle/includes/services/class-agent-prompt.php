<?php

namespace Bridle\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * What the agent is told, what it must answer, and whether the answer holds up.
 *
 * Kept apart from AgentService (which loads data, calls the model and stores
 * the draft) because everything here is pure: it takes plain arrays and
 * strings and is unit-tested without WordPress.
 *
 * Knowledge is a map of sources keyed by id: the Agent instructions, the
 * Snippets, and what KnowledgeSearch found for this email (help docs, site
 * pages and posts, products, how the team answered before). A draft is
 * "verified" only when every source it cites is in that map, every quote
 * really appears in that source, and every link in the reply comes from it.
 */
class AgentPrompt {

	/** Messages from the end of the conversation the model sees. */
	const MAX_MESSAGES = 12;

	/** Characters kept per message; long quoted mail is noise. */
	const MAX_MESSAGE_CHARS = 4000;

	/** A shorter quote can't show where a fact came from. */
	const MIN_QUOTE_CHARS = 8;

	/** Source id prefixes, in the order the prompt lists them (most authoritative first). */
	const SOURCE_TYPES = [ 'instructions', 'snippet', 'kb', 'product', 'page', 'post', 'past' ];

	/** What the model may flag about an email: each one keeps a person in the loop. */
	const FLAGS = [ 'refund', 'billing', 'legal', 'privacy', 'security', 'cancellation', 'upset' ];

	/** The shape the model must answer in. */
	public static function schema(): array {
		return [
			'type'       => 'object',
			'properties' => [
				'reply_html'         => [ 'type' => 'string' ],
				'confidence'         => [
					'type' => 'string',
					'enum' => [ 'high', 'medium', 'low' ],
				],
				'grounded_in'        => [
					'type'  => 'array',
					'items' => [
						'type'       => 'object',
						'properties' => [
							'source' => [
								'type'        => 'string',
								'description' => 'The id in brackets: instructions, snippet:…, kb:…, product:…, page:…, post:… or past:…',
							],
							'quote'  => [ 'type' => 'string' ],
						],
						'required'   => [ 'source', 'quote' ],
					],
				],
				'flags'              => [
					'type'  => 'array',
					'items' => [
						'type' => 'string',
						'enum' => self::FLAGS,
					],
				],
				'needs_human_reason' => [ 'type' => 'string' ],
				'summary'            => [ 'type' => 'string' ],
			],
			'required'   => [ 'reply_html', 'confidence', 'grounded_in', 'flags', 'needs_human_reason', 'summary' ],
		];
	}

	public static function system_instruction( string $business ): string {
		$business = '' !== trim( $business ) ? trim( $business ) : 'this business';

		return "You are the customer support agent for {$business}. You draft email replies; a teammate usually reviews them, and some are sent as written, so be exact.\n\n"
			. "Rules:\n"
			. "- Answer only from KNOWLEDGE and the conversation. Never invent facts, prices, policies, features, dates or links.\n"
			. "- For every fact you use, add an entry to grounded_in: source = the id in square brackets before that piece of knowledge (for example \"instructions\", \"snippet:sr_1\", \"kb:123\", \"page:45\"), with a short quote copied exactly from it.\n"
			. "- Only include links that appear in KNOWLEDGE. A source's own link, shown in its heading, counts.\n"
			. "- Prices and stock come only from [product:…] entries or the instructions.\n"
			. "- [past:…] entries show how the team answered other customers. Use them for the approach and the wording, never as policy over the instructions or docs, and never mention those customers or anything specific to them.\n"
			. "- Text like [email], [link], [name] or [number] is redacted. Never copy it into a reply.\n"
			. "- If KNOWLEDGE does not cover the question, still write the most useful reply you can (for example, ask the one clarifying question you need), set confidence to low or medium, and say in needs_human_reason what a person must check.\n"
			. "- Refunds, billing disputes, legal, privacy or security matters, cancellations and angry customers always need a person: list them in flags and say why in needs_human_reason.\n"
			. "- needs_human_reason is an empty string only when the reply fully and safely answers the customer.\n"
			. "- Reply in the customer's language. Be warm, specific and brief. Greet the customer by first name. Do not sign off with a name; a signature is added automatically.\n"
			. "- reply_html uses only p, br, ul, ol, li, a, strong, em and code.\n"
			. '- summary is one sentence for the teammate: what the customer needs and where things stand.';
	}

	/**
	 * Bridle Chat's instruction (#114): the same rules and the same answer
	 * shape as a draft, for a visitor on the website who reads it at once.
	 * ChatPolicy::decide() shows it only when it is verified and sure.
	 */
	public static function chat_instruction( string $business ): string {
		$business = '' !== trim( $business ) ? trim( $business ) : 'this business';

		return "You are the AI assistant for {$business}, answering a visitor in a chat on the website. Your answer is shown to them at once unless you say a person must check it.\n\n"
			. "Rules:\n"
			. "- Answer only from KNOWLEDGE and the conversation. Never invent facts, prices, policies, features, dates or links.\n"
			. "- For every fact you use, add an entry to grounded_in: source = the id in square brackets before that piece of knowledge, with a short quote copied exactly from it.\n"
			. "- Only include links that appear in KNOWLEDGE. A source's own link, shown in its heading, counts. Link the page that answers the question when there is one.\n"
			. "- Prices and stock come only from [product:…] entries or the instructions.\n"
			. "- [past:…] entries show how the team answered other customers. Use them for the approach, never as policy over the instructions or docs, and never mention those customers.\n"
			. "- Text like [email], [link], [name] or [number] is redacted. Never copy it.\n"
			. "- If KNOWLEDGE does not cover the question, do not guess: set confidence to low and say in needs_human_reason what is missing. A person will follow up by email.\n"
			. "- Refunds, billing disputes, legal, privacy or security matters, cancellations and angry visitors always need a person: list them in flags.\n"
			. "- needs_human_reason is an empty string only when the answer fully and safely answers the visitor.\n"
			. "- A greeting or thanks gets a short friendly answer with confidence high and no sources.\n"
			. "- Reply in the visitor's language. Be warm and brief: one to three short paragraphs or a short list. No greeting by name, no sign-off.\n"
			. "- reply_html uses only p, br, ul, ol, li, a, strong, em and code.\n"
			. '- summary is one sentence for the team: what the visitor wanted.';
	}

	/**
	 * The knowledge map: id => [ id, type, ref, title, url, text, date? ], in
	 * the order the prompt shows it.
	 *
	 * @param string $instructions The business's Agent instructions.
	 * @param array  $snippets     [ [ 'id' => …, 'title' => …, 'body' => … ], … ].
	 * @param array  $found        Items from KnowledgeSearch (each has id, type, title, url, text).
	 */
	public static function knowledge( string $instructions, array $snippets, array $found = [] ): array {
		$map = [
			'instructions' => [
				'id'    => 'instructions',
				'type'  => 'instructions',
				'ref'   => '',
				'title' => 'Agent instructions',
				'url'   => '',
				'text'  => trim( $instructions ),
			],
		];

		foreach ( $snippets as $snippet ) {
			$ref = (string) ( $snippet['id'] ?? '' );
			if ( '' === $ref ) {
				continue;
			}
			$map[ "snippet:{$ref}" ] = [
				'id'    => "snippet:{$ref}",
				'type'  => 'snippet',
				'ref'   => $ref,
				'title' => trim( (string) ( $snippet['title'] ?? '' ) ),
				'url'   => '',
				'text'  => trim( (string) ( $snippet['body'] ?? '' ) ),
			];
		}

		$order = array_flip( self::SOURCE_TYPES );
		usort( $found, static fn( $a, $b ) => ( $order[ $a['type'] ?? '' ] ?? 99 ) <=> ( $order[ $b['type'] ?? '' ] ?? 99 ) );
		foreach ( $found as $item ) {
			if ( ! empty( $item['id'] ) && ! isset( $map[ $item['id'] ] ) ) {
				$map[ $item['id'] ] = $item + [
					'ref'   => '',
					'title' => '',
					'url'   => '',
					'text'  => '',
				];
			}
		}

		return $map;
	}

	/**
	 * The user message: knowledge, the customer, then the conversation.
	 *
	 * @param array $knowledge Output of knowledge().
	 * @param array $customer  [ 'name' => …, 'email' => …, 'cards' => [ card, … ] ].
	 * @param array $messages  [ [ 'author' => 'customer'|'teammate'|'agent'|'system', 'name' => …,
	 *                         'private' => bool, 'at' => 'Y-m-d H:i:s', 'text' => … ], … ] oldest first.
	 */
	public static function user_prompt( array $knowledge, array $customer, array $messages ): string {
		$out = [ 'KNOWLEDGE' ];

		foreach ( $knowledge as $id => $entry ) {
			$out[] = '';
			$out[] = self::heading( (string) $id, $entry );
			$text  = trim( (string) ( $entry['text'] ?? '' ) );
			$out[] = '' !== $text ? $text : '(none)';
		}

		$out[] = '';
		$out[] = 'CUSTOMER';
		$out[] = trim( sprintf( '%s <%s>', $customer['name'] ?? '', $customer['email'] ?? '' ) );
		foreach ( $customer['cards'] ?? [] as $card ) {
			$rows   = array_map(
				static fn( $row ) => ( $row[0] ?? '' ) . ': ' . ( $row[1] ?? '' ),
				array_filter( (array) ( $card['rows'] ?? [] ), 'is_array' )
			);
			$status = $card['status']['label'] ?? '';
			$out[]  = sprintf( '%s%s: %s', $card['title'] ?? 'Info', $status ? " ({$status})" : '', implode( '; ', $rows ) );
		}

		$out[] = '';
		$out[] = 'CONVERSATION (oldest first)';
		foreach ( array_slice( $messages, -self::MAX_MESSAGES ) as $message ) {
			$out[] = '';
			$out[] = sprintf( '[%s] %s', $message['at'] ?? '', self::speaker( $message ) );
			$out[] = self::clip( (string) ( $message['text'] ?? '' ) );
		}

		return implode( "\n", $out );
	}

	/**
	 * Decode the model's JSON answer into a normalized draft, or null when
	 * it isn't usable. Sources keep whatever id the model gave, so verify()
	 * can flag one that isn't in knowledge instead of it vanishing here.
	 *
	 * @param mixed $raw JSON string (or an already-decoded array).
	 */
	public static function parse( $raw ): ?array {
		$data = is_array( $raw ) ? $raw : json_decode( (string) $raw, true );
		if ( ! is_array( $data ) || '' === trim( (string) ( $data['reply_html'] ?? '' ) ) ) {
			return null;
		}

		$sources = [];
		foreach ( (array) ( $data['grounded_in'] ?? [] ) as $source ) {
			if ( ! is_array( $source ) ) {
				continue;
			}
			$id = self::source_id( $source );
			if ( '' !== $id ) {
				$sources[] = [
					'source' => $id,
					'quote'  => (string) ( $source['quote'] ?? '' ),
				];
			}
		}

		$flags = array_values( array_intersect( self::FLAGS, array_map( 'strval', (array) ( $data['flags'] ?? [] ) ) ) );

		return [
			'reply_html'         => (string) $data['reply_html'],
			'confidence'         => in_array( $data['confidence'] ?? '', [ 'high', 'medium', 'low' ], true ) ? $data['confidence'] : 'low',
			'grounded_in'        => $sources,
			'flags'              => $flags,
			'needs_human_reason' => sanitize_textarea_field( (string) ( $data['needs_human_reason'] ?? '' ) ),
			'summary'            => sanitize_text_field( (string) ( $data['summary'] ?? '' ) ),
		];
	}

	/**
	 * Does the draft stand on the knowledge it claims?
	 *
	 * @param array $draft     Output of parse().
	 * @param array $knowledge Output of knowledge(): exactly what the model saw.
	 * @return string[] Problems found; empty means verified.
	 */
	public static function verify( array $draft, array $knowledge ): array {
		$problems = [];

		foreach ( $draft['grounded_in'] as $cited ) {
			$entry = $knowledge[ $cited['source'] ] ?? null;
			if ( ! $entry ) {
				$problems[] = sprintf( 'Cites %s, which is not in knowledge.', $cited['source'] );
				continue;
			}

			$quote = self::flatten( $cited['quote'] );
			if ( mb_strlen( $quote ) < self::MIN_QUOTE_CHARS ) {
				$problems[] = sprintf( 'Quote too short to check in %s.', $cited['source'] );
				continue;
			}
			if ( ! str_contains( self::flatten( ( $entry['title'] ?? '' ) . "\n" . ( $entry['text'] ?? '' ) ), $quote ) ) {
				$problems[] = sprintf( 'Quote not found in %s: "%s"', $cited['source'], self::clip( $cited['quote'], 80 ) );
			}
		}

		$corpus = implode( "\n", array_map( static fn( $e ) => (string) ( $e['text'] ?? '' ), $knowledge ) );
		$urls   = array_map( [ self::class, 'norm_url' ], array_filter( array_map( static fn( $e ) => (string) ( $e['url'] ?? '' ), $knowledge ) ) );
		foreach ( self::links( $draft['reply_html'] ) as $url ) {
			if ( ! in_array( self::norm_url( $url ), $urls, true ) && ! str_contains( $corpus, $url ) ) {
				$problems[] = sprintf( 'Link not found in knowledge: %s', $url );
			}
		}

		if ( preg_match( KnowledgeText::PLACEHOLDER_RE, self::flatten( $draft['reply_html'] ) ) ) {
			$problems[] = 'Reply contains a redacted placeholder.';
		}

		return $problems;
	}

	/**
	 * The draft's citations with what the UI needs to show and link them:
	 * [ source, type, ref, title, url, quote ].
	 */
	public static function cite( array $grounded_in, array $knowledge ): array {
		return array_map(
			static function ( $cited ) use ( $knowledge ) {
				$entry          = $knowledge[ $cited['source'] ] ?? [];
				[ $type, $ref ] = array_pad( explode( ':', $cited['source'], 2 ), 2, '' );

				return [
					'source' => $cited['source'],
					'type'   => $type,
					'ref'    => $ref,
					'title'  => (string) ( $entry['title'] ?? '' ),
					'url'    => (string) ( $entry['url'] ?? '' ),
					'quote'  => $cited['quote'],
				];
			},
			$grounded_in
		);
	}

	/** Every http(s) URL in the reply, from href attributes and bare text. */
	public static function links( string $html ): array {
		preg_match_all( '#https?://[^\s"\'<>)]+#i', $html, $matches );

		return array_values( array_unique( array_map( static fn( $url ) => rtrim( $url, '.,;:!?' ), $matches[0] ) ) );
	}

	/** Compare links without caring about case in the host or a trailing slash. */
	public static function norm_url( string $url ): string {
		$url = trim( $url );
		if ( preg_match( '#^(https?://)([^/?\#]+)(.*)$#i', $url, $m ) ) {
			$url = strtolower( $m[1] . $m[2] ) . $m[3];
		}

		return rtrim( $url, '/' );
	}

	/**
	 * Plain lowercase text with collapsed whitespace, so a quote matches its
	 * source across line breaks and the HTML of rich-text snippets.
	 */
	public static function flatten( string $text ): string {
		$text = html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );

		return mb_strtolower( trim( (string) preg_replace( '/\s+/u', ' ', $text ) ) );
	}

	/** A cited source as a canonical id; accepts the old { type, ref } shape and stray brackets. */
	private static function source_id( array $source ): string {
		if ( isset( $source['source'] ) ) {
			$id = trim( (string) $source['source'], " \t\n\r\0\x0B[]" );
		} elseif ( 'instructions' === ( $source['type'] ?? '' ) ) {
			$id = 'instructions';
		} else {
			$id = trim( (string) ( $source['type'] ?? '' ) ) . ':' . trim( (string) ( $source['ref'] ?? '' ) );
		}

		if ( 'instructions' === strtolower( $id ) ) {
			return 'instructions';
		}
		if ( ! str_contains( $id, ':' ) ) {
			return '';
		}
		[ $type, $ref ] = explode( ':', $id, 2 );
		$type           = strtolower( trim( $type ) );
		$ref            = trim( $ref );

		return '' !== $type && '' !== $ref ? "{$type}:{$ref}" : '';
	}

	/** The line that introduces one source in the prompt. */
	private static function heading( string $id, array $entry ): string {
		$title = trim( (string) ( $entry['title'] ?? '' ) );
		$url   = trim( (string) ( $entry['url'] ?? '' ) );
		$date  = trim( (string) ( $entry['date'] ?? '' ) );

		if ( 'instructions' === $id ) {
			return '[instructions]';
		}
		if ( 'past' === ( $entry['type'] ?? '' ) ) {
			return sprintf( '[%s] How the team answered "%s"%s', $id, $title, $date ? " (resolved {$date})" : '' );
		}

		return rtrim( sprintf( '[%s] %s%s%s', $id, $title, $date ? ", {$date}" : '', $url ? " ({$url})" : '' ) );
	}

	private static function speaker( array $message ): string {
		$name = trim( (string) ( $message['name'] ?? '' ) );
		switch ( $message['author'] ?? '' ) {
			case 'customer':
				// An out-of-office or other auto-responder, not the person.
				if ( ! empty( $message['auto'] ) ) {
					return 'Customer\'s mailbox, an automatic reply they did not write';
				}
				return 'Customer' . ( $name ? " ({$name})" : '' );
			case 'agent':
				return 'Agent (you)';
			default:
				$who = 'Teammate' . ( $name ? " ({$name})" : '' );
				return ! empty( $message['private'] ) ? "{$who}, internal note, not seen by the customer" : $who;
		}
	}

	private static function clip( string $text, int $max = self::MAX_MESSAGE_CHARS ): string {
		$text = trim( $text );

		return mb_strlen( $text ) > $max ? rtrim( mb_substr( $text, 0, $max - 1 ) ) . '…' : $text;
	}
}
