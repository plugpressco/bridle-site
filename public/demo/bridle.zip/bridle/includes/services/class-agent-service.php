<?php

namespace Bridle\Services;

use Bridle\Models\Conversation;
use Bridle\Models\Customer;
use Bridle\Models\Draft;
use Bridle\Models\Thread;
use WP_Error;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The agent's reply drafts.
 *
 * Loads a conversation and the business's knowledge (Agent instructions,
 * Snippets, and what KnowledgeSearch finds: docs, pages, posts, products,
 * past answers), asks the model through the WP 7.0 AI Client, so on whatever
 * provider the site owner connected with their own key, checks the reply
 * against the knowledge it cites (AgentPrompt::verify) and stores it as the
 * conversation's agent draft: the drafts row with user_id 0, its details in
 * `meta`. A teammate sends, edits or discards it, or AutoSend sends it;
 * nothing here sends email.
 */
class AgentService {

	/** Drafts row owner for the agent. Teammates are WP users, so never 0. */
	const USER_ID = 0;

	/**
	 * Model preference among what the site's own AI connector offers; the
	 * first one it lists wins. IDs must match the provider's exactly, or the
	 * AI Client falls back to whichever model it found first.
	 */
	const MODELS = [ 'claude-sonnet-5-5', 'claude-sonnet-5', 'claude-haiku-4-5', 'gpt-4o', 'gemini-2.0-flash' ];

	/** HTML a draft may contain; matches what the prompt allows. */
	const REPLY_TAGS = [
		'p'      => [],
		'br'     => [],
		'ul'     => [],
		'ol'     => [],
		'li'     => [],
		'a'      => [ 'href' => true ],
		'strong' => [],
		'em'     => [],
		'code'   => [],
	];

	/**
	 * Write and store a reply draft for the conversation.
	 *
	 * @return array|WP_Error The stored draft: [ 'content' => html, 'meta' => [...] ].
	 */
	public static function draft( int $conversation_id ) {
		if ( ! AiService::can_use_ai() ) {
			return new WP_Error( 'bridle_ai_unavailable', __( 'No AI provider is configured in WordPress.', 'bridle' ) );
		}

		$conversation = ( new Conversation() )->get_by_id( $conversation_id );
		if ( ! $conversation ) {
			return new WP_Error( 'bridle_not_found', __( 'Conversation not found.', 'bridle' ) );
		}

		$composed = self::compose( $conversation );
		if ( is_wp_error( $composed ) ) {
			return $composed;
		}
		[ 'draft' => $draft, 'knowledge' => $knowledge, 'found' => $found, 'problems' => $problems ] = $composed;

		$meta = self::store_draft(
			$conversation_id,
			$draft['reply_html'],
			[
				'source'             => 'agent',
				'confidence'         => $draft['confidence'],
				'grounded_in'        => AgentPrompt::cite( $draft['grounded_in'], $knowledge ),
				'flags'              => $draft['flags'],
				'needs_human_reason' => $draft['needs_human_reason'],
				'summary'            => $draft['summary'],
				'verified'           => empty( $problems ),
				'problems'           => $problems,
				'retrieved'          => array_column( $found['items'], 'id' ),
			]
		);
		self::record( 'drafted' );

		/**
		 * Fires after the agent answered a conversation: an email draft was
		 * stored, or (from ChatService) a chat answer was decided on.
		 *
		 * @param int   $conversation_id The conversation.
		 * @param array $draft           AgentPrompt::parse(): reply_html, confidence, grounded_in,
		 *                               flags, needs_human_reason, summary.
		 * @param array $context         kind (email | chat), terms (what knowledge was searched for),
		 *                               verified (every fact checked out), shown (chat: the visitor
		 *                               saw it; email: false), reason (chat: ChatPolicy::decide()).
		 */
		do_action(
			'bridle_agent_answered',
			$conversation_id,
			$draft,
			[
				'kind'     => 'email',
				'terms'    => (array) ( $found['terms'] ?? [] ),
				'verified' => empty( $problems ),
				'shown'    => false,
				'reason'   => '',
			]
		);

		return [
			'content' => $draft['reply_html'],
			'meta'    => $meta,
		];
	}

	/**
	 * Ask the model for an answer to a conversation and check it: the
	 * knowledge it found, the prompt, the call, parse, sanitize and verify.
	 * Email drafts and Bridle Chat (#114) share it; only the instruction differs.
	 *
	 * @param object $conversation Conversation row.
	 * @param string $kind         'email' (a draft a teammate reviews) or 'chat'.
	 * @return array{draft: array, knowledge: array, found: array, problems: string[]}|WP_Error
	 */
	public static function compose( object $conversation, string $kind = 'email' ) {
		$threads  = ( new Thread() )->get_by_conversation( (int) $conversation->id );
		$customer = ( new Customer() )->get_by_id( (int) $conversation->customer_id );
		$email    = (string) ( $customer->email ?? '' );

		$found     = KnowledgeSearch::for_conversation( $conversation, $threads );
		$knowledge = AgentPrompt::knowledge( (string) Settings::get( 'agent_instructions', '' ), self::snippets(), $found['items'] );
		$business  = (string) Settings::get( 'business_name' );
		if ( '' === $business ) {
			$business = (string) get_bloginfo( 'name' );
		}

		$user_prompt = AgentPrompt::user_prompt(
			$knowledge,
			[
				'name'  => (string) ( $customer->name ?? '' ),
				'email' => $email,
				// Shared PlugPress filter (see ContactBridge), hence no bridle_ prefix.
				// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
				'cards' => $email ? (array) apply_filters( 'plugpress_contact_cards', [], $email, 'bridle' ) : [],
			],
			array_map( [ self::class, 'message' ], $threads )
		);

		$instruction = 'chat' === $kind ? AgentPrompt::chat_instruction( $business ) : AgentPrompt::system_instruction( $business );

		$answer = self::ask( $instruction, $user_prompt, AgentPrompt::schema(), 'chat' === $kind ? 'chat' : 'email' );
		if ( is_wp_error( $answer ) ) {
			return $answer;
		}
		[ 'id' => $answer_id, 'raw' => $raw ] = $answer;

		$draft = AgentPrompt::parse( $raw );
		if ( ! $draft ) {
			BridleAi::refund( $answer_id );
			return new WP_Error( 'bridle_agent_bad_response', __( 'The model did not return a usable draft.', 'bridle' ) );
		}

		$draft['reply_html'] = wp_kses( $draft['reply_html'], self::REPLY_TAGS );
		// Checked against exactly the passages the model saw.
		$problems = AgentPrompt::verify( $draft, $knowledge );
		// Only checked answers count against Bridle AI.
		if ( $problems ) {
			BridleAi::refund( $answer_id );
		}

		return [
			'draft'     => $draft,
			'knowledge' => $knowledge,
			'found'     => $found,
			'problems'  => $problems,
		];
	}

	/**
	 * One call to the model: the owner's own key first, Bridle AI only when
	 * none is connected. Drafts, chat answers and rewrites (#130) share it.
	 *
	 * @param string $system The system instruction.
	 * @param string $prompt The user message.
	 * @param array  $schema JSON schema for the answer.
	 * @param string $task   'email' or 'chat': whose model it uses (Settings → Replies, #133).
	 * @return array{id: string, raw: string}|WP_Error id is Bridle AI's answer id ('' on the owner's key), for a refund.
	 */
	public static function ask( string $system, string $prompt, array $schema, string $task = 'email' ) {
		if ( 'bridle' === AiService::source() ) {
			$answer = BridleAi::generate( $system, $prompt, $schema );
			if ( is_wp_error( $answer ) ) {
				return $answer;
			}
			return [
				'id'  => $answer['id'],
				'raw' => $answer['text'],
			];
		}
		if ( ! function_exists( 'wp_ai_client_prompt' ) ) {
			return new WP_Error( 'bridle_agent_failed', __( 'No AI provider is connected.', 'bridle' ) );
		}
		try {
			$raw = wp_ai_client_prompt( $prompt )
				->using_system_instruction( $system )
				->using_temperature( 0.3 )
				->as_json_response( $schema )
				->using_model_preference(
					// Model per task (#133): the owner's choice first, then MODELS.
					...AiService::preference(
						(string) Settings::get( 'chat' === $task ? 'model_chat' : 'model_email', '' ),
						self::MODELS,
						array_column( AiService::models(), 'id' )
					)
				)
				->generate_text();
		} catch ( \Throwable $e ) {
			return new WP_Error( 'bridle_agent_failed', $e->getMessage() );
		}
		if ( is_wp_error( $raw ) ) {
			return $raw;
		}
		return [
			'id'  => '',
			'raw' => (string) $raw,
		];
	}

	/**
	 * Store a reply as the conversation's agent draft (the AI DRAFT card),
	 * whoever wrote it: the built-in agent or an external one (draft-reply).
	 * Replaces any earlier agent draft, which also cancels its scheduled send.
	 *
	 * @param array $meta Draft details; status, based_on_thread_id and created_at are filled in.
	 * @return array The stored meta.
	 */
	public static function store_draft( int $conversation_id, string $html, array $meta ): array {
		$meta += [
			'status'             => 'ready',
			'based_on_thread_id' => self::newest_public_thread_id( $conversation_id ),
			'created_at'         => current_time( 'mysql', true ),
		];

		( new Draft() )->upsert( $conversation_id, self::USER_ID, $html, 'reply', wp_json_encode( $meta ) );

		return $meta;
	}

	/** The id of the newest message the customer or the team could see. */
	public static function newest_public_thread_id( int $conversation_id ): int {
		global $wpdb;

		$sql = $wpdb->prepare(
			'SELECT MAX( id ) FROM %i WHERE conversation_id = %d AND is_private = 0',
			$wpdb->prefix . 'bridle_threads',
			$conversation_id
		);

		return (int) $wpdb->get_var( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- prepared just above.
	}

	/**
	 * The conversation's agent draft, or null.
	 *
	 * @return array{content: string, meta: array, updated_at: string}|null
	 */
	public static function get_draft( int $conversation_id ): ?array {
		$row = ( new Draft() )->get( $conversation_id, self::USER_ID );
		if ( ! $row ) {
			return null;
		}

		$meta = json_decode( (string) ( $row->meta ?? '' ), true );

		return [
			'content'    => (string) $row->content,
			'meta'       => is_array( $meta ) ? $meta : [],
			'updated_at' => (string) $row->updated_at,
		];
	}

	/**
	 * Count what happens to the agent's drafts. Deciding when an inbox is
	 * ready for auto-send rests on these numbers.
	 *
	 * @param string $outcome drafted | failed | sent_unedited | sent_edited | discarded.
	 */
	public static function record( string $outcome ): void {
		$stats             = (array) get_option( 'bridle_agent_stats', [] );
		$stats[ $outcome ] = (int) ( $stats[ $outcome ] ?? 0 ) + 1;
		update_option( 'bridle_agent_stats', $stats, false );
	}

	/** Snippets (saved replies) as knowledge: [ id, title, body ]. */
	public static function snippets(): array {
		// Same option SavedRepliesController manages; read directly because
		// services never call into the REST layer.
		$raw = get_option( 'bridle_saved_replies', [] );
		if ( ! is_array( $raw ) ) {
			$raw = json_decode( (string) $raw, true );
		}

		$snippets = [];
		foreach ( is_array( $raw ) ? $raw : [] as $reply ) {
			if ( is_array( $reply ) && ! empty( $reply['body'] ) ) {
				$snippets[] = [
					'id'    => (string) ( $reply['id'] ?? '' ),
					'title' => (string) ( $reply['title'] ?? '' ),
					'body'  => (string) $reply['body'],
				];
			}
		}

		return $snippets;
	}

	/** One thread row as a transcript message for AgentPrompt. */
	public static function message( object $thread ): array {
		$name = '';
		if ( 'teammate' === $thread->author_type && $thread->author_id ) {
			$user = get_userdata( (int) $thread->author_id );
			$name = $user ? $user->display_name : '';
		}

		return [
			'author'  => (string) $thread->author_type,
			'name'    => $name,
			'private' => ! empty( $thread->is_private ),
			'auto'    => 'auto_reply' === (string) ( $thread->thread_type ?? '' ),
			'at'      => (string) $thread->created_at,
			'text'    => (string) $thread->content,
		];
	}
}
