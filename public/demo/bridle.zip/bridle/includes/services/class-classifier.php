<?php

namespace Bridle\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Reads each inbound email with a decision model, on the site owner's own key.
 *
 * Like drafting, classification is bring-your-own-key: Bridle runs no AI of
 * its own, and the email relay only relays. The owner picks a provider in
 * Settings → Agent:
 *
 * - TypeSafe: their API key, model Jev (`jev-latest`).
 * - Cloudflare Workers AI: their account ID and an API token, model Jev
 *   (`typesafe/jev`), Clef or Clef-flash (drop-in compatible decision models).
 *
 * Every provider gets the same state (who, a few headers, the subject and the
 * newest message) and the same five typed questions, and answers in the same
 * shape. The result is what AutomatedMail::sanitize_classification() accepts:
 * routing (Inbox / Updates / Spam) and the auto-send guardrails read it.
 *
 * Best-effort by design: no key, an error or a slow answer returns null, and
 * the email is routed on its headers alone. Mail is never lost or held up.
 * Request building and answer reading are pure, so they are unit-tested.
 */
class Classifier {

	/** The owner's choice and credentials. Never sent to the browser in full. */
	public const OPTION = 'bridle_classifier';

	/** Whether the last call worked, for Settings: { ok, at, error }. */
	public const STATUS_OPTION = 'bridle_classifier_status';

	/** Seconds to wait. The relay waits 20 s for the webhook; most answers take under one. */
	public const TIMEOUT = 3;

	/** The body is cut to the newest message and capped: accuracy drops with noise. */
	public const MAX_BODY_CHARS = 6000;

	/**
	 * Providers and the models each offers, first one the default.
	 * Cloudflare runs third-party Jev on `/ai/run` with the model in the body,
	 * and its own Clef models on `/ai/run/{model}`.
	 */
	public const PROVIDERS = [
		'typesafe'   => [ 'jev-latest' ],
		// Clef first: Cloudflare's own model, on the free daily Workers AI
		// allowance. Jev on Cloudflare is a third-party model paid from AI
		// Gateway credits, so it answers 402 on an account without them.
		'cloudflare' => [ '@cf/cloudflare/clef', '@cf/cloudflare/clef-flash', 'typesafe/jev' ],
	];

	private const TYPESAFE_URL   = 'https://api.typesafe.ai/v1/systemone';
	private const CLOUDFLARE_URL = 'https://api.cloudflare.com/client/v4/accounts/%s/ai/run';

	private const URGENCY_LEVELS = [ 'low', 'normal', 'high' ];

	/** The five questions, the same for every provider. */
	public const QUESTIONS = [
		'box'         => [
			'type'         => 'choice',
			'instructions' => 'Who sent this email to the business, and why? Judge from the sender, the headers and the body.',
			'criteria'     => [
				'customer_request' => 'A real person writing to this business: a question, a problem, a request, a reply in an ongoing support conversation, or a message sent through the website contact form.',
				'automated'        => 'Machine-generated mail: receipts, invoices, order or payment notifications, shipping updates, account or security alerts, system or plugin notifications, newsletters and marketing campaigns.',
				'sales_pitch'      => 'Unsolicited outreach selling something to this business: SEO, guest posts, link building, development or design services, partnerships, investment or lead-generation offers.',
				'spam'             => 'Scams, phishing, malware, or junk with no legitimate purpose.',
			],
		],
		'intent'      => [
			'type'         => 'choice',
			'instructions' => 'What does the sender want from the business?',
			'criteria'     => [
				'bug_report'      => 'Something in the product is broken or behaves wrongly.',
				'how_to'          => 'Asks how to do or set up something.',
				'billing'         => 'Payments, invoices, pricing, plans or licence keys.',
				'refund'          => 'Asks for money back or disputes a charge.',
				'presale'         => 'Considering buying and asks before purchasing.',
				'account'         => 'Login, access, downloads or account details.',
				'feature_request' => 'Asks for something the product does not do yet.',
				'general'         => 'Anything else.',
			],
		],
		'urgency'     => [
			'type'         => 'score',
			'instructions' => 'How urgent is this for the sender?',
			'criteria'     => [
				'Low: no time pressure.',
				'Normal: wants help, but nothing critical is blocked right now.',
				'High: something important is broken or blocked now, a deadline is close, or money is at stake.',
			],
		],
		'sentiment'   => [
			'type'         => 'choice',
			'instructions' => 'How does the sender feel?',
			'criteria'     => [
				'positive'   => 'Happy, thankful or enthusiastic.',
				'neutral'    => 'Matter-of-fact.',
				'frustrated' => 'Annoyed or disappointed, but civil.',
				'angry'      => 'Hostile, threatening or shouting.',
			],
		],
		'needs_human' => [
			'type'         => 'noul',
			'instructions' => 'Handling this email requires a decision by a person at the business.',
			'criteria'     => [
				'true'  => 'A refund or payment dispute, a legal or privacy request, a security incident, account deletion or cancellation, or a threat to leave or complain publicly.',
				'false' => 'A question or problem that can be answered with information or instructions.',
			],
		],
	];

	/** What Settings → Agent "Test" classifies. A pitch, so a working setup shows it isn't a customer. */
	private const SAMPLE = [
		'from'      => 'growth@rank-boost.example',
		'from_name' => 'Daniel from RankBoost',
		'subject'   => 'Quick question about your website traffic',
		'body'      => "Hi there,\n\nI noticed your site isn't ranking for several high-value keywords. Our team can get you to page one in 30 days with guaranteed backlinks from DA 70+ sites.\n\nWould you be open to a quick 15-minute call this week?\n\nBest,\nDaniel",
	];

	/**
	 * The stored choice, with defaults. Contains the key: server-side only.
	 *
	 * @return array{provider: string, model: string, account_id: string, key: string}
	 */
	public static function config(): array {
		$saved = get_option( self::OPTION, [] );
		$saved = is_array( $saved ) ? $saved : [];

		return [
			'provider'   => (string) ( $saved['provider'] ?? '' ),
			'model'      => (string) ( $saved['model'] ?? '' ),
			'account_id' => (string) ( $saved['account_id'] ?? '' ),
			'key'        => (string) ( $saved['key'] ?? '' ),
		];
	}

	/** Whether every email will be classified. */
	public static function enabled( ?array $config = null ): bool {
		$config = $config ?? self::config();
		if ( ! isset( self::PROVIDERS[ $config['provider'] ] ) || '' === $config['key'] ) {
			return false;
		}
		return 'cloudflare' !== $config['provider'] || '' !== $config['account_id'];
	}

	/**
	 * What Settings may see: the choice, the last four characters of the key
	 * and how the last call went. Never the key itself.
	 */
	public static function public_config(): array {
		$config = self::config();
		$status = get_option( self::STATUS_OPTION, [] );

		return [
			'provider'   => $config['provider'],
			'model'      => $config['model'],
			'account_id' => $config['account_id'],
			'has_key'    => '' !== $config['key'],
			'key_hint'   => '' !== $config['key'] ? substr( $config['key'], -4 ) : '',
			'enabled'    => self::enabled( $config ),
			'models'     => self::PROVIDERS,
			'status'     => is_array( $status ) ? $status : [],
		];
	}

	/**
	 * Save a choice from Settings. An empty `key` keeps the stored one, so the
	 * form never has to hold it; provider '' turns classification off and
	 * forgets the credentials.
	 *
	 * @param array $input provider, model, account_id, key.
	 * @return array|\WP_Error public_config() after saving.
	 */
	public static function save( array $input ) {
		$provider = sanitize_key( (string) ( $input['provider'] ?? '' ) );

		if ( '' === $provider ) {
			delete_option( self::OPTION );
			delete_option( self::STATUS_OPTION );
			return self::public_config();
		}
		if ( ! isset( self::PROVIDERS[ $provider ] ) ) {
			return new \WP_Error( 'bridle_classifier_provider', __( 'Choose TypeSafe or Cloudflare.', 'bridle' ), [ 'status' => 400 ] );
		}

		$current = self::config();
		$model   = (string) ( $input['model'] ?? '' );
		if ( ! in_array( $model, self::PROVIDERS[ $provider ], true ) ) {
			$model = self::PROVIDERS[ $provider ][0];
		}
		$account_id = strtolower( preg_replace( '/[^A-Fa-f0-9]/', '', (string) ( $input['account_id'] ?? '' ) ) );
		$key        = trim( preg_replace( '/\s+/', '', (string) ( $input['key'] ?? '' ) ) );
		if ( '' === $key && $current['provider'] === $provider ) {
			$key = $current['key'];
		}

		if ( '' === $key ) {
			return new \WP_Error( 'bridle_classifier_key', __( 'Paste your API key.', 'bridle' ), [ 'status' => 400 ] );
		}
		if ( 'cloudflare' === $provider && 32 !== strlen( $account_id ) ) {
			return new \WP_Error( 'bridle_classifier_account', __( 'A Cloudflare account ID is 32 letters and digits. Find it on your Cloudflare dashboard.', 'bridle' ), [ 'status' => 400 ] );
		}

		update_option(
			self::OPTION,
			[
				'provider'   => $provider,
				'model'      => $model,
				'account_id' => 'cloudflare' === $provider ? $account_id : '',
				'key'        => $key,
			],
			false
		);
		delete_option( self::STATUS_OPTION );

		return self::public_config();
	}

	/**
	 * Classify one inbound email.
	 *
	 * @param array      $email  from, from_name, reply_to, subject, body (newest message as text),
	 *                           list_id, list_unsubscribe, precedence, auto_submitted.
	 * @param array|null $config Defaults to the saved choice.
	 * @return array|null AutomatedMail::sanitize_classification() shape, or null.
	 */
	public static function classify( array $email, ?array $config = null ): ?array {
		$config = $config ?? self::config();
		if ( ! self::enabled( $config ) ) {
			return null;
		}

		$request  = self::request( $config, self::state( $email ) );
		$response = wp_remote_post(
			$request['url'],
			[
				'timeout' => self::TIMEOUT,
				'headers' => $request['headers'],
				'body'    => wp_json_encode( $request['body'] ),
			]
		);

		if ( is_wp_error( $response ) ) {
			self::record( false, $response->get_error_message() );
			return null;
		}

		$code   = (int) wp_remote_retrieve_response_code( $response );
		$data   = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		$result = 200 === $code ? self::normalize( $data, $config['model'] ) : null;

		if ( ! $result ) {
			self::record( false, self::error_text( $code, $data, $config['provider'] ) );
			return null;
		}

		self::record( true, '' );
		return $result;
	}

	/**
	 * Settings → Agent "Test": classify the sample pitch with the saved choice.
	 *
	 * @return array{ok: bool, classification: ?array, error: string}
	 */
	public static function test(): array {
		$result = self::classify( self::SAMPLE );
		$status = get_option( self::STATUS_OPTION, [] );

		return [
			'ok'             => null !== $result,
			'classification' => $result,
			'error'          => null === $result ? (string) ( $status['error'] ?? __( 'Add a key first.', 'bridle' ) ) : '',
		];
	}

	/**
	 * The text the model decides on: who, the headers that mark machine mail,
	 * the subject and the newest message.
	 */
	public static function state( array $email ): string {
		$body = self::newest_message( (string) ( $email['body'] ?? '' ) );
		$body = function_exists( 'mb_substr' ) ? mb_substr( $body, 0, self::MAX_BODY_CHARS ) : substr( $body, 0, self::MAX_BODY_CHARS );
		$from = (string) ( $email['from'] ?? '' );
		if ( ! empty( $email['from_name'] ) ) {
			$from = $email['from_name'] . ' <' . $from . '>';
		}

		$lines = [ 'From: ' . ( '' !== $from ? $from : '(unknown)' ) ];
		foreach (
			[
				'Reply-To'         => $email['reply_to'] ?? '',
				'List-Id'          => $email['list_id'] ?? '',
				'List-Unsubscribe' => ! empty( $email['list_unsubscribe'] ) ? 'present' : '',
				'Precedence'       => $email['precedence'] ?? '',
				'Auto-Submitted'   => $email['auto_submitted'] ?? '',
			] as $name => $value
		) {
			if ( '' !== (string) $value ) {
				$lines[] = $name . ': ' . $value;
			}
		}
		$lines[] = 'Subject: ' . ( ! empty( $email['subject'] ) ? $email['subject'] : '(no subject)' );
		$lines[] = '';
		$lines[] = '' !== $body ? $body : '(empty body)';

		return implode( "\n", $lines );
	}

	/**
	 * Only the newest message: everything from the first reply header on, and
	 * any ">"-quoted line, goes.
	 */
	public static function newest_message( string $text ): string {
		$lines = explode( "\n", str_replace( [ "\r\n", "\r" ], "\n", $text ) );
		$kept  = [];
		foreach ( $lines as $i => $line ) {
			if ( preg_match( '/^On .{0,300}wrote:\s*$/', $line ) || preg_match( '/^-{2,}\s*Original Message\s*-{2,}/i', $line ) ) {
				break;
			}
			if ( preg_match( '/^From: /', $line ) && preg_match( '/^(Sent|Date): /', $lines[ $i + 1 ] ?? '' ) ) {
				break;
			}
			if ( preg_match( '/^\s*>/', $line ) ) {
				continue;
			}
			$kept[] = $line;
		}
		return trim( preg_replace( "/\n{3,}/", "\n\n", implode( "\n", $kept ) ) );
	}

	/**
	 * The HTTP request for a provider: url, headers and the JSON body.
	 *
	 * @return array{url: string, headers: array, body: array}
	 */
	public static function request( array $config, string $state ): array {
		$headers = [
			'Authorization' => 'Bearer ' . $config['key'],
			'Content-Type'  => 'application/json',
		];
		$input   = [
			'state'     => $state,
			'questions' => self::QUESTIONS,
		];

		if ( 'cloudflare' !== $config['provider'] ) {
			return [
				'url'     => self::TYPESAFE_URL,
				'headers' => $headers,
				'body'    => [ 'model' => $config['model'] ] + $input,
			];
		}

		$base = sprintf( self::CLOUDFLARE_URL, rawurlencode( $config['account_id'] ) );
		if ( str_starts_with( $config['model'], '@cf/cloudflare/' ) ) {
			// Clef: the model in the path, plus its short name as a selector.
			return [
				'url'     => $base . '/' . $config['model'],
				'headers' => $headers,
				'body'    => [ 'model' => substr( $config['model'], strlen( '@cf/cloudflare/' ) ) ] + $input,
			];
		}

		// Third-party Jev: the model in the body, the questions under `input`.
		return [
			'url'     => $base,
			'headers' => $headers,
			'body'    => [
				'model' => $config['model'],
				'input' => $input,
			],
		];
	}

	/**
	 * Read a provider's answers into the stored classification shape.
	 * Cloudflare wraps the answer in `result`; TypeSafe returns it bare.
	 *
	 * @param mixed  $data  Decoded response body.
	 * @param string $model The model asked, for the record.
	 */
	public static function normalize( $data, string $model ): ?array {
		if ( is_array( $data ) && isset( $data['result'] ) && is_array( $data['result'] ) ) {
			$data = $data['result'];
		}
		$answers = is_array( $data ) ? ( $data['answers'] ?? null ) : null;
		if ( ! is_array( $answers ) || empty( $answers['box']['choice'] ) ) {
			return null;
		}

		$choice = static fn( $a ) => is_array( $a ) && isset( $a['choice'] )
			? [
				'value'      => (string) $a['choice'],
				'confidence' => (float) ( $a['confidence'] ?? 0 ),
			]
			: null;

		return AutomatedMail::sanitize_classification(
			[
				'model'       => $model . ( ! empty( $data['model'] ) ? '@' . $data['model'] : '' ),
				'box'         => $choice( $answers['box'] ),
				'intent'      => $choice( $answers['intent'] ?? null ),
				'urgency'     => self::level( $answers['urgency'] ?? null ),
				'sentiment'   => $choice( $answers['sentiment'] ?? null ),
				'needs_human' => isset( $answers['needs_human']['noul'] ) ? (float) $answers['needs_human']['noul'] : null,
			]
		);
	}

	/**
	 * A score answer as a level. `score` is probability-weighted (1.04 means
	 * "normal, leaning high"), so the most likely level wins; failing that,
	 * the nearest one.
	 */
	private static function level( $answer ): ?array {
		if ( ! is_array( $answer ) ) {
			return null;
		}
		$index = null;
		if ( ! empty( $answer['probabilities'] ) && is_array( $answer['probabilities'] ) ) {
			$probabilities = array_map( 'floatval', $answer['probabilities'] );
			arsort( $probabilities );
			$index = (int) array_key_first( $probabilities );
		} elseif ( isset( $answer['score'] ) && is_numeric( $answer['score'] ) ) {
			$index = (int) round( (float) $answer['score'] );
		}
		if ( null === $index || ! isset( self::URGENCY_LEVELS[ $index ] ) ) {
			return null;
		}
		return [
			'value'      => self::URGENCY_LEVELS[ $index ],
			'confidence' => (float) ( $answer['confidence'] ?? 0 ),
		];
	}

	/** Why a call failed, in words Settings can show. */
	private static function error_text( int $code, $data, string $provider ): string {
		$cloudflare = 'cloudflare' === $provider;
		switch ( $code ) {
			case 200:
				return __( 'The model answered, but not in the expected shape.', 'bridle' );
			case 401:
			case 403:
				return $cloudflare
					? __( 'Cloudflare refused the token. Check it has the Workers AI permission for this account.', 'bridle' )
					: __( 'TypeSafe refused the key. Check it in your TypeSafe console.', 'bridle' );
			case 404:
				return $cloudflare
					? __( 'Not found. Check the Cloudflare account ID.', 'bridle' )
					: __( 'TypeSafe could not find that model.', 'bridle' );
			case 402:
				return $cloudflare
					? __( 'Cloudflare runs Jev from AI Gateway credits, and this account has none. Pick Clef, which runs on your free daily Workers AI allowance, or load credits under AI → AI Gateway.', 'bridle' )
					: __( 'TypeSafe says this account is out of credit. Add credit in your TypeSafe console.', 'bridle' );
			case 422:
			case 400:
				return __( 'The provider rejected the request.', 'bridle' );
			case 429:
				return __( 'Rate limited by the provider. Bridle will try again with the next email.', 'bridle' );
		}
		$message = is_array( $data ) ? ( $data['errors'][0]['message'] ?? $data['error']['message'] ?? $data['message'] ?? '' ) : '';
		/* translators: %d: HTTP status code */
		$text = sprintf( __( 'The provider answered with status %d.', 'bridle' ), $code );
		return is_string( $message ) && '' !== $message ? $text . ' ' . sanitize_text_field( $message ) : $text;
	}

	/**
	 * Keep how the last call went. A success over a recent success isn't
	 * written again, so a busy inbox doesn't write an option per email.
	 */
	private static function record( bool $ok, string $error ): void {
		$last = get_option( self::STATUS_OPTION, [] );
		if ( $ok && ! empty( $last['ok'] ) && ! empty( $last['at'] )
			&& strtotime( $last['at'] . ' UTC' ) > time() - HOUR_IN_SECONDS
		) {
			return;
		}
		update_option(
			self::STATUS_OPTION,
			[
				'ok'    => $ok,
				'at'    => current_time( 'mysql', true ),
				'error' => $error,
			],
			false
		);
	}
}
