<?php

namespace Bridle\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Per-agent workspace preferences.
 *
 * The workspace had no persistence of any kind: sidebar collapse, contact panel
 * and density were all component state and died on reload, so an agent re-made
 * the same three adjustments every morning. These are per-user rather than
 * per-site on purpose — two agents sharing an install want different layouts.
 *
 * Stored as one user meta row rather than several so reading them costs a single
 * lookup on page load.
 */
class UserPrefs {

	private const META_KEY = 'bridle_prefs';

	/**
	 * Allowed preferences and their defaults.
	 *
	 * Acts as the whitelist too — anything not named here is dropped on save,
	 * so a stale or hostile client cannot grow the row without a code change.
	 */
	private const DEFAULTS = [
		'sidebarCollapsed' => null,     // null = follow the viewport breakpoint.
		'panelOpen'        => false,
		'density'          => 'comfortable',
		'inboxScope'       => null,     // null = all inboxes; otherwise an inbox id (new shell, AGENTS.md §6.3).
	];

	private const DENSITIES = [ 'comfortable', 'compact' ];

	/**
	 * Read a user's preferences, merged over the defaults.
	 */
	public static function get( ?int $user_id = null ): array {
		$user_id = $user_id ?: get_current_user_id();
		if ( ! $user_id ) {
			return self::DEFAULTS;
		}

		$stored = get_user_meta( $user_id, self::META_KEY, true );

		return self::sanitize( is_array( $stored ) ? $stored : [] );
	}

	/**
	 * Merge a partial update into a user's preferences.
	 *
	 * Partial on purpose: the client sends only what changed, so toggling the
	 * sidebar cannot clobber a density set in another tab.
	 */
	public static function save( array $changes, ?int $user_id = null ): array {
		$user_id = $user_id ?: get_current_user_id();
		if ( ! $user_id ) {
			return self::DEFAULTS;
		}

		$merged = self::sanitize( array_merge( self::get( $user_id ), $changes ) );
		update_user_meta( $user_id, self::META_KEY, $merged );

		return $merged;
	}

	/**
	 * Coerce every key to its expected type, dropping anything unrecognised.
	 */
	private static function sanitize( array $prefs ): array {
		$clean = self::DEFAULTS;

		if ( array_key_exists( 'sidebarCollapsed', $prefs ) && null !== $prefs['sidebarCollapsed'] ) {
			$clean['sidebarCollapsed'] = (bool) $prefs['sidebarCollapsed'];
		}

		if ( isset( $prefs['panelOpen'] ) ) {
			$clean['panelOpen'] = (bool) $prefs['panelOpen'];
		}

		if ( isset( $prefs['density'] ) && in_array( $prefs['density'], self::DENSITIES, true ) ) {
			$clean['density'] = $prefs['density'];
		}

		if ( isset( $prefs['inboxScope'] ) && absint( $prefs['inboxScope'] ) > 0 ) {
			$clean['inboxScope'] = absint( $prefs['inboxScope'] );
		}

		return $clean;
	}
}
