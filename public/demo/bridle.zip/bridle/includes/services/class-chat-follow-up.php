<?php
/**
 * What happens after a chat is handed to a person (#120): one conversation
 * in the bubble and by email, the way Intercom, Zendesk and Help Scout do it.
 *
 * @package Bridle
 */

namespace Bridle\Services;

use Bridle\Models\Conversation;
use Bridle\Models\Customer;
use Bridle\Models\Thread;

defined( 'ABSPATH' ) || exit;

/**
 * - A reply-time promise from the real 7-day median first reply.
 * - A confirmation email with the chat, threaded into the same conversation.
 * - The team's replies in the bubble (`messages()`), emailed only if the
 *   visitor hasn't seen them there within a few minutes.
 * - An email to the team when a chat needs a person.
 */
class ChatFollowUp {

	/** The delayed email for a reply the visitor may read in the bubble. */
	public const HOOK = 'bridle_chat_reply_email';

	/** Seconds a reply waits in the bubble before it is emailed (Intercom: 3 minutes). */
	public const EMAIL_AFTER = 180;

	/** The newest reply the visitor saw in the bubble, per chat. */
	private const SEEN = 'bridle_chat_seen_';

	private const PROMISE_CACHE = 'bridle_chat_reply_time';

	public static function init_hooks(): void {
		add_action( self::HOOK, [ self::class, 'send_if_unseen' ], 10, 2 );
	}

	/**
	 * What to promise at handoff, in a sentence, after the
	 * `bridle_chat_promise` filter (Bridle Pro: when the team is back,
	 * outside business hours).
	 */
	public static function promise(): string {
		/**
		 * Filters what the chat promises when it hands a visitor to a person.
		 *
		 * @param string $promise E.g. "We usually reply within an hour."
		 */
		return (string) apply_filters( 'bridle_chat_promise', self::usual_reply() );
	}

	/** The reply-time sentence from the 7-day median. Cached for an hour. */
	private static function usual_reply(): string {
		$time = get_transient( self::PROMISE_CACHE );
		if ( ! is_array( $time ) ) {
			$time = ChatPolicy::reply_time( self::first_reply_minutes() );
			set_transient( self::PROMISE_CACHE, $time, HOUR_IN_SECONDS );
		}
		switch ( $time['kind'] ) {
			case 'minutes':
				return __( 'We usually reply in a few minutes.', 'bridle' );
			case 'hour':
				return __( 'We usually reply within an hour.', 'bridle' );
			case 'hours':
				/* translators: %d: hours */
				return sprintf( _n( 'We usually reply within about %d hour.', 'We usually reply within about %d hours.', (int) $time['n'], 'bridle' ), (int) $time['n'] );
			case 'day':
				return __( 'We usually reply within a day.', 'bridle' );
			case 'days':
				/* translators: %d: days */
				return sprintf( _n( 'We usually reply within %d day.', 'We usually reply within %d days.', (int) $time['n'], 'bridle' ), (int) $time['n'] );
			default:
				return __( 'We’ll reply as soon as we can.', 'bridle' );
		}
	}

	/** Minutes each conversation of the last 7 days waited for a person's first reply. */
	private static function first_reply_minutes(): array {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- cached in a transient by promise().
		$rows    = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT c.created_at, MIN( t.created_at ) AS first_reply
				FROM %i c JOIN %i t ON t.conversation_id = c.id
				WHERE c.created_at >= %s AND t.author_type = 'teammate' AND t.thread_type = 'reply' AND t.is_private = 0
				GROUP BY c.id, c.created_at",
				$wpdb->prefix . 'bridle_conversations',
				$wpdb->prefix . 'bridle_threads',
				gmdate( 'Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS )
			)
		);
		$minutes = [];
		foreach ( (array) $rows as $row ) {
			$wait = strtotime( $row->first_reply . ' UTC' ) - strtotime( $row->created_at . ' UTC' );
			if ( $wait >= 0 ) {
				$minutes[] = $wait / 60;
			}
		}
		return $minutes;
	}

	/**
	 * The team's replies after `$after`, for the bubble: people's replies and
	 * any the agent emailed, never its answers in the chat (the bubble has
	 * those). With `$open`, the visitor is looking, so they count as seen.
	 *
	 * @return array<int, array{id: int, name: string, html: string}>
	 */
	public static function messages( object $conversation, int $after, bool $open ): array {
		$out = [];
		foreach ( ( new Thread() )->get_by_conversation( (int) $conversation->id ) as $thread ) {
			if ( (int) $thread->id <= $after || ! empty( $thread->is_private ) || 'reply' !== $thread->thread_type ) {
				continue;
			}
			if ( 'teammate' === $thread->author_type ) {
				$user = $thread->author_id ? get_userdata( (int) $thread->author_id ) : null;
				$name = $user ? (string) $user->first_name : '';
				$name = '' !== $name ? $name : ( $user ? (string) $user->display_name : '' );
			} elseif ( 'agent' === $thread->author_type ) {
				$sources = json_decode( (string) $thread->ai_sources, true );
				if ( 'chat' === ( is_array( $sources ) ? ( $sources['via'] ?? '' ) : '' ) ) {
					continue;
				}
				$name = (string) Settings::get( 'agent_name', '' );
			} else {
				continue;
			}
			$out[] = [
				'id'   => (int) $thread->id,
				'name' => $name,
				'html' => wp_kses( (string) ( $thread->content_html ? $thread->content_html : wpautop( esc_html( (string) $thread->content ) ) ), AgentService::REPLY_TAGS ),
			];
		}
		if ( $open && $out ) {
			self::mark_seen( (int) $conversation->id, (int) end( $out )['id'] );
		}
		return $out;
	}

	private static function mark_seen( int $conversation_id, int $thread_id ): void {
		if ( $thread_id > self::seen( $conversation_id ) ) {
			set_transient( self::SEEN . $conversation_id, $thread_id, 30 * DAY_IN_SECONDS );
		}
	}

	public static function seen( int $conversation_id ): int {
		return (int) get_transient( self::SEEN . $conversation_id );
	}

	/**
	 * Hold a reply to a chat for the bubble; it is emailed after EMAIL_AFTER
	 * unless the visitor read it there first.
	 */
	public static function hold_email( int $thread_id, int $conversation_id ): void {
		$args = [ $thread_id, $conversation_id ];
		if ( function_exists( 'as_schedule_single_action' ) ) {
			as_schedule_single_action( time() + self::EMAIL_AFTER, self::HOOK, $args, 'bridle' );
			return;
		}
		wp_schedule_single_event( time() + self::EMAIL_AFTER, self::HOOK, $args );
	}

	public static function send_if_unseen( $thread_id, $conversation_id ): void {
		if ( self::seen( (int) $conversation_id ) >= (int) $thread_id ) {
			return;
		}
		EmailService::send_reply( (int) $conversation_id, (int) $thread_id );
	}

	/** After a handoff: the visitor's confirmation, and the team's alert. */
	public static function after_handoff( int $conversation_id ): void {
		$conversation = ( new Conversation() )->get_by_id( $conversation_id );
		if ( ! $conversation ) {
			return;
		}
		EmailService::send_chat_confirmation( $conversation, self::promise() );
		self::alert_team( $conversation );
	}

	/** "A chat needs you", to the address Bridle notifies (the admin email by default). */
	private static function alert_team( object $conversation ): void {
		if ( ! Settings::get( 'chat_alerts', true ) ) {
			return;
		}
		$to = (string) Settings::get( 'notification_email', '' );
		$to = is_email( $to ) ? $to : (string) get_option( 'admin_email' );
		if ( ! is_email( $to ) ) {
			return;
		}
		$customer = ( new Customer() )->get_by_id( (int) $conversation->customer_id );
		$who      = $customer ? trim( (string) ( $customer->name ? $customer->name . ' <' . $customer->email . '>' : $customer->email ) ) : '';
		$link     = admin_url( 'admin.php?page=bridle#/c/' . (int) $conversation->id );

		wp_mail(
			$to,
			/* translators: %s: the chat's first question */
			sprintf( __( 'A chat needs you: %s', 'bridle' ), $conversation->subject ),
			sprintf(
				/* translators: 1: the visitor's name and email, 2: link to the conversation */
				__( "%1\$s asked for a person in the chat on your site.\n\nOpen it: %2\$s", 'bridle' ),
				'' !== $who ? $who : __( 'A visitor', 'bridle' ),
				$link
			)
		);
	}
}
