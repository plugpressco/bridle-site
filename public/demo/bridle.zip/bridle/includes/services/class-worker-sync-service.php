<?php

namespace Bridle\Services;

use Bridle\Models\Inbox;
use Bridle\RestApi\InboxesController;
use WP_Error;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Keeps the email worker's KV registrations in sync with this site.
 *
 * Each inbox's forwarding address is registered with the Cloudflare worker
 * exactly once, at creation time — the worker stores the webhook URL it
 * should POST inbound mail to. If the site's URL later changes (domain
 * move, http→https, subdirectory change), that stored URL goes stale and
 * every inbound email silently fails over to the worker's fallback instead
 * of arriving here.
 *
 * This service detects that drift (each inbox row remembers the webhook URL
 * it last registered in `registered_webhook_url`) and re-registers with the
 * worker, which accepts an in-place update when the webhook_secret matches
 * the one already stored for the hash.
 *
 * A copy of the database (a staging clone) carries the same secrets, so
 * re-pointing a registered inbox must never happen on its own (#104): only
 * this site's own URL change, "Fix forwarding" or `wp bridle sync-forwarding`
 * do it. Each run has a scope (to_register()):
 *
 *  - `new`: inboxes never registered, or deregistered since. The daily job
 *    (self-heals rows saved while the worker was unreachable) and an inbox
 *    switched back on. Drift is only reported.
 *  - `drifted`: those plus inboxes registered for another URL. When the
 *    siteurl/home options change (deferred a minute so the new URL is in
 *    effect) and `wp bridle sync-forwarding`.
 *  - `all`: every inbox. The "Fix forwarding" button and `--force`.
 */
class WorkerSyncService {

	const CRON_EVENT     = 'bridle_worker_sync';
	const REGISTER_EVENT = 'bridle_worker_register';
	const STATUS_OPTION  = 'bridle_worker_sync_status';

	/** Which inboxes a run registers, narrowest first. */
	const SCOPES = [ 'new', 'drifted', 'all' ];

	public static function init_hooks(): void {
		add_action( 'update_option_siteurl', [ self::class, 'schedule_sync' ] );
		add_action( 'update_option_home', [ self::class, 'schedule_sync' ] );
		add_action( self::CRON_EVENT, [ self::class, 'run_scheduled_sync' ] );
		add_action( self::REGISTER_EVENT, [ self::class, 'run_register' ] );
	}

	/**
	 * The webhook URL the worker should be delivering to right now.
	 */
	public static function expected_webhook_url(): string {
		return rest_url( BRIDLE_REST_NAMESPACE . '/inbound-email' );
	}

	/**
	 * Defer the sync ~1 minute so it runs on a request where the new
	 * siteurl/home value (and therefore rest_url()) is fully in effect.
	 */
	public static function schedule_sync(): void {
		if ( ! wp_next_scheduled( self::CRON_EVENT ) ) {
			wp_schedule_single_event( time() + MINUTE_IN_SECONDS, self::CRON_EVENT );
		}
	}

	/**
	 * Register the inboxes that have no registration (a new inbox the worker
	 * didn't answer for, or one switched back on) in the background.
	 */
	public static function schedule_register(): void {
		if ( ! wp_next_scheduled( self::REGISTER_EVENT ) ) {
			wp_schedule_single_event( time() + MINUTE_IN_SECONDS, self::REGISTER_EVENT );
		}
	}

	/** After this site's own URL change: re-point drifted inboxes too. */
	public static function run_scheduled_sync(): void {
		self::sync_all( 'drifted' );
	}

	/** The daily job and schedule_register(): only what was never registered. */
	public static function run_register(): void {
		self::sync_all( 'new' );
	}

	/**
	 * Which inboxes a run of the given scope registers. Pure.
	 *
	 * @param object[] $inboxes  Rows with `registered_webhook_url`.
	 * @param string   $expected This site's webhook URL.
	 * @param string   $scope    One of SCOPES; anything else is `new`.
	 * @return object[]
	 */
	public static function to_register( array $inboxes, string $expected, string $scope ): array {
		return array_values(
			array_filter(
				$inboxes,
				static function ( $inbox ) use ( $expected, $scope ) {
					$registered = (string) ( $inbox->registered_webhook_url ?? '' );
					if ( 'all' === $scope || '' === $registered ) {
						return true;
					}
					return 'drifted' === $scope && $registered !== $expected;
				}
			)
		);
	}

	/**
	 * Drift summary for the admin UI.
	 *
	 * - `drifted`: inboxes whose last-registered webhook URL differs from the
	 *   current one — the site URL changed and their mail is going nowhere.
	 * - `unregistered`: inboxes that have never recorded a successful
	 *   registration (created while the worker was unreachable, or created
	 *   before this column existed). These self-heal on the next sync.
	 */
	public static function get_drift(): array {
		$expected     = self::expected_webhook_url();
		$drifted      = 0;
		$unregistered = 0;

		foreach ( self::syncable_inboxes() as $inbox ) {
			if ( empty( $inbox->registered_webhook_url ) ) {
				$unregistered++;
			} elseif ( $inbox->registered_webhook_url !== $expected ) {
				$drifted++;
			}
		}

		return [
			'drifted'      => $drifted,
			'unregistered' => $unregistered,
			'expected'     => $expected,
		];
	}

	/**
	 * Register the active inboxes the scope covers (to_register()). The
	 * status option records the run and the drift it left alone.
	 *
	 * @param string $scope `new`, `drifted` or `all` (see SCOPES).
	 * @return array{synced: int, skipped: int, failed: int, results: array}
	 */
	public static function sync_all( string $scope = 'drifted' ): array {
		$expected = self::expected_webhook_url();
		$inboxes  = self::syncable_inboxes();
		$targets  = self::to_register( $inboxes, $expected, $scope );
		$results  = [];
		$synced   = 0;
		$skipped  = count( $inboxes ) - count( $targets );
		$failed   = 0;

		foreach ( $targets as $inbox ) {
			$outcome = self::register_inbox( $inbox );

			if ( is_wp_error( $outcome ) ) {
				$failed++;
				$results[] = [
					'inbox_id' => (int) $inbox->id,
					'name'     => $inbox->display_name,
					'success'  => false,
					'error'    => $outcome->get_error_message(),
				];
				continue;
			}

			$synced++;
			$results[] = [
				'inbox_id'           => (int) $inbox->id,
				'name'               => $inbox->display_name,
				'success'            => true,
				'forwarding_address' => $outcome['forwarding_address'],
			];
		}

		$summary = [
			'synced'  => $synced,
			'skipped' => $skipped,
			'failed'  => $failed,
			'results' => $results,
		];

		update_option( self::STATUS_OPTION, array_merge( $summary, [
			'scope'    => $scope,
			'ran_at'   => current_time( 'mysql', true ),
			'expected' => $expected,
			'drifted'  => self::get_drift()['drifted'],
		] ), false );

		return $summary;
	}

	/**
	 * Register one inbox's hash with the worker and record the outcome on
	 * the row. The worker accepts an in-place update (new webhook URL /
	 * site URL) when the supplied webhook_secret matches the stored one.
	 * An inbox without a secret gets one saved first (see
	 * Inbox::ensure_webhook_secret()).
	 *
	 * @return array{forwarding_address: string}|WP_Error
	 */
	public static function register_inbox( object $inbox ): array|WP_Error {
		$webhook_secret = ( new Inbox() )->ensure_webhook_secret( $inbox );
		$webhook_url    = self::expected_webhook_url();

		$response = wp_remote_post( InboxesController::WORKER_URL . '/register', [
			'body'    => wp_json_encode( [
				'site_url'       => home_url(),
				'inbox_hash'     => $inbox->inbox_hash,
				'webhook_url'    => $webhook_url,
				'webhook_secret' => $webhook_secret,
			] ),
			'headers' => [ 'Content-Type' => 'application/json' ],
			'timeout' => 15,
		] );

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'bridle_worker_unreachable', $response->get_error_message() );
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 409 === $code ) {
			return new WP_Error(
				'bridle_hash_taken',
				__( 'This forwarding address is registered to another site. Recreate the inbox to get a fresh address.', 'bridle' )
			);
		}
		if ( $code < 200 || $code >= 300 ) {
			return new WP_Error(
				'bridle_register_failed',
				sprintf(
					/* translators: %d: HTTP status code returned by the worker. */
					__( 'Worker returned HTTP %d.', 'bridle' ),
					$code
				)
			);
		}

		// The relay answers with the address it routes; anything else falls back to ours.
		$forwarding = sanitize_email( (string) ( $body['forwarding_address'] ?? '' ) );
		if ( ! is_email( $forwarding ) ) {
			$forwarding = $inbox->inbox_hash . '@' . InboxesController::EMAIL_DOMAIN;
		}

		$update = [ 'registered_webhook_url' => $webhook_url ];
		if ( $forwarding !== $inbox->forwarding_address ) {
			$update['forwarding_address'] = $forwarding;
		}
		( new Inbox() )->update( $inbox->id, $update );

		return [ 'forwarding_address' => $forwarding ];
	}

	/**
	 * Tell the worker to stop delivering mail for one inbox. Best effort:
	 * callers must not let a failure block what they are doing.
	 *
	 * An inbox registered for another URL is left alone: on a copy of the
	 * database (a staging clone) it is production's address, and switching
	 * it off or erasing the copy's data must not stop production's mail.
	 * Once the worker has let go (2xx, or 404: it had nothing), the row
	 * forgets its registration, so switching it back on registers it again.
	 *
	 * @param int $timeout Seconds to wait for the worker.
	 * @return true|WP_Error
	 */
	public static function deregister_inbox( object $inbox, int $timeout = 10 ): bool|WP_Error {
		if ( empty( $inbox->inbox_hash ) ) {
			return true;
		}
		$registered = (string) ( $inbox->registered_webhook_url ?? '' );
		if ( '' !== $registered && self::expected_webhook_url() !== $registered ) {
			return new WP_Error(
				'bridle_not_this_site',
				__( 'This address is registered for another copy of this site, so it was left as it is.', 'bridle' )
			);
		}

		$response = wp_remote_post( InboxesController::WORKER_URL . '/deregister', [
			'body'    => wp_json_encode( [
				'inbox_hash'     => $inbox->inbox_hash,
				'webhook_secret' => $inbox->webhook_secret,
			] ),
			'headers' => [ 'Content-Type' => 'application/json' ],
			'timeout' => $timeout,
		] );

		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( ! self::let_go( $code ) ) {
			return new WP_Error(
				'bridle_deregister_failed',
				sprintf(
					/* translators: %d: HTTP status code returned by the worker. */
					__( 'Worker returned HTTP %d.', 'bridle' ),
					$code
				)
			);
		}
		if ( ! empty( $inbox->id ) ) {
			( new Inbox() )->update( (int) $inbox->id, [ 'registered_webhook_url' => null ] );
		}
		return true;
	}

	/** Whether the worker's answer to /deregister means it no longer routes the address. */
	public static function let_go( int $code ): bool {
		return ( $code >= 200 && $code < 300 ) || 404 === $code;
	}

	/**
	 * Active inboxes that have a forwarding hash to keep registered.
	 */
	private static function syncable_inboxes(): array {
		$inboxes = ( new Inbox() )->list( [ 'is_active' => 1 ] );

		return array_values( array_filter( (array) $inboxes, static function ( $inbox ) {
			return ! empty( $inbox->inbox_hash );
		} ) );
	}
}
