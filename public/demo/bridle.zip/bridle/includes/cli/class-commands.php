<?php

namespace Bridle\Cli;

use Bridle\Models\Inbox;
use Bridle\RestApi\InboxesController;
use WP_CLI;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WP-CLI commands for Bridle. Registered from bridle.php when WP_CLI is
 * defined.
 *
 *   wp bridle list-inboxes [--all]
 *   wp bridle register-inbox <inbox_id> [--worker=<url>]
 *   wp bridle sync-forwarding [--force]
 *   wp bridle repair-customer-names [--dry-run]
 *   wp bridle migrate-inbox-domain <inbox_id> [--domain=<domain>] [--worker=<url>] [--yes]
 *   wp bridle merge-inbox <source_id> <target_id> [--keep-address] [--keep-active] [--yes]
 *   wp bridle agent-draft <conversation_id>
 *   wp bridle knowledge <conversation_id> [--query=<words>]
 */
class Commands {

	/**
	 * Ask the agent for a reply draft to one conversation, store it as the
	 * conversation's agent draft and print it. Ignores the inbox's agent
	 * mode, so it works for testing before the agent is switched on.
	 *
	 * ## OPTIONS
	 *
	 * <conversation_id>
	 * : The conversation to draft a reply for.
	 *
	 * ## EXAMPLES
	 *
	 *     wp bridle agent-draft 42
	 *
	 * @subcommand agent-draft
	 */
	public function agent_draft( $args, $assoc_args ): void {
		$result = \Bridle\Services\AgentService::draft( absint( $args[0] ?? 0 ) );

		if ( is_wp_error( $result ) ) {
			WP_CLI::error( $result->get_error_message() );
		}

		$meta = $result['meta'];
		WP_CLI::log( wp_strip_all_tags( str_replace( [ '</p>', '<br>', '<br />', '</li>' ], "\n", $result['content'] ) ) );
		WP_CLI::log( '' );
		WP_CLI::log( sprintf( 'Confidence: %s · verified: %s · sources: %d', $meta['confidence'], $meta['verified'] ? 'yes' : 'no', count( $meta['grounded_in'] ) ) );
		foreach ( $meta['problems'] as $problem ) {
			WP_CLI::warning( $problem );
		}
		if ( '' !== $meta['needs_human_reason'] ) {
			WP_CLI::log( 'Needs a person: ' . $meta['needs_human_reason'] );
		}
		WP_CLI::success( 'Stored as the agent draft. Summary: ' . $meta['summary'] );
	}

	/**
	 * Show what the agent would read to answer one conversation: the search
	 * terms and every doc, page, post, product and past answer it found,
	 * already budgeted and redacted, exactly as the model would see them.
	 *
	 * ## OPTIONS
	 *
	 * <conversation_id>
	 * : The conversation to look up knowledge for. Use 0 with --query.
	 *
	 * [--query=<words>]
	 * : Search these words instead of the conversation's subject and message.
	 *
	 * ## EXAMPLES
	 *
	 *     wp bridle knowledge 42
	 *     wp bridle knowledge 0 --query="license new domain"
	 */
	public function knowledge( $args, $assoc_args ): void {
		$id = absint( $args[0] ?? 0 );

		if ( ! empty( $assoc_args['query'] ) ) {
			$terms = \Bridle\Services\KnowledgeText::terms( '', (string) $assoc_args['query'] );
			$items = \Bridle\Services\KnowledgeSearch::search( $terms, [ 'exclude_id' => $id ] );
		} else {
			$conversation = ( new \Bridle\Models\Conversation() )->get_by_id( $id );
			if ( ! $conversation ) {
				WP_CLI::error( 'Conversation not found.' );
			}
			$found = \Bridle\Services\KnowledgeSearch::for_conversation( $conversation, ( new \Bridle\Models\Thread() )->get_by_conversation( $id ) );
			$terms = $found['terms'];
			$items = $found['items'];
		}

		WP_CLI::log( 'Terms: ' . ( $terms ? implode( ', ', $terms ) : '(none)' ) );
		foreach ( \Bridle\Services\KnowledgeSearch::status() as $source => $state ) {
			WP_CLI::log( sprintf( '  %-8s %s', $source, $state['enabled'] ? 'on' : ( $state['available'] ? 'off' : 'not available' ) ) );
		}
		WP_CLI::log( '' );

		$chars = 0;
		foreach ( $items as $item ) {
			$chars += mb_strlen( $item['text'] );
			WP_CLI::log( sprintf( '[%s] %s%s  (score %.1f, %d chars)', $item['id'], $item['title'], $item['url'] ? ' ' . $item['url'] : '', $item['score'] ?? 0, mb_strlen( $item['text'] ) ) );
			WP_CLI::log( $item['text'] );
			WP_CLI::log( '' );
		}

		WP_CLI::success( sprintf( '%d sources, %d characters.', count( $items ), $chars ) );
	}

	/**
	 * Re-register every active inbox with the email worker so forwarding
	 * addresses deliver to THIS site — run after a site URL / domain change.
	 *
	 * Only inboxes whose recorded registration differs from the current
	 * site (or that were never registered) are re-registered; pass --force
	 * to re-register all of them, e.g. when the worker's KV entries changed
	 * behind the plugin's back (the recorded URL still matches, the worker's
	 * copy does not). --force is the CLI twin of the admin "Fix forwarding"
	 * button. Never run this on a staging copy: it points the addresses at
	 * whichever site runs it.
	 *
	 * ## OPTIONS
	 *
	 * [--force]
	 * : Re-register every inbox even if it already matches the current site.
	 *
	 * ## EXAMPLES
	 *
	 *   wp bridle sync-forwarding
	 *   wp bridle sync-forwarding --force
	 */
	public function sync_forwarding( $args, $assoc_args ): void {
		$summary = \Bridle\Services\WorkerSyncService::sync_all( isset( $assoc_args['force'] ) ? 'all' : 'drifted' );

		foreach ( $summary['results'] as $result ) {
			if ( $result['success'] ) {
				WP_CLI::log( sprintf( '  ✓ #%d %s → %s', $result['inbox_id'], $result['name'], $result['forwarding_address'] ) );
			} else {
				WP_CLI::warning( sprintf( '#%d %s: %s', $result['inbox_id'], $result['name'], $result['error'] ) );
			}
		}

		if ( $summary['failed'] > 0 ) {
			WP_CLI::error( sprintf(
				'%d synced, %d already current, %d FAILED.',
				$summary['synced'],
				$summary['skipped'],
				$summary['failed']
			) );
		}

		WP_CLI::success( sprintf( '%d synced, %d already current.', $summary['synced'], $summary['skipped'] ) );
	}

	/**
	 * Replace placeholder customer names with the real sender's name.
	 *
	 * Until the inbound identity fix, a customer's name was set once at creation
	 * and never corrected, so contact-form conversations got branded with the
	 * *site's* name ("DiviTorque") or the address's local part ("egonzalez")
	 * permanently. This re-reads each affected customer's earliest thread and
	 * recovers the name from the form's `Name:`/`Email:` block.
	 *
	 * Only rows whose current name is a placeholder are touched — a name a human
	 * typed in the Contacts UI is never overwritten.
	 *
	 * ## OPTIONS
	 *
	 * [--dry-run]
	 * : Report what would change without writing anything.
	 *
	 * ## EXAMPLES
	 *
	 *   wp bridle repair-customer-names --dry-run
	 *   wp bridle repair-customer-names
	 */
	public function repair_customer_names( $args, $assoc_args ): void {
		global $wpdb;

		$dry_run   = isset( $assoc_args['dry-run'] );
		$customers = $wpdb->get_results( $wpdb->prepare( 'SELECT id, name, email FROM %i ORDER BY id ASC', $wpdb->prefix . 'bridle_customers' ) );

		if ( ! $customers ) {
			WP_CLI::success( 'No customers to check.' );
			return;
		}

		$model     = new \Bridle\Models\Customer();
		$threads   = $wpdb->prefix . 'bridle_threads';
		$convs     = $wpdb->prefix . 'bridle_conversations';
		$repaired  = 0;
		$unmatched = 0;

		foreach ( $customers as $customer ) {
			if ( ! \Bridle\Services\SenderIdentity::is_placeholder_name( (string) $customer->name, (string) $customer->email ) ) {
				continue;
			}

			// Earliest inbound thread for this customer — that's the one carrying
			// the contact form's identity block.
			$body = $wpdb->get_var( $wpdb->prepare(
				'SELECT t.content FROM %i t
				 INNER JOIN %i c ON c.id = t.conversation_id
				 WHERE c.customer_id = %d
				 ORDER BY t.id ASC
				 LIMIT 1',
				$threads,
				$convs,
				$customer->id
			) );

			$form = $body ? \Bridle\Services\SenderIdentity::parse_form_identity( (string) $body ) : null;

			if ( ! $form || '' === $form['name'] || strtolower( $form['email'] ) !== strtolower( (string) $customer->email ) ) {
				++$unmatched;
				WP_CLI::debug( sprintf( '#%d %s (%s): no recoverable name', $customer->id, $customer->name, $customer->email ) );
				continue;
			}

			WP_CLI::log( sprintf( '  %s #%d  "%s" → "%s"  <%s>', $dry_run ? '·' : '✓', $customer->id, $customer->name, $form['name'], $customer->email ) );

			if ( ! $dry_run ) {
				$model->update( (int) $customer->id, [ 'name' => $form['name'] ] );
			}
			++$repaired;
		}

		if ( $dry_run ) {
			WP_CLI::success( sprintf( '%d would be repaired, %d placeholder rows had no recoverable name.', $repaired, $unmatched ) );
			return;
		}

		WP_CLI::success( sprintf( '%d repaired, %d placeholder rows had no recoverable name.', $repaired, $unmatched ) );
	}

	/**
	 * (Re)register an inbox with the email worker so its forwarding address
	 * actually delivers mail.
	 *
	 * Use this when an inbox was created while the worker was unreachable —
	 * the plugin saves the inbox row anyway, so its address exists in the UI
	 * but isn't in the worker's KV. Mail to it then falls back to the
	 * worker's FALLBACK_EMAIL (or bounces, if Email Routing's catch-all
	 * isn't set up) instead of arriving as a conversation.
	 *
	 * Re-registering the same inbox_hash for the same site is safe and
	 * idempotent — the worker just refreshes the stored webhook URL/secret.
	 *
	 * ## OPTIONS
	 *
	 * <inbox_id>
	 * : The inbox id (see `wp bridle list-inboxes`).
	 *
	 * [--worker=<url>]
	 * : Worker base URL. Defaults to InboxesController::WORKER_URL.
	 *
	 * ## EXAMPLES
	 *
	 *   wp bridle register-inbox 4
	 */
	public function register_inbox( $args, $assoc_args ): void {
		$inbox_id = absint( $args[0] ?? 0 );
		if ( ! $inbox_id ) {
			WP_CLI::error( 'Inbox id is required.' );
		}

		$worker = rtrim( $assoc_args['worker'] ?? InboxesController::WORKER_URL, '/' );

		$model = new Inbox();
		$inbox = $model->get_by_id( $inbox_id );

		if ( ! $inbox ) {
			WP_CLI::error( sprintf( 'No inbox found with id %d.', $inbox_id ) );
		}
		if ( empty( $inbox->inbox_hash ) ) {
			WP_CLI::error( sprintf( 'Inbox %d has no inbox_hash — recreate it.', $inbox_id ) );
		}

		$webhook_secret = $model->ensure_webhook_secret( $inbox );
		$webhook_url    = rest_url( BRIDLE_REST_NAMESPACE . '/inbound-email' );

		WP_CLI::log( '' );
		WP_CLI::log( sprintf( 'Registering inbox #%d "%s"', $inbox->id, $inbox->display_name ) );
		WP_CLI::log( sprintf( '  inbox_hash  : %s', $inbox->inbox_hash ) );
		WP_CLI::log( sprintf( '  webhook_url : %s', $webhook_url ) );
		WP_CLI::log( sprintf( '  worker      : %s', $worker ) );
		WP_CLI::log( '' );

		$response = wp_remote_post( $worker . '/register', [
			'body'    => wp_json_encode( [
				'site_url'       => home_url(),
				'inbox_hash'     => $inbox->inbox_hash,
				'webhook_url'    => $webhook_url,
				'webhook_secret' => $webhook_secret,
			] ),
			'headers' => [ 'Content-Type' => 'application/json' ],
			'timeout' => 15,
		] );

		if ( is_wp_error( $response ) ) {
			WP_CLI::error( sprintf( 'Worker unreachable: %s', $response->get_error_message() ) );
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 409 === $code ) {
			WP_CLI::error( 'Address is already registered to a different site (409). Recreate the inbox to get a fresh hash.' );
		}
		if ( $code < 200 || $code >= 300 ) {
			WP_CLI::error( sprintf( 'Worker returned %d: %s', $code, wp_remote_retrieve_body( $response ) ) );
		}

		$confirmed = $body['forwarding_address'] ?? ( $inbox->inbox_hash . '@' . InboxesController::EMAIL_DOMAIN );

		// Keep the stored forwarding address in sync with the worker's answer.
		if ( $confirmed && $confirmed !== $inbox->forwarding_address ) {
			$model->update( $inbox->id, [ 'forwarding_address' => $confirmed ] );
		}

		WP_CLI::success( sprintf( 'Registered. Mail to %s now reaches this site.', $confirmed ) );
	}

	/**
	 * List inboxes with their id, forwarding address, status and
	 * conversation count — handy for finding the ids merge-inbox needs.
	 *
	 * ## OPTIONS
	 *
	 * [--all]
	 * : Include deactivated inboxes (is_active = 0) too.
	 *
	 * ## EXAMPLES
	 *
	 *   wp bridle list-inboxes
	 *   wp bridle list-inboxes --all
	 */
	public function list_inboxes( $args, $assoc_args ): void {
		global $wpdb;

		$table      = $wpdb->prefix . 'bridle_inboxes';
		$conv_table = $wpdb->prefix . 'bridle_conversations';
		$rows       = isset( $assoc_args['all'] )
			? $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i ORDER BY id ASC', $table ) )
			: $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE is_active = 1 ORDER BY id ASC', $table ) );

		if ( empty( $rows ) ) {
			WP_CLI::log( 'No inboxes found.' );
			return;
		}

		$items = [];
		foreach ( $rows as $r ) {
			$convs   = (int) $wpdb->get_var( $wpdb->prepare(
				'SELECT COUNT(*) FROM %i WHERE inbox_id = %d',
				$conv_table,
				$r->id
			) );
			$items[] = [
				'id'            => (int) $r->id,
				'name'          => $r->display_name,
				'forwarding'    => $r->forwarding_address ?: '(unset)',
				'active'        => $r->is_active ? 'yes' : 'no',
				'conversations' => $convs,
			];
		}

		\WP_CLI\Utils\format_items( 'table', $items, [ 'id', 'name', 'forwarding', 'active', 'conversations' ] );
	}

	/**
	 * Merge one inbox into another: move every conversation from <source_id>
	 * into <target_id>, then deactivate the source.
	 *
	 * Conversations keep their threads, customers and attachments — only
	 * their inbox_id changes. The source is soft-deleted (is_active = 0)
	 * and, unless --keep-address is passed, its forwarding address is
	 * deregistered from the worker so new mail stops arriving (otherwise it
	 * would silently land in the now-hidden source inbox, since inbound
	 * resolves by hash regardless of is_active).
	 *
	 * After the merge, customers should email the TARGET inbox's address.
	 *
	 * ## OPTIONS
	 *
	 * <source_id>
	 * : Inbox to merge FROM (the old one). Emptied and deactivated.
	 *
	 * <target_id>
	 * : Inbox to merge INTO (the new one). Receives all conversations.
	 *
	 * [--keep-address]
	 * : Do NOT deregister the source's old forwarding address from the worker.
	 *
	 * [--keep-active]
	 * : Leave the source inbox active instead of deactivating it.
	 *
	 * [--yes]
	 * : Skip the confirmation prompt.
	 *
	 * ## EXAMPLES
	 *
	 *   wp bridle merge-inbox 2 5
	 *   wp bridle merge-inbox 2 5 --yes
	 */
	public function merge_inbox( $args, $assoc_args ): void {
		global $wpdb;

		$source_id = absint( $args[0] ?? 0 );
		$target_id = absint( $args[1] ?? 0 );

		if ( ! $source_id || ! $target_id ) {
			WP_CLI::error( 'Both <source_id> and <target_id> are required.' );
		}
		if ( $source_id === $target_id ) {
			WP_CLI::error( 'Source and target must be different inboxes.' );
		}

		$model  = new Inbox();
		$source = $model->get_by_id( $source_id );
		$target = $model->get_by_id( $target_id );

		if ( ! $source ) {
			WP_CLI::error( sprintf( 'No inbox found with id %d (source).', $source_id ) );
		}
		if ( ! $target ) {
			WP_CLI::error( sprintf( 'No inbox found with id %d (target).', $target_id ) );
		}

		$conv_table = $wpdb->prefix . 'bridle_conversations';
		$count      = (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(*) FROM %i WHERE inbox_id = %d',
			$conv_table,
			$source_id
		) );

		WP_CLI::log( '' );
		WP_CLI::log( sprintf( 'Merge inbox #%d "%s"  →  #%d "%s"', $source->id, $source->display_name, $target->id, $target->display_name ) );
		WP_CLI::log( sprintf( '  Conversations to move : %d', $count ) );
		WP_CLI::log( sprintf( '  Source forwarding     : %s', $source->forwarding_address ?: '(unset)' ) );
		WP_CLI::log( sprintf( '  Target forwarding     : %s', $target->forwarding_address ?: '(unset)' ) );
		WP_CLI::log( '' );

		WP_CLI::confirm( 'Proceed with the merge?', $assoc_args );

		// 1. Move conversations.
		$moved = $wpdb->query( $wpdb->prepare(
			'UPDATE %i SET inbox_id = %d WHERE inbox_id = %d',
			$conv_table,
			$target_id,
			$source_id
		) );

		WP_CLI::log( sprintf( 'Moved %d conversation(s) into "%s".', (int) $moved, $target->display_name ) );

		// 2. Deregister the old address so new mail stops (unless told not to).
		if ( ! isset( $assoc_args['keep-address'] ) && ! empty( $source->inbox_hash ) ) {
			$resp = \Bridle\Services\WorkerSyncService::deregister_inbox( $source );

			if ( is_wp_error( $resp ) ) {
				WP_CLI::warning( sprintf( 'Could not deregister old address from worker: %s', $resp->get_error_message() ) );
			} else {
				WP_CLI::log( sprintf( 'Deregistered old address %s from the worker.', $source->forwarding_address ?: $source->inbox_hash ) );
			}
		}

		// 3. Deactivate the source inbox (unless told to keep it).
		if ( ! isset( $assoc_args['keep-active'] ) ) {
			$model->update( $source->id, [ 'is_active' => 0 ] );
			WP_CLI::log( sprintf( 'Deactivated source inbox #%d.', $source->id ) );
		}

		WP_CLI::success( sprintf(
			'Merged inbox #%d into #%d — %d conversation(s) now in "%s".',
			$source->id,
			$target->id,
			(int) $moved,
			$target->display_name
		) );
	}

	/**
	 * Switch an existing inbox's forwarding address to a new email domain,
	 * keeping its hash, secret, and all conversation history in place.
	 *
	 * Workflow:
	 *   1. Validate the inbox exists and has an inbox_hash.
	 *   2. POST /register on the target worker with the inbox's existing
	 *      hash + webhook_secret + webhook_url, so the worker's KV knows
	 *      to route mail for the new domain to this inbox.
	 *   3. Update the inbox row's forwarding_address column.
	 *
	 * Conversations, threads, customers, drafts, and attachments are
	 * untouched — they continue to belong to the same inbox_id.
	 *
	 * The old domain's mail will keep flowing until the old worker /
	 * email-routing rule is retired. This command does not delete the
	 * old KV entry; run that cleanup separately when ready.
	 *
	 * ## OPTIONS
	 *
	 * <inbox_id>
	 * : The numeric id of the inbox to migrate (from wp_bridle_inboxes.id).
	 *
	 * [--domain=<domain>]
	 * : Target email domain. Defaults to InboxesController::EMAIL_DOMAIN
	 * : (currently "bridle.to").
	 *
	 * [--worker=<url>]
	 * : Worker /register endpoint base URL. Defaults to
	 * : InboxesController::WORKER_URL.
	 *
	 * [--yes]
	 * : Skip the confirmation prompt.
	 *
	 * ## EXAMPLES
	 *
	 *   wp bridle migrate-inbox-domain 3
	 *   wp bridle migrate-inbox-domain 3 --domain=bridle.to --yes
	 */
	public function migrate_inbox_domain( $args, $assoc_args ): void {
		global $wpdb;

		$inbox_id = absint( $args[0] ?? 0 );
		if ( ! $inbox_id ) {
			WP_CLI::error( 'Inbox id is required.' );
		}

		$domain = $assoc_args['domain'] ?? InboxesController::EMAIL_DOMAIN;
		$worker = rtrim( $assoc_args['worker'] ?? InboxesController::WORKER_URL, '/' );

		$model = new Inbox();
		$inbox = $model->get_by_id( $inbox_id );

		if ( ! $inbox ) {
			WP_CLI::error( sprintf( 'No inbox found with id %d.', $inbox_id ) );
		}

		if ( empty( $inbox->inbox_hash ) ) {
			WP_CLI::error( sprintf( 'Inbox %d has no inbox_hash — cannot migrate.', $inbox_id ) );
		}

		$old_address = $inbox->forwarding_address;
		$new_address = $inbox->inbox_hash . '@' . $domain;

		if ( $old_address === $new_address ) {
			WP_CLI::warning( sprintf( 'Forwarding address is already %s. Nothing to do.', $new_address ) );
			return;
		}

		WP_CLI::log( '' );
		WP_CLI::log( sprintf( 'Inbox #%d — %s', $inbox->id, $inbox->display_name ) );
		WP_CLI::log( sprintf( '  Customer-facing email : %s', $inbox->email_address ) );
		WP_CLI::log( sprintf( '  Forwarding (current)  : %s', $old_address ?: '(unset)' ) );
		WP_CLI::log( sprintf( '  Forwarding (new)      : %s', $new_address ) );
		WP_CLI::log( sprintf( '  Worker                : %s', $worker ) );
		WP_CLI::log( '' );

		WP_CLI::confirm( 'Proceed with the migration?', $assoc_args );

		// 1. Register inbox_hash on the target worker (writes KV).
		$webhook_secret = $model->ensure_webhook_secret( $inbox );
		$webhook_url    = rest_url( BRIDLE_REST_NAMESPACE . '/inbound-email' );

		$response = wp_remote_post( $worker . '/register', [
			'body'    => wp_json_encode( [
				'site_url'       => home_url(),
				'inbox_hash'     => $inbox->inbox_hash,
				'webhook_url'    => $webhook_url,
				'webhook_secret' => $webhook_secret,
			] ),
			'headers' => [ 'Content-Type' => 'application/json' ],
			'timeout' => 15,
		] );

		if ( is_wp_error( $response ) ) {
			WP_CLI::error( sprintf( 'Worker registration failed: %s', $response->get_error_message() ) );
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( $code < 200 || $code >= 300 ) {
			WP_CLI::error( sprintf(
				'Worker returned %d: %s',
				$code,
				is_array( $body ) ? wp_json_encode( $body ) : wp_remote_retrieve_body( $response )
			) );
		}

		WP_CLI::log( sprintf( 'Worker registered — confirmed forwarding address: %s', $body['forwarding_address'] ?? $new_address ) );

		// 2. Update the inbox row.
		$table   = $wpdb->prefix . 'bridle_inboxes';
		$updated = $wpdb->update(
			$table,
			[ 'forwarding_address' => $new_address ],
			[ 'id' => $inbox->id ],
			[ '%s' ],
			[ '%d' ]
		);

		if ( false === $updated ) {
			WP_CLI::error( sprintf( 'Failed to update inbox row: %s', $wpdb->last_error ) );
		}

		WP_CLI::success( sprintf( 'Inbox #%d migrated to %s.', $inbox->id, $new_address ) );
		WP_CLI::log( '' );
		WP_CLI::log( 'Mail to the OLD address will keep working until you retire' );
		WP_CLI::log( 'the old worker / Email Routing rule. Both addresses now' );
		WP_CLI::log( 'deliver to the same inbox.' );
	}
}
