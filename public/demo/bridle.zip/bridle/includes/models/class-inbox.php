<?php

namespace Bridle\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Inbox {

	private string $table;

	public function __construct() {
		global $wpdb;
		$this->table = $wpdb->prefix . 'bridle_inboxes';
	}

	public function create( array $data ) {
		global $wpdb;

		$result = $wpdb->insert( $this->table, [
			'email_address'      => sanitize_email( $data['email_address'] ),
			'display_name'       => sanitize_text_field( $data['display_name'] ),
			'icon'               => isset( $data['icon'] ) ? self::sanitize_icon( $data['icon'] ) : null,
			'color'              => isset( $data['color'] ) ? self::sanitize_color( $data['color'] ) : null,
			'inbox_hash'         => sanitize_text_field( $data['inbox_hash'] ),
			'forwarding_address' => isset( $data['forwarding_address'] ) ? sanitize_text_field( $data['forwarding_address'] ) : null,
			'webhook_secret'     => isset( $data['webhook_secret'] ) ? sanitize_text_field( $data['webhook_secret'] ) : null,
			'is_active'          => isset( $data['is_active'] ) ? absint( $data['is_active'] ) : 1,
			'created_at'         => current_time( 'mysql', true ),
		] );

		if ( false === $result ) {
			return false;
		}

		return (int) $wpdb->insert_id;
	}

	public function get_by_id( int $id ): ?object {
		global $wpdb;

		return $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM %i WHERE id = %d',
			$this->table,
			$id
		) );
	}

	public function get_by_hash( string $hash ): ?object {
		global $wpdb;

		return $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM %i WHERE inbox_hash = %s',
			$this->table,
			sanitize_text_field( $hash )
		) );
	}

	public function list( array $args = [] ): array {
		global $wpdb;

		if ( isset( $args['is_active'] ) ) {
			return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE is_active = %d ORDER BY created_at ASC', $this->table, absint( $args['is_active'] ) ) ) ?: [];
		}

		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i ORDER BY created_at ASC', $this->table ) ) ?: [];
	}

	public function update( int $id, array $data ): bool {
		global $wpdb;

		$allowed = [
			'email_address', 'display_name', 'icon', 'icon_url', 'color', 'forwarding_address', 'is_active', 'last_received_at',
			'registered_webhook_url',
			'auto_reply_enabled', 'auto_reply_subject', 'auto_reply_body',
			'signature', 'satisfaction_enabled', 'satisfaction_text', 'restricted_access',
		];
		$update  = [];

		foreach ( $allowed as $field ) {
			if ( array_key_exists( $field, $data ) ) {
				$update[ $field ] = self::sanitize_field( $field, $data[ $field ] );
			}
		}

		if ( empty( $update ) ) {
			return false;
		}

		return (bool) $wpdb->update( $this->table, $update, [ 'id' => $id ] );
	}

	public function delete( int $id ): bool {
		global $wpdb;

		return (bool) $wpdb->delete( $this->table, [ 'id' => $id ] );
	}

	/**
	 * The secret new inboxes are registered with: the site's bridle_api_key,
	 * created on first use.
	 */
	public static function default_webhook_secret(): string {
		$secret = (string) get_option( 'bridle_api_key', '' );
		if ( '' === $secret ) {
			$secret = 'bridle_live_' . wp_generate_password( 28, false );
			update_option( 'bridle_api_key', $secret );
		}

		return $secret;
	}

	/**
	 * The inbox's webhook secret, stored on the row first if it has none.
	 *
	 * The inbound webhook accepts only the secret on the row, so registering
	 * a secret-less inbox with anything else can never deliver. The default
	 * is also what such inboxes used to be registered with, so the worker's
	 * existing entry still matches.
	 */
	public function ensure_webhook_secret( object $inbox ): string {
		global $wpdb;

		if ( ! empty( $inbox->webhook_secret ) ) {
			return (string) $inbox->webhook_secret;
		}

		$secret = self::default_webhook_secret();
		$wpdb->update( $this->table, [ 'webhook_secret' => $secret ], [ 'id' => (int) $inbox->id ] );
		$inbox->webhook_secret = $secret;

		return $secret;
	}

	public function count(): int {
		global $wpdb;

		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i', $this->table ) );
	}

	/**
	 * Clean one updatable column. The server-managed ones (forwarding
	 * address, registered webhook URL, last received) are only set by our
	 * own code and pass through as given.
	 */
	private static function sanitize_field( string $field, $value ) {
		switch ( $field ) {
			case 'icon':
				return self::sanitize_icon( $value );
			case 'icon_url':
				return self::sanitize_icon_url( $value );
			case 'color':
				return self::sanitize_color( $value );
			case 'email_address':
				return sanitize_email( (string) $value );
			case 'forwarding_address':
				return null === $value ? null : sanitize_email( (string) $value );
			case 'registered_webhook_url':
				return null === $value ? null : esc_url_raw( (string) $value );
			case 'last_received_at':
				return preg_match( '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', (string) $value ) ? (string) $value : null;
			case 'display_name':
			case 'auto_reply_subject':
			case 'satisfaction_text':
				return sanitize_text_field( (string) $value );
			case 'auto_reply_body':
			case 'signature':
				return wp_kses_post( (string) $value );
			case 'is_active':
			case 'auto_reply_enabled':
			case 'satisfaction_enabled':
			case 'restricted_access':
				return empty( $value ) ? 0 : 1;
			default:
				return sanitize_text_field( (string) $value );
		}
	}

	/**
	 * Sanitize an inbox icon. Accepts a short string (emoji or 1–4 chars).
	 * Returns null for empty/invalid input.
	 */
	private static function sanitize_icon( $icon ): ?string {
		if ( ! is_string( $icon ) ) {
			return null;
		}
		// Icon is a key from the curated set (e.g. "inbox", "support"); keep
		// to a-z/0-9/-/_ , max 16 chars (matches the schema + sidebar map).
		$icon = preg_replace( '/[^a-z0-9_-]/', '', strtolower( trim( $icon ) ) );
		return ( '' !== $icon ) ? substr( $icon, 0, 16 ) : null;
	}

	/**
	 * Sanitize an uploaded icon URL. Must be an image URL from the current site
	 * (WordPress media library) — external URLs are rejected to prevent SSRF
	 * and hotlinking arbitrary hosts into the admin UI.
	 */
	private static function sanitize_icon_url( $url ): ?string {
		if ( ! is_string( $url ) ) {
			return null;
		}
		$url = trim( $url );
		if ( '' === $url ) {
			return null;
		}
		$url = esc_url_raw( $url );
		if ( '' === $url ) {
			return null;
		}
		// Restrict to the site's own uploads host to keep this to WP media picks.
		$site_host   = wp_parse_url( home_url(), PHP_URL_HOST );
		$target_host = wp_parse_url( $url, PHP_URL_HOST );
		if ( $site_host && $target_host && strcasecmp( $site_host, $target_host ) !== 0 ) {
			return null;
		}
		return $url;
	}

	/**
	 * Sanitize a hex color. Accepts #RGB or #RRGGBB. Returns null if invalid.
	 */
	private static function sanitize_color( $color ): ?string {
		if ( ! is_string( $color ) ) {
			return null;
		}
		$color = trim( $color );
		if ( '' === $color ) {
			return null;
		}
		if ( preg_match( '/^#([A-Fa-f0-9]{3}|[A-Fa-f0-9]{6})$/', $color ) ) {
			return strtoupper( $color );
		}
		return null;
	}
}
