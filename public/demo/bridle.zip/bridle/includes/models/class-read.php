<?php

namespace Bridle\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Who has read what: one row per (conversation, teammate) holding when they
 * last opened it. A conversation is unread for a teammate when the customer
 * wrote after that, so it turns unread again when they write back.
 *
 * Mail that arrived before read/unread existed counts as read: with no row,
 * the mark is the `bridle_unread_since` option (set once by the Activator).
 * Marking unread stores the epoch, so any customer message beats it.
 */
class Read {

	/** The read_at that "mark as unread" stores. */
	public const NEVER = '1970-01-01 00:00:00';

	private string $table;

	public function __construct() {
		global $wpdb;
		$this->table = $wpdb->prefix . 'bridle_reads';
	}

	public function mark_read( int $conversation_id, int $user_id ): bool {
		return $this->set( $conversation_id, $user_id, current_time( 'mysql', true ) );
	}

	public function mark_unread( int $conversation_id, int $user_id ): bool {
		return $this->set( $conversation_id, $user_id, self::NEVER );
	}

	/**
	 * Forget the rows of conversations that are being deleted.
	 *
	 * @param int[] $conversation_ids Conversation IDs.
	 */
	public function delete_for_conversations( array $conversation_ids ): void {
		global $wpdb;

		$ids = array_values( array_filter( array_map( 'absint', $conversation_ids ) ) );
		if ( empty( $ids ) ) {
			return;
		}
		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- a %d placeholder list.
		$wpdb->query( $wpdb->prepare( "DELETE FROM %i WHERE conversation_id IN ({$placeholders})", array_merge( [ $this->table ], $ids ) ) );
	}

	/** Forget a deleted WordPress user's rows (`deleted_user`). */
	public function delete_for_user( int $user_id ): void {
		global $wpdb;
		$wpdb->delete( $this->table, [ 'user_id' => $user_id ], [ '%d' ] );
	}

	/**
	 * Whether a conversation is unread for one teammate.
	 *
	 * All three are UTC MySQL datetimes, which order as strings.
	 *
	 * @param string|null $last_customer_at The customer's newest message, if any.
	 * @param string|null $read_at          The teammate's row, if any.
	 * @param string      $since            When read/unread started (`bridle_unread_since`).
	 */
	public static function is_unread( ?string $last_customer_at, ?string $read_at, string $since ): bool {
		if ( empty( $last_customer_at ) ) {
			return false;
		}
		$mark = null !== $read_at && '' !== $read_at ? $read_at : $since;
		if ( '' === $mark ) {
			return false;
		}
		return strcmp( $last_customer_at, $mark ) > 0;
	}

	private function set( int $conversation_id, int $user_id, string $read_at ): bool {
		global $wpdb;

		if ( $conversation_id <= 0 || $user_id <= 0 ) {
			return false;
		}
		// REPLACE works the same on MySQL and on the local SQLite site.
		return false !== $wpdb->replace(
			$this->table,
			[
				'conversation_id' => $conversation_id,
				'user_id'         => $user_id,
				'read_at'         => $read_at,
			],
			[ '%d', '%d', '%s' ]
		);
	}
}
