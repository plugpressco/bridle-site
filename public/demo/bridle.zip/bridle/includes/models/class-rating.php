<?php

namespace Bridle\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Customer satisfaction rating, one per conversation. Rating is an int
 * 1..4 mapped to Great / Good / Okay / Bad.
 */
class Rating {

	public const GREAT = 4;
	public const GOOD  = 3;
	public const OKAY  = 2;
	public const BAD   = 1;

	private string $table;

	public function __construct() {
		global $wpdb;
		$this->table = $wpdb->prefix . 'bridle_ratings';
	}

	/**
	 * Insert a rating, or overwrite the existing one for the same
	 * conversation. Returns false on bad rating value.
	 */
	public function record( int $conversation_id, int $rating, string $comment = '' ) {
		global $wpdb;

		$rating = max( 1, min( 4, $rating ) );

		$existing = $this->get_for_conversation( $conversation_id );
		if ( $existing ) {
			return false !== $wpdb->update(
				$this->table,
				[
					'rating'  => $rating,
					'comment' => sanitize_textarea_field( $comment ),
				],
				[ 'id' => (int) $existing->id ]
			);
		}

		return false !== $wpdb->insert( $this->table, [
			'conversation_id' => $conversation_id,
			'rating'          => $rating,
			'comment'         => sanitize_textarea_field( $comment ),
			'created_at'      => current_time( 'mysql', true ),
		] );
	}

	public function get_for_conversation( int $conversation_id ): ?object {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM %i WHERE conversation_id = %d',
			$this->table,
			$conversation_id
		) );
	}

	/**
	 * Overall CSAT % (Great+Good as a percent of all ratings) and the
	 * four-bucket breakdown. Window-scoped via $since.
	 */
	public function summary( string $since = '' ): array {
		global $wpdb;

		$rows = ( $since
			? $wpdb->get_results( $wpdb->prepare( 'SELECT rating, COUNT(*) AS c FROM %i WHERE created_at >= %s GROUP BY rating', $this->table, $since ) )
			: $wpdb->get_results( $wpdb->prepare( 'SELECT rating, COUNT(*) AS c FROM %i GROUP BY rating', $this->table ) )
		) ?: [];

		$buckets = [ 1 => 0, 2 => 0, 3 => 0, 4 => 0 ];
		$total   = 0;
		foreach ( $rows as $r ) {
			$buckets[ (int) $r->rating ] = (int) $r->c;
			$total += (int) $r->c;
		}

		$score = $total ? round( ( ( $buckets[3] + $buckets[4] ) / $total ) * 100 ) : null;

		return [
			'score'   => $score,    // null when no ratings yet
			'total'   => $total,
			'buckets' => [
				'great' => $buckets[4],
				'good'  => $buckets[3],
				'okay'  => $buckets[2],
				'bad'   => $buckets[1],
			],
		];
	}

	/** Build a tamper-proof token a public link can verify. */
	public static function make_token( int $conversation_id ): string {
		return wp_hash( 'bridle_rating_' . $conversation_id );
	}

	public static function verify_token( int $conversation_id, string $token ): bool {
		return hash_equals( self::make_token( $conversation_id ), $token );
	}
}
