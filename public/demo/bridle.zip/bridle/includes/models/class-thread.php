<?php

namespace Bridle\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Thread {

	private string $table;

	public function __construct() {
		global $wpdb;
		$this->table = $wpdb->prefix . 'bridle_threads';
	}

	public function create( array $data ) {
		global $wpdb;

		$conversation_id = absint( $data['conversation_id'] );
		$author_type     = sanitize_text_field( $data['author_type'] ?? 'customer' );
		$thread_type     = sanitize_text_field( $data['thread_type'] ?? 'reply' );
		$is_private      = ! empty( $data['is_private'] ) ? 1 : 0;
		$message_id      = self::normalize_message_id( (string) ( $data['email_message_id'] ?? '' ) );

		$result = $wpdb->insert( $this->table, [
			'conversation_id' => $conversation_id,
			'author_type'     => $author_type,
			'author_id'       => isset( $data['author_id'] ) ? absint( $data['author_id'] ) : null,
			'thread_type'     => $thread_type,
			'content'         => wp_kses_post( $data['content'] ),
			'content_html'    => isset( $data['content_html'] ) ? wp_kses_post( $data['content_html'] ) : null,
			'ai_generated'    => ! empty( $data['ai_generated'] ) ? 1 : 0,
			'ai_sources'      => isset( $data['ai_sources'] ) ? wp_json_encode( $data['ai_sources'] ) : null,
			'email_message_id' => '' === $message_id ? null : $message_id,
			'is_private'      => $is_private,
			'created_at'      => current_time( 'mysql', true ),
		] );

		if ( false === $result ) {
			return false;
		}

		$thread_id = (int) $wpdb->insert_id;

		// First public reply from the team or the agent stamps
		// first_responded_at so first-response time can be measured.
		if ( in_array( $author_type, [ 'teammate', 'agent' ], true ) && 'reply' === $thread_type && ! $is_private ) {
			$conv_table = $wpdb->prefix . 'bridle_conversations';
			$wpdb->query( $wpdb->prepare(
				'UPDATE %i
				 SET first_responded_at = %s
				 WHERE id = %d AND first_responded_at IS NULL',
				$conv_table,
				current_time( 'mysql', true ),
				$conversation_id
			) );
		}

		return $thread_id;
	}

	public function get_by_id( int $id ): ?object {
		global $wpdb;

		return $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM %i WHERE id = %d',
			$this->table,
			$id
		) );
	}

	public function get_by_conversation( int $conversation_id ): array {
		global $wpdb;

		$results = $wpdb->get_results( $wpdb->prepare(
			'SELECT * FROM %i WHERE conversation_id = %d ORDER BY created_at ASC',
			$this->table,
			$conversation_id
		) );

		return $results ?: [];
	}

	/**
	 * Public messages (no notes) of several conversations in one query,
	 * oldest first: the agent's memory reads past questions and answers.
	 *
	 * @param int[] $conversation_ids
	 * @return array<int, object[]> conversation id => threads.
	 */
	public function get_public_by_conversations( array $conversation_ids ): array {
		global $wpdb;

		$ids = array_values( array_filter( array_map( 'absint', $conversation_ids ) ) );
		if ( ! $ids ) {
			return [];
		}

		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQL.NotPrepared -- a list of %d placeholders.
		$sql  = $wpdb->prepare(
			"SELECT id, conversation_id, author_type, content, content_html, created_at FROM %i
			WHERE conversation_id IN ({$placeholders}) AND is_private = 0 AND thread_type = 'reply'
			ORDER BY created_at ASC",
			array_merge( [ $this->table ], $ids )
		);
		$rows = (array) $wpdb->get_results( $sql );
		// phpcs:enable

		$by_conversation = [];
		foreach ( $rows as $row ) {
			$by_conversation[ (int) $row->conversation_id ][] = $row;
		}

		return $by_conversation;
	}

	public function count_by_conversation( int $conversation_id ): int {
		global $wpdb;

		return (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(*) FROM %i WHERE conversation_id = %d',
			$this->table,
			$conversation_id
		) );
	}

	public function update( int $id, array $data ): bool {
		global $wpdb;

		$allowed = [];

		if ( isset( $data['content'] ) ) {
			$allowed['content'] = wp_kses_post( $data['content'] );
		}
		if ( isset( $data['content_html'] ) ) {
			$allowed['content_html'] = wp_kses_post( $data['content_html'] );
		}
		if ( isset( $data['is_private'] ) ) {
			$allowed['is_private'] = ! empty( $data['is_private'] ) ? 1 : 0;
		}

		if ( empty( $allowed ) ) {
			return false;
		}

		$result = $wpdb->update( $this->table, $allowed, [ 'id' => $id ] );

		return false !== $result;
	}

	public function delete( int $id ): bool {
		global $wpdb;

		$result = $wpdb->delete( $this->table, [ 'id' => $id ] );

		return false !== $result;
	}

	/**
	 * Message-IDs in a header value, in canonical `<id>` form and header
	 * order. Covers In-Reply-To (one id, sometimes with a trailing comment)
	 * and References (many). Never pass these through sanitize_text_field():
	 * it strips `<id>` as an HTML tag and leaves nothing.
	 *
	 * @return string[]
	 */
	public static function message_ids( string $header ): array {
		preg_match_all( '/<([^<>\s]{1,250})>/', $header, $matches );
		$ids = $matches[1];

		// Some senders omit the brackets on a lone id.
		$bare = trim( $header );
		if ( ! $ids && '' !== $bare && ! preg_match( '/[\s<>]/', $bare ) ) {
			$ids = [ $bare ];
		}

		$ids = array_filter( array_map( static fn( $id ) => preg_replace( '/[^\x21-\x7E]/', '', $id ), $ids ) );

		return array_values( array_unique( array_map( static fn( $id ) => '<' . substr( $id, 0, 250 ) . '>', $ids ) ) );
	}

	/** The first Message-ID in a header value, or ''. */
	public static function normalize_message_id( string $header ): string {
		return self::message_ids( $header )[0] ?? '';
	}

	public function find_by_message_id( string $message_id ): ?object {
		global $wpdb;

		return $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM %i WHERE email_message_id = %s LIMIT 1',
			$this->table,
			$message_id
		) );
	}
}
