<?php

namespace Bridle\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Conversation {

	/** Statuses a client may set. "pending" was retired in DB 1.4.0. */
	public const STATUSES = [ 'active', 'closed', 'spam', 'trash' ];

	public const URGENCIES = [ 'low', 'normal', 'high', 'urgent' ];

	/** Boxes a list can be filtered to. "inbox" is needs_reply + waiting. */
	public const BOXES = [ 'inbox', 'needs_reply', 'waiting', 'feed', 'closed', 'spam', 'trash' ];

	/** The most ids one "select all" can act on. */
	public const IDS_LIMIT = 2000;

	/**
	 * True for Feed mail. A sender's override wins over the per-message flag,
	 * so "always Feed / always Inbox" re-files all their mail at once.
	 * Needs the customers table joined as `cu` (see box_joins()). Standard
	 * CASE, not MySQL's IF(): the SQLite driver some installs run on
	 * mistranslates IF() and always takes the else branch.
	 */
	public const FEED_SQL = "COALESCE( cu.box_override, CASE WHEN c.is_automated = 1 THEN 'feed' ELSE 'inbox' END ) = 'feed'";

	private string $table;

	public function __construct() {
		global $wpdb;
		$this->table = $wpdb->prefix . 'bridle_conversations';
	}

	public function create( array $data ) {
		global $wpdb;

		$thread_id = $this->generate_thread_id( $data['thread_prefix'] ?? null );

		$result = $wpdb->insert( $this->table, [
			'thread_id'         => $thread_id,
			'subject'           => sanitize_text_field( $data['subject'] ),
			'status'            => sanitize_text_field( $data['status'] ?? 'active' ),
			'urgency'           => sanitize_text_field( $data['urgency'] ?? 'normal' ),
			'channel'           => sanitize_text_field( $data['channel'] ?? 'email' ),
			'source_url'        => ! empty( $data['source_url'] ) ? esc_url_raw( (string) $data['source_url'] ) : null,
			'inbox_id'          => isset( $data['inbox_id'] ) ? absint( $data['inbox_id'] ) : null,
			'customer_id'       => absint( $data['customer_id'] ),
			'assigned_to'       => isset( $data['assigned_to'] ) ? absint( $data['assigned_to'] ) : null,
			'is_automated'      => empty( $data['is_automated'] ) ? 0 : 1,
			'ai_classification' => $data['ai_classification'] ?? null,
			'last_activity_at'  => current_time( 'mysql', true ),
			'created_at'        => current_time( 'mysql', true ),
			'updated_at'        => current_time( 'mysql', true ),
		] );

		if ( false === $result ) {
			return false;
		}

		return (int) $wpdb->insert_id;
	}

	public function get_by_id( int $id ): ?object {
		global $wpdb;

		return $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM %i WHERE id = %d',
			$this->table,
			$id
		) );
	}

	public function get_by_thread_id( string $thread_id ): ?object {
		global $wpdb;

		return $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM %i WHERE thread_id = %s',
			$this->table,
			$thread_id
		) );
	}

	public function update( int $id, array $data ): bool {
		global $wpdb;

		$allowed = [
			'subject', 'status', 'urgency', 'inbox_id', 'customer_id', 'assigned_to',
			'ai_classification', 'last_activity_at',
			'first_responded_at', 'closed_at', 'automation_handled', 'trashed_at',
		];
		$update  = [];

		foreach ( $allowed as $field ) {
			if ( array_key_exists( $field, $data ) ) {
				$update[ $field ] = $data[ $field ];
			}
		}

		if ( empty( $update ) ) {
			return false;
		}

		// trashed_at follows the status: stamped on the way into Trash, cleared
		// on the way out. The daily purge (Services\TrashPurge) deletes what
		// has sat there longer than the retention period.
		if ( isset( $update['status'] ) && ! array_key_exists( 'trashed_at', $update ) ) {
			$update['trashed_at'] = 'trash' === $update['status'] ? current_time( 'mysql', true ) : null;
		}

		// Stamp closed_at the first time status transitions to "closed".
		if ( isset( $update['status'] ) && 'closed' === $update['status']
			&& ! array_key_exists( 'closed_at', $update )
		) {
			$current = $this->get_by_id( $id );
			if ( $current && empty( $current->closed_at ) ) {
				$update['closed_at'] = current_time( 'mysql', true );
				do_action( 'bridle_conversation_closed', $id );
			}
		}

		$update['updated_at'] = current_time( 'mysql', true );

		return (bool) $wpdb->update( $this->table, $update, [ 'id' => $id ] );
	}

	/**
	 * The WHERE clause and its values for a list query: box or status, inbox,
	 * assignee, customer, sender, draft, search. Shared by list() and ids(), so
	 * "select all" acts on exactly what the list shows.
	 *
	 * @return array{0: string, 1: array} [ "WHERE …", values ]
	 */
	private function filters( array $args ): array {
		global $wpdb;

		// "1 = %d" keeps at least one placeholder in every query, so both the
		// list and the count always go through prepare().
		$where  = [ '1 = %d' ];
		$values = [ 1 ];

		$box = self::box_sql( (string) ( $args['box'] ?? '' ) );

		if ( $box ) {
			$where[] = $box;
		} elseif ( ! empty( $args['status'] ) && 'allmail' === $args['status'] ) {
			// "All mail" (Gmail-style): everything except spam + trash, i.e. the
			// inbox plus the archive.
			$where[]  = 'c.status NOT IN (%s, %s)';
			$values[] = 'spam';
			$values[] = 'trash';
		} elseif ( ! empty( $args['status'] ) ) {
			$where[]  = 'c.status = %s';
			$values[] = sanitize_text_field( $args['status'] );
		} else {
			// Default: show only active/pending conversations. Closed, spam, and
			// trash are only shown when explicitly requested via status filter.
			$where[]  = 'c.status NOT IN (%s, %s, %s)';
			$values[] = 'closed';
			$values[] = 'spam';
			$values[] = 'trash';
		}

		if ( ! empty( $args['inbox_id'] ) ) {
			$where[]  = 'c.inbox_id = %d';
			$values[] = absint( $args['inbox_id'] );
		}

		if ( ! empty( $args['assigned_to'] ) ) {
			if ( 'none' === $args['assigned_to'] ) {
				$where[] = 'c.assigned_to IS NULL';
			} else {
				$where[]  = 'c.assigned_to = %d';
				$values[] = absint( $args['assigned_to'] );
			}
		}

		if ( ! empty( $args['customer_id'] ) ) {
			$where[]  = 'c.customer_id = %d';
			$values[] = absint( $args['customer_id'] );
		}

		if ( ! empty( $args['sent_by'] ) ) {
			$where[]  = "c.id IN ( SELECT DISTINCT conversation_id FROM %i WHERE author_type = 'teammate' AND author_id = %d AND thread_type = 'reply' )";
			$values[] = $wpdb->prefix . 'bridle_threads';
			$values[] = absint( $args['sent_by'] );
		}

		if ( ! empty( $args['has_draft_by'] ) ) {
			$where[]  = 'c.id IN ( SELECT conversation_id FROM %i WHERE user_id = %d )';
			$values[] = $wpdb->prefix . 'bridle_drafts';
			$values[] = absint( $args['has_draft_by'] );
		}

		$threads_table = $wpdb->prefix . 'bridle_threads';

		// Search reaches message bodies, not just what the row shows, so a
		// customer's own words find their conversation.
		if ( ! empty( $args['search'] ) ) {
			$like    = '%' . $wpdb->esc_like( sanitize_text_field( $args['search'] ) ) . '%';
			$where[] = '( c.subject LIKE %s OR cu.name LIKE %s OR cu.email LIKE %s
				OR EXISTS ( SELECT 1 FROM %i ts WHERE ts.conversation_id = c.id AND ts.content LIKE %s ) )';
			array_push( $values, $like, $like, $like, $threads_table, $like );
		}

		// Any of several words, in the subject or a message (the agent's memory
		// looks up how similar questions were answered).
		if ( ! empty( $args['search_terms'] ) && is_array( $args['search_terms'] ) ) {
			$any = [];
			foreach ( array_slice( array_filter( array_map( 'sanitize_text_field', $args['search_terms'] ) ), 0, 8 ) as $term ) {
				$like  = '%' . $wpdb->esc_like( $term ) . '%';
				$any[] = 'c.subject LIKE %s OR EXISTS ( SELECT 1 FROM %i tt WHERE tt.conversation_id = c.id AND tt.is_private = 0 AND tt.content LIKE %s )';
				array_push( $values, $like, $threads_table, $like );
			}
			if ( $any ) {
				$where[] = '( ' . implode( ' OR ', $any ) . ' )';
			}
		}

		if ( ! empty( $args['closed_since'] ) ) {
			$where[]  = 'c.closed_at >= %s';
			$values[] = sanitize_text_field( $args['closed_since'] );
		}

		if ( ! empty( $args['exclude_id'] ) ) {
			$where[]  = 'c.id <> %d';
			$values[] = absint( $args['exclude_id'] );
		}

		return [ 'WHERE ' . implode( ' AND ', $where ), $values ];
	}

	/**
	 * Every id a list query matches, newest activity first, without the row
	 * data: what "select all N conversations" acts on. Capped at `$limit`.
	 *
	 * @return array{ids: int[], total: int}
	 */
	public function ids( array $args = [], int $limit = self::IDS_LIMIT ): array {
		global $wpdb;

		[ $where_sql, $values ] = $this->filters( $args );
		$joins                  = self::box_joins();
		$limit                  = min( self::IDS_LIMIT, max( 1, $limit ) );
		$tables                 = array_merge( [ $this->table ], self::box_join_tables() );

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- $joins and $where_sql hold only constants and placeholders (box_joins(), filters()); every table and value is bound.
		$ids   = $wpdb->get_col( $wpdb->prepare( "SELECT c.id FROM %i c {$joins} {$where_sql} ORDER BY c.last_activity_at DESC LIMIT %d", array_merge( $tables, $values, [ $limit ] ) ) );
		$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i c {$joins} {$where_sql}", array_merge( $tables, $values ) ) );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber

		return [
			'ids'   => array_map( 'intval', (array) $ids ),
			'total' => $total,
		];
	}

	public function list( array $args = [] ): array {
		global $wpdb;

		[ $where_sql, $values ] = $this->filters( $args );

		$threads_table = $wpdb->prefix . 'bridle_threads';
		$per_page      = min( 100, max( 1, absint( $args['per_page'] ?? 20 ) ) );
		$page          = max( 1, absint( $args['page'] ?? 1 ) );
		$offset        = ( $page - 1 ) * $per_page;

		// Read/unread for one teammate (`reader_id`): their row in reads and
		// the customer's newest message, compared below (Read::is_unread()).
		$reader      = absint( $args['reader_id'] ?? 0 );
		$read_select = '';
		$read_join   = '';
		$drafts      = $wpdb->prefix . 'bridle_drafts';
		$agent       = (int) \Bridle\Services\AgentService::USER_ID;
		$select_args = [ $drafts, $agent, $drafts, $agent ];
		$join_args   = [ $wpdb->prefix . 'bridle_inboxes' ];
		if ( $reader ) {
			$read_select   = ", rd.read_at AS read_at,
				( SELECT MAX( tc.created_at ) FROM %i tc WHERE tc.conversation_id = c.id AND tc.author_type = 'customer' ) AS last_customer_at";
			$read_join     = 'LEFT JOIN %i rd ON rd.conversation_id = c.id AND rd.user_id = %d';
			$select_args[] = $threads_table;
			array_push( $join_args, $wpdb->prefix . 'bridle_reads', $reader );
		}

		// The newest public thread (notes excluded) supplies both who spoke
		// last — "needs reply" when it was the customer — and the row snippet.
		// Every fragment holds only constants and placeholders; the tables and
		// values are bound in the order they appear.
		$joins = self::box_joins();
		$sql   = "SELECT c.*, cu.name AS customer_name, cu.email AS customer_email, ib.display_name AS inbox_name,
				lt.author_type AS last_author_type, lt.id AS last_thread_id, LEFT( lt.content, 400 ) AS last_message_preview,
				( SELECT ad.meta FROM %i ad WHERE ad.conversation_id = c.id AND ad.user_id = %d LIMIT 1 ) AS agent_draft_meta,
				( SELECT LEFT( ac.content, 600 ) FROM %i ac WHERE ac.conversation_id = c.id AND ac.user_id = %d LIMIT 1 ) AS agent_draft_content
				{$read_select}
			FROM %i c
			{$joins}
			LEFT JOIN %i ib ON c.inbox_id = ib.id
			{$read_join}
			{$where_sql}
			ORDER BY c.last_activity_at DESC
			LIMIT %d OFFSET %d";
		$sql_args = array_merge(
			$select_args,
			[ $this->table ],
			self::box_join_tables(),
			$join_args,
			$values,
			[ $per_page, $offset ]
		);

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- see above: placeholders only.
		$items = $wpdb->get_results( $wpdb->prepare( $sql, $sql_args ) ) ?: [];

		$unread_since = $reader ? (string) get_option( 'bridle_unread_since', '' ) : '';
		foreach ( $items as $item ) {
			$item->last_message_preview = self::preview_text( $item->last_message_preview );
			if ( $reader ) {
				$item->unread = Read::is_unread( $item->last_customer_at, $item->read_at, $unread_since );
				unset( $item->read_at, $item->last_customer_at );
			}
			// The agent's draft, if any: 'ready' or 'failed' (drafts.meta.status), so a
			// row can show the AI-draft chip without another request.
			$meta              = ! empty( $item->agent_draft_meta ) ? json_decode( $item->agent_draft_meta, true ) : null;
			$item->agent_draft = is_array( $meta ) && ! empty( $meta['status'] ) ? (string) $meta['status'] : null;
			// A draft the agent will send by itself shows as "sending", with when.
			$item->agent_send_at = null;
			if ( 'ready' === $item->agent_draft && 'scheduled' === ( $meta['auto']['state'] ?? '' ) ) {
				$item->agent_draft   = 'scheduled';
				$item->agent_send_at = (string) $meta['auto']['send_at'];
			}
			// What the Inbox groups on (#108): ready to send, sending, or a
			// person should look and why; plus the draft's opening words.
			$review              = \Bridle\Services\AutoSend::review( is_array( $meta ) ? $meta : null, (int) ( $item->last_thread_id ?? 0 ) );
			$item->agent_review  = $review['state'];
			$item->agent_reason  = $review['reason'];
			$item->agent_preview = in_array( $review['state'], [ 'ready', 'sending' ], true )
				? self::preview_text( (string) ( $item->agent_draft_content ?? '' ) )
				: '';
			unset( $item->agent_draft_meta, $item->agent_draft_content, $item->last_thread_id );
		}

		// Total count, with the same joins: search and box filters use them.
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery -- constant joins and placeholders; every table and value is bound.
		$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i c {$joins} {$where_sql}", array_merge( [ $this->table ], self::box_join_tables(), $values ) ) );

		return [
			'items'    => $items,
			'total'    => $total,
			'page'     => $page,
			'per_page' => $per_page,
		];
	}

	/**
	 * Joins every box query needs: the customer (`cu`, for the Feed
	 * override) and the newest public thread (`lt`, for who spoke last).
	 * The tables are `%i` placeholders; bind box_join_tables() in their place.
	 */
	public static function box_joins(): string {
		return 'LEFT JOIN %i cu ON c.customer_id = cu.id
			LEFT JOIN %i lt ON lt.id = (
				SELECT MAX( t.id ) FROM %i t
				WHERE t.conversation_id = c.id AND t.is_private = 0
			)';
	}

	/**
	 * The tables for box_joins()' placeholders, in order.
	 *
	 * @return string[]
	 */
	public static function box_join_tables(): array {
		global $wpdb;
		return [ $wpdb->prefix . 'bridle_customers', $wpdb->prefix . 'bridle_threads', $wpdb->prefix . 'bridle_threads' ];
	}

	/**
	 * Where an active conversation files: 'feed' (Updates) or 'inbox'. The
	 * PHP twin of FEED_SQL for one row: the sender's override wins, then the
	 * per-message flag.
	 *
	 * @param string|null     $override     customers.box_override: 'feed', 'inbox' or null.
	 * @param int|string|bool $is_automated conversations.is_automated.
	 */
	public static function files_to( ?string $override, $is_automated ): string {
		if ( 'feed' === $override || 'inbox' === $override ) {
			return $override;
		}
		return 1 === (int) $is_automated ? 'feed' : 'inbox';
	}

	/**
	 * SQL condition for one box, against the aliases from box_joins(). Only
	 * constants go into it, so it needs no escaping. Null for an unknown box.
	 */
	public static function box_sql( string $box ): ?string {
		$feed  = self::FEED_SQL;
		$inbox = "c.status = 'active' AND NOT ( {$feed} )";

		switch ( $box ) {
			case 'inbox':
				return $inbox;
			case 'needs_reply':
				return "{$inbox} AND lt.author_type = 'customer'";
			case 'waiting':
				return "{$inbox} AND ( lt.author_type IS NULL OR lt.author_type <> 'customer' )";
			case 'feed':
				return "c.status = 'active' AND {$feed}";
			case 'closed':
			case 'spam':
			case 'trash':
				return "c.status = '{$box}'";
			default:
				return null;
		}
	}

	/**
	 * The fields a client may change through PATCH, validated. Anything
	 * else in the payload (timestamps, ai_classification, …) is dropped.
	 *
	 * @return array{0: array<string, mixed>, 1: string[]} Clean fields, and
	 *         the names of fields that were sent with an invalid value.
	 */
	public static function editable_fields( array $params ): array {
		$fields  = [];
		$invalid = [];

		if ( array_key_exists( 'subject', $params ) ) {
			$subject = sanitize_text_field( (string) $params['subject'] );
			if ( '' === $subject ) {
				$invalid[] = 'subject';
			} else {
				$fields['subject'] = $subject;
			}
		}

		foreach ( [ 'status' => self::STATUSES, 'urgency' => self::URGENCIES ] as $key => $choices ) {
			if ( ! array_key_exists( $key, $params ) ) {
				continue;
			}
			if ( in_array( $params[ $key ], $choices, true ) ) {
				$fields[ $key ] = $params[ $key ];
			} else {
				$invalid[] = $key;
			}
		}

		if ( array_key_exists( 'assigned_to', $params ) ) {
			$fields['assigned_to'] = empty( $params['assigned_to'] ) ? null : absint( $params['assigned_to'] );
		}

		if ( array_key_exists( 'inbox_id', $params ) ) {
			$inbox_id = absint( $params['inbox_id'] );
			if ( $inbox_id ) {
				$fields['inbox_id'] = $inbox_id;
			} else {
				$invalid[] = 'inbox_id';
			}
		}

		return [ $fields, $invalid ];
	}

	/**
	 * One line of plain text for a list row: tags stripped, entities decoded,
	 * whitespace collapsed, capped at 240 characters.
	 */
	public static function preview_text( ?string $content ): string {
		$text = html_entity_decode( wp_strip_all_tags( (string) $content ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$text = trim( (string) preg_replace( '/\s+/u', ' ', $text ) );

		return mb_strlen( $text ) > 240 ? rtrim( mb_substr( $text, 0, 239 ) ) . '…' : $text;
	}

	/**
	 * The Feed, one row per sender: how many conversations, the newest
	 * subject and when. Newest sender first.
	 *
	 * @return array{items: object[], total: int}
	 */
	public function feed_senders( array $args = [] ): array {
		global $wpdb;

		$joins    = self::box_joins();
		$where    = self::box_sql( 'feed' );
		$values   = [];
		$per_page = min( 100, max( 1, absint( $args['per_page'] ?? 50 ) ) );
		$page     = max( 1, absint( $args['page'] ?? 1 ) );

		if ( ! empty( $args['inbox_id'] ) ) {
			$where   .= ' AND c.inbox_id = %d';
			$values[] = absint( $args['inbox_id'] );
		}

		$tables = array_merge( [ $this->table ], self::box_join_tables() );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter -- $joins and $where hold only constants and placeholders; every table and value is bound.
		$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT( DISTINCT c.customer_id ) FROM %i c {$joins} WHERE {$where}", array_merge( $tables, $values ) ) );

		// The newest subject per sender comes from a correlated subquery, not
		// GROUP_CONCAT … SEPARATOR, which SQLite-backed installs can't parse.
		$sql = "SELECT cu.id AS customer_id, cu.name, cu.email, cu.box_override,
				COUNT(*) AS conversations,
				MAX( c.last_activity_at ) AS last_activity_at,
				( SELECT c2.subject FROM %i c2
					WHERE c2.id IN ( SELECT MAX( c3.id ) FROM %i c3 WHERE c3.customer_id = cu.id AND c3.status = 'active' ) ) AS latest_subject
			FROM %i c {$joins}
			WHERE {$where}
			GROUP BY cu.id, cu.name, cu.email, cu.box_override
			ORDER BY last_activity_at DESC
			LIMIT %d OFFSET %d";

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- as above.
		$items = $wpdb->get_results( $wpdb->prepare( $sql, array_merge( [ $this->table, $this->table ], $tables, $values, [ $per_page, ( $page - 1 ) * $per_page ] ) ) );

		return [
			'items' => is_array( $items ) ? $items : [],
			'total' => $total,
		];
	}

	public function delete( int $id ): bool {
		global $wpdb;

		return (bool) $wpdb->delete( $this->table, [ 'id' => $id ] );
	}

	/**
	 * Permanently delete conversations and everything hanging off them:
	 * attachments (rows, and the media Bridle stored for them), threads,
	 * drafts, ratings and read marks.
	 *
	 * @param int[] $ids Conversation IDs.
	 * @return int Conversations deleted.
	 */
	public function hard_delete( array $ids ): int {
		global $wpdb;

		$ids = array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
		if ( empty( $ids ) ) {
			return 0;
		}

		$thread_table = $wpdb->prefix . 'bridle_threads';
		$att_table    = $wpdb->prefix . 'bridle_attachments';
		$draft_table  = $wpdb->prefix . 'bridle_drafts';
		$rating_table = $wpdb->prefix . 'bridle_ratings';
		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- %d placeholder lists only.
		$thread_ids = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT id FROM %i WHERE conversation_id IN ({$placeholders})", array_merge( [ $thread_table ], $ids ) ) ) );

		if ( ! empty( $thread_ids ) ) {
			$t_ph      = implode( ',', array_fill( 0, count( $thread_ids ), '%d' ) );
			$media_ids = (array) $wpdb->get_col( $wpdb->prepare( "SELECT wp_attachment_id FROM %i WHERE thread_id IN ({$t_ph}) AND wp_attachment_id IS NOT NULL", array_merge( [ $att_table ], $thread_ids ) ) );
			$wpdb->query( $wpdb->prepare( "DELETE FROM %i WHERE thread_id IN ({$t_ph})", array_merge( [ $att_table ], $thread_ids ) ) );
			( new Attachment() )->delete_media( $media_ids );
		}

		$wpdb->query( $wpdb->prepare( "DELETE FROM %i WHERE conversation_id IN ({$placeholders})", array_merge( [ $thread_table ], $ids ) ) );
		$wpdb->query( $wpdb->prepare( "DELETE FROM %i WHERE conversation_id IN ({$placeholders})", array_merge( [ $draft_table ], $ids ) ) );
		$wpdb->query( $wpdb->prepare( "DELETE FROM %i WHERE conversation_id IN ({$placeholders})", array_merge( [ $rating_table ], $ids ) ) );
		( new Read() )->delete_for_conversations( $ids );
		$deleted = $wpdb->query( $wpdb->prepare( "DELETE FROM %i WHERE id IN ({$placeholders})", array_merge( [ $this->table ], $ids ) ) );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare

		return (int) $deleted;
	}

	/**
	 * Permanently delete every conversation a customer has had.
	 *
	 * @return int Conversations deleted.
	 */
	public function hard_delete_for_customer( int $customer_id ): int {
		global $wpdb;

		$ids = $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM %i WHERE customer_id = %d', $this->table, $customer_id ) );

		return $this->hard_delete( (array) $ids );
	}

	public function get_with_threads( int $id ): ?object {
		$conversation = $this->get_by_id( $id );

		if ( ! $conversation ) {
			return null;
		}

		$thread_model            = new Thread();
		$conversation->threads   = $thread_model->get_by_conversation( $id );
		$conversation->customer  = ( new Customer() )->get_by_id( $conversation->customer_id );

		// Flat customer fields for parity with the list query (the detail
		// header + composer read these). get_by_id() returns only the raw
		// conversation row, which has no joined customer columns.
		$conversation->customer_name   = $conversation->customer->name ?? null;
		$conversation->customer_email  = $conversation->customer->email ?? null;
		$conversation->customer_avatar = \Bridle\Services\Avatars::url( $conversation->customer_email ?? '', 96 );

		// Which box an active conversation sits in, so the detail view can say
		// "filed in Updates" and send Back to the right place.
		$conversation->box = 'active' === $conversation->status
			? self::files_to( $conversation->customer->box_override ?? null, $conversation->is_automated ?? 0 )
			: null;

		// Hydrate attachments per thread.
		if ( ! empty( $conversation->threads ) ) {
			$thread_ids = array_map( fn( $t ) => (int) $t->id, $conversation->threads );
			$atts_raw   = ( new Attachment() )->get_by_thread_ids( $thread_ids );
			$by_thread  = [];
			foreach ( $atts_raw as $att ) {
				$by_thread[ (int) $att->thread_id ][] = [
					'id'         => (int) $att->id,
					'filename'   => $att->filename,
					'mime_type'  => $att->mime_type,
					'size_bytes' => (int) $att->size_bytes,
					'is_inline'  => (bool) $att->is_inline,
					'url'        => Attachment::url_for( (int) $att->wp_attachment_id ),
				];
			}
			foreach ( $conversation->threads as $t ) {
				$t->attachments = $by_thread[ (int) $t->id ] ?? [];
			}
		}

		// Enrich threads with author name + email for teammates.
		$user_cache = [];
		foreach ( $conversation->threads as $thread ) {
			if ( 'teammate' === $thread->author_type && $thread->author_id ) {
				$uid = (int) $thread->author_id;
				if ( ! isset( $user_cache[ $uid ] ) ) {
					$user = get_userdata( $uid );
					$user_cache[ $uid ] = [
						'name'   => $user ? $user->display_name : __( 'Teammate', 'bridle' ),
						'email'  => $user ? $user->user_email : '',
						'avatar' => $user ? \Bridle\Services\Avatars::url( $user->ID, 64 ) : '',
					];
				}
				$thread->author_name   = $user_cache[ $uid ]['name'];
				$thread->author_email  = $user_cache[ $uid ]['email'];
				$thread->author_avatar = $user_cache[ $uid ]['avatar'];
			} elseif ( 'agent' === $thread->author_type ) {
				// Bridle's own agent, or an external one (Claude via MCP…): who, and whether it sent by itself.
				$sources       = json_decode( (string) ( $thread->ai_sources ?? '' ), true );
				$sources       = is_array( $sources ) ? $sources : [];
				$thread->agent = [
					'sent_by' => (string) ( $sources['sent_by'] ?? 'agent' ),
					'client'  => (string) ( $sources['client'] ?? '' ),
					'via'     => (string) ( $sources['via'] ?? '' ),
					'auto'    => ! empty( $sources['auto'] ),
				];

				$agent_name           = trim( (string) \Bridle\Services\Settings::get( 'agent_name', '' ) );
				$thread->author_name  = '' !== $thread->agent['client'] ? $thread->agent['client'] : ( '' !== $agent_name ? $agent_name : 'Bridle' );
				$thread->author_email = '';
			} else {
				// Customer (or system) thread — reuse the customer's gravatar
				// (+ email, so the client's initials colour seed matches).
				$thread->author_avatar = $conversation->customer_avatar ?? '';
				$thread->author_email  = $conversation->customer_email ?? '';
			}
		}

		// Customer's other conversations (for contact history).
		if ( $conversation->customer_id ) {
			global $wpdb;
			$joins = self::box_joins();
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- $joins is constant placeholders (box_joins()).
			$conversation->customer_conversations = $wpdb->get_results( $wpdb->prepare(
				"SELECT c.id, c.thread_id, c.subject, c.status, c.created_at,
					c.first_responded_at, lt.author_type AS last_author_type
				FROM %i c {$joins}
				WHERE c.customer_id = %d AND c.id != %d
				ORDER BY c.created_at DESC
				LIMIT 10",
				array_merge( [ $this->table ], self::box_join_tables(), [ $conversation->customer_id, $id ] )
			) ) ?: [];
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
		}

		return $conversation;
	}

	public function generate_thread_id( ?string $prefix = null ): string {
		// Two letters or digits, so the [#XX-XXXXXX] subject tag always matches
		// (an inbox named "a" has the hash "a-1f2e", which gave "A-").
		$prefix = strtoupper( (string) preg_replace( '/[^a-z0-9]/i', '', (string) $prefix ) );
		$prefix = '' !== $prefix ? str_pad( substr( $prefix, 0, 2 ), 2, 'X' ) : 'BR';
		$hash   = strtoupper( substr( bin2hex( random_bytes( 3 ) ), 0, 6 ) );

		return $prefix . '-' . $hash;
	}
}
