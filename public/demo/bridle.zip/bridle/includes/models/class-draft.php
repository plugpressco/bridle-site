<?php

namespace Bridle\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Per-user draft reply for a conversation.
 * Unique on (conversation_id, user_id) so every teammate has their own draft.
 * The agent's draft is the row with user_id 0; its details live in `meta`
 * (see AgentService).
 */
class Draft {

	private string $table;

	public function __construct() {
		global $wpdb;
		$this->table = $wpdb->prefix . 'bridle_drafts';
	}

	public function get( int $conversation_id, int $user_id ): ?object {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM %i WHERE conversation_id = %d AND user_id = %d',
			$this->table,
			$conversation_id,
			$user_id
		) );
	}

	public function upsert( int $conversation_id, int $user_id, string $content, string $thread_type = 'reply', ?string $meta = null ): bool {
		global $wpdb;

		$now = current_time( 'mysql', true );

		$result = $wpdb->query( $wpdb->prepare(
			'INSERT INTO %i (conversation_id, user_id, content, thread_type, meta, updated_at)
			VALUES (%d, %d, %s, %s, %s, %s)
			ON DUPLICATE KEY UPDATE
				content = VALUES(content),
				thread_type = VALUES(thread_type),
				meta = VALUES(meta),
				updated_at = VALUES(updated_at)',
			$this->table,
			$conversation_id,
			$user_id,
			$content,
			$thread_type,
			$meta,
			$now
		) );

		return false !== $result;
	}

	/**
	 * Replace a draft's meta only if it still is $expected: a compare-and-swap
	 * that lets exactly one job claim a scheduled send, even on databases
	 * without GET_LOCK (SQLite).
	 *
	 * @return bool True when this call made the change.
	 */
	public function swap_meta( int $conversation_id, int $user_id, string $expected, string $next ): bool {
		global $wpdb;

		$changed = $wpdb->query(
			$wpdb->prepare(
				'UPDATE %i SET meta = %s, updated_at = %s WHERE conversation_id = %d AND user_id = %d AND meta = %s',
				$this->table,
				$next,
				current_time( 'mysql', true ),
				$conversation_id,
				$user_id,
				$expected
			)
		);

		return 1 === (int) $changed;
	}

	public function delete( int $conversation_id, int $user_id ): void {
		global $wpdb;
		$wpdb->delete( $this->table, [
			'conversation_id' => $conversation_id,
			'user_id'         => $user_id,
		] );
	}

	public function list_for_user( int $user_id ): array {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare(
			'SELECT * FROM %i WHERE user_id = %d ORDER BY updated_at DESC',
			$this->table,
			$user_id
		) );
		return $rows ?: [];
	}
}
