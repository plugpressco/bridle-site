<?php

namespace Bridle\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Customer {

	private string $table;

	public function __construct() {
		global $wpdb;
		$this->table = $wpdb->prefix . 'bridle_customers';
	}

	public function create( array $data ) {
		global $wpdb;

		$result = $wpdb->insert( $this->table, [
			'email'               => sanitize_email( $data['email'] ),
			'name'                => isset( $data['name'] ) ? sanitize_text_field( $data['name'] ) : null,
			'wp_user_id'          => isset( $data['wp_user_id'] ) ? absint( $data['wp_user_id'] ) : null,
			'total_conversations' => 0,
			'created_at'          => current_time( 'mysql', true ),
			'updated_at'          => current_time( 'mysql', true ),
		] );

		if ( false === $result ) {
			return false;
		}

		return (int) $wpdb->insert_id;
	}

	public function get_by_id( int $id ): ?object {
		global $wpdb;

		return $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM %i WHERE id = %d',
			$this->table,
			$id
		) );
	}

	public function find_by_email( string $email ): ?object {
		global $wpdb;

		return $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM %i WHERE email = %s',
			$this->table,
			sanitize_email( $email )
		) );
	}

	public function update( int $id, array $data ): bool {
		global $wpdb;

		$allowed = [ 'email', 'name', 'wp_user_id', 'total_conversations', 'box_override' ];
		$update  = [];

		foreach ( $allowed as $field ) {
			if ( array_key_exists( $field, $data ) ) {
				$update[ $field ] = $data[ $field ];
			}
		}

		if ( empty( $update ) ) {
			return false;
		}

		$update['updated_at'] = current_time( 'mysql', true );

		return (bool) $wpdb->update( $this->table, $update, [ 'id' => $id ] );
	}

	public function increment_conversations( int $id ): void {
		global $wpdb;

		$wpdb->query( $wpdb->prepare(
			'UPDATE %i SET total_conversations = total_conversations + 1, updated_at = %s WHERE id = %d',
			$this->table,
			current_time( 'mysql', true ),
			$id
		) );
	}

	public function merge( int $target_id, int $source_id ): bool {
		global $wpdb;

		$target = $this->get_by_id( $target_id );
		$source = $this->get_by_id( $source_id );

		if ( ! $target || ! $source || $target_id === $source_id ) {
			return false;
		}

		$conv_table = $wpdb->prefix . 'bridle_conversations';

		// Move all conversations from source to target.
		$wpdb->update(
			$conv_table,
			[ 'customer_id' => $target_id ],
			[ 'customer_id' => $source_id ]
		);

		// Update conversation count on target.
		$count = (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(*) FROM %i WHERE customer_id = %d',
			$conv_table,
			$target_id
		) );

		$merged = [
			'total_conversations' => $count,
			'updated_at'          => current_time( 'mysql', true ),
		];
		// Keep the source's "always Feed / always Inbox" if the target has none.
		if ( empty( $target->box_override ) && ! empty( $source->box_override ) ) {
			$merged['box_override'] = $source->box_override;
		}

		$wpdb->update( $this->table, $merged, [ 'id' => $target_id ] );

		// Delete source customer.
		$wpdb->delete( $this->table, [ 'id' => $source_id ] );

		return true;
	}

	public function delete( int $id ): bool {
		global $wpdb;
		return (bool) $wpdb->delete( $this->table, [ 'id' => $id ] );
	}

	public function list( array $args = [] ): array {
		global $wpdb;

		// "1 = %d" keeps a placeholder in every query, so list and count always use prepare().
		$where  = [ '1 = %d' ];
		$values = [ 1 ];

		if ( ! empty( $args['search'] ) ) {
			$like     = '%' . $wpdb->esc_like( sanitize_text_field( $args['search'] ) ) . '%';
			$where[]  = '(email LIKE %s OR name LIKE %s)';
			$values[] = $like;
			$values[] = $like;
		}

		$where_sql = ! empty( $where ) ? 'WHERE ' . implode( ' AND ', $where ) : '';
		$per_page  = min( 100, max( 1, absint( $args['per_page'] ?? 20 ) ) );
		$page      = max( 1, absint( $args['page'] ?? 1 ) );
		$offset    = ( $page - 1 ) * $per_page;

		// $where_sql holds only constants and placeholders; the table and every value are bound.
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
		$items = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM %i {$where_sql} ORDER BY created_at DESC LIMIT %d OFFSET %d", array_merge( [ $this->table ], $values, [ $per_page, $offset ] ) ) );
		$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i {$where_sql}", array_merge( [ $this->table ], $values ) ) );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber

		return [
			'items'    => $items ?: [],
			'total'    => $total,
			'page'     => $page,
			'per_page' => $per_page,
		];
	}
}
