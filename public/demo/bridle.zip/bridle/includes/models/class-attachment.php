<?php

namespace Bridle\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Attachment {

	/**
	 * Post meta on media Bridle created itself (inbound mail, composer
	 * uploads). Media picked from the library belongs to the site and is
	 * never deleted with a conversation.
	 */
	const OWNED_META = '_bridle_attachment';

	private string $table;

	public function __construct() {
		global $wpdb;
		$this->table = $wpdb->prefix . 'bridle_attachments';
	}

	public function create( array $data ): int|false {
		global $wpdb;

		$result = $wpdb->insert( $this->table, [
			'thread_id'        => absint( $data['thread_id'] ),
			'wp_attachment_id' => isset( $data['wp_attachment_id'] ) ? absint( $data['wp_attachment_id'] ) : null,
			'filename'         => sanitize_file_name( $data['filename'] ),
			'mime_type'        => sanitize_text_field( $data['mime_type'] ),
			'size_bytes'       => absint( $data['size_bytes'] ?? 0 ),
			'is_inline'        => ! empty( $data['is_inline'] ) ? 1 : 0,
			'content_id'       => isset( $data['content_id'] ) ? sanitize_text_field( $data['content_id'] ) : null,
			'created_at'       => current_time( 'mysql', true ),
		] );

		if ( false === $result ) {
			return false;
		}

		return (int) $wpdb->insert_id;
	}

	public function get_by_thread( int $thread_id ): array {
		global $wpdb;

		$rows = $wpdb->get_results( $wpdb->prepare(
			'SELECT * FROM %i WHERE thread_id = %d ORDER BY id ASC',
			$this->table,
			$thread_id
		) );

		return $rows ?: [];
	}

	public function get_by_thread_ids( array $thread_ids ): array {
		global $wpdb;

		if ( empty( $thread_ids ) ) {
			return [];
		}

		$ids         = array_map( 'absint', $thread_ids );
		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- a list of %d placeholders.
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM %i WHERE thread_id IN ({$placeholders}) ORDER BY thread_id, id ASC",
			array_merge( [ $this->table ], $ids )
		) ) ?: [];
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
	}

	public function delete_by_thread( int $thread_id ): void {
		global $wpdb;
		$wpdb->delete( $this->table, [ 'thread_id' => $thread_id ] );
	}

	/**
	 * Look up an orphan row by id. Used by the link-on-send flow so the
	 * threads controller can verify the row is still unclaimed before
	 * adopting it.
	 */
	public function get_orphan( int $id ): ?object {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM %i WHERE id = %d AND thread_id = 0',
			$this->table,
			$id
		) );
	}

	/**
	 * Adopt orphan attachment rows by stamping a real thread_id onto them.
	 * Returns the number of rows actually claimed (in case some were
	 * already linked, deleted, or never belonged to this user).
	 */
	public function link_to_thread( array $ids, int $thread_id ): int {
		global $wpdb;
		if ( empty( $ids ) || ! $thread_id ) {
			return 0;
		}
		$ids = array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
		if ( empty( $ids ) ) {
			return 0;
		}
		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- a list of %d placeholders.
		return (int) $wpdb->query( $wpdb->prepare(
			"UPDATE %i SET thread_id = %d WHERE thread_id = 0 AND id IN ({$placeholders})",
			array_merge( [ $this->table, $thread_id ], $ids )
		) );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
	}

	/**
	 * Delete orphan rows older than the given timestamp and return the
	 * deleted rows so the caller can also unlink the underlying WP
	 * attachment posts. Used by the daily cron sweep.
	 *
	 * @param string $cutoff_mysql A MySQL datetime string in UTC.
	 * @return object[] Rows that were deleted (id, wp_attachment_id).
	 */
	public function purge_orphans_older_than( string $cutoff_mysql ): array {
		global $wpdb;

		$rows = $wpdb->get_results( $wpdb->prepare(
			'SELECT id, wp_attachment_id FROM %i WHERE thread_id = 0 AND created_at < %s',
			$this->table,
			$cutoff_mysql
		) ) ?: [];

		if ( empty( $rows ) ) {
			return [];
		}

		$ids          = array_map( fn( $r ) => (int) $r->id, $rows );
		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- a list of %d placeholders.
		$wpdb->query( $wpdb->prepare(
			"DELETE FROM %i WHERE id IN ({$placeholders})",
			array_merge( [ $this->table ], $ids )
		) );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare

		return $rows;
	}

	/**
	 * Delete the media items behind attachment rows that are already gone:
	 * only those Bridle created, and only when no remaining row still
	 * points at them (a received file can be attached to a later reply).
	 *
	 * @param int[] $wp_attachment_ids Media IDs the deleted rows pointed at.
	 * @return int Media items deleted.
	 */
	public function delete_media( array $wp_attachment_ids ): int {
		global $wpdb;

		$ids = array_values( array_unique( array_filter( array_map( 'absint', $wp_attachment_ids ) ) ) );
		if ( empty( $ids ) || ! function_exists( 'wp_delete_attachment' ) ) {
			return 0;
		}

		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- a %d placeholder list.
		$still_used = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT wp_attachment_id FROM %i WHERE wp_attachment_id IN ({$placeholders})", array_merge( [ $this->table ], $ids ) ) ) );

		$deleted = 0;
		foreach ( array_diff( $ids, $still_used ) as $id ) {
			if ( get_post_meta( $id, self::OWNED_META, true ) && wp_delete_attachment( $id, true ) ) {
				++$deleted;
			}
		}

		return $deleted;
	}

	/**
	 * Return public URL for an attachment via its wp_attachment_id.
	 */
	public static function url_for( ?int $wp_attachment_id ): string {
		if ( ! $wp_attachment_id ) {
			return '';
		}
		$url = wp_get_attachment_url( $wp_attachment_id );
		return $url ?: '';
	}
}
