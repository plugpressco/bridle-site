<?php

namespace Bridle\RestApi;

use Bridle\Models\Attachment;
use Bridle\Models\Conversation;
use Bridle\Models\Customer;
use Bridle\Models\Inbox;
use Bridle\Models\Thread;
use Bridle\Services\AttachmentService;
use Bridle\Services\AutomatedMail;
use Bridle\Services\Classifier;
use Bridle\Services\EmailQuoteStripper;
use Bridle\Services\SenderIdentity;
use WP_Error;
use WP_REST_Controller;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class InboundEmailController extends WP_REST_Controller {

	/** The header the email worker carries the inbox's webhook secret in. */
	const AUTH_HEADER = 'X-Bridle-Auth';

	protected $namespace = BRIDLE_REST_NAMESPACE;
	protected $rest_base = 'inbound-email';

	public function register_routes(): void {
		$args = [
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'handle_inbound' ],
				'permission_callback' => [ $this, 'check_webhook' ],
			],
		];
		register_rest_route( $this->namespace, '/' . $this->rest_base, $args );
	}

	/**
	 * Permission check for the webhook. The caller is the Bridle email relay,
	 * not a logged-in user, so there is no cookie or nonce: each request must
	 * carry the addressed inbox's own webhook secret in X-Bridle-Auth.
	 *
	 * @return true|WP_Error
	 */
	public function check_webhook( $request ) {
		$inbox = self::authorized_inbox( $request );
		return is_wp_error( $inbox ) ? $inbox : true;
	}

	/**
	 * The inbox a webhook request is for, once its secret checks out.
	 *
	 * @return object|WP_Error
	 */
	private static function authorized_inbox( $request ) {
		$params = (array) $request->get_json_params();

		// The inbox hash is the local part of the 'to' address (support-a3f2@bridle.to).
		$inbox_hash = self::inbox_hash_from_address( sanitize_text_field( (string) ( $params['to'] ?? '' ) ) );
		if ( ! $inbox_hash ) {
			return new WP_Error( 'bridle_invalid_recipient', __( 'Invalid recipient address.', 'bridle' ), [ 'status' => 400 ] );
		}

		$inbox = ( new Inbox() )->get_by_hash( $inbox_hash );

		// An unknown inbox gets the same 401 as a wrong secret, so the
		// endpoint can't be used to find out which addresses exist.
		if ( ! $inbox || ! self::is_authorized( $request, $inbox->webhook_secret ) ) {
			return new WP_Error( 'bridle_unauthorized', __( 'Invalid webhook secret.', 'bridle' ), [ 'status' => 401 ] );
		}

		return $inbox;
	}

	public function handle_inbound( $request ) {
		$params = $request->get_json_params();

		// Checked again here, so a direct call is held to the same rule.
		$inbox = self::authorized_inbox( $request );
		if ( is_wp_error( $inbox ) ) {
			return $inbox;
		}

		$inbox_model = new Inbox();
		$inbox_model->update( $inbox->id, [ 'last_received_at' => current_time( 'mysql', true ) ] );

		$from_email = sanitize_email( $params['from'] ?? '' );
		$from_name  = sanitize_text_field( $params['from_name'] ?? '' );

		// Parse the raw header BEFORE sanitizing. sanitize_text_field() runs
		// wp_strip_all_tags(), which eats `<addr@host>` as if it were a tag —
		// running it first destroys both the address and the name.
		$reply_to_raw  = (string) ( $params['reply_to'] ?? '' );
		$reply_to      = sanitize_email( SenderIdentity::address( $reply_to_raw ) );
		$reply_to_name = sanitize_text_field( $params['reply_to_name'] ?? '' );
		if ( '' === $reply_to_name ) {
			// Older workers send only a bare address; recover a name if the raw
			// header happens to carry one.
			$reply_to_name = sanitize_text_field( SenderIdentity::display_name( $reply_to_raw ) );
		}
		$original_from = sanitize_email( SenderIdentity::address( (string) ( $params['x_original_from'] ?? '' ) ) );

		// A malformed Reply-To (e.g. a broken sender fusing "Name" + address into
		// one string) must never override From — replies to it would bounce.
		if ( $reply_to && ! is_email( $reply_to ) ) {
			$reply_to      = '';
			$reply_to_name = '';
		}
		if ( $original_from && ! is_email( $original_from ) ) {
			$original_from = '';
		}
		$subject    = sanitize_text_field( $params['subject'] ?? '' );
		$text       = $params['text'] ?? '';
		$html       = $params['html'] ?? '';

		// Plaintext keeps its quoted history stripped — it feeds list previews
		// and search, where old thread history is pure noise.
		//
		// HTML does NOT. Deleting quotes at ingest destroyed them permanently:
		// a customer who quoted an error message or a prior promise had it
		// removed from the record with no way back. The client folds them
		// behind a toggle instead, which is reversible. See clean_html().
		//
		// Both must run BEFORE wp_kses_post so matching can see raw tags/classes.
		$text = EmailQuoteStripper::strip_text( $text );

		// A stripped copy purely for working out who actually wrote in — the
		// forwarded-`From:` heuristic would happily match a *quoted* header if
		// it could see the history we now keep.
		$identity_body = $text ?: wp_strip_all_tags( EmailQuoteStripper::strip_html( $html ) );

		$html = EmailQuoteStripper::clean_html( $html );

		// Strip dangerous blocks (<script>, onclick, etc.) with a broad email
		// allowlist first; Thread::create() then runs wp_kses_post on save.
		$html = self::strip_noisy_blocks( $html );
		$html = self::sanitize_email_html( $html );

		$text = wp_kses_post( $text );
		$message_id  = Thread::normalize_message_id( (string) ( $params['message_id'] ?? '' ) );
		$in_reply_to = Thread::normalize_message_id( (string) ( $params['in_reply_to'] ?? '' ) );
		$references  = Thread::message_ids( (string) ( $params['references'] ?? '' ) );

		// The same message can arrive twice: a worker retry, or a copy that
		// reached the inbox by two forwarding routes. Also catches our own
		// outgoing replies echoed back. Answer as if stored, store nothing.
		if ( $message_id ) {
			$duplicate = ( new Thread() )->find_by_message_id( $message_id );
			if ( $duplicate ) {
				return new WP_REST_Response( [
					'conversation_id' => (int) $duplicate->conversation_id,
					'thread_id'       => (int) $duplicate->id,
					'is_new'          => false,
					'duplicate'       => true,
				], 200 );
			}
		}

		// Machine-mail signals. They feed routing below, with the classifier's
		// reading when the owner has one, and the auto-reply loop checks.
		// List-Id and List-Unsubscribe are written in angle brackets
		// (`<news.example.com>`), which sanitize_text_field() strips as a tag,
		// leaving nothing. Unwrap them first.
		$unbracket        = static fn( $v ) => sanitize_text_field( str_replace( [ '<', '>' ], ' ', (string) $v ) );
		$incoming_headers = [
			'precedence'               => sanitize_text_field( $params['precedence'] ?? '' ),
			'auto_submitted'           => sanitize_text_field( $params['auto_submitted'] ?? '' ),
			'x_auto_response_suppress' => sanitize_text_field( $params['x_auto_response_suppress'] ?? '' ),
			'x_autoreply'              => sanitize_text_field( $params['x_autoreply'] ?? '' ),
			'x_autorespond'            => sanitize_text_field( $params['x_autorespond'] ?? '' ),
			'list_id'                  => $unbracket( $params['list_id'] ?? '' ),
			'list_unsubscribe'         => $unbracket( $params['list_unsubscribe'] ?? '' ),
			'subject'                  => $subject,
		];

		if ( ! $from_email ) {
			return new WP_Error( 'bridle_missing_from', __( 'From address is required.', 'bridle' ), [ 'status' => 400 ] );
		}
		if ( ! is_email( $from_email ) ) {
			return new WP_Error( 'bridle_invalid_from', __( 'From address is not a valid email.', 'bridle' ), [ 'status' => 400 ] );
		}

		// The owner's decision model reads the email (Services\Classifier):
		// null without a key, or on any error or a slow answer, and routing
		// then goes by the headers alone.
		$classification = Classifier::classify(
			[
				'from'             => $from_email,
				'from_name'        => $from_name,
				'reply_to'         => $reply_to,
				'subject'          => $subject,
				'body'             => $identity_body,
				'list_id'          => $incoming_headers['list_id'],
				'list_unsubscribe' => $incoming_headers['list_unsubscribe'],
				'precedence'       => $incoming_headers['precedence'],
				'auto_submitted'   => $incoming_headers['auto_submitted'],
			]
		);

		// Real sender resolution — determines the actual customer email.
		//
		// Many setups send FROM a server address (wordpress@, noreply@, etc.)
		// with Reply-To set to the real person. Examples:
		//   - Contact Form 7 via WP SMTP: From: wordpress@site.com, Reply-To: customer@gmail.com
		//   - Gmail forwarding: From: support@site.com (inbox's own address)
		//
		// Priority order (matches FreeScout behavior):
		//   1. Reply-To (if present, different from From, and not the inbox itself)
		//   2. The body's own "Name:/Email:" identity block (contact forms)
		//   3. X-Original-From / Resent-From
		//   4. Forwarded body parsing ("From: ..." in body text)
		//   5. Fall back to From
		$resolved = $this->resolve_real_sender( $from_email, $from_name, $reply_to, $reply_to_name, $original_from, $identity_body, '', $inbox );
		if ( $resolved ) {
			$from_email = $resolved['email'];
			if ( $resolved['name'] ) {
				$from_name = $resolved['name'];
			}
		}

		$customer_model = new Customer();
		$customer       = $customer_model->find_by_email( $from_email );

		if ( ! $customer ) {
			$customer_id = $customer_model->create( [
				'email' => $from_email,
				'name'  => $from_name ?: SenderIdentity::name_from_email( $from_email ),
			] );
			$customer = $customer_model->get_by_id( $customer_id );

			/**
			 * Fires after a new customer is created from an inbound email.
			 *
			 * @param int    $customer_id The new customer ID.
			 * @param object $customer    The customer row.
			 */
			do_action( 'bridle_customer_created', (int) $customer_id, $customer );
		} elseif ( $from_name && $from_name !== $customer->name && SenderIdentity::is_placeholder_name( (string) $customer->name, (string) $customer->email ) ) {
			// Upgrade a placeholder name once a real one turns up. Without this a
			// name is set once and never corrected, so a single badly-addressed
			// email brands that customer permanently.
			$customer_model->update( $customer->id, [ 'name' => $from_name ] );
			$customer->name = $from_name;
		}

		// Thread matching.
		$conversation    = null;
		$thread_model    = new Thread();
		$conv_model      = new Conversation();

		// 1. Match by In-Reply-To, then by References newest-first — the
		//    customer may be replying to an older message, or their client
		//    may send only References.
		$ancestors = array_filter( array_merge( [ $in_reply_to ], array_slice( array_reverse( $references ), 0, 20 ) ) );
		foreach ( array_unique( $ancestors ) as $ancestor ) {
			$existing_thread = $thread_model->find_by_message_id( $ancestor );
			if ( $existing_thread ) {
				$conversation = $conv_model->get_by_id( $existing_thread->conversation_id );
				break;
			}
		}

		// 2. Match by subject thread ID pattern [#XX-XXXXXX]. Prefix may be letters OR digits
		// because the inbox hash (used to derive the prefix) can start with either.
		if ( ! $conversation && preg_match( '/\[#([A-Z0-9]{2}-[A-F0-9]{6})\]/i', $subject, $matches ) ) {
			$conversation = $conv_model->get_by_thread_id( strtoupper( $matches[1] ) );
		}

		// 3. New conversation.
		if ( ! $conversation ) {
			$thread_prefix = strtoupper( substr( $inbox->inbox_hash, 0, 2 ) );

			$clean_subject = $this->normalize_subject( $subject );

			/**
			 * Filter the conversation subject before the conversation is created.
			 *
			 * Use this to normalise subjects, strip known prefixes, or translate.
			 * Returning an empty string falls back to "(No Subject)".
			 *
			 * @param string $clean_subject The normalised subject.
			 * @param int    $inbox_id      The inbox ID receiving the email.
			 */
			$clean_subject = (string) apply_filters( 'bridle_conversation_subject', $clean_subject, (int) $inbox->id );

			// Spam filter hook — an extension can listen on this
			// filter and return 'spam' if the sender is blacklisted or
			// the Bayesian classifier flags the content. Whitelisted
			// senders always pass. Returns null = no override.
			$route = AutomatedMail::route( $from_email, $incoming_headers, $classification );

			$status_override = apply_filters( 'bridle_inbound_email_pre_create', null, [
				'inbox_id'   => (int) $inbox->id,
				'from_email' => $from_email,
				'subject'    => $clean_subject,
				'text'       => $text,
			] );

			$status = $status_override ?: $route['status'];

			$conversation_id = $conv_model->create( [
				'subject'           => $clean_subject ?: __( '(No Subject)', 'bridle' ),
				'status'            => $status,
				'urgency'           => $route['urgency'] ?? 'normal',
				'is_automated'      => $route['is_automated'],
				'ai_classification' => $classification ? wp_json_encode( $classification ) : null,
				'customer_id'       => $customer->id,
				'inbox_id'          => $inbox->id,
				'channel'           => 'email',
				'thread_prefix'     => $thread_prefix,
			] );

			$customer_model->increment_conversations( $customer->id );
			$conversation = $conv_model->get_by_id( $conversation_id );
			$is_new       = true;
			$is_spam      = 'spam' === $status;
		} else {
			$is_new = false;

			// An out-of-office or other auto-responder answering our reply.
			// It stays in the conversation, marked, for whoever reads it,
			// but as a private line: it never becomes the last message, so
			// the conversation keeps its place (no "needs reply", no reopen,
			// no move up the list), and nobody is notified or drafts an
			// answer to it.
			if ( AutomatedMail::is_auto_reply( $incoming_headers ) ) {
				$thread_id = $thread_model->create( [
					'conversation_id'  => $conversation->id,
					'author_type'      => 'customer',
					'author_id'        => $customer->id,
					'thread_type'      => 'auto_reply',
					'is_private'       => true,
					'content'          => $text,
					'content_html'     => '' !== (string) $html ? $html : null,
					'email_message_id' => $message_id,
				] );

				/**
				 * Fires after an auto-reply (out of office, vacation, a
				 * receipt) is kept on an existing conversation.
				 *
				 * @param int $thread_id       The thread ID.
				 * @param int $conversation_id The conversation ID.
				 */
				do_action( 'bridle_auto_reply_received', (int) $thread_id, (int) $conversation->id );

				return new WP_REST_Response( [
					'conversation_id' => $conversation->id,
					'thread_id'       => $thread_id,
					'is_new'          => false,
					'auto_reply'      => true,
				], 201 );
			}
		}

		$thread_id = $thread_model->create( [
			'conversation_id'  => $conversation->id,
			'author_type'      => 'customer',
			'author_id'        => $customer->id,
			'thread_type'      => 'reply',
			'content'          => $text,
			'content_html'     => $html ?: null,
			'email_message_id' => $message_id,
		] );

		// Store attachments + rewrite inline cid: references in content_html.
		$attachments_in = $params['attachments'] ?? [];
		if ( is_array( $attachments_in ) && ! empty( $attachments_in ) && $thread_id ) {
			$cid_url_map = AttachmentService::store_for_thread( (int) $thread_id, $attachments_in );
			if ( $html && ! empty( $cid_url_map ) ) {
				$rewritten_html = AttachmentService::rewrite_cid_refs( $html, $cid_url_map );
				if ( $rewritten_html !== $html ) {
					$thread_model->update( (int) $thread_id, [ 'content_html' => $rewritten_html ] );
				}
			}
		}

		// Update conversation last_activity_at and reopen if closed.
		$update_data = [ 'last_activity_at' => current_time( 'mysql', true ) ];
		if ( 'closed' === $conversation->status ) {
			$update_data['status'] = 'active';
		}
		// The newest message's reading wins: sentiment and needs-human
		// describe where the conversation is now, not how it started.
		if ( ! $is_new && $classification ) {
			$update_data['ai_classification'] = wp_json_encode( $classification );
		}
		$conv_model->update( $conversation->id, $update_data );

		if ( $classification ) {
			/**
			 * Fires after an inbound message's classification (the owner's
			 * decision model, Services\Classifier) is stored on its conversation.
			 *
			 * @param int   $conversation_id The conversation ID.
			 * @param array $classification  See AutomatedMail::sanitize_classification().
			 */
			do_action( 'bridle_conversation_classified', (int) $conversation->id, $classification );
		}

		if ( $is_new && empty( $is_spam ) ) {
			// Pass incoming email headers + sender so auto-reply can prevent loops (RFC 3834).
			// Skipped entirely for auto-spammed conversations — no notifications and
			// no auto-reply. The conversation sits silently in the spam folder until
			// a teammate reviews it.
			do_action( 'bridle_conversation_created', $conversation->id, $conversation, [ 'from' => $from_email ] + $incoming_headers );
		}

		do_action( 'bridle_thread_added', $thread_id, $conversation->id );

		return new WP_REST_Response( [
			'conversation_id' => $conversation->id,
			'thread_id'       => $thread_id,
			'is_new'          => $is_new,
		], 201 );
	}

	/**
	 * Whether the request carries the inbox's webhook secret in X-Bridle-Auth.
	 *
	 * An inbox with no stored secret (e.g. created from WP-CLI) never
	 * authorizes: hash_equals() on a null first arg fatals on PHP 8.1+, so it
	 * must be a clean 401 rather than a 500.
	 *
	 * @param object      $request Anything with get_header(), normally WP_REST_Request.
	 * @param string|null $secret  The inbox's stored webhook_secret.
	 */
	public static function is_authorized( $request, $secret ): bool {
		$header = (string) $request->get_header( self::AUTH_HEADER );

		return ! empty( $secret ) && '' !== $header && hash_equals( (string) $secret, $header );
	}

	/**
	 * Map an incoming "To:" address to the inbox_hash column.
	 *
	 * The hash is the whole local part, {slug}-{4hex}: "support-a3f2" for
	 * support-a3f2@bridle.to.
	 */
	public static function inbox_hash_from_address( string $email ): ?string {
		$local = explode( '@', $email )[0];

		return '' !== $local ? $local : null;
	}

	/**
	 * Strip reply/forward prefixes and existing ticket-ID tags from an incoming subject
	 * so the stored conversation subject stays clean.
	 *
	 * "Re: [#CF-A3F8B2] Fwd: Order issue" → "Order issue"
	 */
	private function normalize_subject( string $subject ): string {
		$subject = trim( $subject );
		if ( '' === $subject ) {
			return '';
		}

		$previous = null;
		while ( $subject !== $previous ) {
			$previous = $subject;
			// Strip leading Re:/RE:/Fwd:/FW: (repeatable, e.g. "Re: Re: ").
			$subject = preg_replace( '/^(re|fwd?|aw|sv)\s*:\s*/i', '', $subject );
			// Strip leading ticket-ID tag like [#CF-A3F8B2] or [#1234].
			$subject = preg_replace( '/^\[#[A-Za-z0-9\-]+\]\s*/', '', $subject );
		}

		return trim( $subject );
	}

	/**
	 * Recover the real sender when the From header is not the person who wrote in.
	 *
	 * Priority:
	 *   1. Reply-To header
	 *   2. The body's own `Name:`/`Email:` identity block (contact forms)
	 *   3. X-Original-From / Resent-From header      (forwarded mail only)
	 *   4. `From:` line in the forwarded body        (forwarded mail only)
	 *
	 * Returns [ 'email' => ..., 'name' => ... ] if a replacement was found, or null.
	 */
	private function resolve_real_sender( string $from_email, string $from_name, string $reply_to, string $reply_to_name, string $original_from, string $text, string $html, \stdClass $inbox ): ?array {
		$from_email_lc = strtolower( $from_email );
		$inbox_emails  = [];
		if ( ! empty( $inbox->email_address ) ) { $inbox_emails[] = strtolower( $inbox->email_address ); }
		if ( ! empty( $inbox->forwarding_address ) ) { $inbox_emails[] = strtolower( $inbox->forwarding_address ); }

		$body = $text ?: wp_strip_all_tags( $html );
		$form = SenderIdentity::parse_form_identity( $body );

		// 1. Reply-To always wins — if valid, different from From, and not
		//    the inbox's own address.
		if ( $reply_to && is_email( $reply_to ) && strtolower( $reply_to ) !== $from_email_lc && ! in_array( strtolower( $reply_to ), $inbox_emails, true ) ) {
			$name = $reply_to_name;

			// Some senders strip the display name off Reply-To and pass only the
			// bare address (Mailyard does this deliberately — its ESP drivers run
			// sanitize_email(), which mangles "Name <addr>"). When the body's form
			// block names that same address, take the name from there.
			if ( '' === $name && $form && strtolower( $form['email'] ) === strtolower( $reply_to ) ) {
				$name = $form['name'];
			}

			return [ 'email' => $reply_to, 'name' => $name ];
		}

		// 2. The body's identity block. Reached when the form set no Reply-To, so
		//    the header names the site and only the body names the customer.
		if ( $form
			&& strtolower( $form['email'] ) !== $from_email_lc
			&& ! in_array( strtolower( $form['email'] ), $inbox_emails, true ) ) {
			return $form;
		}

		// Everything below only applies when From is the inbox's own address
		// (i.e., a forwarded email, not a direct send). If From is a third-party
		// address and there's no Reply-To, trust it as-is.
		if ( ! in_array( $from_email_lc, $inbox_emails, true ) ) {
			return null;
		}

		// 2. X-Original-From / Resent-From — some forwarders preserve it explicitly.
		if ( $original_from && is_email( $original_from ) && strtolower( $original_from ) !== $from_email_lc ) {
			return [ 'email' => $original_from, 'name' => '' ];
		}

		// 3. Parse the forwarded body for "From: Name <email@...>" or "From: email@..."
		//    Gmail's "Forward" action prepends this block to the body.
		$body = $text ?: wp_strip_all_tags( $html );
		if ( $body && preg_match( '/^From:\s*(.+?)$/mi', $body, $m ) ) {
			$header_value = trim( $m[1] );
			$found_email  = sanitize_email( SenderIdentity::address( $header_value ) );
			if ( $found_email && is_email( $found_email ) && strtolower( $found_email ) !== $from_email_lc ) {
				return [
					'email' => $found_email,
					'name'  => SenderIdentity::display_name( $header_value ),
				];
			}
		}

		return null;
	}

	/**
	 * Sanitize inbound email HTML with a broader allowlist than wp_kses_post.
	 *
	 * Email HTML uses tables, inline styles, width/height/bgcolor attributes,
	 * and images extensively. wp_kses_post strips most of these, breaking the
	 * email layout. This method allows the HTML elements and attributes that
	 * email clients produce while still blocking scripts and event handlers.
	 */
	private static function sanitize_email_html( string $html ): string {
		if ( ! $html ) {
			return '';
		}

		// Remove script tags and their content.
		$html = preg_replace( '#<script[^>]*>.*?</script>#si', '', $html );

		// Remove event handler attributes (onclick, onload, onerror, etc.).
		$html = preg_replace( '/\s+on[a-z]+\s*=\s*["\'][^"\']*["\']/i', '', $html );
		$html = preg_replace( '/\s+on[a-z]+\s*=\s*\S+/i', '', $html );

		// Remove javascript: URLs.
		$html = preg_replace( '/href\s*=\s*["\']javascript:[^"\']*["\']/i', 'href="#"', $html );
		$html = preg_replace( '/src\s*=\s*["\']javascript:[^"\']*["\']/i', 'src=""', $html );

		// Remove <form> tags (but keep content inside).
		$html = preg_replace( '#</?form[^>]*>#i', '', $html );

		// Remove <iframe>, <embed>, <object>, <applet>.
		$html = preg_replace( '#<(iframe|embed|object|applet)[^>]*>.*?</\1>#si', '', $html );
		$html = preg_replace( '#<(iframe|embed|object|applet)[^>]*/?\s*>#i', '', $html );

		return $html;
	}


	/**
	 * Strip elements whose text-content bleeds into rendered output after wp_kses.
	 *
	 * wp_kses_post removes disallowed wrapper tags but keeps the text between
	 * them — so <style>.foo{...}</style> becomes the raw CSS string. We must
	 * remove these blocks (including content) beforehand.
	 *
	 * Also strips document-level wrappers (<!DOCTYPE>, <html>, <head>, <body>,
	 * <meta>, <title>, <link>, <base>) and HTML comments that otherwise leave
	 * empty wrappers or stray head content in the body.
	 */
	public static function strip_noisy_blocks( string $html ): string {
		if ( '' === $html ) {
			return '';
		}

		// Raw-text elements — strip tag + content (case-insensitive, multiline).
		$html = preg_replace( '#<(style|script|noscript|template)\b[^>]*>.*?</\1>#is', '', $html );

		// Document wrappers — unwrap (strip open/close tags, keep inner content).
		$html = preg_replace( '#</?(html|head|body)\b[^>]*>#i', '', $html );

		// <title> with its text, before the void-tag pass below: that pass used
		// to eat the bare opening tag first, so the title text survived into the
		// body (twice for templates with two <title>s, like Solid Security's).
		$html = preg_replace( '#<title\b[^>]*>.*?</title>#is', '', $html );

		// Self-closing head metadata — strip entirely.
		$html = preg_replace( '#<(meta|link|base)\b[^>]*/?\s*>#i', '', $html );
		$html = preg_replace( '#</?title\b[^>]*>#i', '', $html );

		// DOCTYPE + HTML/XML comments + conditional comments.
		$html = preg_replace( '#<!DOCTYPE[^>]*>#i', '', $html );
		$html = preg_replace( '#<!--.*?-->#s', '', $html );

		return $html;
	}
}
