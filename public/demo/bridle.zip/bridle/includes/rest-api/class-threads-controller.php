<?php

namespace Bridle\RestApi;

use Bridle\Models\Attachment;
use Bridle\Models\Conversation;
use Bridle\Models\Draft;
use Bridle\Models\Thread;
use Bridle\Services\ReplyService;
use WP_Error;
use WP_REST_Controller;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ThreadsController extends WP_REST_Controller {

	protected $namespace = BRIDLE_REST_NAMESPACE;
	protected $rest_base = 'conversations/(?P<conversation_id>[\d]+)/threads';

	public function register_routes(): void {
		register_rest_route( $this->namespace, '/' . $this->rest_base, [
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_items' ],
				'permission_callback' => [ $this, 'get_items_permissions_check' ],
			],
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'create_item' ],
				'permission_callback' => [ $this, 'create_item_permissions_check' ],
			],
		] );

		// Draft endpoints — per-user draft reply per conversation.
		register_rest_route( $this->namespace, '/conversations/(?P<conversation_id>[\d]+)/draft', [
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_draft' ],
				'permission_callback' => [ $this, 'create_item_permissions_check' ],
			],
			[
				'methods'             => WP_REST_Server::EDITABLE,
				'callback'            => [ $this, 'save_draft' ],
				'permission_callback' => [ $this, 'create_item_permissions_check' ],
			],
			[
				'methods'             => WP_REST_Server::DELETABLE,
				'callback'            => [ $this, 'delete_draft' ],
				'permission_callback' => [ $this, 'create_item_permissions_check' ],
			],
		] );
	}

	public function get_items_permissions_check( $request ) {
		return current_user_can( 'bridle_manage_conversations' ) || current_user_can( 'bridle_reply_conversations' );
	}

	public function create_item_permissions_check( $request ) {
		return current_user_can( 'bridle_reply_conversations' ) || current_user_can( 'bridle_manage_conversations' );
	}

	public function get_items( $request ) {
		$conversation_id = absint( $request['conversation_id'] );
		$conversation    = ( new Conversation() )->get_by_id( $conversation_id );

		if ( ! $conversation ) {
			return new WP_Error( 'bridle_not_found', __( 'Conversation not found.', 'bridle' ), [ 'status' => 404 ] );
		}

		$threads = ( new Thread() )->get_by_conversation( $conversation_id );

		// Hydrate attachments per thread.
		if ( ! empty( $threads ) ) {
			$thread_ids = array_map( fn( $t ) => (int) $t->id, $threads );
			$atts_raw   = ( new Attachment() )->get_by_thread_ids( $thread_ids );

			$by_thread = [];
			foreach ( $atts_raw as $att ) {
				$by_thread[ (int) $att->thread_id ][] = [
					'id'         => (int) $att->id,
					'filename'   => $att->filename,
					'mime_type'  => $att->mime_type,
					'size_bytes' => (int) $att->size_bytes,
					'is_inline'  => (bool) $att->is_inline,
					'url'        => Attachment::url_for( (int) $att->wp_attachment_id ),
				];
			}

			foreach ( $threads as $t ) {
				$t->attachments = $by_thread[ (int) $t->id ] ?? [];
			}
		}

		return new WP_REST_Response( $threads );
	}

	public function create_item( $request ) {
		$conversation_id = absint( $request['conversation_id'] );
		$params          = (array) $request->get_json_params();

		$thread = ReplyService::add( $conversation_id, [
			'content'          => (string) ( $params['content'] ?? '' ),
			'content_html'     => $params['content_html'] ?? null,
			'thread_type'      => sanitize_text_field( $params['thread_type'] ?? 'reply' ),
			'is_private'       => ! empty( $params['is_private'] ),
			'attachment_ids'   => $params['attachment_ids'] ?? [],
			'from_agent_draft' => ! empty( $params['from_agent_draft'] ),
		] );

		if ( is_wp_error( $thread ) ) {
			return $thread;
		}

		// @mentions: email each mentioned teammate (desktop notifications are a
		// future version; email is the notification channel for now).
		if ( 'note' === $thread->thread_type && ! empty( $params['mentioned_user_ids'] ) && is_array( $params['mentioned_user_ids'] ) ) {
			$this->notify_mentions(
				( new Conversation() )->get_by_id( $conversation_id ),
				array_map( 'absint', $params['mentioned_user_ids'] ),
				get_current_user_id(),
				(string) ( $params['content'] ?? '' )
			);
		}

		return new WP_REST_Response( $thread, 201 );
	}

	/**
	 * Email teammates who were @mentioned in an internal note.
	 *
	 * @param object $conversation The conversation row.
	 * @param int[]  $user_ids     Mentioned WP user ids.
	 * @param int    $author_id    The teammate who wrote the note.
	 * @param string $note         The note text.
	 */
	private function notify_mentions( object $conversation, array $user_ids, int $author_id, string $note ): void {
		$author   = get_userdata( $author_id );
		$by       = $author ? $author->display_name : __( 'A teammate', 'bridle' );
		$subject  = sprintf( /* translators: %s conversation subject */ __( 'You were mentioned in “%s”', 'bridle' ), $conversation->subject );
		$url      = admin_url( 'admin.php?page=bridle#/c/' . (int) $conversation->id );
		$excerpt  = wp_strip_all_tags( $note );

		foreach ( array_unique( $user_ids ) as $uid ) {
			if ( ! $uid || $uid === $author_id ) {
				continue;
			}
			$user = get_userdata( $uid );
			if ( ! $user || ! is_email( $user->user_email ) ) {
				continue;
			}
			$body = sprintf(
				/* translators: 1: author name, 2: note text, 3: admin URL */
				__( "%1\$s mentioned you in a conversation:\n\n%2\$s\n\nView it in Bridle: %3\$s", 'bridle' ),
				$by,
				$excerpt,
				$url
			);
			wp_mail( $user->user_email, $subject, $body );
		}
	}

	public function get_draft( $request ) {
		$conversation_id = absint( $request['conversation_id'] );
		$draft = ( new Draft() )->get( $conversation_id, get_current_user_id() );

		return new WP_REST_Response( $draft ? [
			'content'     => $draft->content,
			'thread_type' => $draft->thread_type,
			'updated_at'  => $draft->updated_at,
		] : null );
	}

	public function save_draft( $request ) {
		$conversation_id = absint( $request['conversation_id'] );
		$conversation    = ( new Conversation() )->get_by_id( $conversation_id );
		if ( ! $conversation ) {
			return new WP_Error( 'bridle_not_found', __( 'Conversation not found.', 'bridle' ), [ 'status' => 404 ] );
		}

		$params      = $request->get_json_params();
		$content     = wp_kses_post( $params['content'] ?? '' );
		$thread_type = sanitize_text_field( $params['thread_type'] ?? 'reply' );

		$draft_model = new Draft();

		// Empty content → delete the draft instead of storing blank.
		if ( '' === trim( $content ) ) {
			$draft_model->delete( $conversation_id, get_current_user_id() );
			return new WP_REST_Response( [ 'saved' => false, 'deleted' => true ] );
		}

		$draft_model->upsert( $conversation_id, get_current_user_id(), $content, $thread_type );

		return new WP_REST_Response( [ 'saved' => true, 'updated_at' => current_time( 'mysql', true ) ] );
	}

	public function delete_draft( $request ) {
		$conversation_id = absint( $request['conversation_id'] );
		( new Draft() )->delete( $conversation_id, get_current_user_id() );
		return new WP_REST_Response( [ 'deleted' => true ] );
	}
}
