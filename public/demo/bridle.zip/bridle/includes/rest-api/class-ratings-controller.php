<?php

namespace Bridle\RestApi;

use Bridle\Models\Conversation;
use Bridle\Models\Rating;
use WP_Error;
use WP_REST_Controller;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RatingsController extends WP_REST_Controller {

	protected $namespace = BRIDLE_REST_NAMESPACE;
	protected $rest_base = 'ratings';

	public function register_routes(): void {
		// The customer who got the rating email is not logged in, so the
		// permission check is the conversation's own signed token.
		register_rest_route( $this->namespace, '/' . $this->rest_base . '/submit', [
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'submit' ],
				'permission_callback' => [ $this, 'token_check' ],
				'args'                => [
					'conversation_id' => [
						'type'              => 'integer',
						'required'          => true,
						'sanitize_callback' => 'absint',
					],
					'token'           => [
						'type'              => 'string',
						'required'          => true,
						'sanitize_callback' => 'sanitize_text_field',
					],
					'rating'          => [
						'type'     => 'integer',
						'required' => true,
						'minimum'  => 1,
						'maximum'  => 4,
					],
					'comment'         => [
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_textarea_field',
					],
				],
			],
		] );

		// Internal read — used by the conversation detail to show the
		// customer's score and for the overall summary.
		register_rest_route( $this->namespace, '/conversations/(?P<id>[\d]+)/rating', [
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_for_conversation' ],
				'permission_callback' => [ $this, 'reply_check' ],
			],
		] );
	}

	public function reply_check( $request ): bool {
		return current_user_can( 'bridle_manage_conversations' )
			|| current_user_can( 'bridle_reply_conversations' );
	}

	/**
	 * The rating link's token: an HMAC of the conversation id (Rating::verify_token()).
	 *
	 * @return true|WP_Error
	 */
	public function token_check( WP_REST_Request $request ) {
		$id = absint( $request->get_param( 'conversation_id' ) );
		if ( ! $id || ! Rating::verify_token( $id, (string) $request->get_param( 'token' ) ) ) {
			return new WP_Error( 'bridle_invalid_token', __( 'Invalid rating link.', 'bridle' ), [ 'status' => 403 ] );
		}
		return true;
	}

	public function submit( WP_REST_Request $request ) {
		$id      = absint( $request->get_param( 'conversation_id' ) );
		$rating  = (int) $request->get_param( 'rating' );
		$comment = sanitize_textarea_field( (string) ( $request->get_param( 'comment' ) ?? '' ) );

		if ( ! ( new Conversation() )->get_by_id( $id ) ) {
			return new WP_Error( 'bridle_not_found', __( 'Conversation not found.', 'bridle' ), [ 'status' => 404 ] );
		}

		if ( $rating < 1 || $rating > 4 ) {
			return new WP_Error( 'bridle_bad_rating', __( 'Rating must be 1–4.', 'bridle' ), [ 'status' => 400 ] );
		}

		( new Rating() )->record( $id, $rating, $comment );

		return new WP_REST_Response( [ 'recorded' => true ] );
	}

	public function get_for_conversation( $request ): WP_REST_Response {
		$rating = ( new Rating() )->get_for_conversation( absint( $request['id'] ) );
		return new WP_REST_Response( $rating );
	}
}
