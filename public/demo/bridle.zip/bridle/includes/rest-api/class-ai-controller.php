<?php

namespace Bridle\RestApi;

use Bridle\Abilities\AbilitiesRegistrar;
use Bridle\Models\Conversation;
use Bridle\Services\AgentService;
use Bridle\Services\AiService;
use Bridle\Services\AutoSend;
use Bridle\Services\BridleAi;
use Bridle\Services\Classifier;
use Bridle\Services\KnowledgeSearch;
use Bridle\Services\ReplyService;
use Bridle\Services\Rewrite;
use WP_Error;
use WP_REST_Controller;
use WP_REST_Response;
use WP_REST_Server;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * AI status and the conversation's agent draft.
 *
 * Sending a draft goes through the normal threads endpoint with
 * `from_agent_draft: true`, so there is one send path (ReplyService).
 */
class AiController extends WP_REST_Controller {

	protected $namespace = BRIDLE_REST_NAMESPACE;

	public function register_routes(): void {
		register_rest_route( $this->namespace, '/ai/status', [
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_status' ],
				'permission_callback' => [ $this, 'permissions_check' ],
			],
		] );

		register_rest_route(
			$this->namespace,
			'/ai/models',
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_models' ],
				'permission_callback' => [ $this, 'settings_permissions_check' ],
				'args'                => [
					'refresh' => [
						'type'    => 'boolean',
						'default' => false,
					],
				],
			]
		);

		// Rewrite or translate a reply a person is writing (#130).
		register_rest_route(
			$this->namespace,
			'/ai/rewrite',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'rewrite' ],
					'permission_callback' => [ $this, 'permissions_check' ],
					'args'                => [
						'html'            => [
							'type'     => 'string',
							'required' => true,
						],
						'style'           => [
							'type'     => 'string',
							'required' => true,
							'enum'     => Rewrite::STYLES,
						],
						'language'        => [
							'type'              => 'string',
							'default'           => '',
							'sanitize_callback' => 'sanitize_text_field',
						],
						'conversation_id' => [
							'type'    => 'integer',
							'default' => 0,
						],
					],
				],
			]
		);

		register_rest_route( $this->namespace, '/conversations/(?P<id>[\d]+)/agent-draft', [
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_agent_draft' ],
				'permission_callback' => [ $this, 'permissions_check' ],
			],
			[
				'methods'             => WP_REST_Server::DELETABLE,
				'callback'            => [ $this, 'discard_agent_draft' ],
				'permission_callback' => [ $this, 'permissions_check' ],
			],
		] );

		// Who may let an external agent send replies.
		register_rest_route(
			$this->namespace,
			'/ai/senders/(?P<user_id>[\d]+)',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'add_sender' ],
					'permission_callback' => [ $this, 'settings_permissions_check' ],
				],
				[
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => [ $this, 'remove_sender' ],
					'permission_callback' => [ $this, 'settings_permissions_check' ],
				],
			]
		);

		// Stop a scheduled send; the draft stays for a person.
		register_rest_route(
			$this->namespace,
			'/conversations/(?P<id>[\d]+)/agent-draft/stop',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'stop_agent_send' ],
					'permission_callback' => [ $this, 'permissions_check' ],
				],
			]
		);

		// Bridle AI (Services\BridleAi): answers without the owner's own key.
		register_rest_route(
			$this->namespace,
			'/ai/bridle',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_bridle_ai' ],
					'permission_callback' => [ $this, 'settings_permissions_check' ],
				],
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'turn_on_bridle_ai' ],
					'permission_callback' => [ $this, 'settings_permissions_check' ],
					'args'                => [
						'email' => [
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_email',
						],
					],
				],
				[
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => [ $this, 'turn_off_bridle_ai' ],
					'permission_callback' => [ $this, 'settings_permissions_check' ],
				],
			]
		);
		register_rest_route(
			$this->namespace,
			'/ai/bridle/checkout',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'bridle_ai_checkout' ],
					'permission_callback' => [ $this, 'settings_permissions_check' ],
					'args'                => [
						'pack' => [
							'type'     => 'string',
							'required' => true,
							'enum'     => array_keys( BridleAi::PACKS ),
						],
					],
				],
			]
		);
		// Public, and only while a sign-up waits: the service asks the site to
		// echo the nonce it sent, which proves the site itself is signing up.
		register_rest_route(
			$this->namespace,
			'/ai/bridle/verify',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'bridle_ai_verify' ],
					'permission_callback' => [ $this, 'bridle_ai_verify_check' ],
				],
			]
		);

		// The owner's decision model for sorting mail (Services\Classifier).
		// The key goes in, never out.
		register_rest_route(
			$this->namespace,
			'/ai/classifier',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_classifier' ],
					'permission_callback' => [ $this, 'settings_permissions_check' ],
				],
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'save_classifier' ],
					'permission_callback' => [ $this, 'settings_permissions_check' ],
				],
			]
		);
		register_rest_route(
			$this->namespace,
			'/ai/classifier/test',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'test_classifier' ],
					'permission_callback' => [ $this, 'settings_permissions_check' ],
				],
			]
		);

		// Draft again now, synchronously: the teammate is waiting on it.
		register_rest_route( $this->namespace, '/conversations/(?P<id>[\d]+)/agent-draft/retry', [
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'retry_agent_draft' ],
				'permission_callback' => [ $this, 'permissions_check' ],
			],
		] );
	}

	/**
	 * POST /ai/rewrite: the reply reshaped, or why not. The HTML is limited
	 * to the editor's tags in Rewrite::run() before the model sees it.
	 *
	 * @param \WP_REST_Request $request The request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function rewrite( $request ) {
		$result = Rewrite::run(
			(string) $request->get_param( 'html' ),
			(string) $request->get_param( 'style' ),
			(string) $request->get_param( 'language' ),
			absint( $request->get_param( 'conversation_id' ) )
		);
		return is_wp_error( $result ) ? $result : new WP_REST_Response( $result );
	}

	public function permissions_check( $request ) {
		return current_user_can( 'bridle_manage_conversations' ) || current_user_can( 'bridle_reply_conversations' );
	}

	public function settings_permissions_check( $request ) {
		return current_user_can( 'bridle_manage_settings' );
	}

	public function get_bridle_ai( $request ) {
		BridleAi::balance( true );
		return new WP_REST_Response( BridleAi::status() + [ 'own_provider' => AiService::own_provider() ] );
	}

	public function turn_on_bridle_ai( $request ) {
		$email = (string) $request->get_param( 'email' );
		if ( '' === $email ) {
			$user  = wp_get_current_user();
			$email = (string) ( $user->user_email ?? '' );
		}
		$result = BridleAi::turn_on( $email );
		return is_wp_error( $result ) ? $result : new WP_REST_Response( $result + [ 'own_provider' => AiService::own_provider() ] );
	}

	public function turn_off_bridle_ai( $request ) {
		return new WP_REST_Response( BridleAi::turn_off() + [ 'own_provider' => AiService::own_provider() ] );
	}

	public function bridle_ai_checkout( $request ) {
		$url = BridleAi::checkout( (string) $request->get_param( 'pack' ) );
		return is_wp_error( $url ) ? $url : new WP_REST_Response( [ 'url' => $url ] );
	}

	/** True only while a sign-up waits for the service to check this site. */
	public function bridle_ai_verify_check( $request ) {
		return '' !== BridleAi::pending_nonce()
			? true
			: new WP_Error( 'rest_no_route', __( 'Nothing to verify.', 'bridle' ), [ 'status' => 404 ] );
	}

	public function bridle_ai_verify( $request ) {
		$response = new WP_REST_Response( [ 'nonce' => BridleAi::pending_nonce() ] );
		$response->header( 'Cache-Control', 'no-store, private' );
		return $response;
	}

	public function get_status( $request ) {
		return new WP_REST_Response( [
			'can_use_ai'    => AiService::can_use_ai(),
			'ai_source'     => AiService::source(),
			'wp_version_ok' => function_exists( 'wp_ai_client_prompt' ),
			'stats'         => (array) get_option( 'bridle_agent_stats', [] ),
			'knowledge'     => KnowledgeSearch::status(),
			'connect'       => [
				'abilities'     => function_exists( 'wp_register_ability' ),
				'saddle'        => class_exists( 'Saddle_Integrations' ) || defined( 'SADDLE_VERSION' ),
				// Whether Saddle already offers Bridle's tools: always from Saddle
				// 1.5.2, where Bridle is a PlugPress plugin; before that only once
				// the owner switched it on under Services.
				'saddle_on'     => is_callable( [ 'Saddle_Integrations', 'is_approved' ] ) && \Saddle_Integrations::is_approved( 'bridle' ),
				'mcp_adapter'   => class_exists( '\WP\MCP\Plugin' ) || class_exists( '\WP\MCP\Core\McpAdapter' ),
				'app_passwords' => function_exists( 'wp_is_application_passwords_available' ) && wp_is_application_passwords_available(),
				'profile_url'   => admin_url( 'profile.php#application-passwords-section' ),
			],
			'senders'       => array_map(
				static fn( $user ) => [
					'id'   => (int) $user->ID,
					'name' => (string) $user->display_name,
				],
				get_users( [ 'capability' => AbilitiesRegistrar::SEND_CAP ] )
			),
		] );
	}

	/** The models the owner's AI connection offers, for the model per task (#133). */
	public function get_models( $request ) {
		return new WP_REST_Response( [ 'models' => AiService::models( (bool) $request->get_param( 'refresh' ) ) ] );
	}

	/** Let this teammate's AI agent send replies. Only for people who can answer support already. */
	public function add_sender( $request ) {
		$user = get_userdata( absint( $request['user_id'] ) );
		if ( ! $user || ! ( $user->has_cap( 'bridle_reply_conversations' ) || $user->has_cap( 'bridle_manage_conversations' ) ) ) {
			return new WP_Error( 'bridle_not_a_teammate', __( 'Only teammates who answer support can let an agent send.', 'bridle' ), [ 'status' => 400 ] );
		}

		$user->add_cap( AbilitiesRegistrar::SEND_CAP );

		return $this->get_status( $request );
	}

	public function remove_sender( $request ) {
		$user = get_userdata( absint( $request['user_id'] ) );
		if ( $user ) {
			$user->remove_cap( AbilitiesRegistrar::SEND_CAP );
		}

		return $this->get_status( $request );
	}

	public function get_classifier( $request ) {
		return new WP_REST_Response( Classifier::public_config() );
	}

	public function save_classifier( $request ) {
		$params = (array) $request->get_json_params();
		$result = Classifier::save(
			[
				'provider'   => (string) ( $params['provider'] ?? '' ),
				'model'      => (string) ( $params['model'] ?? '' ),
				'account_id' => (string) ( $params['account_id'] ?? '' ),
				'key'        => (string) ( $params['key'] ?? '' ),
			]
		);

		return is_wp_error( $result ) ? $result : new WP_REST_Response( $result );
	}

	/** Classify a sample pitch with the saved key, so the owner sees it works. */
	public function test_classifier( $request ) {
		$result           = Classifier::test();
		$result['config'] = Classifier::public_config();

		return new WP_REST_Response( $result );
	}

	public function get_agent_draft( $request ) {
		$conversation_id = absint( $request['id'] );
		if ( ! ( new Conversation() )->get_by_id( $conversation_id ) ) {
			return new WP_Error( 'bridle_not_found', __( 'Conversation not found.', 'bridle' ), [ 'status' => 404 ] );
		}

		return new WP_REST_Response( AgentService::get_draft( $conversation_id ) );
	}

	public function discard_agent_draft( $request ) {
		return new WP_REST_Response( [ 'deleted' => ReplyService::discard_agent_draft( absint( $request['id'] ) ) ] );
	}

	public function stop_agent_send( $request ) {
		$conversation_id = absint( $request['id'] );
		AutoSend::stop( $conversation_id, get_current_user_id() );

		return new WP_REST_Response( AgentService::get_draft( $conversation_id ) );
	}

	public function retry_agent_draft( $request ) {
		$result = AgentService::draft( absint( $request['id'] ) );

		if ( is_wp_error( $result ) ) {
			$status = 'bridle_not_found' === $result->get_error_code() ? 404 : 502;
			$result->add_data( [ 'status' => $status ] );
			return $result;
		}

		return new WP_REST_Response( AgentService::get_draft( absint( $request['id'] ) ) );
	}
}
