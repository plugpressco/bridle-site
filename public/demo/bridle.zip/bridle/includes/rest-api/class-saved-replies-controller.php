<?php

namespace Bridle\RestApi;

use WP_REST_Controller;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Saved replies (canned responses / macros) — team-wide reusable snippets.
 *
 * Stored as a single JSON option (`bridle_saved_replies`): a list of
 * { id, title, body } records. The whole collection is small, so we read and
 * replace it wholesale rather than maintaining a table.
 */
class SavedRepliesController extends WP_REST_Controller {

	protected $namespace = BRIDLE_REST_NAMESPACE;
	protected $rest_base = 'saved-replies';

	const OPTION = 'bridle_saved_replies';

	public function register_routes(): void {
		register_rest_route( $this->namespace, '/' . $this->rest_base, [
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_items' ],
				'permission_callback' => [ $this, 'reply_check' ],
			],
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'create_item' ],
				'permission_callback' => [ $this, 'reply_check' ],
				'args'                => [
					'title' => [ 'type' => 'string', 'required' => true ],
					'body'  => [ 'type' => 'string', 'required' => true ],
				],
			],
		] );

		register_rest_route( $this->namespace, '/' . $this->rest_base . '/(?P<id>[\w-]+)', [
			[
				'methods'             => WP_REST_Server::EDITABLE,
				'callback'            => [ $this, 'update_item' ],
				'permission_callback' => [ $this, 'reply_check' ],
				'args'                => [
					'title' => [ 'type' => 'string' ],
					'body'  => [ 'type' => 'string' ],
				],
			],
			[
				'methods'             => WP_REST_Server::DELETABLE,
				'callback'            => [ $this, 'delete_item' ],
				'permission_callback' => [ $this, 'reply_check' ],
			],
		] );
	}

	public function reply_check(): bool {
		return current_user_can( 'bridle_manage_conversations' )
			|| current_user_can( 'bridle_reply_conversations' );
	}

	/** Read + normalise the stored list. */
	private function all(): array {
		$raw = get_option( self::OPTION, [] );
		if ( ! is_array( $raw ) ) {
			$raw = json_decode( (string) $raw, true );
		}
		return is_array( $raw ) ? array_values( $raw ) : [];
	}

	private function save( array $list ): void {
		update_option( self::OPTION, array_values( $list ), false );
	}

	public function get_items( $request ): WP_REST_Response {
		return new WP_REST_Response( $this->all() );
	}

	public function create_item( $request ): WP_REST_Response {
		$list = $this->all();
		$item = [
			'id'    => 'r_' . wp_generate_password( 8, false ),
			'title' => sanitize_text_field( (string) $request->get_param( 'title' ) ),
			'body'  => wp_kses_post( (string) $request->get_param( 'body' ) ),
		];
		$list[] = $item;
		$this->save( $list );
		return new WP_REST_Response( $this->all() );
	}

	public function update_item( $request ): WP_REST_Response {
		$id   = sanitize_text_field( (string) $request['id'] );
		$list = array_map(
			function ( $r ) use ( $request, $id ) {
				if ( ( $r['id'] ?? '' ) !== $id ) {
					return $r;
				}
				if ( null !== $request->get_param( 'title' ) ) {
					$r['title'] = sanitize_text_field( (string) $request->get_param( 'title' ) );
				}
				if ( null !== $request->get_param( 'body' ) ) {
					$r['body'] = wp_kses_post( (string) $request->get_param( 'body' ) );
				}
				return $r;
			},
			$this->all()
		);
		$this->save( $list );
		return new WP_REST_Response( $this->all() );
	}

	public function delete_item( $request ): WP_REST_Response {
		$id   = sanitize_text_field( (string) $request['id'] );
		$list = array_filter( $this->all(), fn( $r ) => ( $r['id'] ?? '' ) !== $id );
		$this->save( $list );
		return new WP_REST_Response( $this->all() );
	}
}
