<?php

namespace Bridle\RestApi;

use Bridle\Models\Conversation;
use Bridle\Models\Customer;
use WP_Error;
use WP_REST_Controller;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CustomersController extends WP_REST_Controller {

	protected $namespace = BRIDLE_REST_NAMESPACE;
	protected $rest_base = 'customers';

	public function register_routes(): void {
		register_rest_route( $this->namespace, '/' . $this->rest_base, [
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_items' ],
				'permission_callback' => [ $this, 'read_check' ],
				'args'                => [
					'search'   => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ],
					'page'     => [ 'type' => 'integer', 'default' => 1 ],
					'per_page' => [ 'type' => 'integer', 'default' => 20 ],
				],
			],
		] );

		register_rest_route( $this->namespace, '/' . $this->rest_base . '/(?P<id>[\d]+)', [
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_item' ],
				'permission_callback' => [ $this, 'read_check' ],
			],
			[
				'methods'             => 'PATCH',
				'callback'            => [ $this, 'update_item' ],
				'permission_callback' => [ $this, 'manage_check' ],
			],
			[
				// Deletes the contact and every conversation they had: settings
				// managers only, not every teammate who can work conversations.
				'methods'             => WP_REST_Server::DELETABLE,
				'callback'            => [ $this, 'delete_item' ],
				'permission_callback' => [ $this, 'delete_check' ],
			],
		] );

		// Merge customers.
		register_rest_route( $this->namespace, '/' . $this->rest_base . '/merge', [
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'merge_customers' ],
				'permission_callback' => [ $this, 'manage_check' ],
			],
		] );

		// Cross-plugin contact cards (read-only federation by email).
		register_rest_route( $this->namespace, '/contact-cards', [
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_contact_cards' ],
				'permission_callback' => [ $this, 'read_check' ],
				'args'                => [
					'email' => [ 'type' => 'string', 'required' => true, 'sanitize_callback' => 'sanitize_email' ],
				],
			],
		] );
	}

	/**
	 * Cards contributed by sibling PlugPress products for this email (e.g.
	 * Outbees newsletter status). Returns [] when no other product answers.
	 */
	public function get_contact_cards( $request ) {
		$email = sanitize_email( (string) $request->get_param( 'email' ) );
		if ( ! $email || ! is_email( $email ) ) {
			return new WP_REST_Response( [] );
		}
		/** This filter is the shared cross-plugin convention. */
		$cards = apply_filters( 'plugpress_contact_cards', [], $email, 'bridle' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- deliberate cross-product filter shared by PlugPress plugins.
		return new WP_REST_Response( is_array( $cards ) ? array_values( $cards ) : [] );
	}

	public function read_check( $request ) {
		return current_user_can( 'bridle_manage_conversations' ) || current_user_can( 'bridle_reply_conversations' );
	}

	public function manage_check( $request ) {
		return current_user_can( 'bridle_manage_conversations' ) || current_user_can( 'manage_options' );
	}

	public function delete_check( $request ) {
		// phpcs:ignore WordPress.WP.Capabilities.Unknown -- Bridle's own capability (Activator::create_roles()).
		return current_user_can( 'bridle_manage_settings' ) || current_user_can( 'manage_options' );
	}

	public function get_items( $request ) {
		$model  = new Customer();
		$result = $model->list( [
			'search'   => $request->get_param( 'search' ),
			'page'     => $request->get_param( 'page' ) ?: 1,
			'per_page' => $request->get_param( 'per_page' ) ?: 20,
		] );

		foreach ( $result['items'] as $item ) {
			$item->avatar_url = \Bridle\Services\Avatars::url( $item->email ?? '', 96 );
		}

		$response = new WP_REST_Response( $result['items'] );
		$response->header( 'X-WP-Total', $result['total'] );
		$response->header( 'X-WP-TotalPages', ceil( $result['total'] / $result['per_page'] ) );

		return $response;
	}

	public function get_item( $request ) {
		$customer = ( new Customer() )->get_by_id( absint( $request['id'] ) );

		if ( ! $customer ) {
			return new WP_Error( 'bridle_not_found', __( 'Contact not found.', 'bridle' ), [ 'status' => 404 ] );
		}

		$customer->avatar_url = \Bridle\Services\Avatars::url( $customer->email ?? '', 96 );

		return new WP_REST_Response( $customer );
	}

	public function update_item( $request ) {
		$model    = new Customer();
		$customer = $model->get_by_id( absint( $request['id'] ) );

		if ( ! $customer ) {
			return new WP_Error( 'bridle_not_found', __( 'Contact not found.', 'bridle' ), [ 'status' => 404 ] );
		}

		$params = $request->get_json_params();
		$update = [];

		if ( array_key_exists( 'name', $params ) ) {
			$update['name'] = sanitize_text_field( $params['name'] );
		}

		if ( array_key_exists( 'email', $params ) ) {
			$email = sanitize_email( $params['email'] );
			if ( ! is_email( $email ) ) {
				return new WP_Error( 'bridle_invalid_email', __( 'That is not a valid email address.', 'bridle' ), [ 'status' => 400 ] );
			}
			$existing = $model->find_by_email( $email );
			if ( $existing && (int) $existing->id !== (int) $customer->id ) {
				return new WP_Error( 'bridle_email_taken', __( 'Another contact already uses that email. Merge the contacts instead.', 'bridle' ), [ 'status' => 409 ] );
			}
			$update['email'] = $email;
		}

		// "Always Feed" / "Always Inbox" for everything this sender sends;
		// null (or "") returns them to automatic routing.
		if ( array_key_exists( 'box_override', $params ) ) {
			$box = $params['box_override'];
			if ( null === $box || '' === $box ) {
				$update['box_override'] = null;
			} elseif ( in_array( $box, [ 'feed', 'inbox' ], true ) ) {
				$update['box_override'] = $box;
			} else {
				return new WP_Error( 'bridle_invalid_box', __( 'box_override must be "feed", "inbox" or null.', 'bridle' ), [ 'status' => 400 ] );
			}
		}

		if ( empty( $update ) ) {
			return new WP_Error( 'bridle_nothing_to_update', __( 'Nothing to update.', 'bridle' ), [ 'status' => 400 ] );
		}

		$model->update( $customer->id, $update );

		if ( array_key_exists( 'box_override', $update ) ) {
			\Bridle\Services\Counts::flush();
		}

		return new WP_REST_Response( $model->get_by_id( $customer->id ) );
	}

	public function delete_item( $request ) {
		$model    = new Customer();
		$customer = $model->get_by_id( absint( $request['id'] ) );

		if ( ! $customer ) {
			return new WP_Error( 'bridle_not_found', __( 'Contact not found.', 'bridle' ), [ 'status' => 404 ] );
		}

		// Delete all their conversations, with everything attached to them.
		( new Conversation() )->hard_delete_for_customer( (int) $customer->id );
		$model->delete( (int) $customer->id );
		\Bridle\Services\Counts::flush();

		return new WP_REST_Response( [ 'deleted' => true ] );
	}

	public function merge_customers( $request ) {
		$params    = $request->get_json_params();
		$target_id = absint( $params['target_id'] ?? 0 );
		$source_id = absint( $params['source_id'] ?? 0 );

		if ( ! $target_id || ! $source_id ) {
			return new WP_Error( 'bridle_missing_fields', __( 'Target and source contact IDs are required.', 'bridle' ), [ 'status' => 400 ] );
		}

		if ( $target_id === $source_id ) {
			return new WP_Error( 'bridle_same_customer', __( 'Cannot merge a contact with itself.', 'bridle' ), [ 'status' => 400 ] );
		}

		$model  = new Customer();
		$result = $model->merge( $target_id, $source_id );

		if ( ! $result ) {
			return new WP_Error( 'bridle_merge_failed', __( 'Merge failed. Check that both contacts exist.', 'bridle' ), [ 'status' => 400 ] );
		}

		return new WP_REST_Response( [
			'merged'   => true,
			'customer' => $model->get_by_id( $target_id ),
		] );
	}
}
