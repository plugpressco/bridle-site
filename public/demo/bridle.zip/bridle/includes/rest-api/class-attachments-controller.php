<?php

namespace Bridle\RestApi;

use Bridle\Services\AttachmentService;
use WP_Error;
use WP_REST_Controller;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Browser-side attachment upload.
 *
 * POST /bridle/v1/attachments  (multipart/form-data, field name `file`)
 *
 * Stores the upload in WP media, drops an orphan row in bridle_attachments
 * (thread_id = 0), and returns { id, url, filename, mime, size } so the
 * composer can render an inline chip immediately. The orphan row is
 * adopted by the threads controller when the message is sent, or reaped by
 * AttachmentService::purge_stale_orphans() after 24h if the user abandons.
 */
class AttachmentsController extends WP_REST_Controller {

	protected $namespace = BRIDLE_REST_NAMESPACE;
	protected $rest_base = 'attachments';

	public function register_routes(): void {
		register_rest_route( $this->namespace, '/' . $this->rest_base, [
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'create_item' ],
				'permission_callback' => [ $this, 'permissions_check' ],
				'args'                => [
					'wp_attachment_id' => [
						'type'              => 'integer',
						'required'          => false,
						'sanitize_callback' => 'absint',
					],
				],
			],
		] );
	}

	public function permissions_check( $request ) {
		return current_user_can( 'bridle_reply_conversations' )
			|| current_user_can( 'bridle_manage_conversations' )
			|| current_user_can( 'manage_options' );
	}

	public function create_item( $request ) {
		$files = $request->get_file_params();

		// Path A: raw multipart upload (drag / paste / file input).
		if ( ! empty( $files ) && isset( $files['file'] ) ) {
			$file = $files['file'];

			if ( ! empty( $file['error'] ) && UPLOAD_ERR_OK !== (int) $file['error'] ) {
				return new WP_Error( 'bridle_upload_error', $this->upload_error_message( (int) $file['error'] ), [ 'status' => 400 ] );
			}

			$result = AttachmentService::store_uploaded_file( $file );

			return is_wp_error( $result ) ? $result : new WP_REST_Response( $result, 201 );
		}

		// Path B: an existing WP Media Library item picked via window.wp.media.
		$wp_attachment_id = absint( $request->get_param( 'wp_attachment_id' ) );
		if ( $wp_attachment_id ) {
			$result = AttachmentService::store_from_media_id( $wp_attachment_id );

			return is_wp_error( $result ) ? $result : new WP_REST_Response( $result, 201 );
		}

		return new WP_Error( 'bridle_no_file', __( 'No file or media item provided.', 'bridle' ), [ 'status' => 400 ] );
	}

	private function upload_error_message( int $code ): string {
		switch ( $code ) {
			case UPLOAD_ERR_INI_SIZE:
			case UPLOAD_ERR_FORM_SIZE:
				return __( 'File is too large.', 'bridle' );
			case UPLOAD_ERR_PARTIAL:
				return __( 'File upload was interrupted.', 'bridle' );
			case UPLOAD_ERR_NO_FILE:
				return __( 'No file uploaded.', 'bridle' );
			case UPLOAD_ERR_NO_TMP_DIR:
			case UPLOAD_ERR_CANT_WRITE:
				return __( 'Server could not write the file.', 'bridle' );
			default:
				return __( 'Upload failed.', 'bridle' );
		}
	}
}
