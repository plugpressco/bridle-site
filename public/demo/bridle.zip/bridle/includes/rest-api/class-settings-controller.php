<?php

namespace Bridle\RestApi;

use WP_Error;
use WP_REST_Controller;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SettingsController extends WP_REST_Controller {

	protected $namespace = BRIDLE_REST_NAMESPACE;
	protected $rest_base = 'settings';

	public function register_routes(): void {
		// API Key.
		register_rest_route( $this->namespace, '/' . $this->rest_base . '/api-key', [
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_api_key' ],
				'permission_callback' => [ $this, 'manage_permissions_check' ],
			],
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'generate_api_key' ],
				'permission_callback' => [ $this, 'manage_permissions_check' ],
			],
			[
				'methods'             => WP_REST_Server::DELETABLE,
				'callback'            => [ $this, 'revoke_api_key' ],
				'permission_callback' => [ $this, 'manage_permissions_check' ],
			],
		] );

		// General settings (save/get).
		register_rest_route( $this->namespace, '/' . $this->rest_base, [
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_settings' ],
				'permission_callback' => [ $this, 'manage_permissions_check' ],
			],
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'save_settings' ],
				'permission_callback' => [ $this, 'manage_permissions_check' ],
			],
		] );

		// Per-agent workspace preferences. Deliberately NOT gated on
		// manage_options like the routes above — these are one agent's own
		// layout, and every agent who can work a conversation may set them.
		register_rest_route( $this->namespace, '/preferences', [
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'save_preferences' ],
				'permission_callback' => [ $this, 'workspace_permissions_check' ],
			],
		] );

		// Onboarding complete.
		register_rest_route( $this->namespace, '/onboarding/complete', [
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'complete_onboarding' ],
				'permission_callback' => [ $this, 'manage_permissions_check' ],
			],
		] );

		// Detect SMTP plugin.
		register_rest_route( $this->namespace, '/' . $this->rest_base . '/detect-smtp', [
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'detect_smtp' ],
				'permission_callback' => [ $this, 'manage_permissions_check' ],
			],
		] );

		// Teammates.
		register_rest_route( $this->namespace, '/teammates', [
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_teammates' ],
				'permission_callback' => function() {
					return current_user_can( 'bridle_manage_conversations' ) || current_user_can( 'bridle_reply_conversations' );
				},
			],
		] );

		// Add / remove teammate.
		register_rest_route( $this->namespace, '/teammates/(?P<user_id>[\d]+)', [
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'add_teammate' ],
				'permission_callback' => [ $this, 'manage_permissions_check' ],
			],
			[
				'methods'             => WP_REST_Server::DELETABLE,
				'callback'            => [ $this, 'remove_teammate' ],
				'permission_callback' => [ $this, 'manage_permissions_check' ],
			],
		] );

		// List all WP users (for "add teammate" picker).
		register_rest_route( $this->namespace, '/users', [
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_wp_users' ],
				'permission_callback' => [ $this, 'manage_permissions_check' ],
			],
		] );

		// Danger Zone — erase all plugin data (explicit, confirmed action).
		register_rest_route( $this->namespace, '/' . $this->rest_base . '/erase-all-data', [
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'erase_all_data' ],
				'permission_callback' => [ $this, 'manage_permissions_check' ],
			],
		] );

	}

	public function manage_permissions_check( $request ) {
		return current_user_can( 'bridle_manage_settings' ) || current_user_can( 'manage_options' );
	}

	/**
	 * Anyone who works conversations may set their own workspace preferences.
	 */
	public function workspace_permissions_check( $request ) {
		return current_user_can( 'bridle_manage_conversations' ) || current_user_can( 'manage_options' );
	}

	/**
	 * Persist a partial preference update for the current user.
	 */
	public function save_preferences( $request ) {
		$changes = [];

		// inboxScope: an inbox id, or 0 to go back to all inboxes (UserPrefs maps 0 to null).
		foreach ( [ 'sidebarCollapsed', 'panelOpen', 'density', 'inboxScope' ] as $key ) {
			if ( null !== $request->get_param( $key ) ) {
				$changes[ $key ] = $request->get_param( $key );
			}
		}

		return rest_ensure_response( \Bridle\Services\UserPrefs::save( $changes ) );
	}

	// Danger Zone

	/**
	 * Erase ALL plugin data, then recreate a clean install.
	 *
	 * Defence in depth: refuses unless the request body carries
	 * confirm === 'DELETE'. Never erases without that token.
	 */
	public function erase_all_data( $request ) {
		$confirm = $request->get_param( 'confirm' );

		if ( 'DELETE' !== $confirm ) {
			return new WP_Error(
				'bridle_confirm_required',
				__( 'Confirmation token missing. Type DELETE to confirm.', 'bridle' ),
				[ 'status' => 400 ]
			);
		}

		\Bridle\Activator::delete_all_data();

		return new WP_REST_Response( [ 'erased' => true ] );
	}

	// General Settings

	public function get_settings( $request ) {
		$response = \Bridle\Services\Settings::all();
		// Defaults that are derived from other WP state, not stored as
		// settings — apply them when the user hasn't set their own value.
		if ( empty( $response['notification_email'] ) ) {
			$response['notification_email'] = get_option( 'admin_email' );
		}
		// onboarding_done lives outside the settings tree.
		$response['onboarding_done'] = (bool) get_option( 'bridle_onboarding_done', false );
		return new WP_REST_Response( $response );
	}

	public function save_settings( $request ) {
		$params = $request->get_json_params();

		// Sanitize per allowlisted key. wp_kses_post for the email body
		// template; sanitize_text_field for everything else. REST params
		// are not slashed, so nothing is unslashed (#104).
		$html_keys = [ 'auto_reply_body' ];
		$clean     = [];

		foreach ( $params as $key => $value ) {
			if ( ! array_key_exists( $key, \Bridle\Services\Settings::DEFAULTS ) ) {
				continue;
			}
			if ( is_bool( $value ) ) {
				$clean[ $key ] = $value;
			} elseif ( 'agent_instructions' === $key ) {
				// Plain text for the model: keep line breaks, drop markup.
				$clean[ $key ] = sanitize_textarea_field( (string) $value );
			} elseif ( in_array( $key, $html_keys, true ) ) {
				$clean[ $key ] = wp_kses_post( $value );
			} else {
				$clean[ $key ] = sanitize_text_field( (string) $value );
			}
		}

		\Bridle\Services\Settings::update_many( $clean );

		return new WP_REST_Response( [ 'saved' => true ] );
	}

	// Onboarding

	public function complete_onboarding( $request ) {
		update_option( 'bridle_onboarding_done', true );
		return new WP_REST_Response( [ 'done' => true ] );
	}

	// SMTP Detection

	public function detect_smtp( $request ) {
		$smtp_plugins = [
			'mailyard/mailyard.php'                     => 'Mailyard',
			'fluent-smtp/fluent-smtp.php'               => 'FluentSMTP',
			'wp-mail-smtp/wp_mail_smtp.php'             => 'WP Mail SMTP',
			'post-smtp/postman-smtp.php'                => 'Post SMTP',
			'easy-wp-smtp/easy-wp-smtp.php'             => 'Easy WP SMTP',
			'smtp-mailer/main.php'                      => 'SMTP Mailer',
			'wp-smtp/wp-smtp.php'                       => 'WP SMTP',
		];

		$active_plugins = (array) get_option( 'active_plugins', [] );

		foreach ( $smtp_plugins as $path => $name ) {
			if ( in_array( $path, $active_plugins, true ) ) {
				return new WP_REST_Response( [
					'found'      => true,
					'name'       => $name,
					'slug'       => dirname( $path ),
					'configured' => true,
				] );
			}
		}

		return new WP_REST_Response( [
			'found'      => false,
			'name'       => null,
			'slug'       => null,
			'configured' => false,
		] );
	}

	// API Key

	public function get_api_key( $request ) {
		$key = get_option( 'bridle_api_key', '' );

		return new WP_REST_Response( [
			'has_key'    => ! empty( $key ),
			'key_prefix' => ! empty( $key ) ? substr( $key, 0, 8 ) . '...' : '',
			'created_at' => get_option( 'bridle_api_key_created', '' ),
		] );
	}

	public function generate_api_key( $request ) {
		$key = 'bridle_live_' . wp_generate_password( 28, false );

		update_option( 'bridle_api_key', $key );
		update_option( 'bridle_api_key_created', current_time( 'mysql', true ) );

		return new WP_REST_Response( [
			'key'        => $key,
			'has_key'    => true,
			'key_prefix' => substr( $key, 0, 12 ) . '...',
			'created_at' => get_option( 'bridle_api_key_created', '' ),
		], 201 );
	}

	public function revoke_api_key( $request ) {
		delete_option( 'bridle_api_key' );
		delete_option( 'bridle_api_key_created' );

		return new WP_REST_Response( [ 'has_key' => false ] );
	}

	// Teammates

	public function get_teammates( $request ) {
		$users = get_users( [
			'capability__in' => [ 'bridle_manage_conversations', 'bridle_reply_conversations', 'manage_options' ],
			'orderby'        => 'display_name',
			'order'          => 'ASC',
		] );

		$result = [];
		foreach ( $users as $user ) {
			$result[] = [
				'id'           => $user->ID,
				'display_name' => $user->display_name,
				'email'        => $user->user_email,
				'avatar_url'   => \Bridle\Services\Avatars::url( $user->ID, 96 ),
			];
		}

		return new WP_REST_Response( $result );
	}

	public function add_teammate( $request ) {
		$user_id = absint( $request['user_id'] );
		$user    = get_userdata( $user_id );

		if ( ! $user ) {
			return new WP_Error( 'bridle_user_not_found', __( 'User not found.', 'bridle' ), [ 'status' => 404 ] );
		}

		// Don't add if already a teammate.
		if ( $user->has_cap( 'bridle_reply_conversations' ) ) {
			return new WP_REST_Response( [
				'id'           => $user->ID,
				'display_name' => $user->display_name,
				'email'        => $user->user_email,
				'avatar_url'   => \Bridle\Services\Avatars::url( $user->ID, 96 ),
				'role'         => 'agent',
			] );
		}

		$user->add_role( 'bridle_support_agent' );
		$user->add_cap( 'bridle_manage_conversations' );
		$user->add_cap( 'bridle_reply_conversations' );

		return new WP_REST_Response( [
			'id'           => $user->ID,
			'display_name' => $user->display_name,
			'email'        => $user->user_email,
			'avatar_url'   => \Bridle\Services\Avatars::url( $user->ID, 96 ),
			'role'         => 'agent',
		], 201 );
	}

	public function remove_teammate( $request ) {
		$user_id = absint( $request['user_id'] );
		$user    = get_userdata( $user_id );

		if ( ! $user ) {
			return new WP_Error( 'bridle_user_not_found', __( 'User not found.', 'bridle' ), [ 'status' => 404 ] );
		}

		// Don't remove admins — they always have access.
		if ( $user->has_cap( 'manage_options' ) ) {
			return new WP_Error( 'bridle_cannot_remove_admin', __( 'Cannot remove administrators.', 'bridle' ), [ 'status' => 400 ] );
		}

		$user->remove_role( 'bridle_support_agent' );
		$user->remove_cap( 'bridle_manage_conversations' );
		$user->remove_cap( 'bridle_reply_conversations' );

		return new WP_REST_Response( [ 'removed' => true ] );
	}

	public function get_wp_users( $request ) {
		$users = get_users( [
			'orderby' => 'display_name',
			'order'   => 'ASC',
			'number'  => 50,
		] );

		$result = [];
		foreach ( $users as $user ) {
			$is_teammate = $user->has_cap( 'bridle_reply_conversations' ) || $user->has_cap( 'manage_options' );
			$result[] = [
				'id'           => $user->ID,
				'display_name' => $user->display_name,
				'email'        => $user->user_email,
				'avatar_url'   => \Bridle\Services\Avatars::url( $user->ID, 96 ),
				'is_teammate'  => $is_teammate,
				'is_admin'     => $user->has_cap( 'manage_options' ),
			];
		}

		return new WP_REST_Response( $result );
	}
}
