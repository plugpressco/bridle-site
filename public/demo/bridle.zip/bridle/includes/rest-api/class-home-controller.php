<?php
/**
 * GET /home: Home's numbers and the agent's health (#112).
 *
 * @package Bridle
 */

namespace Bridle\RestApi;

use Bridle\Services\HomeSummary;
use WP_REST_Controller;
use WP_REST_Response;
use WP_REST_Server;

defined( 'ABSPATH' ) || exit;

/**
 * One read-only route. Home's lists come from GET /conversations like the
 * Inbox's; this adds only what no other route has.
 */
class HomeController extends WP_REST_Controller {

	protected $namespace = BRIDLE_REST_NAMESPACE;
	protected $rest_base = 'home';

	public function register_routes(): void {
		register_rest_route( $this->namespace, '/' . $this->rest_base, [
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_summary' ],
				'permission_callback' => [ $this, 'permissions_check' ],
			],
		] );
	}

	public function permissions_check( $request ) {
		return current_user_can( 'bridle_manage_conversations' ) || current_user_can( 'bridle_reply_conversations' );
	}

	public function get_summary( $request ) {
		return new WP_REST_Response( HomeSummary::build() );
	}
}
