<?php

namespace Bridle\Integrations;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Built-in WooCommerce integration.
 *
 * Auto-registered by Plugin::init() when WooCommerce is active.
 * Adds an "Orders" card to the Bridle contact panel showing:
 *   - Order count + LTV
 *   - Last order date
 *   - Active / Lapsed status (lapsed = no order in 180 days)
 *
 * The card links directly to the WooCommerce orders screen filtered
 * by the customer's email address.
 */
class WooCommerce {

	public static function register(): void {
		// Registered at plugins_loaded, before translations may load (WP 6.7+
		// notices that), so the translated title comes with the card instead.
		\Bridle\IntegrationRegistry::register( 'woocommerce', [
			'title' => 'WooCommerce',
			'fetch' => [ self::class, 'fetch' ],
		] );
	}

	/**
	 * @param string $email Customer email.
	 * @return array|null Card data or null to hide the card.
	 */
	public static function fetch( string $email ): ?array {
		$user = get_user_by( 'email', $email );
		if ( ! $user ) {
			return null;
		}

		$customer = new \WC_Customer( $user->ID );
		$order_count = $customer->get_order_count();
		if ( 0 === $order_count ) {
			return null;
		}

		$total_spent = (float) $customer->get_total_spent();

		$last_orders = wc_get_orders( [
			'customer' => $email,
			'limit'    => 1,
			'orderby'  => 'date',
			'order'    => 'DESC',
			'return'   => 'objects',
		] );

		$last_date = '';
		$lapsed    = true;
		if ( ! empty( $last_orders ) ) {
			$created   = $last_orders[0]->get_date_created();
			$last_date = $created ? $created->date_i18n( get_option( 'date_format' ) ) : '';
			$lapsed    = $created && ( time() - $created->getTimestamp() > 180 * DAY_IN_SECONDS );
		}

		$symbol = get_woocommerce_currency_symbol();

		return [
			'title'  => __( 'WooCommerce', 'bridle' ),
			'status' => $lapsed
				? [ 'label' => __( 'Lapsed', 'bridle' ),  'tone' => 'muted' ]
				: [ 'label' => __( 'Active', 'bridle' ),  'tone' => 'green' ],
			'rows'   => [
				[ __( 'Orders',      'bridle' ), (string) $order_count ],
				[ __( 'Total spent', 'bridle' ), $symbol . number_format( $total_spent, 2 ) ],
				[ __( 'Last order',  'bridle' ), $last_date ?: '—' ],
			],
			'link'   => admin_url( 'edit.php?post_type=shop_order&s=' . rawurlencode( $email ) . '&action=-1' ),
		];
	}
}
