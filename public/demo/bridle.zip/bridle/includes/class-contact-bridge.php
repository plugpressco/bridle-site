<?php

namespace Bridle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Cross-plugin contact federation (read-only, no coupling).
 *
 * PlugPress products share one convention — the `plugpress_contact_cards`
 * filter — so each can show "this person also exists over there" inside its
 * own contact panel, keyed only by email. There is NO shared table and NO
 * hard dependency: a product registers a provider that contributes a card,
 * and consumes the filter to render cards from the others. If no sibling
 * plugin is active, the filter returns an empty array and the panel section
 * simply hides itself.
 *
 *   apply_filters( 'plugpress_contact_cards', array $cards, string $email, string $requesting_slug )
 *
 * A provider skips when it is the one asking (a product never shows a card
 * about itself). Card shape (renderer-agnostic):
 *   [ 'source' => 'bridle', 'title' => 'Support',
 *     'status' => [ 'label' => '2 open', 'tone' => 'green' ],
 *     'rows'   => [ [ 'Conversations', '5' ], [ 'Last activity', '2 days ago' ] ],
 *     'link'   => 'https://site/wp-admin/admin.php?page=bridle#/inbox' ]
 */
class ContactBridge {

	const SLUG = 'bridle';

	public static function init(): void {
		add_filter( 'plugpress_contact_cards', [ self::class, 'provide' ], 10, 3 );
	}

	/**
	 * Contribute an Bridle "Support" card for a contact email.
	 *
	 * @param array  $cards      Cards accumulated so far.
	 * @param string $email      Contact email being looked up.
	 * @param string $requesting Slug of the product rendering the panel.
	 * @return array
	 */
	public static function provide( array $cards, string $email, string $requesting ): array {
		if ( self::SLUG === $requesting ) {
			return $cards;   // never show our own card inside our own panel
		}

		$customer = ( new Models\Customer() )->find_by_email( $email );
		if ( ! $customer ) {
			return $cards;
		}

		global $wpdb;
		$conv = $wpdb->prefix . 'bridle_conversations';

		$open = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM %i WHERE customer_id = %d AND status NOT IN ( 'closed', 'spam', 'trash' )",
			$conv,
			$customer->id
		) );
		$total = (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(*) FROM %i WHERE customer_id = %d',
			$conv,
			$customer->id
		) );
		$last = $wpdb->get_var( $wpdb->prepare(
			'SELECT last_activity_at FROM %i WHERE customer_id = %d ORDER BY last_activity_at DESC LIMIT 1',
			$conv,
			$customer->id
		) );

		$cards[] = [
			'source' => self::SLUG,
			'title'  => __( 'Support', 'bridle' ),
			'status' => $open > 0
				/* translators: %d open conversation count. */
				? [ 'label' => sprintf( _n( '%d open', '%d open', $open, 'bridle' ), $open ), 'tone' => 'green' ]
				: [ 'label' => __( 'No open', 'bridle' ), 'tone' => 'muted' ],
			'rows'   => [
				[ __( 'Conversations', 'bridle' ), (string) $total ],
				[ __( 'Last activity', 'bridle' ), $last ? self::ago( $last ) : '—' ],
			],
			'link'   => admin_url( 'admin.php?page=bridle#/inbox' ),
		];

		return $cards;
	}

	/** Human "x ago" from a UTC MySQL datetime. */
	private static function ago( string $mysql ): string {
		$ts = strtotime( $mysql . ' UTC' );
		if ( ! $ts ) {
			return '';
		}
		/* translators: %s human time difference, e.g. "2 days". */
		return sprintf( __( '%s ago', 'bridle' ), human_time_diff( $ts, time() ) );
	}
}
