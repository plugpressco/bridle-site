<?php

namespace Bridle\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AdminPage {

	/**
	 * Keeps the WP submenu highlight on the Bridle route that owns the hash.
	 */
	private const MENU_SYNC_JS = <<<'JS'
(function(){
	var adminMenu = document.getElementById( 'adminmenu' );
	if ( ! adminMenu ) { return; }
	var links = adminMenu.querySelectorAll( 'a[href*="bridle#/"], a[href$="page=bridle"]' );
	var map = {};
	links.forEach( function( a ) {
		var m = a.href.match( /bridle#(\/[a-z0-9\/-]*)/ );
		var hash = m ? m[ 1 ] : '/';
		map[ hash ] = a.parentElement;
		a.addEventListener( 'click', function( e ) {
			e.preventDefault();
			window.location.hash = hash;
		} );
	} );
	// Collapse each shell route to the submenu item that owns it: Home, Settings, or the Inbox.
	function canonical( hash ) {
		hash = hash.replace( /\?.*$/, '' );
		if ( /^\/settings/.test( hash ) ) { return '/settings'; }
		if ( hash === '/' || /^\/home/.test( hash ) ) { return '/'; }
		return '/inbox';
	}
	function syncActive() {
		var hash = canonical( window.location.hash.replace( /^#/, '' ) || '/' );
		Object.values( map ).forEach( function( li ) { li.classList.remove( 'current' ); } );
		var li = map[ hash ] || map[ '/' ];
		if ( li ) { li.classList.add( 'current' ); }
	}
	window.addEventListener( 'hashchange', syncActive );
	syncActive();
})();
JS;

	public static function render(): void {
		// Minimal pre-hydrate state. The spinner lives inside #bridle-root
		// and is wiped when React mounts. The root itself stays a plain
		// block so the React tree's own layout (flex columns, full-width
		// pages, etc.) is never fought by inline styles on the host.
		echo '<div id="bridle-root">'
			// Admin-bar height is 32px on desktop but 46px below 782px — WordPress
			// exposes it as a custom property, so don't hardcode either.
			. '<div style="min-height:calc(100vh - var(--wp-admin--admin-bar--height, 32px));background:#F5F5F2;display:flex;align-items:center;justify-content:center">'
			. '<div style="width:18px;height:18px;border:2px solid #E6E6E1;border-top-color:#679EEE;border-radius:50%;animation:bridle-spin 0.7s linear infinite"></div>'
			. '</div>'
			. '</div>';
	}

	public static function register(): void {
		add_action( 'admin_enqueue_scripts', [ self::class, 'enqueue_assets' ] );
		add_action( 'admin_enqueue_scripts', [ self::class, 'enqueue_commands' ] );

		// The WordPress admin menu is left exactly as the user has it. (It
		// used to be folded to its icon rail on this screen; the owner wants
		// the sidebar kept, so the shell's column widths assume ~160px less.)
	}

	/**
	 * Bridle in WordPress's command palette (⌘K) on every admin screen: the
	 * boxes, the Settings pages and a conversation search. Only where
	 * WordPress has the palette, and only for people who manage
	 * conversations.
	 */
	public static function enqueue_commands(): void {
		if ( ! current_user_can( 'bridle_manage_conversations' ) || ! wp_script_is( 'wp-commands', 'registered' ) ) {
			return;
		}
		$asset_file = BRIDLE_PLUGIN_DIR . 'build/commands.asset.php';
		if ( ! file_exists( $asset_file ) ) {
			return;
		}
		$asset = require $asset_file;

		wp_enqueue_script(
			'bridle-commands',
			BRIDLE_PLUGIN_URL . 'build/commands.js',
			array_unique( array_merge( (array) $asset['dependencies'], [ 'wp-commands', 'wp-data' ] ) ),
			(string) $asset['version'],
			true
		);
		wp_set_script_translations( 'bridle-commands', 'bridle', BRIDLE_PLUGIN_DIR . 'languages' );
		wp_add_inline_script(
			'bridle-commands',
			'window.bridleCommands = ' . wp_json_encode(
				[
					'base'     => esc_url_raw( admin_url( 'admin.php?page=bridle' ) ),
					'settings' => current_user_can( 'bridle_manage_settings' ),
				]
			) . ';',
			'before'
		);
	}

	public static function enqueue_assets( string $hook ): void {
		// One React bundle, one admin page (?page=bridle). All "sub-pages"
		// are just hash routes the SPA reads from window.location.hash.
		if ( 'toplevel_page_bridle' !== $hook ) {
			return;
		}

		$asset_file = BRIDLE_PLUGIN_DIR . 'build/app.asset.php';
		$asset      = file_exists( $asset_file ) ? require $asset_file : [
			'dependencies' => [],
			'version'      => BRIDLE_VERSION,
		];

		/**
		 * Scripts that must run before Bridle's app: an add-on (Bridle Pro)
		 * registers its `bridle.*` JS filters there, so they apply on the
		 * app's first render. Return handles of scripts already registered.
		 *
		 * @param string[] $handles Script handles.
		 */
		$before = array_values( array_filter( (array) apply_filters( 'bridle_admin_script_dependencies', [] ), 'is_string' ) );

		wp_enqueue_script(
			'bridle-admin',
			BRIDLE_PLUGIN_URL . 'build/app.js',
			array_merge( $asset['dependencies'], $before ),
			$asset['version'],
			true
		);

		// Defer script — don't block DOM parsing.
		wp_script_add_data( 'bridle-admin', 'strategy', 'defer' );

		wp_enqueue_style(
			'bridle-admin',
			BRIDLE_PLUGIN_URL . 'build/app.css',
			[],
			$asset['version']
		);

		// WP submenu ↔ React router bridge. Each Bridle sub-page is a hash
		// route on the same toplevel admin page; clicks update the hash and
		// the active highlight follows window.location.hash.
		wp_register_script( 'bridle-admin-menu', false, [], BRIDLE_VERSION, true );
		wp_enqueue_script( 'bridle-admin-menu' );
		wp_add_inline_script( 'bridle-admin-menu', self::MENU_SYNC_JS );

		// JS strings from languages/, and the mirrored build/app-rtl.css for RTL locales.
		wp_set_script_translations( 'bridle-admin', 'bridle', BRIDLE_PLUGIN_DIR . 'languages' );
		wp_style_add_data( 'bridle-admin', 'rtl', 'replace' );

		$has_api_key     = ! empty( get_option( 'bridle_api_key', '' ) );
		// Only finishing onboarding sets this. A reload halfway through (the
		// inbox exists, forwarding isn't done) resumes the conversation.
		$onboarding_done = (bool) get_option( 'bridle_onboarding_done', false );
		$current_user = wp_get_current_user();

		// Pre-fetch initial data to eliminate API calls on mount.
		$inboxes = array_map(
			static function ( $inbox ) {
				unset( $inbox->webhook_secret ); // Matched by the email worker; the browser never needs it.
				return $inbox;
			},
			( new \Bridle\Models\Inbox() )->list()
		);

		wp_localize_script( 'bridle-admin', 'bridleData', [
			'apiRoot'        => esc_url_raw( rest_url() ),
			'nonce'          => wp_create_nonce( 'wp_rest' ),
			'siteUrl'        => esc_url_raw( home_url() ),
			// Bridle Pro's version while it is active, else ''.
			'pro'            => defined( 'BRIDLE_PRO_VERSION' ) ? (string) BRIDLE_PRO_VERSION : '',
			'siteName'       => get_bloginfo( 'name' ),
			'adminUrl'       => esc_url_raw( admin_url() ),
			'version'        => BRIDLE_VERSION,
			'hasApiKey'      => $has_api_key,
			'onboardingDone' => $onboarding_done,
			'userName'       => $current_user->display_name,
			'userEmail'      => $current_user->user_email,
			'userId'         => $current_user->ID,
			'userAvatar'     => \Bridle\Services\Avatars::url( $current_user->ID, 96 ),
			'initialInboxes' => $inboxes,
			'userPrefs'      => \Bridle\Services\UserPrefs::get( $current_user->ID ),
			'forwardingDrift' => \Bridle\Services\WorkerSyncService::get_drift(),
			// Days a conversation stays in Trash (0: until emptied).
			'trashDays'      => \Bridle\Services\TrashPurge::days(),
			// Whether anything can answer (own key or Bridle AI): rewrite shows only then.
			'canUseAi'       => \Bridle\Services\AiService::can_use_ai(),
		] );
	}
}
