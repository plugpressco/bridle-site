<?php

namespace Bridle\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AdminMenu {

	public function register(): void {
		add_action( 'admin_menu', [ $this, 'add_menu' ] );
		// After Bridle KB adds Docs (priority 20): Home · Inbox · Docs · Settings.
		add_action( 'admin_menu', [ $this, 'order_submenu' ], 99 );
		add_filter( 'plugin_action_links_' . plugin_basename( BRIDLE_PLUGIN_FILE ), [ $this, 'action_links' ] );
		// Priority 100: after WordPress's own nodes, so Bridle sits alongside
		// Comments rather than jumping ahead of core chrome.
		add_action( 'admin_bar_menu', [ $this, 'add_admin_bar' ], 100 );
		// The admin bar renders on the front end too, so the icon needs its
		// styles on both sides.
		add_action( 'admin_enqueue_scripts', [ $this, 'add_admin_bar_styles' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'add_admin_bar_styles' ] );
		add_action( 'admin_menu', [ $this, 'hide_menus_for_agents' ], 999 );
		add_action( 'admin_bar_menu', [ $this, 'clean_admin_bar_for_agents' ], 999 );
	}

	public function add_menu(): void {
		$capability   = 'bridle_manage_conversations';
		$settings_cap = 'bridle_manage_settings';

		// Top-level "Bridle" menu — the inbox workspace.
		// The Bridle mark (ring and rein, small cut), delivered as a base64
		// SVG data URI. WordPress's svg-painter tints it per colour scheme
		// and state by rewriting the `fill` attribute, so it must be one
		// filled path (strokes are never recoloured). The raw fill is a
		// neutral grey that reads on every dark scheme until the painter runs.
		$icon_svg = '<svg viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"><path fill="#a7aaad" fill-rule="evenodd" d="M12.61 41.42L4.65 3.98L14.91 1.8L19.06 21.36A21.18 21.18 0 1 1 12.61 41.42ZM23.05 37.02a10.28 10.28 0 1 0 20.55 0a10.28 10.28 0 1 0 -20.55 0Z"/></svg>';
		$icon_uri = 'data:image/svg+xml;base64,' . base64_encode( $icon_svg );

		add_menu_page(
			__( 'Bridle', 'bridle' ),
			// Same bubble Comments uses for pending moderation, for the same
			// reason: an agent should see there is mail waiting without opening
			// the workspace first. Counts open conversations — the customer
			// spoke last, the ball is in our court — not those Waiting on the
			// customer, so a busy inbox that is fully answered shows nothing.
			__( 'Bridle', 'bridle' ) . self::count_bubble(),
			$capability,
			'bridle',
			[ AdminPage::class, 'render' ],
			$icon_uri,
			// PlugPress ecosystem menu band (see @plugpress/ui php/menu-positions.php).
			'58.10'
		);

		// WordPress names every sub-page's hook after the parent's menu title,
		// sanitized, and ours carries the count bubble: with three open
		// conversations a sibling's page would hook as
		// `bridle-33-open-conversations_page_bridle-kb`. Pin it to the slug so
		// pages added under this menu (Bridle KB's Knowledge base) keep one
		// hook name.
		$GLOBALS['admin_page_hooks']['bridle'] = 'bridle'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- the documented way to fix a bubbled menu title's hook prefix (WooCommerce does the same).

		// All sub-pages share the same WP-admin page (?page=bridle) and use
		// the URL fragment for routing. WordPress treats the slug as the
		// link target, so a slug like "bridle#/customers" produces
		// admin.php?page=bridle#/customers — same document, hash changes,
		// no full reload, no second React bundle mount.
		// Home is the first screen (#112): the parent's own page.
		add_submenu_page(
			'bridle',
			__( 'Home', 'bridle' ),
			__( 'Home', 'bridle' ),
			$capability,
			'bridle',
			[ AdminPage::class, 'render' ]
		);

		add_submenu_page(
			'bridle',
			__( 'Inbox', 'bridle' ),
			__( 'Inbox', 'bridle' ),
			$capability,
			'bridle#/inbox',
			'__return_null'
		);

		// Two menus of Bridle's own: Updates, Resolved, Spam and Trash are
		// views inside the Inbox, not places of their own. Bridle KB, when
		// active, adds Knowledge base between these two (docs/design-system.md).
		add_submenu_page(
			'bridle',
			__( 'Settings', 'bridle' ),
			__( 'Settings', 'bridle' ),
			$settings_cap,
			'bridle#/settings',
			'__return_null'
		);
	}

	/**
	 * Bubble markup for the menu title, or '' when there is nothing waiting.
	 *
	 * Reuses core's `awaiting-mod` / `pending-count` classes rather than
	 * inventing our own: they are already styled in every admin colour scheme,
	 * including the ones a site owner picked, and they animate on update.
	 */
	private static function count_bubble(): string {
		if ( ! current_user_can( 'bridle_manage_conversations' ) ) {
			return '';
		}

		$awaiting = \Bridle\Services\Counts::for_chrome()['awaiting'];
		if ( $awaiting < 1 ) {
			return '';
		}

		return sprintf(
			' <span class="awaiting-mod count-%1$d"><span class="pending-count" aria-hidden="true">%2$s</span><span class="screen-reader-text">%3$s</span></span>',
			$awaiting,
			esc_html( number_format_i18n( $awaiting ) ),
			esc_html( sprintf(
				/* translators: %s: number of open conversations. */
				_n( '%s open conversation', '%s open conversations', $awaiting, 'bridle' ),
				number_format_i18n( $awaiting )
			) )
		);
	}

	/**
	 * Admin-bar node — the count follows you onto the front end too.
	 *
	 * Modelled on core's Comments node: an icon plus a count, with a submenu
	 * that breaks the number down so it is actionable rather than just alarming.
	 */
	/**
	 * Bridle's row on the Plugins screen: Settings, and while Bridle Pro isn't
	 * active, a plain "Get Pro" link (one of Pro's three quiet places, #118).
	 *
	 * @param string[] $links The row's action links.
	 * @return string[]
	 */
	public function action_links( $links ): array {
		$links = (array) $links;
		array_unshift(
			$links,
			sprintf( '<a href="%s">%s</a>', esc_url( admin_url( 'admin.php?page=bridle#/settings' ) ), esc_html__( 'Settings', 'bridle' ) )
		);
		if ( ! defined( 'BRIDLE_PRO_VERSION' ) ) {
			$links[] = sprintf(
				'<a href="%s" target="_blank" rel="noopener noreferrer">%s</a>',
				esc_url( 'https://bridle.to/pro/?utm_source=plugin&utm_medium=plugins-row&utm_campaign=pro' ),
				esc_html__( 'Get Pro', 'bridle' )
			);
		}
		return $links;
	}

	/**
	 * Keep Bridle's menu in one order whatever position other plugins ask for:
	 * Home, Inbox, then anything added (Bridle KB's Docs), Settings last.
	 */
	public function order_submenu(): void {
		global $submenu;
		if ( empty( $submenu['bridle'] ) || ! is_array( $submenu['bridle'] ) ) {
			return;
		}
		$rank = static function ( array $item ): int {
			$slug = (string) ( $item[2] ?? '' );
			if ( 'bridle' === $slug ) {
				return 0;
			}
			if ( 'bridle#/inbox' === $slug ) {
				return 1;
			}
			return 'bridle#/settings' === $slug ? 3 : 2;
		};
		$items = array_values( $submenu['bridle'] );
		usort( $items, static fn( $a, $b ) => $rank( $a ) <=> $rank( $b ) );
		$submenu['bridle'] = $items; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- ordering our own submenu.
	}

	public function add_admin_bar( $wp_admin_bar ): void {
		if ( ! is_admin_bar_showing() || ! current_user_can( 'bridle_manage_conversations' ) ) {
			return;
		}

		$counts   = \Bridle\Services\Counts::for_chrome();
		$awaiting = $counts['awaiting'];
		$base     = admin_url( 'admin.php?page=bridle#/inbox' );

		$label = $awaiting > 0
			? sprintf(
				/* translators: %s: number of open conversations. */
				_n( '%s open conversation', '%s open conversations', $awaiting, 'bridle' ),
				number_format_i18n( $awaiting )
			)
			: __( 'Bridle — nothing open', 'bridle' );

		$wp_admin_bar->add_node( [
			'id'    => 'bridle',
			'title' => '<span class="ab-icon" aria-hidden="true">' . self::admin_bar_icon() . '</span>'
				. '<span class="ab-label awaiting-mod pending-count count-' . (int) $awaiting . '" aria-hidden="true">' . esc_html( number_format_i18n( $awaiting ) ) . '</span>'
				. '<span class="screen-reader-text">' . esc_html( $label ) . '</span>',
			'href'  => $base,
			'meta'  => [ 'title' => $label ],
		] );

		$views = [
			'bridle-open'    => [ __( 'Open', 'bridle' ), $awaiting, $base ],
			'bridle-waiting' => [ __( 'Waiting', 'bridle' ), max( 0, $counts['open'] - $awaiting ), $base ],
		];

		foreach ( $views as $id => [ $title, $count, $href ] ) {
			$wp_admin_bar->add_node( [
				'parent' => 'bridle',
				'id'     => $id,
				'title'  => esc_html( $title ) . ' (' . esc_html( number_format_i18n( $count ) ) . ')',
				'href'   => $href,
			] );
		}
	}

	/**
	 * `.ab-icon` is built for a dashicon glyph — give the inline SVG the same
	 * box so it lines up with Comments and Updates beside it.
	 */
	public function add_admin_bar_styles(): void {
		if ( ! is_admin_bar_showing() || ! current_user_can( 'bridle_manage_conversations' ) ) {
			return;
		}
		wp_add_inline_style(
			'admin-bar',
			'#wpadminbar #wp-admin-bar-bridle .ab-icon { width: 20px; height: 20px; margin-right: 6px; }'
			. '#wpadminbar #wp-admin-bar-bridle .ab-icon svg { display: block; width: 20px; height: 20px; margin-top: 6px; }'
			. '#wpadminbar #wp-admin-bar-bridle .ab-icon::before { content: none; }'
		);
	}

	/**
	 * The brand glyph, sized for the admin bar.
	 *
	 * Inline rather than the base64 data URI the menu uses: admin-bar icons
	 * inherit `color` from the bar's hover states, and a data URI cannot.
	 */
	private static function admin_bar_icon(): string {
		return '<svg viewBox="0 0 60 60" width="20" height="20" style="vertical-align:text-bottom" focusable="false" aria-hidden="true">'
			. '<path fill="currentColor" fill-rule="evenodd" d="M12.61 41.42L4.65 3.98L14.91 1.8L19.06 21.36A21.18 21.18 0 1 1 12.61 41.42ZM23.05 37.02a10.28 10.28 0 1 0 20.55 0a10.28 10.28 0 1 0 -20.55 0Z" />'
			. '</svg>';
	}

	/**
	 * Hide all WP admin menus for Support Agent role.
	 * They should only see the Bridle page.
	 */
	public function hide_menus_for_agents(): void {
		if ( ! self::is_support_agent() ) {
			return;
		}

		global $menu;

		if ( ! is_array( $menu ) ) {
			return;
		}

		foreach ( $menu as $key => $item ) {
			// Keep Bridle menu, remove everything else.
			if ( isset( $item[2] ) && 'bridle' !== $item[2] ) {
				remove_menu_page( $item[2] );
			}
		}
	}

	/**
	 * Clean admin bar for Support Agents.
	 */
	public function clean_admin_bar_for_agents( $wp_admin_bar ): void {
		if ( ! self::is_support_agent() ) {
			return;
		}

		$wp_admin_bar->remove_node( 'wp-logo' );
		$wp_admin_bar->remove_node( 'comments' );
		$wp_admin_bar->remove_node( 'new-content' );
		$wp_admin_bar->remove_node( 'updates' );
	}

	/**
	 * Check if current user is a Support Agent (not admin).
	 */
	private static function is_support_agent(): bool {
		$user = wp_get_current_user();
		return in_array( 'bridle_support_agent', (array) $user->roles, true );
	}
}
