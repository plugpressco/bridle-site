<?php

namespace Bridle\Abilities;

use Bridle\Services\AgentPrompt;
use Bridle\Services\AgentService;
use Bridle\Services\AutoSend;
use Bridle\Services\KnowledgeSearch;
use Bridle\Services\KnowledgeText;
use Bridle\Services\ReplyService;
use Bridle\Services\Settings;
use WP_Error;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Abilities that help answer: search-knowledge, draft-reply, send-reply,
 * add-note. An external agent's reply lands as the conversation's draft,
 * the same card Bridle's own agent fills, checked against the same
 * knowledge; sending goes through AutoSend's hold and safety checks.
 */
class ReplyAbilities {

	public static function register(): void {
		self::search_knowledge();
		self::draft_reply();
		self::send_reply();
		self::add_note();
	}

	private static function search_knowledge(): void {
		wp_register_ability(
			'bridle/search-knowledge',
			[
				'label'               => __( 'Search knowledge', 'bridle' ),
				'description'         => __( 'Searches what the business knows, the same way Bridle’s own agent does: the agent instructions, saved replies (snippets), help docs, site pages and posts, products, and how the team answered similar questions before (redacted). Pass conversation_id to search for that email, or query for your own words. Answer only from what this returns, and cite entries by id in draft-reply.', 'bridle' ),
				'category'            => AbilitiesRegistrar::CATEGORY,
				'input_schema'        => [
					'type'       => 'object',
					'properties' => [
						'conversation_id' => [ 'type' => 'integer' ],
						'query'           => [ 'type' => 'string' ],
					],
				],
				'output_schema'       => [
					'type'       => 'object',
					'properties' => [
						'terms'        => [ 'type' => 'array' ],
						'instructions' => [ 'type' => 'string' ],
						'snippets'     => [ 'type' => 'array' ],
						'items'        => [ 'type' => 'array' ],
					],
				],
				'execute_callback'    => static function ( $input = [] ) {
					$input = (array) $input;
					if ( ! empty( $input['query'] ) ) {
						$terms = KnowledgeText::terms( '', (string) $input['query'] );
						$items = KnowledgeSearch::search( $terms, [ 'exclude_id' => absint( $input['conversation_id'] ?? 0 ) ] );
					} elseif ( ! empty( $input['conversation_id'] ) ) {
						$conversation = ConversationAbilities::find( $input );
						if ( is_wp_error( $conversation ) ) {
							return $conversation;
						}
						$found = KnowledgeSearch::for_conversation( $conversation, ( new \Bridle\Models\Thread() )->get_by_conversation( (int) $conversation->id ) );
						$terms = $found['terms'];
						$items = $found['items'];
					} else {
						return new WP_Error( 'bridle_missing_query', __( 'Pass conversation_id or query.', 'bridle' ), [ 'status' => 400 ] );
					}

					return [
						'terms'        => array_values( array_map( 'strval', $terms ) ),
						'instructions' => (string) Settings::get( 'agent_instructions', '' ),
						'snippets'     => array_map(
							static fn( $s ) => [
								'id'    => 'snippet:' . $s['id'],
								'title' => (string) $s['title'],
								'text'  => KnowledgeText::plain( (string) $s['body'] ),
							],
							AgentService::snippets()
						),
						'items'        => array_map(
							static fn( $i ) => [
								'id'    => (string) $i['id'],
								'type'  => (string) $i['type'],
								'title' => (string) $i['title'],
								'url'   => (string) $i['url'],
								'text'  => (string) $i['text'],
							],
							$items
						),
					];
				},
				'permission_callback' => AbilitiesRegistrar::can_reply(),
				'meta'                => AbilitiesRegistrar::meta( true, false, true ),
			]
		);
	}

	private static function draft_reply(): void {
		wp_register_ability(
			'bridle/draft-reply',
			[
				'label'               => __( 'Draft a reply', 'bridle' ),
				'description'         => __( 'Saves your reply as the conversation’s draft for a person to review and send. Nothing is emailed. Replaces any earlier draft. Cite each fact in sources as { source, quote } with ids from search-knowledge (instructions, snippet:…, kb:…, page:…, post:…, product:…, past:…) and a quote copied exactly; the result says whether every citation and link checked out.', 'bridle' ),
				'category'            => AbilitiesRegistrar::CATEGORY,
				'input_schema'        => self::reply_input(),
				'output_schema'       => self::reply_output(),
				'execute_callback'    => static fn( $input = [] ) => self::store( (array) $input ),
				'permission_callback' => AbilitiesRegistrar::can_reply(),
				'meta'                => AbilitiesRegistrar::meta( false, false, true ),
			]
		);
	}

	private static function send_reply(): void {
		wp_register_ability(
			'bridle/send-reply',
			[
				'label'               => __( 'Send a reply', 'bridle' ),
				'description'         => __( 'Emails your reply to the customer, after a two-minute hold in which a person can stop it in Bridle. Only works when the site owner has allowed your account to send (Settings → Agent) and the inbox’s agent isn’t off; otherwise use draft-reply. Same input as draft-reply. Refused for automated senders, when the customer wrote again, or when Bridle just answered them.', 'bridle' ),
				'category'            => AbilitiesRegistrar::CATEGORY,
				'input_schema'        => self::reply_input(),
				'output_schema'       => self::reply_output(),
				'execute_callback'    => static function ( $input = [] ) {
					$stored = self::store( (array) $input );
					if ( is_wp_error( $stored ) ) {
						return $stored;
					}

					$scheduled = AutoSend::schedule_external( (int) $stored['conversation_id'] );
					if ( is_wp_error( $scheduled ) ) {
						return $scheduled;
					}

					return array_merge(
						$stored,
						[
							'status'  => 'scheduled',
							'send_at' => (string) $scheduled['send_at'],
						]
					);
				},
				'permission_callback' => AbilitiesRegistrar::can_send(),
				'meta'                => AbilitiesRegistrar::meta( false, true, false, [ 'openWorldHint' => true ] ),
			]
		);
	}

	private static function add_note(): void {
		wp_register_ability(
			'bridle/add-note',
			[
				'label'               => __( 'Add an internal note', 'bridle' ),
				'description'         => __( 'Adds a private note to a conversation for the team: findings, a summary, what to check. The customer never sees it.', 'bridle' ),
				'category'            => AbilitiesRegistrar::CATEGORY,
				'input_schema'        => [
					'type'       => 'object',
					'properties' => [
						'conversation_id' => [ 'type' => 'integer' ],
						'text'            => [ 'type' => 'string' ],
						'client'          => [
							'type'        => 'string',
							'description' => 'Your name, e.g. Claude. Shown on the note.',
						],
					],
					'required'   => [ 'conversation_id', 'text' ],
				],
				'output_schema'       => [
					'type'       => 'object',
					'properties' => [
						'id'              => [ 'type' => 'integer' ],
						'conversation_id' => [ 'type' => 'integer' ],
					],
				],
				'execute_callback'    => static function ( $input = [] ) {
					$input        = (array) $input;
					$conversation = ConversationAbilities::find( $input );
					if ( is_wp_error( $conversation ) ) {
						return $conversation;
					}

					$who    = AbilitiesRegistrar::client( $input );
					$thread = ReplyService::add(
						(int) $conversation->id,
						[
							'content'     => sanitize_textarea_field( (string) ( $input['text'] ?? '' ) ),
							'thread_type' => 'note',
							'author_type' => 'agent',
							'author_id'   => $who['user_id'],
							'agent'       => [ 'source' => 'external' ] + $who,
						]
					);
					if ( is_wp_error( $thread ) ) {
						return $thread;
					}

					return [
						'id'              => (int) $thread->id,
						'conversation_id' => (int) $conversation->id,
					];
				},
				'permission_callback' => AbilitiesRegistrar::can_reply(),
				'meta'                => AbilitiesRegistrar::meta( false, false, false ),
			]
		);
	}

	/**
	 * Store an external agent's reply as the conversation's draft, checked
	 * against the full text of the sources it cites.
	 *
	 * @return array|WP_Error [ conversation_id, status, verified, problems, url ].
	 */
	private static function store( array $input ) {
		$conversation = ConversationAbilities::find( $input );
		if ( is_wp_error( $conversation ) ) {
			return $conversation;
		}
		if ( 'active' !== $conversation->status ) {
			return new WP_Error( 'bridle_not_active', __( 'This conversation is resolved or in spam. Reopen it first.', 'bridle' ), [ 'status' => 409 ] );
		}

		$html = isset( $input['reply_html'] ) && '' !== trim( (string) $input['reply_html'] )
			? wp_kses( (string) $input['reply_html'], AgentService::REPLY_TAGS )
			: wpautop( esc_html( (string) ( $input['reply_text'] ?? '' ) ) );
		if ( '' === trim( wp_strip_all_tags( $html ) ) ) {
			return new WP_Error( 'bridle_missing_content', __( 'Pass reply_html or reply_text.', 'bridle' ), [ 'status' => 400 ] );
		}

		$draft = AgentPrompt::parse(
			[
				'reply_html'         => $html,
				'confidence'         => (string) ( $input['confidence'] ?? '' ),
				'grounded_in'        => (array) ( $input['sources'] ?? [] ),
				'needs_human_reason' => (string) ( $input['needs_human_reason'] ?? '' ),
				'summary'            => (string) ( $input['summary'] ?? '' ),
			]
		);

		$cited     = array_column( $draft['grounded_in'], 'source' );
		$knowledge = AgentPrompt::knowledge(
			(string) Settings::get( 'agent_instructions', '' ),
			AgentService::snippets(),
			array_values( KnowledgeSearch::resolve( $cited ) )
		);
		$problems  = AgentPrompt::verify( $draft, $knowledge );
		$who       = AbilitiesRegistrar::client( $input );

		AgentService::store_draft(
			(int) $conversation->id,
			$draft['reply_html'],
			[
				'source'             => 'external',
				'client'             => $who['client'],
				'via'                => $who['via'],
				'user_id'            => $who['user_id'],
				'confidence'         => isset( $input['confidence'] ) ? $draft['confidence'] : null,
				'grounded_in'        => AgentPrompt::cite( $draft['grounded_in'], $knowledge ),
				'flags'              => [],
				'needs_human_reason' => $draft['needs_human_reason'],
				'summary'            => $draft['summary'],
				'verified'           => empty( $problems ),
				'problems'           => $problems,
			]
		);

		return [
			'conversation_id' => (int) $conversation->id,
			'status'          => 'ready',
			'verified'        => empty( $problems ),
			'problems'        => array_values( $problems ),
			'url'             => AbilitiesRegistrar::conversation_url( (int) $conversation->id ),
		];
	}

	private static function reply_input(): array {
		return [
			'type'       => 'object',
			'properties' => [
				'conversation_id'    => [ 'type' => 'integer' ],
				'reply_html'         => [
					'type'        => 'string',
					'description' => 'The reply. Allowed tags: p, br, ul, ol, li, a, strong, em, code. No signature; Bridle adds it.',
				],
				'reply_text'         => [
					'type'        => 'string',
					'description' => 'Plain-text alternative to reply_html.',
				],
				'sources'            => [
					'type'  => 'array',
					'items' => [
						'type'       => 'object',
						'properties' => [
							'source' => [ 'type' => 'string' ],
							'quote'  => [ 'type' => 'string' ],
						],
						'required'   => [ 'source', 'quote' ],
					],
				],
				'confidence'         => [
					'type' => 'string',
					'enum' => [ 'high', 'medium', 'low' ],
				],
				'needs_human_reason' => [
					'type'        => 'string',
					'description' => 'What a person must check before this goes out, if anything.',
				],
				'summary'            => [
					'type'        => 'string',
					'description' => 'One sentence for the team.',
				],
				'client'             => [
					'type'        => 'string',
					'description' => 'Your name, e.g. Claude. Shown on the draft.',
				],
			],
			'required'   => [ 'conversation_id' ],
		];
	}

	private static function reply_output(): array {
		return [
			'type'       => 'object',
			'properties' => [
				'conversation_id' => [ 'type' => 'integer' ],
				'status'          => [ 'type' => 'string' ],
				'verified'        => [ 'type' => 'boolean' ],
				'problems'        => [ 'type' => 'array' ],
				'url'             => [ 'type' => 'string' ],
				'send_at'         => [ 'type' => 'string' ],
			],
		];
	}
}
