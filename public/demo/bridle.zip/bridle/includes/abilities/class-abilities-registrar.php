<?php

namespace Bridle\Abilities;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The WordPress Abilities API surface: category `bridle`, ids `bridle/<verb-noun>`
 * (AGENTS.md §2), for external AI agents (ChatGPT, Claude, Codex, any MCP
 * client) reaching the inbox through Saddle or the WordPress MCP Adapter
 * with an application password.
 *
 * - ConversationAbilities: list-conversations, get-conversation, set-status.
 * - ReplyAbilities: search-knowledge, draft-reply, send-reply, add-note.
 *
 * Agents draft by default; send-reply needs the bridle_agent_send
 * capability, which nobody has until the site owner grants it in
 * Settings → Agent. This class keeps what they share: exposure, permission
 * checks and who is calling.
 *
 * WP_Ability insists on a label, a description, an `execute_callback` and a
 * `permission_callback`; miss one and the registry logs a notice and the
 * ability never exists.
 */
class AbilitiesRegistrar {

	public const CATEGORY = 'bridle';

	/** The capability that lets an external agent send, granted to nobody by default. */
	public const SEND_CAP = 'bridle_agent_send';

	public static function init(): void {
		add_action( 'wp_abilities_api_categories_init', [ self::class, 'register_category' ] );
		add_action( 'wp_abilities_api_init', [ self::class, 'register_abilities' ] );
		add_filter( 'map_meta_cap', [ self::class, 'map_send_cap' ], 10, 3 );
		add_filter( 'saddle_integrations', [ self::class, 'enrol_in_saddle' ] );
		add_filter( 'saddle_integration_target_keys', [ self::class, 'saddle_target_keys' ] );
	}

	public static function register_category(): void {
		wp_register_ability_category(
			self::CATEGORY,
			[
				'label'       => __( 'Bridle', 'bridle' ),
				'description' => __( 'The support inbox in Bridle: read conversations, search the business’s knowledge, draft replies for a person to review, add notes, resolve, and send when allowed.', 'bridle' ),
			]
		);
	}

	public static function register_abilities(): void {
		ConversationAbilities::register();
		ReplyAbilities::register();
	}

	/**
	 * Offer the abilities through Saddle, if it's installed. Saddle counts
	 * Bridle as a PlugPress plugin (from 1.5.2), so the tools are on as soon
	 * as both are active; older Saddle keeps them off until the owner switches
	 * Bridle on under Services. Bridle doesn't depend on Saddle either way.
	 */
	public static function enrol_in_saddle( $integrations ) {
		$integrations           = (array) $integrations;
		$integrations['bridle'] = [
			'prefix'      => 'bridle/',
			'title'       => 'Bridle',
			'description' => __( 'The support inbox: read conversations, search knowledge, draft replies, add notes, resolve.', 'bridle' ),
			'author'      => 'PlugPress',
			'url'         => 'https://bridle.to',
		];

		return $integrations;
	}

	/**
	 * Tell Saddle which input names the conversation, so its confirm step
	 * says "on #42" instead of a hash of the arguments.
	 *
	 * @param array $keys Candidate keys, best first.
	 * @return array
	 */
	public static function saddle_target_keys( $keys ) {
		$keys = (array) $keys;
		if ( ! in_array( 'conversation_id', $keys, true ) ) {
			$keys[] = 'conversation_id';
		}

		return $keys;
	}

	/**
	 * Exposure for every ability: the REST run endpoint (WP 7.0 needs
	 * show_in_rest), the high-level public flag (WP 7.1), and the MCP
	 * Adapter's own key.
	 */
	public static function meta( bool $read_only, bool $destructive, bool $idempotent, array $extra = [] ): array {
		return [
			'public'       => true,
			'show_in_rest' => true,
			'mcp'          => [ 'public' => true ],
			'annotations'  => array_merge(
				[
					'readonly'    => $read_only,
					'destructive' => $destructive,
					'idempotent'  => $idempotent,
				],
				$extra
			),
		];
	}

	/** Teammates who answer support. */
	public static function can_reply(): callable {
		return static fn(): bool => current_user_can( 'bridle_reply_conversations' ) || current_user_can( 'bridle_manage_conversations' );
	}

	public static function can_manage(): callable {
		return static fn(): bool => current_user_can( 'bridle_manage_conversations' );
	}

	/** Sending needs both: the reply capability and the explicit grant. */
	public static function can_send(): callable {
		return static fn(): bool => current_user_can( self::SEND_CAP ) && ( current_user_can( 'bridle_reply_conversations' ) || current_user_can( 'bridle_manage_conversations' ) );
	}

	/**
	 * bridle_agent_send counts only when granted to that user explicitly, so
	 * no role, and no multisite super admin, has it implicitly.
	 */
	public static function map_send_cap( $caps, $cap, $user_id ) {
		if ( self::SEND_CAP !== $cap ) {
			return $caps;
		}

		$user = get_userdata( (int) $user_id );

		return $user && ! empty( $user->caps[ self::SEND_CAP ] ) ? [ 'exist' ] : [ 'do_not_allow' ];
	}

	/**
	 * Who is calling: the application password's name when there is one
	 * (the site owner chose it, so it's the most honest label), else what
	 * the agent says it is, else "An AI agent"; and how it reached us.
	 *
	 * @return array{client: string, via: string, user_id: int}
	 */
	public static function client( array $input ): array {
		$label = '';
		$user  = get_current_user_id();

		if ( function_exists( 'rest_get_authenticated_app_password' ) && class_exists( '\WP_Application_Passwords' ) ) {
			$uuid = rest_get_authenticated_app_password();
			if ( $uuid ) {
				$password = \WP_Application_Passwords::get_user_application_password( $user, $uuid );
				$label    = (string) ( $password['name'] ?? '' );
			}
		}
		if ( '' === $label ) {
			$label = (string) ( $input['client'] ?? '' );
		}

		$label = trim( mb_substr( sanitize_text_field( $label ), 0, 40 ) );

		return [
			'client'  => '' !== $label ? $label : __( 'An AI agent', 'bridle' ),
			'via'     => self::via_from_route( self::current_route() ),
			'user_id' => $user,
		];
	}

	/**
	 * How a call arrived: the core abilities REST endpoint ('rest'), any
	 * other REST route (an MCP server such as Saddle or the MCP Adapter:
	 * 'mcp'), or PHP on the site ('php').
	 */
	public static function via_from_route( ?string $route ): string {
		if ( null === $route || '' === $route ) {
			return 'php';
		}

		return str_starts_with( '/' . ltrim( $route, '/' ), '/wp-abilities/' ) ? 'rest' : 'mcp';
	}

	/** Where in the admin a conversation opens. */
	public static function conversation_url( int $conversation_id ): string {
		return admin_url( 'admin.php?page=bridle#/c/' . $conversation_id );
	}

	private static function current_route(): ?string {
		if ( ! ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return null;
		}
		global $wp;

		return isset( $wp->query_vars['rest_route'] ) ? (string) $wp->query_vars['rest_route'] : '/';
	}
}
