<?php

namespace Bridle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * GDPR / CCPA privacy compliance.
 *
 * Registers WP personal-data exporter and eraser so site admins can
 * fulfill data subject requests from Tools → Export / Erase Personal Data.
 *
 * Data exported/erased:
 *   - Customer record (email, name, created date)
 *   - All conversations where customer_id matches
 *   - All threads (messages) within those conversations
 *   - Erasure only: their attachments (and the files Bridle stored for
 *     them), drafts and ratings
 *
 * Also registers a privacy-policy suggestion so admins know what to disclose.
 */
class Privacy {

	public static function init(): void {
		add_filter( 'wp_privacy_personal_data_exporters', [ self::class, 'register_exporter' ] );
		add_filter( 'wp_privacy_personal_data_erasers', [ self::class, 'register_eraser' ] );
		add_action( 'admin_init', [ self::class, 'add_privacy_policy_content' ] );
	}

	// Exporter

	public static function register_exporter( array $exporters ): array {
		$exporters['bridle'] = [
			'exporter_friendly_name' => __( 'Bridle Support Data', 'bridle' ),
			'callback'               => [ self::class, 'export_personal_data' ],
		];
		return $exporters;
	}

	public static function export_personal_data( string $email, int $page = 1 ): array {
		$data = [];

		$customer = ( new Models\Customer() )->find_by_email( $email );
		if ( ! $customer ) {
			return [ 'data' => [], 'done' => true ];
		}

		// Customer record.
		$data[] = [
			'group_id'          => 'bridle-customer',
			'group_label'       => __( 'Bridle Contact Profile', 'bridle' ),
			'group_description' => __( 'Support contact information stored by Bridle.', 'bridle' ),
			'item_id'           => 'customer-' . $customer->id,
			'data'              => [
				[ 'name' => __( 'Email', 'bridle' ),   'value' => $customer->email ],
				[ 'name' => __( 'Name', 'bridle' ),    'value' => $customer->name ?: '' ],
				[ 'name' => __( 'Created', 'bridle' ), 'value' => $customer->created_at ?: '' ],
				[ 'name' => __( 'Total Conversations', 'bridle' ), 'value' => $customer->total_conversations ?? 0 ],
			],
		];

		// Conversations + threads.
		global $wpdb;
		$conv_table   = $wpdb->prefix . 'bridle_conversations';
		$thread_table = $wpdb->prefix . 'bridle_threads';

		$conversations = $wpdb->get_results( $wpdb->prepare(
			'SELECT * FROM %i WHERE customer_id = %d ORDER BY created_at ASC',
			$conv_table,
			$customer->id
		) );

		foreach ( (array) $conversations as $conv ) {
			$conv_data = [
				[ 'name' => __( 'Thread ID', 'bridle' ), 'value' => $conv->thread_id ],
				[ 'name' => __( 'Subject', 'bridle' ),   'value' => $conv->subject ],
				[ 'name' => __( 'Status', 'bridle' ),    'value' => $conv->status ],
				[ 'name' => __( 'Created', 'bridle' ),   'value' => $conv->created_at ],
			];

			$data[] = [
				'group_id'    => 'bridle-conversations',
				'group_label' => __( 'Bridle Conversations', 'bridle' ),
				'item_id'     => 'conversation-' . $conv->id,
				'data'        => $conv_data,
			];

			// Threads (messages) in this conversation.
			$threads = $wpdb->get_results( $wpdb->prepare(
				"SELECT * FROM %i WHERE conversation_id = %d AND author_type = 'customer' ORDER BY created_at ASC",
				$thread_table,
				$conv->id
			) );

			foreach ( (array) $threads as $thread ) {
				$data[] = [
					'group_id'    => 'bridle-messages',
					'group_label' => __( 'Bridle Messages', 'bridle' ),
					'item_id'     => 'thread-' . $thread->id,
					'data'        => [
						[ 'name' => __( 'Conversation', 'bridle' ), 'value' => $conv->thread_id ],
						[ 'name' => __( 'Content', 'bridle' ),      'value' => wp_strip_all_tags( $thread->content_html ?: $thread->content ) ],
						[ 'name' => __( 'Date', 'bridle' ),         'value' => $thread->created_at ],
					],
				];
			}
		}

		return [ 'data' => $data, 'done' => true ];
	}

	// Eraser

	public static function register_eraser( array $erasers ): array {
		$erasers['bridle'] = [
			'eraser_friendly_name' => __( 'Bridle Support Data', 'bridle' ),
			'callback'             => [ self::class, 'erase_personal_data' ],
		];
		return $erasers;
	}

	public static function erase_personal_data( string $email, int $page = 1 ): array {
		$customer = ( new Models\Customer() )->find_by_email( $email );
		if ( ! $customer ) {
			return [ 'items_removed' => 0, 'items_retained' => 0, 'messages' => [], 'done' => true ];
		}

		// Their conversations with threads, attachments, drafts and ratings.
		$removed = ( new Models\Conversation() )->hard_delete_for_customer( (int) $customer->id );

		// Delete the customer record.
		( new Models\Customer() )->delete( (int) $customer->id );
		$removed++;

		Services\Counts::flush();

		return [
			'items_removed'  => $removed,
			'items_retained' => 0,
			'messages'       => [],
			'done'           => true,
		];
	}

	// Privacy Policy Suggestion

	public static function add_privacy_policy_content(): void {
		if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
			return;
		}

		$content = sprintf(
			'<h2>%s</h2><p>%s</p><h3>%s</h3><p>%s</p><h3>%s</h3><p>%s</p><h3>%s</h3><p>%s</p><h3>%s</h3><p>%s</p><h3>%s</h3><p>%s</p><h3>%s</h3><p>%s</p>',
			esc_html__( 'Support email', 'bridle' ),
			esc_html__( 'When you email our support address, we collect and store the following data to handle your request.', 'bridle' ),
			esc_html__( 'What we collect', 'bridle' ),
			esc_html__( 'Your email address, your name if you give it, the content of your messages and any attachments you send. We also store when each message arrived and the state of the conversation.', 'bridle' ),
			esc_html__( 'How your email reaches us', 'bridle' ),
			esc_html__( 'Our support address forwards to the Bridle email relay, run by PlugPress on Cloudflare, which passes each message on to this website. The relay does not keep your message. If this website cannot be reached, the relay forwards the message to PlugPress\'s fallback mailbox so it is not lost.', 'bridle' ),
			esc_html__( 'Website chat', 'bridle' ),
			esc_html__( 'If this website shows a chat, your messages are stored as a support conversation, and an AI assistant answers from this website\'s help pages. If you leave your email address so a person can reply, we store it and your name if you give it, and email you a copy of the chat and our replies. We count messages per visitor for an hour to stop abuse, using a scrambled form of your IP address that is never stored. If the chat checks for bots, Cloudflare Turnstile runs in your browser when you open it.', 'bridle' ),
			esc_html__( 'AI assistance', 'bridle' ),
			esc_html__( 'Replies may be drafted with an AI service we have chosen (our own provider, or Bridle AI, run by PlugPress), which then receives the text of your conversation. If we use a sorting model, it receives your name, email address, subject line and newest message once, when the email arrives. A person or the agent we set up answers you.', 'bridle' ),
			esc_html__( 'How long we keep it', 'bridle' ),
			esc_html__( 'Support conversations are kept until you ask us to delete them or we remove them. Conversations moved to Trash are deleted for good after 30 days.', 'bridle' ),
			esc_html__( 'Your rights', 'bridle' ),
			esc_html__( 'You can ask for a copy of your support data, or for it to be erased, at any time. Contact us, or use the data request form if this website has one.', 'bridle' )
		);

		wp_add_privacy_policy_content( 'Bridle', $content );
	}
}
