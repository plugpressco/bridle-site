<?php

namespace Bridle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * IntegrationRegistry — extensible customer data providers for the Bridle
 * contact panel.
 *
 * Any plugin can call IntegrationRegistry::register() during `plugins_loaded`
 * to contribute a data card. Cards appear in the right-side contact panel
 * whenever an agent opens a conversation.
 *
 * USAGE
 *
 *   add_action( 'plugins_loaded', function() {
 *       if ( ! class_exists( '\Bridle\IntegrationRegistry' ) ) { return; }
 *
 *       \Bridle\IntegrationRegistry::register( 'salesforce', [
 *           'title' => 'Salesforce',
 *           'fetch' => function( string $email ): ?array {
 *
 *               $contact = my_salesforce_lookup( $email );
 *               if ( ! $contact ) { return null; }  // null = hide the card
 *
 *               return [
 *                   'status' => [ 'label' => 'Open deal', 'tone' => 'green' ],
 *                   'rows'   => [
 *                       [ 'Account',   $contact['account_name'] ],
 *                       [ 'Stage',     $contact['stage'] ],
 *                       [ 'Value',     '$' . number_format( $contact['value'] ) ],
 *                   ],
 *                   'link'   => $contact['url'],   // makes the card clickable
 *               ];
 *           },
 *       ] );
 *   } );
 *
 * CARD SCHEMA
 *
 *   title   string   Card heading (e.g. "WooCommerce", "Salesforce").
 *   status  array    { label: string, tone: 'green'|'amber'|'red'|'muted' }
 *   rows    array    [ [ 'Label', 'Value' ], … ]  — key-value pairs.
 *   link    string   Optional URL — wraps the whole card in an <a>.
 *
 * EXAMPLES OF DATA SOURCES
 *
 *   WooCommerce   — order count, LTV, last order date, active/lapsed.
 *   Salesforce    — account stage, opportunity value, deal owner.
 *   Stripe        — subscription plan, MRR, payment status.
 *   HubSpot       — lifecycle stage, deal stage, last contact.
 *   Custom server — active plugin licences, PHP version, WP version per site.
 *   Any REST API  — whatever your business tracks against an email address.
 */
class IntegrationRegistry {

	/** @var array<string, array{title: string, fetch: callable}> */
	private static array $providers = [];

	/**
	 * Register a customer data provider.
	 *
	 * @param string $id     Unique slug — used as the React card key and for dedup.
	 *                       Use reverse-domain style: 'woocommerce', 'my-plugin/salesforce'.
	 * @param array  $config {
	 *     @type string   $title  Card heading shown in the contact panel.
	 *     @type callable $fetch  fn( string $email ): ?array
	 *                           Return a card array to show the card, null to hide it.
	 * }
	 */
	public static function register( string $id, array $config ): void {
		self::$providers[ $id ] = $config;
	}

	/**
	 * Run every registered provider for $email and collect the resulting cards.
	 * A provider that throws or returns null is silently skipped.
	 *
	 * @return array[]
	 */
	public static function cards_for( string $email ): array {
		$cards = [];

		foreach ( self::$providers as $id => $cfg ) {
			$fetch = $cfg['fetch'] ?? null;
			if ( ! is_callable( $fetch ) ) {
				continue;
			}
			try {
				$result = $fetch( $email );
				if ( $result && is_array( $result ) ) {
					$cards[] = array_merge(
						[
							'source' => $id,
							'title'  => (string) ( $cfg['title'] ?? $id ),
						],
						$result
					);
				}
			} catch ( \Throwable ) {
				// one failing provider never breaks the others
			}
		}

		return $cards;
	}

	/**
	 * Hook the registry into the shared `plugpress_contact_cards` filter.
	 * Called once during Plugin::init().
	 */
	public static function init(): void {
		add_filter( 'plugpress_contact_cards', [ self::class, 'on_filter' ], 20, 3 );
	}

	/** @internal */
	public static function on_filter( array $cards, string $email, string $requesting ): array {
		return array_merge( $cards, self::cards_for( $email ) );
	}
}
