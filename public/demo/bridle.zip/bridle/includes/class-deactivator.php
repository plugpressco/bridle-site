<?php

namespace Bridle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Deactivator {

	public static function deactivate(): void {
		foreach ( Activator::CRON_HOOKS as $hook ) {
			wp_clear_scheduled_hook( $hook );
		}
		// Drafting and sending jobs queued in Action Scheduler, if it runs them.
		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( '', [], 'bridle' );
		}
		flush_rewrite_rules();
	}
}
