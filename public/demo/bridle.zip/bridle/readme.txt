=== Bridle ===
Contributors: plugpress
Tags: support, ai, email, inbox, customer support
Requires at least: 7.0
Tested up to: 7.1
Requires PHP: 8.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

The AI support agent inside WordPress. Mail arrives sorted and every reply is drafted from your own docs, pages and past answers.

== Description ==

Bridle puts your support mailbox inside wp-admin. Forward `support@` to the address Bridle gives you and each customer email becomes a conversation, already sorted and usually with a reply drafted. You send the draft, or let the agent send the ones it is sure of. Your conversations stay in your own database.

**What it does**

* **Sorts the mail.** People land in the Inbox. Receipts, newsletters and pitches go to Updates, a feed you read in place. Scams go to Spam.
* **Drafts from what you already know.** Each reply is written from your Agent instructions, snippets, Bridle KB docs, your pages and posts, WooCommerce products and your past replies, with names, emails and order numbers removed. Each source can be switched off. Every fact and link in a draft is checked against those sources, and the agent does not write from outside knowledge.
* **Draft or Auto, per inbox.** In Draft a person sends every reply. In Auto the agent sends only the replies it is sure of, after a 15-minute hold you can stop. It answers a conversation at most twice and sends at most 30 an hour per inbox. Refunds, billing, legal, security, cancellations and upset customers always wait for a person.
* **Bring your own agent.** ChatGPT, Claude, Codex or any agent that speaks MCP can read the inbox, search your knowledge, write drafts and add notes through [Saddle](https://saddle.to) or the WordPress MCP Adapter. Sending stays off until you allow it for that agent.
* **A chat bubble that answers.** Switch on Bridle Chat and visitors get answers from the same knowledge, checked the same way. Anything it isn't sure of comes to your Inbox, and you reply by email.
* **Your AI key, or none.** Connect Anthropic, OpenAI or Google in WordPress and use them as much as you like. Without a key, Bridle AI answers instead: 100 answers a month free, then packs.
* **Starts with a chat.** Bridle asks for your business name and support address, finds out where that mail is hosted and shows the forwarding steps for that provider.
* **Works for a team.** Invite teammates, assign conversations and leave private notes. Several addresses get an inbox each.
* **Keeps your data.** Conversations, contacts and settings live in `wp_bridle_*` tables on your site.

**Bridle Pro**

Bridle is complete without it. [Bridle Pro](https://bridle.to/pro/) adds chat on your other sites, taking over a chat live, order lookups and a list of what the agent couldn't answer.

Bridle is built by the team behind [Saddle](https://saddle.to).

== External services ==

Bridle connects to the services below. Nothing is sent until you create an inbox or an email arrives.

**1. The Bridle email relay (PlugPress)**

Inbound mail reaches your site through a Cloudflare Email Worker run by PlugPress at `bridle-email-worker.plugpress.workers.dev`. Forwarding addresses are on `bridle.to`.

* When Bridle contacts it: when you create an inbox or switch one back on, when your site URL changes, once a day to re-sync, when you press "Fix forwarding", and when you switch off or remove an inbox or erase all data (to deregister it).
* What is sent: your site URL, your webhook URL, the inbox code and a secret your site generated for that inbox. The secret lets your site check that each delivery came from the relay.
* What the relay does with mail: it parses each message sent to a forwarding address and posts it to your webhook. The only thing it stores is the inbox registration. If your site cannot be reached, or a message arrives for an address no site has registered, the relay forwards that message to PlugPress's fallback mailbox so it is not lost.
* [Terms of Service](https://bridle.to/terms/) and [Privacy Policy](https://bridle.to/privacy/).

**2. The AI provider you connect**

Drafts are written by the provider you connect in WordPress's AI settings (the WordPress AI Client), with your own key. Without one, Bridle AI (below) can write them instead, if you switch it on.

* When: each time a draft is written for a new customer message, when you ask for a redraft, each time a visitor asks something in Bridle Chat (if you switch it on), when you rewrite or translate a reply, and when **Settings → Replies** checks that a provider is connected (WordPress may ask the provider for its list of models).
* What is sent: the conversation text (the last 12 messages, or the chat so far), the customer's contact details Bridle holds, your Agent instructions and snippets, and the passages from your docs, pages, products and redacted past replies that match the question. A rewrite sends only the reply you are writing, plus the customer's newest message when you translate into their language.
* The provider's own terms and privacy policy apply. They depend on which provider you choose, for example Anthropic, OpenAI or Google.

**3. Bridle AI (optional)**

If you don't connect your own AI key, you can switch on Bridle AI under **Settings → Replies**: a service run by PlugPress that writes the same drafts and chat answers with no key. 100 answers a month are free; more are sold in packs. Your own key, when connected, is always used first. Off unless you switch it on.

* When: once when you switch it on (to sign up your site, which the service confirms by calling your site back), each time a draft, a chat answer or a rewrite is written while it is on, when Settings shows how many answers are left, and when you buy a pack.
* What is sent: at sign-up, your site URL and the email you enter for receipts. For each answer, the same text an AI provider would get (the conversation or chat so far, the contact details Bridle holds, your Agent instructions and snippets, and the matching passages from your knowledge). The service passes it to its model through Cloudflare AI Gateway and does not keep it; it keeps your site URL, your email and a count of answers used.
* Packs are paid through Polar on a checkout page that opens in your browser.
* [Terms of Service](https://bridle.to/terms/) and [Privacy Policy](https://bridle.to/privacy/).

**4. The decision model you connect (optional)**

If you add a key under **Settings → Sorting**, Bridle asks a decision model to read each inbound email, with your own account. Without a key nothing is sent and mail is sorted by its headers.

* When: once for every email that arrives, and when you press "Save and test" (a made-up sample email).
* What is sent: the sender's name and address, the Reply-To and mailing-list headers, the subject and the newest message (quoted history removed, at most 6,000 characters).
* TypeSafe (Jev) at `api.typesafe.ai`: [Master Customer Agreement](https://typesafe.ai/legal/mca), [Privacy Policy](https://typesafe.ai/legal/privacy-policy), [Data Processing Agreement](https://typesafe.ai/legal/data-processing).
* Cloudflare Workers AI (Jev, Clef or Clef-flash) at `api.cloudflare.com`: [Terms](https://www.cloudflare.com/website-terms/), [Privacy Policy](https://www.cloudflare.com/privacypolicy/).

**5. Cloudflare Turnstile (optional)**

Only if you add Turnstile keys under **Settings → Chat**. Without keys nothing is loaded or sent.

* When: a visitor's browser loads Turnstile from `challenges.cloudflare.com` when they open the chat; your site asks Cloudflare to check the result when that visitor starts a chat.
* What is sent: Turnstile collects signals from the visitor's browser to tell people from bots. Your site sends Cloudflare the token from the browser and your secret key.
* [Turnstile Privacy Addendum](https://www.cloudflare.com/turnstile-privacy-policy/), [Terms](https://www.cloudflare.com/website-terms/).

**6. Gravatar**

The conversation list and letters show customer pictures through WordPress's own avatar function. Your browser asks Gravatar (run by Automattic) for the picture, which sends a hash of the customer's email address. Customers without a Gravatar get an illustrated face drawn by Bridle. [Terms of Service](https://wordpress.com/tos/) and [Privacy Policy](https://automattic.com/privacy/).

**Not an external service: mail host lookup**

When you enter your support address, Bridle works out who hosts it so it can show the right forwarding steps. For common free-mail domains it recognises the name. For a company domain it runs a DNS MX lookup from your own server, using PHP's `getmxrr()` and your server's resolver. No HTTP request is made and no data is sent to PlugPress.

Replies you send go through `wp_mail()` and whichever SMTP plugin or mail service your site already uses.

== Installation ==

1. In wp-admin go to **Plugins → Add New**, search for "Bridle", then install and activate it.
2. Open **Bridle** and answer the setup chat: your business name and the support address you use today.
3. Forward that address to the Bridle address shown in the chat. Bridle gives the steps for your mail host, and setup finishes itself when the first email arrives.
4. Connect an AI provider in WordPress's AI settings.
5. Under **Settings → Replies**, choose Draft for the inbox.

An SMTP plugin is optional but helps your replies reach inboxes reliably.

== Frequently Asked Questions ==

= Do I need a mail server? =

No. Inbound mail comes through a forwarding rule from your existing mailbox to the Bridle address. Outbound replies go through `wp_mail()`, or your SMTP plugin if you have one.

= Does it work with Gmail, Outlook or Zoho? =

Anything that can forward mail works. Bridle never logs in to your provider; it receives what you forward. The setup chat shows the forwarding steps for your host and surfaces Gmail's confirmation code and link for you.

= Do I need WordPress 7.0? =

Yes. Bridle uses the AI Client and the Abilities API that arrived in 7.0. The inbox works without an AI provider connected; the agent stays off until you connect one.

= Which AI provider does it use? =

Whichever one you connect in WordPress's AI settings, with your own key, free and without limits. If you'd rather not get a key, switch on Bridle AI under Settings → Replies: 100 answers a month free, then packs. See External services above for exactly what is sent.

= What does the agent read? =

Your Agent instructions and snippets, plus, each switchable under **Settings → Knowledge**: published Bridle KB docs, your pages and posts, WooCommerce products and past replies. Past replies come only from your team's own answers in resolved conversations in the same inbox, with names, emails, phone numbers, order numbers, keys and links to other sites removed.

= Can the agent send replies by itself? =

Yes, in an inbox set to Auto (off by default). It sends only replies whose every quote and link checked out against your knowledge, and never about refunds, billing, legal, security, cancellations or upset customers. Each reply waits 15 minutes so you can read it, send it now or stop it. It answers a conversation at most twice and sends at most 30 an hour per inbox. A reply it sends carries a short line saying an AI wrote it. If you sometimes answer from your mail app, stay on Draft, because Bridle cannot see those replies.

= Can I use ChatGPT, Claude or Codex instead? =

Yes. Install Saddle or the WordPress MCP Adapter, create an application password named after the agent, and connect your AI app to your site. With the MCP Adapter, the address is `https://your-site/wp-json/mcp/mcp-adapter-default-server`, and Bridle's tools appear through its discover and execute tools. In Saddle, give the app **Edit content** under **AI apps** (with Saddle 1.5.1 or older, also switch Bridle on under **Services**). The agent brings its own model; Bridle gives it the inbox and your knowledge through WordPress Abilities. Its drafts appear in Bridle with its name on them and are checked the same way. It can send only once you allow it for that teammate under **Settings → AI apps**, and each send waits two minutes so you can stop it.

= Can I run support@, info@ and sales@ separately? =

Yes. Under **Settings → Inbox → Connect an inbox**, create one inbox per address, each with its own forwarding address, sender name and agent mode. The inbox switcher in the top bar shows one or all.

= Where is customer data stored? =

In your own database, in tables prefixed `wp_bridle_`. Deleting the plugin keeps them. **Settings → Data → Erase all data** erases everything.

= What happens to my mail if I stop using Bridle? =

Remove the forwarding rule at your mail host first. Deactivating or deleting Bridle doesn't change your mailbox, so `support@` keeps forwarding to the Bridle address, and the relay sends whatever it can't deliver to PlugPress's fallback mailbox.

= Are there keyboard shortcuts? =

Yes. They are not printed on the buttons, so the screen stays clean.

* `1` to `5`: Inbox, Updates, Resolved, Spam, Trash
* `j` / `k`: move down and up a list. `↵` opens, `x` selects; shift-click a checkbox to select a range
* `r`: reply. `n`: note. `e`: resolve. `a`: accept the agent's draft
* `⌘↵` (`Ctrl`+`Enter` on Windows): send. `⌘⇧↵`: send and resolve
* `/`: search. `Esc`: back
* `⌘K` (`Ctrl`+`K` on Windows), anywhere in WordPress: its command palette, with every Bridle box and Settings page and a search of your conversations

= How do I export or erase a person's data? =

The standard WordPress privacy tools (Tools → Export Personal Data and Erase Personal Data) include Bridle's conversations, messages and attachments tied to an email address.

= Where is the source code? =

The admin app is built from the `src/` folder shipped in this plugin, with `@wordpress/scripts`. To rebuild it, run `npm install && npm run build` in the plugin folder. The compiled files are in `build/`. The PHP is unminified.

= What third-party code does it include? =

All GPL-compatible: the Mona Sans and Geist Mono fonts (SIL Open Font License 1.1, licence texts in `src/app/styles/fonts/`), Lucide icons (ISC), Radix UI, shadcn/ui, TipTap, Tailwind CSS and class-variance-authority (MIT).

== Screenshots ==

1. The Inbox, with every box in the dock below.
2. The agent's draft, with the help doc and past reply it was checked against.
3. The setup chat: forwarding connected, then how the agent should sound.
4. Settings → Replies: Off, Draft or Auto for each inbox.
5. Updates: receipts and newsletters as a feed you read in place, with Move to inbox on each card.

== Changelog ==

= 1.0.0 =
First release.

* Sorts mail into Inbox, Updates and Spam.
* Drafts replies from your instructions, docs, pages, products and past answers.
* Draft or Auto per inbox, with guardrails and a 15-minute hold.
* Works with ChatGPT, Claude, Codex or any MCP agent through WordPress Abilities.
* Setup is a chat that walks through forwarding for your mail host.
* Newsletters, receipts and reports look the way their sender designed them.
* Resolve or trash a conversation straight from the list.
* Unread conversations are marked for each teammate.
* Optional sorting with a decision model on your own key: Jev through TypeSafe, or Clef (the default, on Cloudflare's free daily allowance) and Jev through Cloudflare.
* With Bridle KB installed, its Docs sit in Bridle's menu, between Inbox and Settings, in the same look.
* Home, the first screen: one next step, this week's numbers, what needs you and whether each part of the agent is working.
* Bridle Chat: switch on a chat bubble for your site. It answers from the same knowledge as your email drafts, checks every fact, says it is an AI, and hands refunds, billing, upset visitors and anything it isn't sure of to a person, who replies by email. Every chat is kept in Bridle.
* No AI key? Switch on Bridle AI under Settings → Replies: 100 answers a month free, then packs from $10. Only answers that pass Bridle's checks count, and your own key is always used first.
* Settings → Bridle Pro says what the Pro plugin adds. Nothing else in Bridle asks you to buy it.
* When the chat hands a visitor to a person, it says when you usually reply (from your real first-reply time), and sends them a copy of the chat. Your reply shows in their chat bubble, and by email if they haven't read it there within a few minutes. You get an email when a chat needs you.
* Settings is one panel with a page for each part: Inboxes, Replies, Knowledge, Sorting, AI apps, Team, Emails and Data. Help sits behind a ? beside each label.
* While the agent drafts, the Inbox groups mail by what you do next: Ready to send, Sending soon and Needs you, each row showing the draft's first line or why a person should look.
* A calmer top bar: the mark, search, Settings and one Help menu with the keyboard shortcuts. Which inbox a list shows sits beside its title, and every box has the same width and title.
* Select many conversations the way you do in Gmail: hover an avatar for its checkbox, shift-click for a range, select all, read or unread, or every conversation in the view. Mark them read or unread, resolve, spam or trash them at once.
* Trash empties itself: conversations there are deleted for good after 30 days. Delete forever is one click away in Trash.
* One Bridle icon everywhere: the white mark on a blue circle, in the app and the plugin directory.
* Works with the WordPress MCP Adapter plugin. When an AI agent's reply can't be sent, Bridle says why in words, the same ones the app shows.
* A chat shows the page the visitor started it on. The chat answers only on your own site.
* "Powered by Bridle" under the chat is off unless you turn it on (Settings → Chat), like the line under emails.
* A staging copy of your site can no longer take your live site's mail: Bridle only points a forwarding address at a new site address when the site's own address changes or you press Fix forwarding, and a copy leaves the live site's addresses alone when you switch an inbox off or erase its data. Home tells you when an address points elsewhere.
* An inbox you switch off and on again gets its mail again.
* Backslashes in emails, notes and settings are kept as written.
* Bridle in WordPress's command palette (⌘K) on every admin screen: go to any box or Settings page, connect an inbox, or type to find a conversation. The Help menu opens it too, and shows Bridle's version.
* Pick the model for each task: one for email drafts and one for chat answers, from the models your AI connection offers (Settings → Replies).
* A cleaner chat: pick the button's icon, corner, size and a light or dark theme. The window shows your site icon, keeps its actions in one menu and lists the sources it used.
* Settings pages link to short guides on bridle.to for the job at hand, such as putting the chat on your other sites. No admin notices, ever.
* Rewrite a reply or the agent's draft: shorter, friendlier, more formal, spelling fixed, or translated into the customer's language or any other. It keeps every link and number, refuses a rewrite that changes one, and Undo puts your words back.
