const defaultConfig = require( '@wordpress/scripts/config/webpack.config' );
const path = require( 'path' );

module.exports = {
	...defaultConfig,
	entry: {
		// The admin app (shadcn/ui + Tailwind, AGENTS.md §6): src/app → build/app.js.
		app: path.resolve( __dirname, 'src/app/index.js' ),
		// Bridle Chat's bubble on the front end (#114): no dependencies, its
		// own shadow root. src/chat → build/chat.js.
		chat: path.resolve( __dirname, 'src/chat/index.js' ),
		// Bridle in WordPress's command palette (⌘K) on every admin screen.
		// src/commands → build/commands.js.
		commands: path.resolve( __dirname, 'src/commands/index.js' ),
	},
	resolve: {
		...defaultConfig.resolve,
		alias: {
			...( defaultConfig.resolve && defaultConfig.resolve.alias ),
			// shadcn's generated imports (`@/components/ui/button`). The same
			// alias is declared in jsconfig.json (editor + shadcn CLI),
			// .eslintrc.js and jest.config.js.
			'@': path.resolve( __dirname, 'src/app' ),
		},
	},
};
