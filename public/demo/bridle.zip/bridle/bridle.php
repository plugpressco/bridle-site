<?php
/**
 * Plugin Name:       Bridle
 * Plugin URI:        https://bridle.to
 * Description:       The AI support agent inside WordPress. Mail arrives sorted and every reply is drafted from your own docs, pages and past answers.
 * Version:           1.0.0
 * Requires at least: 7.0
 * Requires PHP:      8.1
 * Author:            PlugPress
 * Author URI:        https://plugpress.io
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       bridle
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// PHP version check.
if ( version_compare( PHP_VERSION, '8.1', '<' ) ) {
	add_action( 'admin_notices', function () {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		echo '<div class="notice notice-error"><p>';
		echo esc_html__( 'Bridle requires PHP 8.1 or higher.', 'bridle' );
		echo '</p></div>';
	} );
	return;
}

// Constants.
define( 'BRIDLE_VERSION', '1.0.0' );
define( 'BRIDLE_PLUGIN_FILE', __FILE__ );
define( 'BRIDLE_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'BRIDLE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'BRIDLE_REST_NAMESPACE', 'bridle/v1' );

// Autoloader.
spl_autoload_register( function ( string $class ) {
	$prefix = 'Bridle\\';

	if ( 0 !== strpos( $class, $prefix ) ) {
		return;
	}

	$relative = substr( $class, strlen( $prefix ) );
	$parts    = explode( '\\', $relative );
	$filename = array_pop( $parts );

	// Convert CamelCase class name to kebab-case with class- prefix.
	$filename = 'class-' . strtolower( preg_replace( '/([a-z])([A-Z])/', '$1-$2', $filename ) ) . '.php';

	// Convert namespace parts to lowercase directory names.
	$subdir = '';
	if ( ! empty( $parts ) ) {
		$subdir = strtolower( implode( '/', array_map( function ( $part ) {
			return preg_replace( '/([a-z])([A-Z])/', '$1-$2', $part );
		}, $parts ) ) ) . '/';
	}

	$file = BRIDLE_PLUGIN_DIR . 'includes/' . $subdir . $filename;

	if ( file_exists( $file ) ) {
		require_once $file;
	}
} );

// Activation.
register_activation_hook( __FILE__, function () {
	Bridle\Activator::activate();
} );

// Deactivation.
register_deactivation_hook( __FILE__, function () {
	Bridle\Deactivator::deactivate();
} );

// Boot.
add_action( 'plugins_loaded', function () {
	Bridle\Plugin::get_instance()->init();
} );

// WP-CLI commands.
if ( defined( 'WP_CLI' ) && WP_CLI ) {
	WP_CLI::add_command( 'bridle', Bridle\Cli\Commands::class );
}
