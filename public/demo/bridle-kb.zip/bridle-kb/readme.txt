=== Bridle KB ===
Contributors: plugpress
Tags: knowledge base, documentation, help desk, faq
Requires at least: 7.0
Tested up to: 7.1
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Create and manage documentation, help articles, and FAQs with this easy-to-use knowledge base plugin.

== Description ==

**Bridle KB** helps you create and manage a professional knowledge base or documentation section on your WordPress site. Perfect for product documentation, help articles, FAQs, and customer support.

= Key Features =

* **A help center like a modern docs site** - A grouped navigation on the left, the article in the middle, "On this page" on the right, previous and next articles under it; a home with a card for each topic. Works on phones, where the navigation opens as a sheet
* **Category Organization** - Organize articles with hierarchical categories; subcategories fold open in the navigation, child articles sit under their parent
* **Search from anywhere** - Press `/` or ⌘K for a search dialog with results as you type
* **Copy page** - Visitors copy any article as Markdown, or open it in ChatGPT or Claude to ask about it
* **Your brand** - The accent colour, container width and layout variants are settings; the help center takes your theme's font
* **Theme Compatibility** - Works with any WordPress theme, including FSE (block) themes
* **SEO Friendly** - Properly structured markup for search engines
* **AI Agent Ready** - WordPress Abilities API support: agents can read, create, update and delete docs, and configure the knowledge base. With [Saddle](https://saddle.to) installed, your AI app can work on articles over MCP: Saddle offers Bridle KB's tools as one of its own plugins. Give the app Edit content under Saddle → AI apps so it can write
* **Translation Ready** - Fully internationalized with translation support

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/bridle-kb` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Open **Bridle → Docs** when Bridle is installed, otherwise the **Bridle KB** menu. Write articles and add categories from there

== Frequently Asked Questions ==

= Does this work with my theme? =

Yes, Bridle KB is designed to work with any WordPress theme, including both classic and block themes. The plugin includes its own styling that adapts to your theme's design.

= Can I customize the appearance? =

Yes. Every element has a `bridle-kb-*` class you can style from your theme, and the accent colour comes from the `--bridle-kb-primary` CSS variable. To change the markup, copy a file from the plugin's `templates/` folder into a `bridle-kb/` folder in your (child) theme. Filters: `bridle_kb_archive_title`, `bridle_kb_archive_subtitle`, `bridle_kb_home_label`, `bridle_kb_copy_page` (turn Copy page off) and `bridle_kb_nav_limit` (articles in the navigation, 500 by default).

= Is this plugin translation ready? =

Yes, Bridle KB is fully translation ready. You can translate it using standard WordPress translation tools.

= Does it support SEO? =

Yes, the plugin generates proper semantic HTML markup that's optimized for search engines.

= Can I bring my docs from Intercom, Help Scout or Notion? =

Yes. Docs → Import reads them with a token you paste, keeps their categories, order and images, and runs in the background. Import again later to bring in changes.

= Can I use this with page builders? =

The help center's pages come from the plugin's own templates. The `bridle_kb_*` shortcodes print those pages inside block themes' templates and only render on the docs pages themselves, so they are not meant for other pages.

== Changelog ==

= 1.0.0 =
* First release as **Bridle KB**, the knowledge base that sits next to Bridle, the AI support agent for WordPress.
* Every identifier is renamed: text domain and slug `bridle-kb`, REST namespace `bridle-kb/v1`, abilities `bridle-kb/*`, options `bridle_kb_settings` / `bridle_kb_design`, template meta `_bridle_kb_template`, shortcodes `bridle_kb_*`, CSS variables `--bridle-kb-*`.
* The pre-release settings migration shim is gone; nothing shipped under the old name.
* The `docs` post type and `docs_category` taxonomy are unchanged.
* The Docs screen shares Bridle's top bar: the mark on the left, a link to the inbox, and Settings on the right.
* With Bridle on the site, Docs is one item in Bridle's menu (Bridle → Inbox, Docs, Settings) instead of a menu of its own.
* The admin is one page in Bridle's look, Docs: every article in one table, grouped under its category like the help center's navigation, with All / Published / Drafts / Trash tabs, search as you type (titles at once, article text too), sorting, and Gmail-style selection to publish, move to draft, move to a category or trash many at once, with Undo. WordPress's own articles list opens Docs; the categories screen gets the same bar, with the way back.
* Sentence case on every screen: "New article", "Edit article", "Categories", "Icon", "Article template".
* The help center is laid out like a modern docs site: a grouped navigation (one query, cached), the category over the title, Copy page (Markdown, or open in ChatGPT or Claude), "On this page" that follows your reading, previous and next articles, and a home of category cards under one search. Search is a dialog with results as you type, from `/` or ⌘K anywhere. The breadcrumb root says Docs; the default accent is Bridle's blue and the default width 76rem, so the pages sit inside a theme's frame.
* `GET bridle-kb/v1/categories` also returns each category's parent, icon and colour.
* Saddle: Bridle KB offers its tools through Saddle, on as soon as both plugins are active (Saddle 1.5.2 or newer).
* Import your help center from Intercom, Help Scout or Notion (Docs → Import): paste a token, see what will come in, and import as drafts or published. Categories, article order and images come with it, links between articles point at the new docs, and importing again updates them instead of adding copies. It runs in the background; the token is used only while it runs.

= 0.1.1 =
* Abilities API: the create-doc and update-doc abilities can now set a doc's slug (permalink) and author, so AI agents can assign and rename permalinks

= 0.1.0 =
* Initial release
* Knowledge base post type and categories
* AJAX search functionality
* Responsive grid and list layouts
* Full support for FSE (Full Site Editing) block themes — templates render theme header/footer correctly
* WordPress Abilities API support — AI agents can manage docs, categories and settings
* Translation ready
* Theme compatibility

== External services ==

Bridle KB connects to an outside service only when a site administrator imports docs (Docs → Import), and only to the one they choose, with the token they paste:

* **Intercom** (`api.intercom.io`): reads the help center's collections and articles. [Terms](https://www.intercom.com/legal/terms-and-policies), [privacy](https://www.intercom.com/legal/privacy).
* **Help Scout Docs** (`docsapi.helpscout.net`): reads collections, categories and articles. [Terms](https://www.helpscout.com/company/legal/terms-of-service/), [privacy](https://www.helpscout.com/company/legal/privacy/).
* **Notion** (`api.notion.com`): reads the pages and databases shared with the integration. [Terms](https://www.notion.so/notion/Terms-and-Privacy-28ffdd083dc3473e9c2da6ec011b58ac), [privacy](https://www.notion.so/notion/Privacy-Policy-3468d120cf614d4c9014c09f6adc9091).

Images in imported articles are downloaded from where those articles keep them (usually the service's own file host) into your media library. Nothing about your site or its visitors is sent; the token is kept only while the import runs.

== Privacy Policy ==

Bridle KB does not collect, store, or transmit any visitor data. No cookies are set, no IP addresses are logged, and no external HTTP requests are made by the plugin except the import an administrator starts (see External services). The Copy page menu links to ChatGPT and Claude with the article's address; nothing is sent unless a visitor follows one of those links. All data (articles, categories, and their metadata) is stored locally in your WordPress database.

== Upgrade Notice ==

= 1.0.0 =
First release as Bridle KB. Install fresh; there is no upgrade path from the earlier pre-release builds.
