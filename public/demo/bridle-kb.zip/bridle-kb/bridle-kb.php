<?php

/**
 * Plugin Name: Bridle KB
 * Plugin URI:  https://bridle.to
 * Description: Create and manage a professional knowledge base. Perfect for documentation, help articles, and FAQs.
 * Version:     1.0.0
 * Author:      PlugPress
 * Author URI:  https://plugpress.co/
 * Text Domain: bridle-kb
 * Domain Path: /languages
 * License:     GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 7.0
 * Tested up to: 7.1
 * Requires PHP: 8.0
 * Network:     false
 *
 * @package BridleKB
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'BRIDLE_KB_VERSION', '1.0.0' );
define( 'BRIDLE_KB_FILE', __FILE__ );
define( 'BRIDLE_KB_PATH', plugin_dir_path( __FILE__ ) );
define( 'BRIDLE_KB_URL', plugin_dir_url( __FILE__ ) );

spl_autoload_register(
	function ( $class ) {
		$prefix = 'BridleKB\\';

		if ( strpos( $class, $prefix ) !== 0 ) {
			return;
		}

		$relative_class = substr( $class, strlen( $prefix ) );

		// Convert PascalCase to kebab-case: BlockTemplates → block-templates.
		$filename = strtolower( preg_replace( '/([a-z])([A-Z])/', '$1-$2', $relative_class ) );

		$file = BRIDLE_KB_PATH . 'includes/class-' . str_replace( '\\', '/', $filename ) . '.php';

		if ( file_exists( $file ) ) {
			require_once $file;
		}
	}
);

/**
 * Retrieve a plugin option from grouped storage.
 *
 * @param string $key     Option key.
 * @param mixed  $default Default value.
 * @return mixed
 */
function bridle_kb_get_option( $key, $default = null ) {
	static $cache = [];

	$settings_keys = [ 'articles_per_page', 'search_placeholder', 'post_type_slug' ];
	$group         = in_array( $key, $settings_keys, true ) ? 'bridle_kb_settings' : 'bridle_kb_design';

	if ( ! isset( $cache[ $group ] ) ) {
		$cache[ $group ] = get_option( $group, [] );
	}

	return array_key_exists( $key, $cache[ $group ] ) ? $cache[ $group ][ $key ] : $default;
}

function bridle_kb() {
	return BridleKB\Plugin::get_instance();
}

// Boot the plugin.
bridle_kb();

// Activation / Deactivation.
register_activation_hook( __FILE__, [ bridle_kb(), 'activate' ] );
register_deactivation_hook( __FILE__, [ bridle_kb(), 'deactivate' ] );
