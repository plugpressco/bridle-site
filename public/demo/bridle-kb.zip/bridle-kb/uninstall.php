<?php

/**
 * Uninstall script for Bridle KB plugin
 *
 * @package Bridle KB
 * @since   1.0.0
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'bridle_kb_settings' );
delete_option( 'bridle_kb_design' );

// Remove term meta added by this plugin.
delete_metadata( 'term', 0, 'category_icon', '', true );
delete_metadata( 'term', 0, 'category_color', '', true );

wp_cache_flush();
