<?php

/**
 * WordPress Abilities API integration.
 *
 * Registers Bridle KB's domain abilities so AI agents (via the Abilities REST
 * API `wp-abilities/v1` or the bundled WordPress MCP adapter) can read,
 * create, update and delete docs, browse categories, and configure the
 * knowledge base.
 *
 * The Abilities API ships in WordPress core 6.9+. On older versions the
 * `wp_abilities_api_*` hooks never fire, so this class is inert — no
 * feature detection is required beyond the defensive function_exists guard.
 *
 * @package BridleKB
 */

namespace BridleKB;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Abilities
 */
class Abilities {

	/**
	 * Ability category ID.
	 *
	 * @var string
	 */
	const CATEGORY = 'bridle-kb';

	/**
	 * Settings keys allowed in the `bridle_kb_settings` option group,
	 * mapped to their sanitizer.
	 *
	 * @var array<string, string>
	 */
	const SETTINGS_KEYS = [
		'articles_per_page'  => 'int',
		'search_placeholder' => 'text',
		'post_type_slug'     => 'slug',
	];

	/**
	 * Design keys allowed in the `bridle_kb_design` option group,
	 * mapped to their sanitizer.
	 *
	 * @var array<string, string>
	 */
	const DESIGN_KEYS = [
		'template_archive'   => 'key',
		'template_single'    => 'key',
		'template_taxonomy'  => 'key',
		'spacing_top'        => 'int',
		'container_width'    => 'key',
		'sidebar_visible'    => 'bool',
		'sidebar_search'     => 'bool',
		'toc_visible'        => 'bool',
		'toc_position'       => 'key',
		'breadcrumb_visible' => 'bool',
		'primary_color'      => 'color',
		'accent_color'       => 'color',
		'text_color'         => 'color',
		'heading_color'      => 'color',
		'muted_color'        => 'color',
		'bg_color'           => 'color',
		'card_bg_color'      => 'color',
		'hero_bg_color'      => 'color',
		'color_mode'         => 'key',
	];

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'wp_abilities_api_categories_init', [ $this, 'register_category' ] );
		add_action( 'wp_abilities_api_init', [ $this, 'register_abilities' ] );
		add_filter( 'saddle_integrations', [ $this, 'enrol_in_saddle' ] );
	}

	/**
	 * Offer the abilities through Saddle, if it is installed, the way Bridle
	 * does. Saddle wraps each bridle-kb/* ability as a saddle/bridle-kb-* tool.
	 * From Saddle 1.5.2 Bridle KB is one of its PlugPress plugins, so the tools
	 * are on as soon as both are active; older Saddle keeps them off until the
	 * site owner switches Bridle KB on under Services. Bridle KB does not
	 * depend on Saddle either way.
	 *
	 * @param array $integrations Saddle's catalog: slug => definition.
	 * @return array
	 */
	public function enrol_in_saddle( $integrations ) {
		$integrations                   = (array) $integrations;
		$integrations[ self::CATEGORY ] = [
			'prefix'      => self::CATEGORY . '/',
			'title'       => 'Bridle KB',
			'description' => __( 'The knowledge base: read, write and organise help articles and their categories.', 'bridle-kb' ),
			'author'      => 'PlugPress',
			'url'         => 'https://bridle.to',
		];

		return $integrations;
	}

	/**
	 * Register the Bridle KB ability category.
	 */
	public function register_category() {
		if ( ! function_exists( 'wp_register_ability_category' ) ) {
			return;
		}

		wp_register_ability_category(
			self::CATEGORY,
			[
				'label'       => __( 'Bridle KB', 'bridle-kb' ),
				// Core requires a description; without it the category fails
				// to register and every bridle-kb/* ability fails with it.
				'description' => __( 'Read, create and manage Bridle KB knowledge base docs, categories and settings.', 'bridle-kb' ),
			]
		);
	}

	/**
	 * Register all Bridle KB abilities.
	 */
	public function register_abilities() {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		$this->register_get_docs();
		$this->register_get_doc();
		$this->register_create_doc();
		$this->register_update_doc();
		$this->register_delete_doc();
		$this->register_get_categories();
		$this->register_get_stats();
		$this->register_get_settings();
		$this->register_update_settings();
	}

	/**
	 * Shared meta for read-only abilities.
	 *
	 * @return array
	 */
	private function readonly_meta() {
		return [
			'show_in_rest' => true,
			'mcp'          => [ 'public' => true ],
			'annotations'  => [
				'readonly'    => true,
				'destructive' => false,
				'idempotent'  => true,
			],
		];
	}

	/**
	 * Shared meta for write abilities.
	 *
	 * @param bool $destructive Whether the write can destroy existing data.
	 * @param bool $idempotent  Whether repeat calls with the same input are safe.
	 * @return array
	 */
	private function write_meta( $destructive, $idempotent ) {
		return [
			'show_in_rest' => true,
			'mcp'          => [ 'public' => true ],
			'annotations'  => [
				'readonly'    => false,
				'destructive' => $destructive,
				'idempotent'  => $idempotent,
			],
		];
	}

	/**
	 * JSON Schema fragment describing a doc in ability output.
	 *
	 * @param bool $with_content Include the full content property.
	 * @return array
	 */
	private function doc_schema( $with_content = false ) {
		$properties = [
			'id'         => [ 'type' => 'integer' ],
			'title'      => [ 'type' => 'string' ],
			'slug'       => [ 'type' => 'string' ],
			'url'        => [ 'type' => 'string' ],
			'status'     => [ 'type' => 'string' ],
			'excerpt'    => [ 'type' => 'string' ],
			'parent'     => [ 'type' => 'integer' ],
			'menu_order' => [ 'type' => 'integer' ],
			'template'   => [ 'type' => 'string' ],
			'author'     => [ 'type' => 'integer' ],
			'created'    => [ 'type' => 'string' ],
			'modified'   => [ 'type' => 'string' ],
			'categories' => [
				'type'  => 'array',
				'items' => [
					'type'       => 'object',
					'properties' => [
						'id'   => [ 'type' => 'integer' ],
						'name' => [ 'type' => 'string' ],
						'slug' => [ 'type' => 'string' ],
					],
				],
			],
		];

		if ( $with_content ) {
			$properties['content'] = [ 'type' => 'string' ];
		}

		return [
			'type'       => 'object',
			'properties' => $properties,
		];
	}

	/**
	 * Serialize a doc post for ability output.
	 *
	 * @param \WP_Post $post         Doc post.
	 * @param bool     $with_content Include full post content.
	 * @return array
	 */
	private function doc_to_array( $post, $with_content = false ) {
		$terms      = get_the_terms( $post->ID, 'docs_category' );
		$categories = [];

		if ( $terms && ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				$categories[] = [
					'id'   => (int) $term->term_id,
					'name' => $term->name,
					'slug' => $term->slug,
				];
			}
		}

		$doc = [
			'id'         => (int) $post->ID,
			'title'      => $post->post_title,
			'slug'       => $post->post_name,
			'url'        => get_permalink( $post ),
			'status'     => $post->post_status,
			'excerpt'    => $post->post_excerpt ? $post->post_excerpt : wp_trim_words( $post->post_content, 30 ),
			'parent'     => (int) $post->post_parent,
			'menu_order' => (int) $post->menu_order,
			'template'   => (string) get_post_meta( $post->ID, Editor::META_KEY, true ),
			'author'     => (int) $post->post_author,
			'created'    => $this->post_time_c( $post, false ),
			'modified'   => $this->post_time_c( $post, true ),
			'categories' => $categories,
		];

		if ( $with_content ) {
			$doc['content'] = $post->post_content;
		}

		return $doc;
	}

	/**
	 * ISO 8601 timestamp for a doc, guaranteed to be a string.
	 *
	 * get_post_time()/get_post_modified_time() with $gmt = true return false
	 * for drafts whose GMT date is still 0000-00-00 (WordPress only stamps the
	 * GMT date on publish). The ability output schema requires a string, so a
	 * false there fails validation and breaks the whole response. Prefer GMT,
	 * fall back to local (which drafts do have), then to an empty string.
	 *
	 * @param \WP_Post $post     Doc post.
	 * @param bool     $modified Use the modified time instead of the created time.
	 * @return string
	 */
	private function post_time_c( $post, $modified = false ) {
		$time = $modified
			? get_post_modified_time( 'c', true, $post )
			: get_post_time( 'c', true, $post );

		if ( false === $time ) {
			$time = $modified
				? get_post_modified_time( 'c', false, $post )
				: get_post_time( 'c', false, $post );
		}

		return is_string( $time ) ? $time : '';
	}

	/**
	 * Resolve a doc from an ability input `id`.
	 *
	 * @param mixed $input Ability input.
	 * @return \WP_Post|\WP_Error
	 */
	private function resolve_doc( $input ) {
		if ( ! is_array( $input ) || ! isset( $input['id'] ) || ! is_numeric( $input['id'] ) || (int) $input['id'] <= 0 ) {
			return new \WP_Error(
				'bridle_kb_missing_id',
				__( 'A positive numeric doc id is required.', 'bridle-kb' )
			);
		}

		$post = get_post( (int) $input['id'] );

		if ( ! $post || 'docs' !== $post->post_type ) {
			return new \WP_Error(
				'bridle_kb_doc_not_found',
				__( 'No doc exists with that id.', 'bridle-kb' )
			);
		}

		return $post;
	}

	/**
	 * Resolve category inputs (term IDs, slugs or names) to term IDs.
	 *
	 * Unknown string values are created as new categories when the current
	 * user can manage categories; otherwise a WP_Error is returned.
	 *
	 * @param array $categories Mixed list of ints (term IDs) and strings (slug or name).
	 * @return int[]|\WP_Error
	 */
	private function resolve_categories( $categories ) {
		$term_ids = [];

		foreach ( $categories as $category ) {
			if ( is_numeric( $category ) ) {
				$term = get_term( (int) $category, 'docs_category' );

				if ( ! $term || is_wp_error( $term ) ) {
					return new \WP_Error(
						'bridle_kb_invalid_categories',
						sprintf(
							/* translators: %d: term ID. */
							__( 'No doc category exists with id %d.', 'bridle-kb' ),
							(int) $category
						)
					);
				}

				$term_ids[] = (int) $term->term_id;
				continue;
			}

			if ( ! is_string( $category ) || '' === trim( $category ) ) {
				return new \WP_Error(
					'bridle_kb_invalid_categories',
					__( 'Categories must be term ids, slugs or names.', 'bridle-kb' )
				);
			}

			$name = trim( $category );
			$term = get_term_by( 'slug', sanitize_title( $name ), 'docs_category' );

			if ( ! $term ) {
				$term = get_term_by( 'name', $name, 'docs_category' );
			}

			if ( $term ) {
				$term_ids[] = (int) $term->term_id;
				continue;
			}

			if ( ! current_user_can( 'manage_categories' ) ) {
				return new \WP_Error(
					'bridle_kb_invalid_categories',
					sprintf(
						/* translators: %s: category name. */
						__( 'Doc category "%s" does not exist and you cannot create categories.', 'bridle-kb' ),
						$name
					)
				);
			}

			$created = wp_insert_term( $name, 'docs_category' );

			if ( is_wp_error( $created ) ) {
				return $created;
			}

			$term_ids[] = (int) $created['term_id'];
		}

		return array_values( array_unique( $term_ids ) );
	}

	/**
	 * Ability: bridle-kb/get-docs — list and search docs.
	 */
	private function register_get_docs() {
		wp_register_ability(
			'bridle-kb/get-docs',
			[
				'label'               => __( 'Find docs', 'bridle-kb' ),
				'description'         => __( 'List and search knowledge base docs. Supports free-text search and filtering by category, status and parent doc. Returns doc summaries with excerpts; use bridle-kb/get-doc for full content.', 'bridle-kb' ),
				'category'            => self::CATEGORY,
				'input_schema'        => [
					'type'                 => 'object',
					'default'              => (object) [],
					'additionalProperties' => false,
					'properties'           => [
						'search'   => [
							'type'        => 'string',
							'description' => __( 'Free-text search query.', 'bridle-kb' ),
						],
						'category' => [
							'type'        => [ 'integer', 'string' ],
							'description' => __( 'Doc category term id or slug.', 'bridle-kb' ),
						],
						'status'   => [
							'type'        => 'string',
							'enum'        => [ 'publish', 'draft', 'pending', 'private', 'future', 'any' ],
							'default'     => 'publish',
							'description' => __( 'Post status filter. Statuses other than "publish" require edit permissions.', 'bridle-kb' ),
						],
						'parent'   => [
							'type'        => 'integer',
							'description' => __( 'Only docs that are children of this doc id.', 'bridle-kb' ),
						],
						'per_page' => [
							'type'    => 'integer',
							'minimum' => 1,
							'maximum' => 100,
							'default' => 20,
						],
						'page'     => [
							'type'    => 'integer',
							'minimum' => 1,
							'default' => 1,
						],
						'orderby'  => [
							'type'    => 'string',
							'enum'    => [ 'title', 'date', 'modified', 'menu_order' ],
							'default' => 'menu_order',
						],
						'order'    => [
							'type'    => 'string',
							'enum'    => [ 'asc', 'desc' ],
							'default' => 'asc',
						],
					],
				],
				'output_schema'       => [
					'type'       => 'object',
					'properties' => [
						'docs'        => [
							'type'  => 'array',
							'items' => $this->doc_schema(),
						],
						'total'       => [ 'type' => 'integer' ],
						'total_pages' => [ 'type' => 'integer' ],
						'page'        => [ 'type' => 'integer' ],
					],
				],
				'execute_callback'    => [ $this, 'execute_get_docs' ],
				'permission_callback' => [ $this, 'can_read_docs' ],
				'meta'                => $this->readonly_meta(),
			]
		);
	}

	/**
	 * Permission: reading published docs is public; other statuses need edit rights.
	 *
	 * @param mixed $input Ability input.
	 * @return bool
	 */
	public function can_read_docs( $input = null ) {
		$status = is_array( $input ) && isset( $input['status'] ) ? (string) $input['status'] : 'publish';

		if ( 'publish' === $status ) {
			return true;
		}

		return current_user_can( 'edit_posts' );
	}

	/**
	 * Execute: bridle-kb/get-docs.
	 *
	 * @param mixed $input Ability input.
	 * @return array|\WP_Error
	 */
	public function execute_get_docs( $input = null ) {
		if ( ! is_array( $input ) ) {
			$input = [];
		}

		// Schema property defaults are not injected by the Abilities API — apply them here.
		$status   = isset( $input['status'] ) && is_string( $input['status'] ) ? $input['status'] : 'publish';
		$per_page = isset( $input['per_page'] ) && is_numeric( $input['per_page'] ) ? max( 1, min( 100, (int) $input['per_page'] ) ) : 20;
		$page     = isset( $input['page'] ) && is_numeric( $input['page'] ) ? max( 1, (int) $input['page'] ) : 1;
		$orderby  = isset( $input['orderby'] ) && is_string( $input['orderby'] ) ? $input['orderby'] : 'menu_order';
		$order    = isset( $input['order'] ) && 'desc' === strtolower( (string) $input['order'] ) ? 'DESC' : 'ASC';

		$allowed_status = [ 'publish', 'draft', 'pending', 'private', 'future', 'any' ];

		if ( ! in_array( $status, $allowed_status, true ) ) {
			return new \WP_Error(
				'bridle_kb_invalid_status',
				sprintf(
					/* translators: %s: comma-separated list of valid statuses. */
					__( 'Invalid status. Valid values: %s.', 'bridle-kb' ),
					implode( ', ', $allowed_status )
				)
			);
		}

		$allowed_orderby = [ 'title', 'date', 'modified', 'menu_order' ];

		if ( ! in_array( $orderby, $allowed_orderby, true ) ) {
			$orderby = 'menu_order';
		}

		if ( 'menu_order' === $orderby ) {
			$orderby = 'menu_order title';
		}

		$args = [
			'post_type'      => 'docs',
			'post_status'    => 'any' === $status ? [ 'publish', 'draft', 'pending', 'private', 'future' ] : $status,
			'posts_per_page' => $per_page,
			'paged'          => $page,
			'orderby'        => $orderby,
			'order'          => $order,
		];

		// Users who cannot edit others' posts (e.g. Contributors) only see
		// their own unpublished docs, mirroring core REST edit-context rules.
		if ( 'publish' !== $status && ! current_user_can( 'edit_others_posts' ) ) {
			$args['author'] = get_current_user_id();
		}

		if ( isset( $input['search'] ) && is_string( $input['search'] ) && '' !== trim( $input['search'] ) ) {
			$args['s'] = sanitize_text_field( $input['search'] );
		}

		if ( isset( $input['parent'] ) && is_numeric( $input['parent'] ) ) {
			$args['post_parent'] = (int) $input['parent'];
		}

		if ( isset( $input['category'] ) && '' !== $input['category'] ) {
			$args['tax_query'] = [
				[
					'taxonomy' => 'docs_category',
					'field'    => is_numeric( $input['category'] ) ? 'term_id' : 'slug',
					'terms'    => is_numeric( $input['category'] ) ? (int) $input['category'] : sanitize_title( (string) $input['category'] ),
				],
			];
		}

		$query = new \WP_Query( $args );
		$docs  = [];

		foreach ( $query->posts as $post ) {
			$docs[] = $this->doc_to_array( $post );
		}

		return [
			'docs'        => $docs,
			'total'       => (int) $query->found_posts,
			'total_pages' => (int) $query->max_num_pages,
			'page'        => $page,
		];
	}

	/**
	 * Ability: bridle-kb/get-doc — read a single doc with full content.
	 */
	private function register_get_doc() {
		wp_register_ability(
			'bridle-kb/get-doc',
			[
				'label'               => __( 'Read a doc', 'bridle-kb' ),
				'description'         => __( 'Read one knowledge base doc, including its full content, categories, parent and template.', 'bridle-kb' ),
				'category'            => self::CATEGORY,
				'input_schema'        => [
					'type'                 => 'object',
					'additionalProperties' => false,
					'required'             => [ 'id' ],
					'properties'           => [
						'id' => [
							'type'        => 'integer',
							'description' => __( 'Doc post id.', 'bridle-kb' ),
						],
					],
				],
				'output_schema'       => $this->doc_schema( true ),
				'execute_callback'    => [ $this, 'execute_get_doc' ],
				'permission_callback' => [ $this, 'can_read_doc' ],
				'meta'                => $this->readonly_meta(),
			]
		);
	}

	/**
	 * Permission: published docs are public; drafts etc. need edit rights on the doc.
	 *
	 * @param mixed $input Ability input.
	 * @return bool
	 */
	public function can_read_doc( $input = null ) {
		$post = $this->resolve_doc( $input );

		if ( is_wp_error( $post ) ) {
			// Let the execute callback return the clean not-found/missing-id error.
			return true;
		}

		if ( 'publish' === $post->post_status ) {
			return true;
		}

		return current_user_can( 'edit_post', $post->ID );
	}

	/**
	 * Execute: bridle-kb/get-doc.
	 *
	 * @param mixed $input Ability input.
	 * @return array|\WP_Error
	 */
	public function execute_get_doc( $input = null ) {
		$post = $this->resolve_doc( $input );

		if ( is_wp_error( $post ) ) {
			return $post;
		}

		return $this->doc_to_array( $post, true );
	}

	/**
	 * Ability: bridle-kb/create-doc — create a new doc.
	 */
	private function register_create_doc() {
		wp_register_ability(
			'bridle-kb/create-doc',
			[
				'label'               => __( 'Create a doc', 'bridle-kb' ),
				'description'         => __( 'Create a new knowledge base doc. Optional fields include slug (permalink), author, content, excerpt, categories, parent, order, template and searchability. Categories may be given as term ids, slugs or names; unknown names are created automatically when permitted. Defaults to draft status.', 'bridle-kb' ),
				'category'            => self::CATEGORY,
				'input_schema'        => [
					'type'                 => 'object',
					'additionalProperties' => false,
					'required'             => [ 'title' ],
					'properties'           => $this->doc_write_properties(),
				],
				'output_schema'       => $this->doc_schema(),
				'execute_callback'    => [ $this, 'execute_create_doc' ],
				'permission_callback' => [ $this, 'can_create_docs' ],
				'meta'                => $this->write_meta( false, false ),
			]
		);
	}

	/**
	 * Shared input properties for create-doc / update-doc.
	 *
	 * @return array
	 */
	private function doc_write_properties() {
		return [
			'title'      => [
				'type'        => 'string',
				'description' => __( 'Doc title.', 'bridle-kb' ),
			],
			'slug'       => [
				'type'        => 'string',
				'description' => __( 'Permalink slug. Omit on create to derive it from the title; set to rename an existing doc.', 'bridle-kb' ),
			],
			'author'     => [
				'type'        => 'integer',
				'description' => __( 'Author user id. Requires permission to assign authors; ignored otherwise.', 'bridle-kb' ),
			],
			'content'    => [
				'type'        => 'string',
				'description' => __( 'Doc content as HTML or block markup.', 'bridle-kb' ),
			],
			'excerpt'    => [
				'type'        => 'string',
				'description' => __( 'Short summary shown in listings and search results.', 'bridle-kb' ),
			],
			'status'     => [
				'type'        => 'string',
				'enum'        => [ 'publish', 'draft', 'pending', 'private' ],
				'description' => __( 'Post status. Publishing requires publish permissions. Defaults to draft on create.', 'bridle-kb' ),
			],
			'categories' => [
				'type'        => 'array',
				'items'       => [ 'type' => [ 'integer', 'string' ] ],
				'description' => __( 'Doc categories as term ids, slugs or names.', 'bridle-kb' ),
			],
			'parent'     => [
				'type'        => 'integer',
				'description' => __( 'Parent doc id for hierarchical docs. Use 0 for top level.', 'bridle-kb' ),
			],
			'menu_order' => [
				'type'        => 'integer',
				'description' => __( 'Manual sort position within listings.', 'bridle-kb' ),
			],
			'template'   => [
				'type'        => 'string',
				'description' => __( 'Bridle KB single-doc template key. Empty string uses the global default.', 'bridle-kb' ),
			],
			'searchable' => [
				'type'        => 'boolean',
				'description' => __( 'Whether the doc appears in the frontend AJAX search. Defaults to true.', 'bridle-kb' ),
			],
		];
	}

	/**
	 * Permission: creating docs.
	 *
	 * @return bool
	 */
	public function can_create_docs() {
		$pto = get_post_type_object( 'docs' );
		$cap = ( $pto && isset( $pto->cap->create_posts ) ) ? $pto->cap->create_posts : 'edit_posts';

		return current_user_can( $cap );
	}

	/**
	 * Apply the writable identity fields (slug, author) shared by create and
	 * update onto a wp_insert_post/wp_update_post array.
	 *
	 * Slug is sanitized with sanitize_title() and only applied when non-empty.
	 * Author is only applied when the current user may assign authors on the
	 * docs post type and the target user can edit docs — otherwise it is
	 * silently ignored (never a hard failure, so a partial update still lands).
	 *
	 * @param array $postarr Post array passed by reference.
	 * @param array $input   Ability input.
	 */
	private function apply_writable_identity( array &$postarr, array $input ) {
		if ( isset( $input['slug'] ) && is_string( $input['slug'] ) ) {
			$slug = sanitize_title( $input['slug'] );

			if ( '' !== $slug ) {
				$postarr['post_name'] = $slug;
			}
		}

		if ( isset( $input['author'] ) && is_numeric( $input['author'] ) ) {
			$author_id = (int) $input['author'];
			$pto       = get_post_type_object( 'docs' );
			$cap       = ( $pto && isset( $pto->cap->edit_others_posts ) ) ? $pto->cap->edit_others_posts : 'edit_others_posts';

			if ( $author_id > 0 && current_user_can( $cap ) && get_userdata( $author_id ) ) {
				$postarr['post_author'] = $author_id;
			}
		}
	}

	/**
	 * Execute: bridle-kb/create-doc.
	 *
	 * @param mixed $input Ability input.
	 * @return array|\WP_Error
	 */
	public function execute_create_doc( $input = null ) {
		if ( ! is_array( $input ) ) {
			$input = [];
		}

		if ( ! isset( $input['title'] ) || ! is_string( $input['title'] ) || '' === trim( $input['title'] ) ) {
			return new \WP_Error(
				'bridle_kb_missing_title',
				__( 'A title is required to create a doc.', 'bridle-kb' )
			);
		}

		$status = isset( $input['status'] ) && is_string( $input['status'] ) ? $input['status'] : 'draft';
		$error  = $this->check_status_permission( $status );

		if ( is_wp_error( $error ) ) {
			return $error;
		}

		$postarr = [
			'post_type'   => 'docs',
			'post_title'  => sanitize_text_field( $input['title'] ),
			'post_status' => $status,
		];

		if ( isset( $input['content'] ) && is_string( $input['content'] ) ) {
			$postarr['post_content'] = wp_kses_post( $input['content'] );
		}

		if ( isset( $input['excerpt'] ) && is_string( $input['excerpt'] ) ) {
			$postarr['post_excerpt'] = sanitize_textarea_field( $input['excerpt'] );
		}

		if ( isset( $input['parent'] ) && is_numeric( $input['parent'] ) ) {
			$postarr['post_parent'] = max( 0, (int) $input['parent'] );
		}

		if ( isset( $input['menu_order'] ) && is_numeric( $input['menu_order'] ) ) {
			$postarr['menu_order'] = (int) $input['menu_order'];
		}

		$this->apply_writable_identity( $postarr, $input );

		$term_ids = null;

		if ( isset( $input['categories'] ) && is_array( $input['categories'] ) ) {
			$term_ids = $this->resolve_categories( $input['categories'] );

			if ( is_wp_error( $term_ids ) ) {
				return $term_ids;
			}
		}

		$post_id = wp_insert_post( $postarr, true );

		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		if ( null !== $term_ids ) {
			wp_set_object_terms( $post_id, $term_ids, 'docs_category' );
		}

		$this->apply_doc_meta( $post_id, $input );

		return $this->doc_to_array( get_post( $post_id ) );
	}

	/**
	 * Ability: bridle-kb/update-doc — modify an existing doc.
	 */
	private function register_update_doc() {
		$properties       = $this->doc_write_properties();
		$properties['id'] = [
			'type'        => 'integer',
			'description' => __( 'Doc post id to update.', 'bridle-kb' ),
		];

		wp_register_ability(
			'bridle-kb/update-doc',
			[
				'label'               => __( 'Update a doc', 'bridle-kb' ),
				'description'         => __( 'Update fields of an existing knowledge base doc: title, slug (permalink), author, content, excerpt, status, categories, parent, order, template or searchability. Only the provided fields change.', 'bridle-kb' ),
				'category'            => self::CATEGORY,
				'input_schema'        => [
					'type'                 => 'object',
					'additionalProperties' => false,
					'required'             => [ 'id' ],
					'properties'           => $properties,
				],
				'output_schema'       => $this->doc_schema(),
				'execute_callback'    => [ $this, 'execute_update_doc' ],
				'permission_callback' => [ $this, 'can_edit_doc' ],
				'meta'                => $this->write_meta( true, true ),
			]
		);
	}

	/**
	 * Permission: editing a specific doc.
	 *
	 * @param mixed $input Ability input.
	 * @return bool
	 */
	public function can_edit_doc( $input = null ) {
		$post = $this->resolve_doc( $input );

		if ( is_wp_error( $post ) ) {
			// Let the execute callback return the clean not-found/missing-id error.
			return true;
		}

		return current_user_can( 'edit_post', $post->ID );
	}

	/**
	 * Execute: bridle-kb/update-doc.
	 *
	 * @param mixed $input Ability input.
	 * @return array|\WP_Error
	 */
	public function execute_update_doc( $input = null ) {
		$post = $this->resolve_doc( $input );

		if ( is_wp_error( $post ) ) {
			return $post;
		}

		$postarr = [ 'ID' => $post->ID ];

		if ( isset( $input['title'] ) && is_string( $input['title'] ) ) {
			if ( '' === trim( $input['title'] ) ) {
				return new \WP_Error(
					'bridle_kb_invalid_title',
					__( 'The title cannot be empty.', 'bridle-kb' )
				);
			}

			$postarr['post_title'] = sanitize_text_field( $input['title'] );
		}

		if ( isset( $input['status'] ) && is_string( $input['status'] ) && $input['status'] !== $post->post_status ) {
			$error = $this->check_status_permission( $input['status'] );

			if ( is_wp_error( $error ) ) {
				return $error;
			}

			$postarr['post_status'] = $input['status'];
		}

		if ( isset( $input['content'] ) && is_string( $input['content'] ) ) {
			$postarr['post_content'] = wp_kses_post( $input['content'] );
		}

		if ( isset( $input['excerpt'] ) && is_string( $input['excerpt'] ) ) {
			$postarr['post_excerpt'] = sanitize_textarea_field( $input['excerpt'] );
		}

		if ( isset( $input['parent'] ) && is_numeric( $input['parent'] ) ) {
			if ( (int) $input['parent'] === $post->ID ) {
				return new \WP_Error(
					'bridle_kb_invalid_parent',
					__( 'A doc cannot be its own parent.', 'bridle-kb' )
				);
			}

			$postarr['post_parent'] = max( 0, (int) $input['parent'] );
		}

		if ( isset( $input['menu_order'] ) && is_numeric( $input['menu_order'] ) ) {
			$postarr['menu_order'] = (int) $input['menu_order'];
		}

		$this->apply_writable_identity( $postarr, is_array( $input ) ? $input : [] );

		if ( isset( $input['categories'] ) && is_array( $input['categories'] ) ) {
			$term_ids = $this->resolve_categories( $input['categories'] );

			if ( is_wp_error( $term_ids ) ) {
				return $term_ids;
			}

			wp_set_object_terms( $post->ID, $term_ids, 'docs_category' );
		}

		if ( count( $postarr ) > 1 ) {
			$updated = wp_update_post( $postarr, true );

			if ( is_wp_error( $updated ) ) {
				return $updated;
			}
		}

		$this->apply_doc_meta( $post->ID, is_array( $input ) ? $input : [] );

		return $this->doc_to_array( get_post( $post->ID ) );
	}

	/**
	 * Ability: bridle-kb/delete-doc — trash or permanently delete a doc.
	 */
	private function register_delete_doc() {
		wp_register_ability(
			'bridle-kb/delete-doc',
			[
				'label'               => __( 'Delete a doc', 'bridle-kb' ),
				'description'         => __( 'Move a knowledge base doc to the trash, or permanently delete it when force is true.', 'bridle-kb' ),
				'category'            => self::CATEGORY,
				'input_schema'        => [
					'type'                 => 'object',
					'additionalProperties' => false,
					'required'             => [ 'id' ],
					'properties'           => [
						'id'    => [
							'type'        => 'integer',
							'description' => __( 'Doc post id to delete.', 'bridle-kb' ),
						],
						'force' => [
							'type'        => 'boolean',
							'default'     => false,
							'description' => __( 'Permanently delete instead of trashing.', 'bridle-kb' ),
						],
					],
				],
				'output_schema'       => [
					'type'       => 'object',
					'properties' => [
						'deleted' => [ 'type' => 'boolean' ],
						'trashed' => [ 'type' => 'boolean' ],
						'id'      => [ 'type' => 'integer' ],
					],
				],
				'execute_callback'    => [ $this, 'execute_delete_doc' ],
				'permission_callback' => [ $this, 'can_delete_doc' ],
				'meta'                => $this->write_meta( true, true ),
			]
		);
	}

	/**
	 * Permission: deleting a specific doc.
	 *
	 * @param mixed $input Ability input.
	 * @return bool
	 */
	public function can_delete_doc( $input = null ) {
		$post = $this->resolve_doc( $input );

		if ( is_wp_error( $post ) ) {
			// Let the execute callback return the clean not-found/missing-id error.
			return true;
		}

		return current_user_can( 'delete_post', $post->ID );
	}

	/**
	 * Execute: bridle-kb/delete-doc.
	 *
	 * @param mixed $input Ability input.
	 * @return array|\WP_Error
	 */
	public function execute_delete_doc( $input = null ) {
		$post = $this->resolve_doc( $input );

		if ( is_wp_error( $post ) ) {
			return $post;
		}

		// Schema property defaults are not injected — apply explicitly.
		$force = is_array( $input ) && array_key_exists( 'force', $input ) && null !== $input['force']
			? (bool) $input['force']
			: false;

		if ( $force ) {
			$result = wp_delete_post( $post->ID, true );

			if ( ! $result ) {
				return new \WP_Error(
					'bridle_kb_doc_data_unavailable',
					__( 'The doc could not be deleted.', 'bridle-kb' )
				);
			}

			return [
				'deleted' => true,
				'trashed' => false,
				'id'      => (int) $post->ID,
			];
		}

		if ( 'trash' === $post->post_status ) {
			return [
				'deleted' => false,
				'trashed' => true,
				'id'      => (int) $post->ID,
			];
		}

		$result = wp_trash_post( $post->ID );

		if ( ! $result ) {
			return new \WP_Error(
				'bridle_kb_doc_data_unavailable',
				__( 'The doc could not be trashed.', 'bridle-kb' )
			);
		}

		return [
			'deleted' => false,
			'trashed' => true,
			'id'      => (int) $post->ID,
		];
	}

	/**
	 * Ability: bridle-kb/get-categories — list doc categories.
	 */
	private function register_get_categories() {
		wp_register_ability(
			'bridle-kb/get-categories',
			[
				'label'               => __( 'List doc categories', 'bridle-kb' ),
				'description'         => __( 'List all knowledge base categories with their slug, description, doc count, icon and color. Use the ids or slugs when creating or filtering docs.', 'bridle-kb' ),
				'category'            => self::CATEGORY,
				'input_schema'        => [
					'type'                 => 'object',
					'default'              => (object) [],
					'additionalProperties' => false,
					'properties'           => [
						'hide_empty' => [
							'type'        => 'boolean',
							'default'     => false,
							'description' => __( 'Only categories that contain docs.', 'bridle-kb' ),
						],
					],
				],
				'output_schema'       => [
					'type'       => 'object',
					'properties' => [
						'categories' => [
							'type'  => 'array',
							'items' => [
								'type'       => 'object',
								'properties' => [
									'id'          => [ 'type' => 'integer' ],
									'name'        => [ 'type' => 'string' ],
									'slug'        => [ 'type' => 'string' ],
									'description' => [ 'type' => 'string' ],
									'parent'      => [ 'type' => 'integer' ],
									'count'       => [ 'type' => 'integer' ],
									'url'         => [ 'type' => 'string' ],
									'icon_url'    => [ 'type' => 'string' ],
									'color'       => [ 'type' => 'string' ],
								],
							],
						],
						'total'      => [ 'type' => 'integer' ],
					],
				],
				'execute_callback'    => [ $this, 'execute_get_categories' ],
				'permission_callback' => '__return_true',
				'meta'                => $this->readonly_meta(),
			]
		);
	}

	/**
	 * Execute: bridle-kb/get-categories.
	 *
	 * @param mixed $input Ability input.
	 * @return array|\WP_Error
	 */
	public function execute_get_categories( $input = null ) {
		$hide_empty = is_array( $input ) && array_key_exists( 'hide_empty', $input ) && null !== $input['hide_empty']
			? (bool) $input['hide_empty']
			: false;

		$terms = get_terms(
			[
				'taxonomy'   => 'docs_category',
				'hide_empty' => $hide_empty,
				'orderby'    => 'name',
				'order'      => 'ASC',
			]
		);

		if ( is_wp_error( $terms ) ) {
			return new \WP_Error(
				'bridle_kb_categories_data_unavailable',
				__( 'Doc categories could not be retrieved.', 'bridle-kb' )
			);
		}

		$categories = [];

		foreach ( $terms as $term ) {
			$icon_id  = get_term_meta( $term->term_id, 'category_icon', true );
			$icon_url = $icon_id ? (string) wp_get_attachment_url( $icon_id ) : '';
			$link     = get_term_link( $term );

			$categories[] = [
				'id'          => (int) $term->term_id,
				'name'        => $term->name,
				'slug'        => $term->slug,
				'description' => $term->description,
				'parent'      => (int) $term->parent,
				'count'       => (int) $term->count,
				'url'         => is_wp_error( $link ) ? '' : $link,
				'icon_url'    => $icon_url,
				'color'       => (string) get_term_meta( $term->term_id, 'category_color', true ),
			];
		}

		return [
			'categories' => $categories,
			'total'      => count( $categories ),
		];
	}

	/**
	 * Ability: bridle-kb/get-stats — zero-arg knowledge base overview.
	 */
	private function register_get_stats() {
		wp_register_ability(
			'bridle-kb/get-stats',
			[
				'label'               => __( 'Knowledge base overview', 'bridle-kb' ),
				'description'         => __( 'Get knowledge base totals: published docs, drafts, docs in trash and category count.', 'bridle-kb' ),
				'category'            => self::CATEGORY,
				'input_schema'        => [
					'type'                 => 'object',
					'default'              => (object) [],
					'additionalProperties' => false,
					'properties'           => (object) [],
				],
				'output_schema'       => [
					'type'       => 'object',
					'properties' => [
						'published_docs'   => [ 'type' => 'integer' ],
						'draft_docs'       => [ 'type' => 'integer' ],
						'trashed_docs'     => [ 'type' => 'integer' ],
						'total_categories' => [ 'type' => 'integer' ],
					],
				],
				'execute_callback'    => [ $this, 'execute_get_stats' ],
				'permission_callback' => [ $this, 'can_manage_settings' ],
				'meta'                => $this->readonly_meta(),
			]
		);
	}

	/**
	 * Execute: bridle-kb/get-stats.
	 *
	 * @return array
	 */
	public function execute_get_stats() {
		$counts = wp_count_posts( 'docs' );

		return [
			'published_docs'   => isset( $counts->publish ) ? (int) $counts->publish : 0,
			'draft_docs'       => isset( $counts->draft ) ? (int) $counts->draft : 0,
			'trashed_docs'     => isset( $counts->trash ) ? (int) $counts->trash : 0,
			'total_categories' => (int) wp_count_terms(
				[
					'taxonomy'   => 'docs_category',
					'hide_empty' => false,
				]
			),
		];
	}

	/**
	 * Ability: bridle-kb/get-settings — read knowledge base configuration.
	 */
	private function register_get_settings() {
		wp_register_ability(
			'bridle-kb/get-settings',
			[
				'label'               => __( 'Get knowledge base settings', 'bridle-kb' ),
				'description'         => __( 'Read the Bridle KB configuration: general settings (docs per page, search placeholder, URL slug) and design settings (templates, layout toggles, colors).', 'bridle-kb' ),
				'category'            => self::CATEGORY,
				'input_schema'        => [
					'type'                 => 'object',
					'default'              => (object) [],
					'additionalProperties' => false,
					'properties'           => (object) [],
				],
				'output_schema'       => [
					'type'       => 'object',
					'properties' => [
						'settings' => [ 'type' => 'object' ],
						'design'   => [ 'type' => 'object' ],
					],
				],
				'execute_callback'    => [ $this, 'execute_get_settings' ],
				'permission_callback' => [ $this, 'can_manage_settings' ],
				'meta'                => $this->readonly_meta(),
			]
		);
	}

	/**
	 * Permission: managing plugin configuration (mirrors the admin UI).
	 *
	 * @return bool
	 */
	public function can_manage_settings() {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Execute: bridle-kb/get-settings.
	 *
	 * @return array
	 */
	public function execute_get_settings() {
		$settings = get_option( 'bridle_kb_settings', [] );
		$design   = get_option( 'bridle_kb_design', [] );

		return [
			'settings' => is_array( $settings ) ? $settings : [],
			'design'   => is_array( $design ) ? $design : [],
		];
	}

	/**
	 * Ability: bridle-kb/update-settings — configure the knowledge base.
	 */
	private function register_update_settings() {
		wp_register_ability(
			'bridle-kb/update-settings',
			[
				'label'               => __( 'Update knowledge base settings', 'bridle-kb' ),
				'description'         => __( 'Change Bridle KB configuration. Accepts any subset of general settings (articles_per_page, search_placeholder, post_type_slug) and design settings (template_archive, template_single, template_taxonomy, spacing_top, container_width, sidebar_visible, sidebar_search, toc_visible, toc_position, breadcrumb_visible, primary_color, accent_color, text_color, heading_color, muted_color, bg_color, card_bg_color, hero_bg_color, color_mode). Unspecified keys keep their current value.', 'bridle-kb' ),
				'category'            => self::CATEGORY,
				'input_schema'        => [
					'type'                 => 'object',
					'additionalProperties' => false,
					'properties'           => $this->settings_write_properties(),
				],
				'output_schema'       => [
					'type'       => 'object',
					'properties' => [
						'updated'  => [
							'type'  => 'array',
							'items' => [ 'type' => 'string' ],
						],
						'settings' => [ 'type' => 'object' ],
						'design'   => [ 'type' => 'object' ],
					],
				],
				'execute_callback'    => [ $this, 'execute_update_settings' ],
				'permission_callback' => [ $this, 'can_manage_settings' ],
				'meta'                => $this->write_meta( true, true ),
			]
		);
	}

	/**
	 * Input schema properties for update-settings.
	 *
	 * @return array
	 */
	private function settings_write_properties() {
		return [
			'articles_per_page'  => [
				'type'    => 'integer',
				'minimum' => 1,
				'maximum' => 100,
			],
			'search_placeholder' => [ 'type' => 'string' ],
			'post_type_slug'     => [
				'type'        => 'string',
				'description' => __( 'URL base for the knowledge base (e.g. "docs"). Changing it updates permalinks.', 'bridle-kb' ),
			],
			'template_archive'   => [ 'type' => 'string' ],
			'template_single'    => [ 'type' => 'string' ],
			'template_taxonomy'  => [ 'type' => 'string' ],
			'spacing_top'        => [
				'type'    => 'integer',
				'minimum' => 0,
			],
			'container_width'    => [ 'type' => 'string' ],
			'sidebar_visible'    => [ 'type' => 'boolean' ],
			'sidebar_search'     => [ 'type' => 'boolean' ],
			'toc_visible'        => [ 'type' => 'boolean' ],
			'toc_position'       => [
				'type' => 'string',
				'enum' => [ 'left', 'right' ],
			],
			'breadcrumb_visible' => [ 'type' => 'boolean' ],
			'primary_color'      => [ 'type' => 'string' ],
			'accent_color'       => [ 'type' => 'string' ],
			'text_color'         => [ 'type' => 'string' ],
			'heading_color'      => [ 'type' => 'string' ],
			'muted_color'        => [ 'type' => 'string' ],
			'bg_color'           => [ 'type' => 'string' ],
			'card_bg_color'      => [ 'type' => 'string' ],
			'hero_bg_color'      => [ 'type' => 'string' ],
			'color_mode'         => [ 'type' => 'string' ],
		];
	}

	/**
	 * Execute: bridle-kb/update-settings.
	 *
	 * @param mixed $input Ability input.
	 * @return array|\WP_Error
	 */
	public function execute_update_settings( $input = null ) {
		if ( ! is_array( $input ) || empty( $input ) ) {
			return new \WP_Error(
				'bridle_kb_missing_settings',
				__( 'Provide at least one setting to update.', 'bridle-kb' )
			);
		}

		$settings = get_option( 'bridle_kb_settings', [] );
		$design   = get_option( 'bridle_kb_design', [] );
		$settings = is_array( $settings ) ? $settings : [];
		$design   = is_array( $design ) ? $design : [];

		$updated      = [];
		$slug_changed = false;

		foreach ( $input as $key => $value ) {
			if ( isset( self::SETTINGS_KEYS[ $key ] ) ) {
				$clean = $this->sanitize_setting( $value, self::SETTINGS_KEYS[ $key ] );

				if ( is_wp_error( $clean ) ) {
					return new \WP_Error(
						'bridle_kb_invalid_' . $key,
						sprintf(
							/* translators: %s: setting key. */
							__( 'The value for "%s" is invalid.', 'bridle-kb' ),
							$key
						)
					);
				}

				if ( 'post_type_slug' === $key && $clean !== ( $settings['post_type_slug'] ?? 'docs' ) ) {
					$slug_changed = true;
				}

				$settings[ $key ] = $clean;
				$updated[]        = $key;
				continue;
			}

			if ( isset( self::DESIGN_KEYS[ $key ] ) ) {
				$clean = $this->sanitize_setting( $value, self::DESIGN_KEYS[ $key ] );

				if ( is_wp_error( $clean ) ) {
					return new \WP_Error(
						'bridle_kb_invalid_' . $key,
						sprintf(
							/* translators: %s: setting key. */
							__( 'The value for "%s" is invalid.', 'bridle-kb' ),
							$key
						)
					);
				}

				$design[ $key ] = $clean;
				$updated[]      = $key;
				continue;
			}

			return new \WP_Error(
				'bridle_kb_invalid_setting',
				sprintf(
					/* translators: %s: setting key. */
					__( 'Unknown setting "%s".', 'bridle-kb' ),
					sanitize_key( (string) $key )
				)
			);
		}

		update_option( 'bridle_kb_settings', $settings );
		update_option( 'bridle_kb_design', $design );

		if ( $slug_changed ) {
			// The post type rewrite slug comes from the option; re-register and flush.
			$post_types = new PostTypes();
			$post_types->register_post_type();
			flush_rewrite_rules();
		}

		return [
			'updated'  => $updated,
			'settings' => $settings,
			'design'   => $design,
		];
	}

	/**
	 * Sanitize a settings value by declared type.
	 *
	 * @param mixed  $value Raw value.
	 * @param string $type  One of int|text|slug|key|bool|color.
	 * @return mixed|\WP_Error
	 */
	private function sanitize_setting( $value, $type ) {
		switch ( $type ) {
			case 'int':
				if ( ! is_numeric( $value ) ) {
					return new \WP_Error( 'invalid' );
				}

				return (int) $value;

			case 'bool':
				return (bool) $value;

			case 'text':
				if ( ! is_string( $value ) ) {
					return new \WP_Error( 'invalid' );
				}

				return sanitize_text_field( $value );

			case 'slug':
				if ( ! is_string( $value ) || '' === sanitize_title( $value ) ) {
					return new \WP_Error( 'invalid' );
				}

				return sanitize_title( $value );

			case 'key':
				if ( ! is_string( $value ) ) {
					return new \WP_Error( 'invalid' );
				}

				return sanitize_key( $value );

			case 'color':
				if ( ! is_string( $value ) ) {
					return new \WP_Error( 'invalid' );
				}

				// Empty string is legal — it means "inherit / unset".
				if ( '' === $value ) {
					return '';
				}

				$color = sanitize_hex_color( $value );

				if ( ! $color ) {
					return new \WP_Error( 'invalid' );
				}

				return $color;
		}

		return new \WP_Error( 'invalid' );
	}

	/**
	 * Reject publish-like statuses the current user cannot set.
	 *
	 * wp_insert_post() does not check publish capability itself.
	 *
	 * @param string $status Requested status.
	 * @return true|\WP_Error
	 */
	private function check_status_permission( $status ) {
		$allowed = [ 'publish', 'draft', 'pending', 'private' ];

		if ( ! in_array( $status, $allowed, true ) ) {
			return new \WP_Error(
				'bridle_kb_invalid_status',
				sprintf(
					/* translators: %s: comma-separated list of valid statuses. */
					__( 'Invalid status. Valid values: %s.', 'bridle-kb' ),
					implode( ', ', $allowed )
				)
			);
		}

		if ( in_array( $status, [ 'publish', 'private' ], true ) ) {
			$pto = get_post_type_object( 'docs' );
			$cap = ( $pto && isset( $pto->cap->publish_posts ) ) ? $pto->cap->publish_posts : 'publish_posts';

			if ( ! current_user_can( $cap ) ) {
				return new \WP_Error(
					'bridle_kb_invalid_status',
					__( 'You are not allowed to publish docs. Use "draft" or "pending" instead.', 'bridle-kb' )
				);
			}
		}

		return true;
	}

	/**
	 * Apply template and searchable meta from ability input.
	 *
	 * @param int   $post_id Doc post id.
	 * @param array $input   Ability input.
	 */
	private function apply_doc_meta( $post_id, $input ) {
		if ( isset( $input['template'] ) && is_string( $input['template'] ) ) {
			update_post_meta( $post_id, Editor::META_KEY, sanitize_key( $input['template'] ) );
		}

		if ( array_key_exists( 'searchable', $input ) && null !== $input['searchable'] ) {
			update_post_meta( $post_id, '_bridle_kb_searchable', $input['searchable'] ? '1' : '0' );
		}
	}
}
