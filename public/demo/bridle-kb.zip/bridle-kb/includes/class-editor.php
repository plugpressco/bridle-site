<?php

/**
 * Block Editor — Template panel in publish sidebar.
 *
 * @package BridleKB
 */

namespace BridleKB;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Editor
 */
class Editor {


	/**
	 * Post meta key for doc template override.
	 *
	 * @var string
	 */
	const META_KEY = '_bridle_kb_template';

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'init', [ $this, 'register_meta' ] );
		add_action( 'enqueue_block_editor_assets', [ $this, 'enqueue_editor_assets' ] );
	}

	/**
	 * Register post meta for docs template.
	 */
	public function register_meta() {
		register_post_meta(
			'docs',
			self::META_KEY,
			[
				'show_in_rest'  => true,
				'single'        => true,
				'type'          => 'string',
				'default'       => '',
				'auth_callback' => function () {
					return current_user_can( 'edit_posts' );
				},
			]
		);
	}

	/**
	 * Enqueue block editor assets for docs post type.
	 */
	public function enqueue_editor_assets() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || 'post' !== $screen->base ) {
			return;
		}

		$post_type = 'docs';
		// Read-only screen detection (which post type is being edited) to decide whether
		// to enqueue editor assets — no data is processed, so no nonce applies.
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['post'] ) ) {
			$edited_post = get_post( (int) $_GET['post'] );
			$post_type   = $edited_post ? $edited_post->post_type : $post_type;
		} elseif ( isset( $_GET['post_type'] ) ) {
			$post_type = sanitize_key( wp_unslash( $_GET['post_type'] ) );
		}
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		if ( 'docs' !== $post_type ) {
			return;
		}

		$asset_file = BRIDLE_KB_PATH . 'build/editor.asset.php';
		if ( ! file_exists( $asset_file ) ) {
			return;
		}

		$asset = include $asset_file;

		wp_enqueue_script(
			'bridle-kb-editor',
			BRIDLE_KB_URL . 'build/editor.js',
			$asset['dependencies'],
			$asset['version'],
			true
		);

		$style_file = BRIDLE_KB_PATH . 'build/editor.css';
		if ( file_exists( $style_file ) ) {
			wp_enqueue_style(
				'bridle-kb-editor',
				BRIDLE_KB_URL . 'build/editor.css',
				[],
				$asset['version']
			);
		}

		wp_localize_script(
			'bridle-kb-editor',
			'bridleKbEditor',
			[
				'templates' => Design::get_templates()['single'] ?? [],
				'i18n'      => [
					'panelTitle' => __( 'Article template', 'bridle-kb' ),
					'panelDesc'  => __( 'A different layout for this article. Use default follows the site setting.', 'bridle-kb' ),
					'useDefault' => __( 'Use default', 'bridle-kb' ),
				],
			]
		);
	}
}
