<?php

/**
 * Main Plugin class.
 *
 * @package BridleKB
 */

namespace BridleKB;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Plugin
 */
class Plugin {


	/**
	 * Singleton instance.
	 *
	 * @var Plugin|null
	 */
	private static $instance = null;

	/**
	 * Get the singleton instance.
	 *
	 * @return Plugin
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		$this->init();
	}

	/**
	 * Initialize plugin components.
	 */
	private function init() {
		add_action( 'plugins_loaded', [ $this, 'load_textdomain' ] );

		new PostTypes();
		new Admin();
		new Editor();
		new Assets();
		new REST();
		new Templates();
		new BlockTemplates();
		new TOC();
		new Design();
		new Abilities();
		new Importer();
	}

	/**
	 * Load plugin textdomain.
	 */
	public function load_textdomain() {
		load_plugin_textdomain(
			'bridle-kb',
			false,
			dirname( plugin_basename( BRIDLE_KB_FILE ) ) . '/languages/'
		);
	}

	/**
	 * Plugin activation.
	 */
	public function activate() {
		$post_types = new PostTypes();
		$post_types->register_post_type();
		$post_types->register_taxonomy();

		flush_rewrite_rules();

		// Set defaults for fresh installs.
		$settings_defaults = [
			'articles_per_page'  => 12,
			'search_placeholder' => __( 'Search docs...', 'bridle-kb' ),
			'post_type_slug'     => 'docs',
		];

		$design_defaults = [
			'template_archive'   => 'default',
			'template_single'    => 'default',
			'template_taxonomy'  => 'default',
			'spacing_top'        => 0,
			'container_width'    => 'default',
			'sidebar_visible'    => true,
			'sidebar_search'     => false,
			'toc_visible'        => true,
			'toc_position'       => 'right',
			'breadcrumb_visible' => true,
			'primary_color'      => Design::DEFAULT_PRIMARY,
			'accent_color'       => '',
			'text_color'         => '',
			'heading_color'      => '',
			'muted_color'        => '',
			'bg_color'           => '',
			'card_bg_color'      => '',
			'hero_bg_color'      => '',
			'color_mode'         => 'brand',
		];

		if ( false === get_option( 'bridle_kb_settings' ) ) {
			update_option( 'bridle_kb_settings', $settings_defaults );
		}

		if ( false === get_option( 'bridle_kb_design' ) ) {
			update_option( 'bridle_kb_design', $design_defaults );
		}
	}

	/**
	 * Plugin deactivation.
	 */
	public function deactivate() {
		flush_rewrite_rules();
	}
}
