<?php

/**
 * Breadcrumbs.
 *
 * @package BridleKB
 */

namespace BridleKB;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Breadcrumbs
 */
class Breadcrumbs {


	/**
	 * What the help center's home is called in breadcrumbs and eyebrows.
	 *
	 * @return string
	 */
	public static function home_label() {
		return (string) apply_filters( 'bridle_kb_home_label', __( 'Docs', 'bridle-kb' ) );
	}

	/**
	 * Get breadcrumb items as an array.
	 *
	 * @return array Each item: [ 'label' => string, 'url' => string|null ]
	 */
	public static function get_items() {
		$items = [];

		// The help center's home.
		$items[] = [
			'label' => self::home_label(),
			'url'   => get_post_type_archive_link( 'docs' ),
		];

		if ( is_tax( 'docs_category' ) ) {
			$term = get_queried_object();

			// Parent categories.
			if ( $term && $term->parent ) {
				$ancestors = array_reverse( get_ancestors( $term->term_id, 'docs_category', 'taxonomy' ) );
				foreach ( $ancestors as $ancestor_id ) {
					$ancestor = get_term( $ancestor_id, 'docs_category' );
					if ( $ancestor && ! is_wp_error( $ancestor ) ) {
						$items[] = [
							'label' => $ancestor->name,
							'url'   => get_term_link( $ancestor ),
						];
					}
				}
			}

			// Current category.
			$items[] = [
				'label' => $term->name,
				'url'   => null,
			];
		} elseif ( is_singular( 'docs' ) ) {
			$post       = get_queried_object();
			$categories = get_the_terms( $post->ID, 'docs_category' );

			if ( $categories && ! is_wp_error( $categories ) ) {
				$category = $categories[0];

				// Category ancestors.
				if ( $category->parent ) {
					$ancestors = array_reverse( get_ancestors( $category->term_id, 'docs_category', 'taxonomy' ) );
					foreach ( $ancestors as $ancestor_id ) {
						$ancestor = get_term( $ancestor_id, 'docs_category' );
						if ( $ancestor && ! is_wp_error( $ancestor ) ) {
							$items[] = [
								'label' => $ancestor->name,
								'url'   => get_term_link( $ancestor ),
							];
						}
					}
				}

				$items[] = [
					'label' => $category->name,
					'url'   => get_term_link( $category ),
				];
			}

			// Parent docs (hierarchical).
			if ( $post->post_parent ) {
				$parent_chain = [];
				$parent_id    = $post->post_parent;
				while ( $parent_id ) {
					$parent         = get_post( $parent_id );
					$parent_chain[] = [
						'label' => $parent->post_title,
						'url'   => get_permalink( $parent->ID ),
					];
					$parent_id      = $parent->post_parent;
				}
				$items = array_merge( $items, array_reverse( $parent_chain ) );
			}

			// Current article.
			$items[] = [
				'label' => $post->post_title,
				'url'   => null,
			];
		}

		return apply_filters( 'bridle_kb_breadcrumb_items', $items );
	}

	/**
	 * Render breadcrumbs via template part.
	 */
	public static function render() {
		if ( ! bridle_kb_get_option( 'breadcrumb_visible', true ) ) {
			return;
		}

		$items = self::get_items();
		if ( empty( $items ) ) {
			return;
		}

		Templates::get_template_part( 'parts/breadcrumbs', [ 'items' => $items ] );
	}
}
