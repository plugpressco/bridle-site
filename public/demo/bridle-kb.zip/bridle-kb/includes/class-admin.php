<?php

/**
 * Admin menu and pages.
 *
 * @package BridleKB
 */

namespace BridleKB;

if (! defined('ABSPATH')) {
	exit;
}

/**
 * Class Admin
 *
 * Where the knowledge base lives in wp-admin. With Bridle on the site it is
 * one item in Bridle's menu (Bridle → Inbox · Docs · Settings), the
 * way Saddle's add-ons join Saddle's menu. Without Bridle it keeps a menu of
 * its own. Either way the page is admin.php?page=bridle-kb, and the WordPress
 * screens behind it (the articles list, categories, the editor) keep that
 * item highlighted.
 */
class Admin
{

	/**
	 * The page slug, under Bridle's menu or on its own.
	 */
	const PAGE = 'bridle-kb';

	/**
	 * Bridle's top-level menu slug.
	 */
	const BRIDLE_MENU = 'bridle';

	/**
	 * Hook suffix of the knowledge base page, once registered.
	 *
	 * @var string
	 */
	private static $hook = '';

	/**
	 * Constructor.
	 */
	public function __construct()
	{
		// After Bridle has added its menu (admin_menu, default priority),
		// so the knowledge base can join it.
		add_action('admin_menu', [$this, 'register_menus'], 20);
		add_filter('parent_file', [$this, 'parent_file']);
		add_filter('submenu_file', [$this, 'submenu_file']);
		add_filter('admin_body_class', [$this, 'body_class']);
		add_action('in_admin_header', [$this, 'render_bar']);
		add_action('load-edit.php', [$this, 'redirect_articles_list']);
	}

	/**
	 * Hook suffix of the knowledge base page ('' before admin_menu).
	 *
	 * Read this instead of spelling the hook out: under Bridle's menu,
	 * WordPress derives it from Bridle's menu title.
	 *
	 * @return string
	 */
	public static function page_hook()
	{
		return self::$hook;
	}

	/**
	 * Whether Bridle's menu is there to join. Asked of the menu itself, not of
	 * a Bridle class or version, so it holds for any Bridle that has a menu.
	 *
	 * @return bool
	 */
	public static function in_bridle()
	{
		global $admin_page_hooks;

		return isset($admin_page_hooks[self::BRIDLE_MENU]);
	}

	/**
	 * Register the knowledge base page.
	 */
	public function register_menus()
	{
		if (self::in_bridle()) {
			// Second in Bridle's menu, between Inbox and Settings. One short
			// word, like the items around it.
			self::$hook = (string) add_submenu_page(
				self::BRIDLE_MENU,
				__('Docs', 'bridle-kb'),
				__('Docs', 'bridle-kb'),
				'edit_posts',
				self::PAGE,
				[$this, 'render_page'],
				1
			);
			return;
		}

		// The Bridle KB mark (Bridle's ring and rein, mirrored into a d for
		// docs) as a base64 SVG data URI. WordPress's svg-painter tints menu
		// icons by rewriting `fill`, so it is one filled path with an even-odd
		// hole; the raw grey reads on every dark scheme until the painter runs.
		$icon_svg = '<svg viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"><path fill="#a7aaad" fill-rule="evenodd" d="M47.39 41.42L55.35 3.98L45.09 1.8L40.94 21.36A21.18 21.18 0 1 0 47.39 41.42ZM36.95 37.02a10.28 10.28 0 1 1 -20.55 0a10.28 10.28 0 1 1 20.55 0Z"/></svg>';

		self::$hook = (string) add_menu_page(
			__('Bridle KB', 'bridle-kb'),
			__('Bridle KB', 'bridle-kb'),
			'edit_posts',
			self::PAGE,
			[$this, 'render_page'],
			'data:image/svg+xml;base64,' . base64_encode($icon_svg),
			// PlugPress ecosystem menu band, next to where Bridle sits (58.10).
			'58.16'
		);
	}

	/**
	 * WordPress's own articles list (edit.php?post_type=docs) is the Docs page
	 * now: send it there, keeping the trash view, a search or category, and
	 * the "moved to trash" the block editor reports, so the app can offer
	 * Undo. A bulk action
	 * already on its way through the old list is left alone.
	 */
	public function redirect_articles_list()
	{
		global $typenow;

		if ('docs' !== $typenow || wp_doing_ajax()) {
			return;
		}

		// Read-only routing on a GET screen; nothing is changed here, so no
		// nonce applies.
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$action  = isset($_REQUEST['action']) ? sanitize_key(wp_unslash($_REQUEST['action'])) : '';
		$action2 = isset($_REQUEST['action2']) ? sanitize_key(wp_unslash($_REQUEST['action2'])) : '';

		if (('' !== $action && '-1' !== $action) || ('' !== $action2 && '-1' !== $action2)) {
			return;
		}

		/**
		 * Whether edit.php?post_type=docs sends you to the Docs page.
		 *
		 * @param bool $redirect True by default.
		 */
		if (! apply_filters('bridle_kb_redirect_articles_list', true)) {
			return;
		}

		$args = ['page' => self::PAGE];

		if (isset($_GET['post_status']) && 'trash' === sanitize_key(wp_unslash($_GET['post_status']))) {
			$args['tab'] = 'trash';
		}
		// A category's article count links here; so does WordPress's search.
		// Both become the Docs page's search, which matches category names.
		$search = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
		if ('' === $search && ! empty($_GET['docs_category'])) {
			$term   = get_term_by('slug', sanitize_title(wp_unslash($_GET['docs_category'])), 'docs_category');
			$search = $term ? $term->name : '';
		}
		if ('' !== $search) {
			$args['search'] = rawurlencode($search);
		}
		if (! empty($_GET['trashed']) && ! empty($_GET['ids'])) {
			$ids = array_filter(array_map('absint', explode(',', sanitize_text_field(wp_unslash($_GET['ids'])))));
			// Not `trashed`/`ids`: WordPress strips those from admin URLs
			// on load (wp_removable_query_args()) before the app reads them.
			if ($ids) {
				$args['undo'] = implode(',', $ids);
			}
		}
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		wp_safe_redirect(add_query_arg($args, admin_url('admin.php')));
		exit;
	}

	/**
	 * Whether the current screen is one of WordPress's own for the knowledge
	 * base: the articles list, the editor, or categories.
	 *
	 * @return bool
	 */
	private function is_kb_screen()
	{
		$screen = function_exists('get_current_screen') ? get_current_screen() : null;

		return $screen && ('docs' === $screen->post_type || 'docs_category' === $screen->taxonomy);
	}

	/**
	 * The screens that get the bar: categories (list and edit). The articles
	 * list redirects to the Docs page, and the block editor draws its own
	 * chrome.
	 *
	 * @return string '' when the screen gets no bar, else 'categories'.
	 */
	private function bar_place()
	{
		$screen = function_exists('get_current_screen') ? get_current_screen() : null;

		if (! $screen) {
			return '';
		}
		if ('docs_category' === $screen->taxonomy && in_array($screen->base, ['edit-tags', 'term'], true)) {
			return 'categories';
		}
		return '';
	}

	/**
	 * Keep the knowledge base's menu open on its WordPress screens.
	 *
	 * @param string $parent_file Parent menu slug.
	 * @return string
	 */
	public function parent_file($parent_file)
	{
		if (! $this->is_kb_screen()) {
			return $parent_file;
		}

		return self::in_bridle() ? self::BRIDLE_MENU : self::PAGE;
	}

	/**
	 * Highlight "Docs" on its WordPress screens.
	 *
	 * @param string|null $submenu_file Submenu slug.
	 * @return string|null
	 */
	public function submenu_file($submenu_file)
	{
		return $this->is_kb_screen() ? self::PAGE : $submenu_file;
	}

	/**
	 * Body classes the stylesheets scope to: `bridle-kb-app` on the page,
	 * `bridle-kb-native` on the screens with the bar.
	 *
	 * @param string $classes Space-separated body classes.
	 * @return string
	 */
	public function body_class($classes)
	{
		$screen = function_exists('get_current_screen') ? get_current_screen() : null;

		if ($screen && '' !== self::$hook && self::$hook === $screen->id) {
			return $classes . ' bridle-kb-app';
		}
		if ('' !== $this->bar_place()) {
			return $classes . ' bridle-kb-native';
		}
		return $classes;
	}

	/**
	 * The bar above categories: Bridle's top bar, with
	 * the way back to the knowledge base. Styled by build/chrome.css.
	 */
	public function render_bar()
	{
		$place = $this->bar_place();

		if ('' === $place) {
			return;
		}

		$places = [
			'categories' => __('Categories', 'bridle-kb'),
		];
		$in_bridle = self::in_bridle();
		// Bridle's icon: the white mark on a brand-blue circle, mirrored into
		// Bridle KB's d when the knowledge base stands alone.
		$mirror = $in_bridle ? '' : ' transform="translate(100 0) scale(-1 1)"';
		?>
		<div class="bridle-kb-bar">
			<a class="bridle-kb-bar__back" href="<?php echo esc_url(admin_url('admin.php?page=' . self::PAGE)); ?>">
				<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m12 19-7-7 7-7"/><path d="M19 12H5"/></svg>
				<?php esc_html_e('Docs', 'bridle-kb'); ?>
			</a>
			<div class="bridle-kb-bar__place">
				<svg class="bridle-kb-bar__mark" viewBox="0 0 100 100" aria-hidden="true"><defs><linearGradient id="bridle-kb-bar-icon" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7fb0f3"/><stop offset="1" stop-color="#4c8eef"/></linearGradient></defs><circle cx="50" cy="50" r="50" fill="url(#bridle-kb-bar-icon)"/><g<?php echo $mirror; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- a fixed attribute string. ?>><path transform="translate(20.36 19.15) scale(0.95)" fill="#fff" fill-rule="evenodd" d="M13.31 41.92L5.18 3.67L13.97 1.8L18.57 23.43A20.56 20.56 0 1 1 13.31 41.92ZM22.27 37.64a11.15 11.36 0 1 0 22.3 0a11.15 11.36 0 1 0 -22.3 0Z"/></g></svg>
				<span class="bridle-kb-bar__name"><?php echo esc_html($in_bridle ? __('Bridle', 'bridle-kb') : __('Bridle KB', 'bridle-kb')); ?></span>
				<span class="bridle-kb-bar__muted" aria-hidden="true">·</span>
				<span class="bridle-kb-bar__muted"><?php echo esc_html($places[$place]); ?></span>
			</div>
			<span></span>
		</div>
		<?php
	}

	/**
	 * Render the admin page container for the React app.
	 */
	public function render_page()
	{
		echo '<div id="bridle-kb-root"></div>';
	}
}
