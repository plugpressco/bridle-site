<?php

/**
 * Post Types and Taxonomies.
 *
 * @package BridleKB
 */

namespace BridleKB;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class PostTypes
 */
class PostTypes {


	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'init', [ $this, 'register_post_type' ], 0 );
		add_action( 'init', [ $this, 'register_taxonomy' ], 0 );
		add_action( 'after_setup_theme', [ $this, 'register_sidebar_menus' ] );

		// Category fields (icon + color).
		add_action( 'docs_category_add_form_fields', [ $this, 'add_icon_field' ] );
		add_action( 'docs_category_edit_form_fields', [ $this, 'edit_icon_field' ] );
		add_action( 'created_docs_category', [ $this, 'save_category_fields' ] );
		add_action( 'edited_docs_category', [ $this, 'save_category_fields' ] );

		// Category columns.
		add_filter( 'manage_edit-docs_category_columns', [ $this, 'add_icon_column' ] );
		add_filter( 'manage_docs_category_custom_column', [ $this, 'display_icon_column' ], 10, 3 );
	}

	/**
	 * Register the docs post type.
	 */
	public function register_post_type() {
		// Sentence case, like the rest of Bridle (owner, 2026-10-06): the
		// collection is "Docs", one item is an article.
		$labels = [
			'name'                     => _x( 'Docs', 'Post type general name', 'bridle-kb' ),
			'singular_name'            => _x( 'Article', 'Post type singular name', 'bridle-kb' ),
			'menu_name'                => _x( 'Docs', 'Admin Menu text', 'bridle-kb' ),
			'name_admin_bar'           => _x( 'Article', 'Add New on Toolbar', 'bridle-kb' ),
			'add_new'                  => __( 'New article', 'bridle-kb' ),
			'add_new_item'             => __( 'New article', 'bridle-kb' ),
			'new_item'                 => __( 'New article', 'bridle-kb' ),
			'edit_item'                => __( 'Edit article', 'bridle-kb' ),
			'view_item'                => __( 'View article', 'bridle-kb' ),
			'view_items'               => __( 'View docs', 'bridle-kb' ),
			'all_items'                => __( 'All articles', 'bridle-kb' ),
			'search_items'             => __( 'Search articles', 'bridle-kb' ),
			'parent_item_colon'        => __( 'Parent article:', 'bridle-kb' ),
			'not_found'                => __( 'No articles found.', 'bridle-kb' ),
			'not_found_in_trash'       => __( 'No articles in the trash.', 'bridle-kb' ),
			'featured_image'           => _x( 'Cover image', 'Overrides the "Featured Image" phrase', 'bridle-kb' ),
			'set_featured_image'       => _x( 'Set cover image', 'Overrides the "Set featured image" phrase', 'bridle-kb' ),
			'remove_featured_image'    => _x( 'Remove cover image', 'Overrides the "Remove featured image" phrase', 'bridle-kb' ),
			'use_featured_image'       => _x( 'Use as cover image', 'Overrides the "Use as featured image" phrase', 'bridle-kb' ),
			'archives'                 => _x( 'Docs', 'The post type archive label', 'bridle-kb' ),
			'attributes'               => __( 'Article attributes', 'bridle-kb' ),
			'insert_into_item'         => _x( 'Insert into article', 'Overrides the "Insert into post" phrase', 'bridle-kb' ),
			'uploaded_to_this_item'    => _x( 'Uploaded to this article', 'Overrides the "Uploaded to this post" phrase', 'bridle-kb' ),
			'filter_items_list'        => _x( 'Filter articles', 'Screen reader text for the filter links', 'bridle-kb' ),
			'items_list_navigation'    => _x( 'Articles list navigation', 'Screen reader text for the pagination', 'bridle-kb' ),
			'items_list'               => _x( 'Articles', 'Screen reader text for the items list', 'bridle-kb' ),
			'item_published'           => __( 'Article published.', 'bridle-kb' ),
			'item_published_privately' => __( 'Article published privately.', 'bridle-kb' ),
			'item_reverted_to_draft'   => __( 'Article moved to draft.', 'bridle-kb' ),
			'item_scheduled'           => __( 'Article scheduled.', 'bridle-kb' ),
			'item_updated'             => __( 'Article updated.', 'bridle-kb' ),
			'item_link'                => __( 'Article link', 'bridle-kb' ),
			'item_link_description'    => __( 'A link to an article.', 'bridle-kb' ),
		];

		$slug = bridle_kb_get_option( 'post_type_slug', 'docs' );
		$slug = apply_filters( 'bridle_kb_docs_slug', $slug );

		$args = [
			'labels'             => $labels,
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => false,
			'show_in_nav_menus'  => true,
			'show_in_admin_bar'  => true,
			'show_in_rest'       => true,
			'query_var'          => true,
			'rewrite'            => [
				'slug'       => $slug,
				'with_front' => false,
			],
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => true,
			'supports'           => [
				'title',
				'editor',
				'excerpt',
				'author',
				'thumbnail',
				'revisions',
				'page-attributes',
				'custom-fields',
			],
		];

		register_post_type( 'docs', apply_filters( 'bridle_kb_docs_post_type_args', $args ) );
	}

	/**
	 * Register the docs_category taxonomy.
	 */
	public function register_taxonomy() {
		$labels = [
			'name'                       => _x( 'Categories', 'Taxonomy General Name', 'bridle-kb' ),
			'singular_name'              => _x( 'Category', 'Taxonomy Singular Name', 'bridle-kb' ),
			'menu_name'                  => __( 'Categories', 'bridle-kb' ),
			'all_items'                  => __( 'All categories', 'bridle-kb' ),
			'parent_item'                => __( 'Parent category', 'bridle-kb' ),
			'parent_item_colon'          => __( 'Parent category:', 'bridle-kb' ),
			'new_item_name'              => __( 'New category name', 'bridle-kb' ),
			'add_new_item'               => __( 'New category', 'bridle-kb' ),
			'edit_item'                  => __( 'Edit category', 'bridle-kb' ),
			'update_item'                => __( 'Update category', 'bridle-kb' ),
			'view_item'                  => __( 'View category', 'bridle-kb' ),
			'separate_items_with_commas' => __( 'Separate categories with commas', 'bridle-kb' ),
			'add_or_remove_items'        => __( 'Add or remove categories', 'bridle-kb' ),
			'choose_from_most_used'      => __( 'Choose from the most used', 'bridle-kb' ),
			'popular_items'              => __( 'Popular categories', 'bridle-kb' ),
			'search_items'               => __( 'Search categories', 'bridle-kb' ),
			'not_found'                  => __( 'No categories found.', 'bridle-kb' ),
			'no_terms'                   => __( 'No categories', 'bridle-kb' ),
			'back_to_items'              => __( '&larr; Back to categories', 'bridle-kb' ),
			'items_list'                 => __( 'Categories list', 'bridle-kb' ),
			'items_list_navigation'      => __( 'Categories list navigation', 'bridle-kb' ),
		];

		$slug = apply_filters( 'bridle_kb_category_slug', 'docs-category' );

		$args = [
			'labels'            => $labels,
			'hierarchical'      => true,
			'public'            => true,
			'show_ui'           => true,
			'show_admin_column' => true,
			'show_in_nav_menus' => true,
			'show_tagcloud'     => true,
			'show_in_rest'      => true,
			'query_var'         => true,
			'rewrite'           => [
				'slug'       => $slug,
				'with_front' => false,
			],
		];

		register_taxonomy( 'docs_category', [ 'docs' ], apply_filters( 'bridle_kb_docs_category_args', $args ) );
	}

	/**
	 * Register Bridle KB sidebar menu locations (top and bottom of left sidebar).
	 */
	public function register_sidebar_menus() {
		register_nav_menus(
			[
				'bridle_kb_sidebar_top'    => __( 'Docs sidebar, top', 'bridle-kb' ),
				'bridle_kb_sidebar_bottom' => __( 'Docs sidebar, bottom', 'bridle-kb' ),
			]
		);
	}

	/**
	 * Preset color palette for category color picker.
	 */
	private function color_presets() {
		return [
			'#1BBB81',
			'#3B82F6',
			'#8B5CF6',
			'#EC4899',
			'#F59E0B',
			'#EF4444',
			'#06B6D4',
			'#64748B',
		];
	}

	/**
	 * Render the color swatch picker (shared between add/edit forms).
	 *
	 * @param string $current Currently saved hex color.
	 */
	private function render_color_picker( $current = '' ) {
		$presets   = $this->color_presets();
		$default   = '#1BBB81';
		$current   = $current ?: $default;
		$is_custom = ! in_array( $current, $presets, true );
		?>
		<div class="bridle-kb-color-picker" style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-top:4px;">
			<?php foreach ( $presets as $color ) : ?>
				<label style="cursor:pointer;margin:0;" title="<?php echo esc_attr( $color ); ?>">
					<input
						type="radio"
						name="category_color"
						value="<?php echo esc_attr( $color ); ?>"
						<?php checked( $current, $color ); ?>
						style="position:absolute;opacity:0;width:0;height:0;"
					/>
					<span style="
						display:inline-block;width:24px;height:24px;border-radius:50%;
						background:<?php echo esc_attr( $color ); ?>;
						border:2px solid <?php echo ( $current === $color ) ? '#000' : 'transparent'; ?>;
						box-shadow:0 0 0 1px #ddd;
						outline:none;
					"></span>
				</label>
			<?php endforeach; ?>
			<label style="cursor:pointer;margin:0;display:flex;align-items:center;gap:4px;">
				<input
					type="radio"
					name="category_color"
					value="__custom__"
					<?php checked( $is_custom, true ); ?>
					style="position:absolute;opacity:0;width:0;height:0;"
				/>
				<input
					type="color"
					name="category_color_custom"
					value="<?php echo esc_attr( $is_custom ? $current : $default ); ?>"
					style="width:24px;height:24px;padding:0;border:1px solid #ddd;border-radius:50%;cursor:pointer;background:none;"
					title="<?php esc_attr_e( 'Custom color', 'bridle-kb' ); ?>"
				/>
			</label>
		</div>
		<?php
	}

	/**
	 * Add icon + color fields to the add category form.
	 */
	public function add_icon_field() {
		?>
		<div class="form-field">
			<label for="category_icon"><?php esc_html_e( 'Icon', 'bridle-kb' ); ?></label>
			<div class="bridle-kb-icon-upload">
				<input type="hidden" id="category_icon" name="category_icon" value="" />
				<div class="bridle-kb-icon-preview" style="display: none;">
					<img src="" alt="" style="max-width: 64px; max-height: 64px;" />
					<button type="button" class="button bridle-kb-remove-icon"><?php esc_html_e( 'Remove', 'bridle-kb' ); ?></button>
				</div>
				<button type="button" class="button bridle-kb-upload-icon"><?php esc_html_e( 'Upload icon', 'bridle-kb' ); ?></button>
			</div>
			<p class="description"><?php esc_html_e( 'Upload an icon for this category (recommended: 64x64px)', 'bridle-kb' ); ?></p>
		</div>
		<div class="form-field">
			<label><?php esc_html_e( 'Color', 'bridle-kb' ); ?></label>
			<?php $this->render_color_picker(); ?>
			<p class="description"><?php esc_html_e( 'Tints the icon in your help center.', 'bridle-kb' ); ?></p>
		</div>
		<?php
	}

	/**
	 * Add icon + color fields to the edit category form.
	 *
	 * @param \WP_Term $term Current term object.
	 */
	public function edit_icon_field( $term ) {
		$icon_id  = get_term_meta( $term->term_id, 'category_icon', true );
		$icon_url = $icon_id ? wp_get_attachment_url( $icon_id ) : '';
		$color    = get_term_meta( $term->term_id, 'category_color', true );
		?>
		<tr class="form-field">
			<th scope="row">
				<label for="category_icon"><?php esc_html_e( 'Icon', 'bridle-kb' ); ?></label>
			</th>
			<td>
				<div class="bridle-kb-icon-upload">
					<input type="hidden" id="category_icon" name="category_icon" value="<?php echo esc_attr( $icon_id ); ?>" />
					<div class="bridle-kb-icon-preview" style="<?php echo $icon_url ? '' : 'display: none;'; ?>">
						<img src="<?php echo esc_url( $icon_url ); ?>" alt="" style="max-width: 64px; max-height: 64px;" />
						<button type="button" class="button bridle-kb-remove-icon"><?php esc_html_e( 'Remove', 'bridle-kb' ); ?></button>
					</div>
					<button type="button" class="button bridle-kb-upload-icon"><?php esc_html_e( 'Upload icon', 'bridle-kb' ); ?></button>
				</div>
				<p class="description"><?php esc_html_e( 'Upload an icon for this category (recommended: 64x64px)', 'bridle-kb' ); ?></p>
			</td>
		</tr>
		<tr class="form-field">
			<th scope="row">
				<label><?php esc_html_e( 'Color', 'bridle-kb' ); ?></label>
			</th>
			<td>
				<?php $this->render_color_picker( $color ); ?>
				<p class="description"><?php esc_html_e( 'Tints the icon in your help center.', 'bridle-kb' ); ?></p>
			</td>
		</tr>
		<?php
	}

	/**
	 * Save category icon and color.
	 *
	 * @param int $term_id Term ID.
	 */
	public function save_category_fields( $term_id ) {
		if ( ! current_user_can( 'manage_categories' ) ) {
			return;
		}

		// Nonce is verified by WordPress core (check_admin_referer) in edit-tags.php /
		// term.php before the created_/edited_ term hooks that call this method fire.
		// phpcs:disable WordPress.Security.NonceVerification.Missing

		// Icon.
		if ( isset( $_POST['category_icon'] ) ) {
			$icon_id = sanitize_text_field( wp_unslash( $_POST['category_icon'] ) );
			if ( $icon_id ) {
				update_term_meta( $term_id, 'category_icon', $icon_id );
			} else {
				delete_term_meta( $term_id, 'category_icon' );
			}
		}

		// Color — resolve __custom__ to the color input value.
		if ( isset( $_POST['category_color'] ) ) {
			$chosen = sanitize_text_field( wp_unslash( $_POST['category_color'] ) );
			if ( '__custom__' === $chosen && isset( $_POST['category_color_custom'] ) ) {
				$chosen = sanitize_hex_color( wp_unslash( $_POST['category_color_custom'] ) );
			}
			if ( $chosen && '#' === substr( $chosen, 0, 1 ) ) {
				update_term_meta( $term_id, 'category_color', $chosen );
			} else {
				delete_term_meta( $term_id, 'category_color' );
			}
		}
		// phpcs:enable WordPress.Security.NonceVerification.Missing
	}

	/**
	 * Add icon column to the category list table.
	 *
	 * @param array $columns Existing columns.
	 * @return array
	 */
	public function add_icon_column( $columns ) {
		$new_columns = [];

		foreach ( $columns as $key => $value ) {
			$new_columns[ $key ] = $value;

			if ( 'name' === $key ) {
				$new_columns['category_icon'] = __( 'Icon', 'bridle-kb' );
			}
		}

		return $new_columns;
	}

	/**
	 * Display icon and color swatch in the category list column.
	 *
	 * @param string $content     Column content.
	 * @param string $column_name Column name.
	 * @param int    $term_id     Term ID.
	 * @return string
	 */
	public function display_icon_column( $content, $column_name, $term_id ) {
		if ( 'category_icon' !== $column_name ) {
			return $content;
		}

		$icon_id = get_term_meta( $term_id, 'category_icon', true );
		$color   = get_term_meta( $term_id, 'category_color', true ) ?: '#1BBB81';
		$parts   = [];

		if ( $icon_id ) {
			$icon_url = wp_get_attachment_url( $icon_id );
			if ( $icon_url ) {
				$parts[] = '<span style="display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;border-radius:6px;background:' . esc_attr( $color ) . '20;">'
					. '<img src="' . esc_url( $icon_url ) . '" alt="" style="width:20px;height:20px;object-fit:contain;" />'
					. '</span>';
			}
		}

		$parts[] = '<span style="display:inline-block;width:16px;height:16px;border-radius:50%;background:' . esc_attr( $color ) . ';border:1px solid rgba(0,0,0,.1);vertical-align:middle;" title="' . esc_attr( $color ) . '"></span>';

		return implode( ' ', $parts );
	}
}
