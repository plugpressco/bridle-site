<?php
/**
 * The three help centers the importer reads: Intercom, Help Scout Docs and
 * Notion. Each answers the same three questions: how much is there
 * (preview), what is there (one page of the listing at a time) and what one
 * article says (its title, HTML and category).
 *
 * @package BridleKB
 */

namespace BridleKB;

defined( 'ABSPATH' ) || exit;

/**
 * Class ImportSources
 *
 * A listing cursor is `[ 'todo' => [ [ 'kind' => …, 'id' => …, 'page' => … ], … ] ]`:
 * each step takes the first entry, reads one page and queues what follows.
 * Categories come back keyed by a source id (`c12`, `col:abc`, `db:…`);
 * article refs are `[ 'id', 'category', 'title', 'parent' ]`.
 */
class ImportSources {

	const SOURCES = [ 'intercom', 'helpscout', 'notion' ];

	// phpcs:disable PluginCheck.CodeAnalysis.Offloading.OffloadedContent -- APIs the owner imports from, called only while an import they started runs; no asset is loaded from them.
	const INTERCOM  = 'https://api.intercom.io';
	const HELPSCOUT = 'https://docsapi.helpscout.net/v1';
	const NOTION    = 'https://api.notion.com/v1';
	// phpcs:enable

	/** Notion allows about three requests a second. */
	const NOTION_PAUSE_US = 340000;

	/** Notion blocks read per page, and how deep nested blocks are followed. */
	const NOTION_MAX_BLOCKS = 1500;
	const NOTION_DEPTH      = 4;

	/**
	 * How much a source holds, read with the token before anything is
	 * imported: article and category counts and a few titles.
	 *
	 * @param string $source One of SOURCES.
	 * @param string $token  The token the owner pasted.
	 * @return array|\WP_Error { articles, categories, titles[] }
	 */
	public static function preview( string $source, string $token ) {
		switch ( $source ) {
			case 'intercom':
				$articles = self::get( $source, self::INTERCOM . '/articles?per_page=5&page=1', $token );
				if ( is_wp_error( $articles ) ) {
					return $articles;
				}
				$collections = self::get( $source, self::INTERCOM . '/help_center/collections?per_page=1&page=1', $token );
				return [
					'articles'   => (int) ( $articles['total_count'] ?? count( (array) ( $articles['data'] ?? [] ) ) ),
					'categories' => is_wp_error( $collections ) ? 0 : (int) ( $collections['total_count'] ?? count( (array) ( $collections['data'] ?? [] ) ) ),
					'titles'     => array_values( array_filter( array_map( static fn( $a ) => (string) ( $a['title'] ?? '' ), (array) ( $articles['data'] ?? [] ) ) ) ),
				];

			case 'helpscout':
				$collections = self::get( $source, self::HELPSCOUT . '/collections?page=1', $token );
				if ( is_wp_error( $collections ) ) {
					return $collections;
				}
				$count  = 0;
				$cats   = 0;
				$titles = [];
				foreach ( array_slice( (array) ( $collections['collections']['items'] ?? [] ), 0, 10 ) as $collection ) {
					++$cats;
					$list = self::get( $source, self::HELPSCOUT . '/collections/' . rawurlencode( (string) $collection['id'] ) . '/articles?status=all&pageSize=5', $token );
					if ( ! is_wp_error( $list ) ) {
						$count += (int) ( $list['articles']['count'] ?? 0 );
						foreach ( (array) ( $list['articles']['items'] ?? [] ) as $item ) {
							$titles[] = (string) ( $item['name'] ?? '' );
						}
					}
				}
				return [
					'articles'   => $count,
					'categories' => $cats,
					'titles'     => array_slice( array_values( array_filter( $titles ) ), 0, 5 ),
				];

			case 'notion':
				$found = self::post( $source, self::NOTION . '/search', $token, [ 'page_size' => 100 ] );
				if ( is_wp_error( $found ) ) {
					return $found;
				}
				$pages  = array_values( array_filter( (array) ( $found['results'] ?? [] ), static fn( $r ) => 'page' === ( $r['object'] ?? '' ) && empty( $r['archived'] ) && empty( $r['in_trash'] ) ) );
				$tables = array_filter( (array) ( $found['results'] ?? [] ), static fn( $r ) => 'database' === ( $r['object'] ?? '' ) );
				return [
					'articles'   => count( $pages ),
					'more'       => ! empty( $found['has_more'] ),
					'categories' => count( $tables ),
					'titles'     => array_slice( array_values( array_filter( array_map( [ ImportHtml::class, 'notion_title' ], $pages ) ) ), 0, 5 ),
				];
		}
		return self::unknown();
	}

	/**
	 * Where a listing starts.
	 *
	 * @param string $source One of SOURCES.
	 * @return array
	 */
	public static function first_cursor( string $source ): array {
		$first = [
			'intercom'  => [
				'kind' => 'collections',
				'page' => 1,
			],
			'helpscout' => [
				'kind' => 'collections',
				'page' => 1,
			],
			'notion'    => [
				'kind' => 'search',
				'page' => '',
			],
		];
		return [ 'todo' => [ $first[ $source ] ] ];
	}

	/**
	 * Read one page of a source's listing.
	 *
	 * @param string $source One of SOURCES.
	 * @param string $token  The token.
	 * @param array  $cursor From first_cursor() or the last step.
	 * @return array|\WP_Error { categories: [ id => {name, parent, description} ], items: [ ref ], cursor: array|null }
	 */
	public static function list_step( string $source, string $token, array $cursor ) {
		$todo = (array) ( $cursor['todo'] ?? [] );
		$step = array_shift( $todo );
		$out  = [
			'categories' => [],
			'items'      => [],
			'cursor'     => null,
		];
		if ( ! $step ) {
			return $out;
		}
		$kind = (string) $step['kind'];
		$page = $step['page'];

		if ( 'intercom' === $source ) {
			$path = 'collections' === $kind ? '/help_center/collections' : '/articles';
			$data = self::get( $source, self::INTERCOM . $path . '?per_page=50&page=' . (int) $page, $token );
			if ( is_wp_error( $data ) ) {
				return $data;
			}
			foreach ( (array) ( $data['data'] ?? [] ) as $row ) {
				if ( 'collections' === $kind ) {
					$out['categories'][ 'c' . $row['id'] ] = [
						'name'        => (string) ( $row['name'] ?? '' ),
						'parent'      => ! empty( $row['parent_id'] ) ? 'c' . $row['parent_id'] : '',
						'description' => (string) ( $row['description'] ?? '' ),
					];
				} else {
					$out['items'][] = [
						'id'       => (string) $row['id'],
						'title'    => (string) ( $row['title'] ?? '' ),
						'category' => 'collection' === ( $row['parent_type'] ?? '' ) && ! empty( $row['parent_id'] ) ? 'c' . $row['parent_id'] : '',
					];
				}
			}
			$pages = (int) ( $data['pages']['total_pages'] ?? 1 );
			if ( (int) $page < $pages ) {
				array_unshift(
					$todo,
					[
						'kind' => $kind,
						'page' => (int) $page + 1,
					]
				);
			} elseif ( 'collections' === $kind ) {
				$todo[] = [
					'kind' => 'articles',
					'page' => 1,
				];
			}
		}

		if ( 'helpscout' === $source ) {
			$id   = rawurlencode( (string) ( $step['id'] ?? '' ) );
			$urls = [
				'collections'  => '/collections?page=' . (int) $page,
				'categories'   => '/collections/' . $id . '/categories?page=' . (int) $page,
				// Category lists come in the category's own order.
				'cat_articles' => '/categories/' . $id . '/articles?status=all&pageSize=100&page=' . (int) $page,
				'col_articles' => '/collections/' . $id . '/articles?status=all&pageSize=100&page=' . (int) $page,
			];
			$data = self::get( $source, self::HELPSCOUT . $urls[ $kind ], $token );
			if ( is_wp_error( $data ) ) {
				return $data;
			}
			$key   = [
				'collections'  => 'collections',
				'categories'   => 'categories',
				'cat_articles' => 'articles',
				'col_articles' => 'articles',
			][ $kind ];
			$list  = (array) ( $data[ $key ] ?? [] );
			$after = [];
			foreach ( (array) ( $list['items'] ?? [] ) as $row ) {
				$row_id = (string) ( $row['id'] ?? '' );
				if ( 'collections' === $kind ) {
					$out['categories'][ 'col:' . $row_id ] = [
						'name'        => (string) ( $row['name'] ?? '' ),
						'parent'      => '',
						'description' => (string) ( $row['description'] ?? '' ),
					];
					$after[]                               = [
						'kind' => 'categories',
						'id'   => $row_id,
						'page' => 1,
					];
					$after[]                               = [
						'kind' => 'col_articles',
						'id'   => $row_id,
						'page' => 1,
					];
				} elseif ( 'categories' === $kind ) {
					// Help Scout's default "Uncategorized" adds nothing: its
					// articles land in the collection itself.
					if ( 'uncategorized' !== strtolower( (string) ( $row['slug'] ?? '' ) ) ) {
						$out['categories'][ 'cat:' . $row_id ] = [
							'name'        => (string) ( $row['name'] ?? '' ),
							'parent'      => 'col:' . (string) ( $row['collectionId'] ?? $step['id'] ),
							'description' => (string) ( $row['description'] ?? '' ),
						];
					}
					// Before the collection's own list, so an article keeps its category.
					$after[] = [
						'kind'     => 'cat_articles',
						'id'       => $row_id,
						'page'     => 1,
						'category' => 'uncategorized' === strtolower( (string) ( $row['slug'] ?? '' ) ) ? 'col:' . (string) ( $row['collectionId'] ?? $step['id'] ) : 'cat:' . $row_id,
					];
				} else {
					$out['items'][] = [
						'id'       => $row_id,
						'title'    => (string) ( $row['name'] ?? '' ),
						'category' => 'cat_articles' === $kind ? (string) ( $step['category'] ?? '' ) : 'col:' . (string) ( $row['collectionId'] ?? $step['id'] ),
					];
				}
			}
			if ( (int) $page < (int) ( $list['pages'] ?? 1 ) ) {
				array_unshift( $after, array_merge( $step, [ 'page' => (int) $page + 1 ] ) );
			}
			// Categories and their articles first, then the collection's rest.
			$todo = 'collections' === $kind ? array_merge( $todo, $after ) : array_merge( $after, $todo );
		}

		if ( 'notion' === $source ) {
			$body = [ 'page_size' => 100 ];
			if ( '' !== (string) $page ) {
				$body['start_cursor'] = (string) $page;
			}
			$data = self::post( $source, self::NOTION . '/search', $token, $body );
			if ( is_wp_error( $data ) ) {
				return $data;
			}
			foreach ( (array) ( $data['results'] ?? [] ) as $row ) {
				if ( ! empty( $row['archived'] ) || ! empty( $row['in_trash'] ) ) {
					continue;
				}
				$parent = (array) ( $row['parent'] ?? [] );
				$ref    = [
					'id'     => (string) $row['id'],
					'title'  => ImportHtml::notion_title( $row ),
					'parent' => (string) ( $parent['page_id'] ?? ( $parent['database_id'] ?? '' ) ),
				];
				if ( 'database' === ( $row['object'] ?? '' ) ) {
					$out['categories'][ 'db:' . $row['id'] ] = [
						'name'        => '' !== $ref['title'] ? $ref['title'] : __( 'Notion database', 'bridle-kb' ),
						'parent'      => '',
						'description' => '',
					];
					continue;
				}
				$ref['category'] = '';
				$out['items'][]  = $ref;
			}
			if ( ! empty( $data['has_more'] ) && ! empty( $data['next_cursor'] ) ) {
				array_unshift(
					$todo,
					[
						'kind' => 'search',
						'page' => (string) $data['next_cursor'],
					]
				);
			}
		}

		$out['cursor'] = $todo ? [ 'todo' => $todo ] : null;
		return $out;
	}

	/**
	 * Notion has no help-center categories: a database is one, and so is a
	 * shared top page with pages under it (its pages, at any depth, sit in
	 * it; the top page itself too). Pure.
	 *
	 * @param array $items      Notion refs (id, title, parent).
	 * @param array $categories Categories found so far (the databases).
	 * @return array{items: array, categories: array}
	 */
	public static function notion_groups( array $items, array $categories ): array {
		$by_id = [];
		foreach ( $items as $item ) {
			$by_id[ $item['id'] ] = $item;
		}
		$root_of      = static function ( $id ) use ( $by_id ) {
			$seen = [];
			while ( isset( $by_id[ $id ] ) && '' !== $by_id[ $id ]['parent'] && isset( $by_id[ $by_id[ $id ]['parent'] ] ) && ! isset( $seen[ $id ] ) ) {
				$seen[ $id ] = true;
				$id          = $by_id[ $id ]['parent'];
			}
			return $id;
		};
		$has_children = [];
		foreach ( $items as $item ) {
			if ( isset( $by_id[ $item['parent'] ] ) ) {
				$has_children[ $root_of( $item['id'] ) ] = true;
			}
		}
		foreach ( $items as $i => $item ) {
			$root                    = $root_of( $item['id'] );
			$items[ $i ]['category'] = '';
			if ( isset( $categories[ 'db:' . $item['parent'] ] ) ) {
				$items[ $i ]['category'] = 'db:' . $item['parent'];
			} elseif ( isset( $by_id[ $root ] ) && isset( $categories[ 'db:' . $by_id[ $root ]['parent'] ] ) ) {
				// Under a database row: the database is the category.
				$items[ $i ]['category'] = 'db:' . $by_id[ $root ]['parent'];
			} elseif ( isset( $has_children[ $root ] ) ) {
				$categories[ 'p:' . $root ] = [
					'name'        => '' !== $by_id[ $root ]['title'] ? $by_id[ $root ]['title'] : __( 'Notion', 'bridle-kb' ),
					'parent'      => '',
					'description' => '',
				];
				$items[ $i ]['category']    = 'p:' . $root;
			}
		}
		return [
			'items'      => $items,
			'categories' => $categories,
		];
	}

	/**
	 * One article: its title, HTML, excerpt and the key links to it use.
	 *
	 * @param string $source One of SOURCES.
	 * @param string $token  The token.
	 * @param array  $ref    From the listing.
	 * @return array|\WP_Error { title, html, excerpt, key, published }
	 */
	public static function article( string $source, string $token, array $ref ) {
		$id = (string) $ref['id'];
		switch ( $source ) {
			case 'intercom':
				$data = self::get( $source, self::INTERCOM . '/articles/' . rawurlencode( $id ), $token );
				if ( is_wp_error( $data ) ) {
					return $data;
				}
				return [
					'title'     => (string) ( $data['title'] ?? $ref['title'] ),
					'html'      => (string) ( $data['body'] ?? '' ),
					'excerpt'   => (string) ( $data['description'] ?? '' ),
					'key'       => $id,
					'published' => 'published' === ( $data['state'] ?? '' ),
				];

			case 'helpscout':
				$data = self::get( $source, self::HELPSCOUT . '/articles/' . rawurlencode( $id ), $token );
				if ( is_wp_error( $data ) ) {
					return $data;
				}
				$article = (array) ( $data['article'] ?? [] );
				return [
					'title'     => (string) ( $article['name'] ?? $ref['title'] ),
					'html'      => (string) ( $article['text'] ?? '' ),
					'excerpt'   => '',
					'key'       => (string) ( $article['number'] ?? '' ),
					'published' => 'published' === ( $article['status'] ?? '' ),
				];

			case 'notion':
				$budget = self::NOTION_MAX_BLOCKS;
				$blocks = self::notion_children( $token, $id, 0, $budget );
				if ( is_wp_error( $blocks ) ) {
					return $blocks;
				}
				return [
					'title'     => '' !== (string) $ref['title'] ? (string) $ref['title'] : __( 'Untitled', 'bridle-kb' ),
					'html'      => ImportHtml::notion_blocks( $blocks ),
					'excerpt'   => '',
					'key'       => strtolower( str_replace( '-', '', $id ) ),
					'published' => true,
				];
		}
		return self::unknown();
	}

	/**
	 * A Notion block's children, every page of them, with their own
	 * children under `children`, down to NOTION_DEPTH.
	 *
	 * @param string $token  The token.
	 * @param string $id     A page or block id.
	 * @param int    $depth  How deep this is.
	 * @param int    $budget Blocks still allowed for this page (shared).
	 * @return array|\WP_Error
	 */
	private static function notion_children( string $token, string $id, int $depth, int &$budget ) {
		$blocks = [];
		$cursor = '';
		do {
			$url  = self::NOTION . '/blocks/' . rawurlencode( $id ) . '/children?page_size=100' . ( '' !== $cursor ? '&start_cursor=' . rawurlencode( $cursor ) : '' );
			$data = self::get( 'notion', $url, $token );
			if ( is_wp_error( $data ) ) {
				return $data;
			}
			foreach ( (array) ( $data['results'] ?? [] ) as $block ) {
				if ( --$budget < 0 ) {
					return $blocks;
				}
				$type = (string) ( $block['type'] ?? '' );
				if ( ! empty( $block['has_children'] ) && $depth < self::NOTION_DEPTH && ! in_array( $type, [ 'child_page', 'child_database' ], true ) ) {
					$children = self::notion_children( $token, (string) $block['id'], $depth + 1, $budget );
					if ( is_wp_error( $children ) ) {
						return $children;
					}
					$block['children'] = $children;
				}
				$blocks[] = $block;
			}
			$cursor = ! empty( $data['has_more'] ) ? (string) ( $data['next_cursor'] ?? '' ) : '';
		} while ( '' !== $cursor );
		return $blocks;
	}

	/**
	 * GET a source's API.
	 *
	 * @param string $source One of SOURCES.
	 * @param string $url    The address.
	 * @param string $token  The token.
	 * @return array|\WP_Error The decoded answer.
	 */
	private static function get( string $source, string $url, string $token ) {
		return self::request( $source, 'GET', $url, $token );
	}

	/**
	 * POST JSON to a source's API.
	 *
	 * @param string $source One of SOURCES.
	 * @param string $url    The address.
	 * @param string $token  The token.
	 * @param array  $body   The JSON body.
	 * @return array|\WP_Error
	 */
	private static function post( string $source, string $url, string $token, array $body ) {
		return self::request( $source, 'POST', $url, $token, $body );
	}

	/**
	 * Call a source's API with its auth, in words when it fails.
	 *
	 * @param string     $source One of SOURCES.
	 * @param string     $method GET or POST.
	 * @param string     $url    The address.
	 * @param string     $token  The token.
	 * @param array|null $body   A JSON body.
	 * @return array|\WP_Error
	 */
	private static function request( string $source, string $method, string $url, string $token, ?array $body = null ) {
		$headers = [ 'Accept' => 'application/json' ];
		switch ( $source ) {
			case 'intercom':
				$headers['Authorization']    = 'Bearer ' . $token;
				$headers['Intercom-Version'] = '2.11';
				break;
			case 'helpscout':
				// Help Scout Docs: the API key as the user name, any password.
				$headers['Authorization'] = 'Basic ' . base64_encode( $token . ':X' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- HTTP Basic auth.
				break;
			case 'notion':
				$headers['Authorization']  = 'Bearer ' . $token;
				$headers['Notion-Version'] = '2022-06-28';
				usleep( self::NOTION_PAUSE_US );
				break;
			default:
				return self::unknown();
		}
		$args = [
			'method'  => $method,
			'timeout' => 20,
			'headers' => $headers,
		];
		if ( null !== $body ) {
			$args['headers']['Content-Type'] = 'application/json';
			$args['body']                    = (string) wp_json_encode( $body );
		}

		$response = wp_remote_request( $url, $args );
		if ( is_wp_error( $response ) ) {
			return new \WP_Error( 'bridle_kb_import_network', __( 'Couldn’t reach the service. Check your connection and try again.', 'bridle-kb' ) );
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( 401 === $code || 403 === $code ) {
			return new \WP_Error( 'bridle_kb_import_token', __( 'That token didn’t work. Check it has read access and try again.', 'bridle-kb' ), [ 'status' => 400 ] );
		}
		if ( 429 === $code ) {
			$wait = max( 5, (int) wp_remote_retrieve_header( $response, 'retry-after' ) );
			return new \WP_Error( 'bridle_kb_import_slow', __( 'The service asked to slow down. The import goes on in a moment.', 'bridle-kb' ), [ 'retry' => $wait ] );
		}
		if ( 404 === $code ) {
			return new \WP_Error( 'bridle_kb_import_missing', __( 'Not found at the service.', 'bridle-kb' ) );
		}
		if ( $code < 200 || $code >= 300 || ! is_array( $data ) ) {
			return new \WP_Error(
				'bridle_kb_import_http',
				/* translators: %d: HTTP status code */
				sprintf( __( 'The service answered with an error (%d). Try again later.', 'bridle-kb' ), $code ),
				[ 'retry' => $code >= 500 ? 30 : 0 ]
			);
		}
		return $data;
	}

	/**
	 * An unknown source.
	 *
	 * @return \WP_Error
	 */
	private static function unknown(): \WP_Error {
		return new \WP_Error( 'bridle_kb_import_source', __( 'Choose Intercom, Help Scout or Notion.', 'bridle-kb' ), [ 'status' => 400 ] );
	}
}
