<?php

/**
 * Asset Loading — Scripts and Styles.
 *
 * @package BridleKB
 */

namespace BridleKB;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Assets
 */
class Assets {


	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_media' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_frontend' ] );
	}

	/**
	 * Enqueue the knowledge base page's app, or the bar's stylesheet on the
	 * WordPress screens behind it. Nothing loads anywhere else.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function enqueue_admin( $hook ) {
		if ( 'edit-tags.php' === $hook || 'term.php' === $hook ) {
			$this->enqueue_chrome();
			return;
		}

		if ( '' === Admin::page_hook() || Admin::page_hook() !== $hook ) {
			return;
		}

		$asset_file = BRIDLE_KB_PATH . 'build/admin.asset.php';

		if ( ! file_exists( $asset_file ) ) {
			return;
		}

		$asset = include $asset_file;

		wp_enqueue_script(
			'bridle-kb-admin',
			BRIDLE_KB_URL . 'build/admin.js',
			$asset['dependencies'],
			$asset['version'],
			true
		);

		wp_set_script_translations( 'bridle-kb-admin', 'bridle-kb', BRIDLE_KB_PATH . 'languages' );

		wp_enqueue_style(
			'bridle-kb-admin',
			BRIDLE_KB_URL . 'build/admin.css',
			[],
			$asset['version']
		);

		wp_localize_script( 'bridle-kb-admin', 'bridleKbAdmin', $this->admin_data() );
	}

	/**
	 * What the page starts with: the tab counts, the categories and authors
	 * the rows name, and where its links go. The articles themselves come
	 * from the core REST API (wp/v2/docs), every status at once.
	 *
	 * @return array
	 */
	private function admin_data() {
		$taxonomy   = get_taxonomy( 'docs_category' );
		$can_manage = $taxonomy && current_user_can( $taxonomy->cap->manage_terms );
		$categories = [];
		$terms      = get_terms(
			[
				'taxonomy'   => 'docs_category',
				'hide_empty' => false,
			]
		);

		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				$categories[ $term->term_id ] = [
					'name'    => $term->name,
					'parent'  => (int) $term->parent,
					'editUrl' => $can_manage ? get_edit_term_link( $term, 'docs_category', 'docs' ) : '',
				];
			}
		}

		// The people a row can name: everyone who can write. Capped, so a
		// site with thousands of contributors still renders fast; a row whose
		// author is not here shows no name.
		$authors = [];
		$users   = get_users(
			[
				'capability' => 'edit_posts',
				'number'     => 200,
				'fields'     => [ 'ID', 'display_name' ],
			]
		);

		foreach ( $users as $user ) {
			$authors[ (int) $user->ID ] = [
				'name'   => $user->display_name,
				'avatar' => get_avatar_url( (int) $user->ID, [ 'size' => 48 ] ),
			];
		}

		return [
			'adminUrl'      => admin_url(),
			'newUrl'        => admin_url( 'post-new.php?post_type=docs' ),
			'categoriesUrl' => $can_manage
				? admin_url( 'edit-tags.php?taxonomy=docs_category&post_type=docs' )
				: '',
			'siteUrl'       => (string) get_post_type_archive_link( 'docs' ),
			'inBridle'      => Admin::in_bridle(),
			'counts'        => REST::tab_counts(),
			'categories'    => (object) $categories,
			'authors'       => (object) $authors,
			'trashDays'     => (int) EMPTY_TRASH_DAYS,
			'canPublish'    => current_user_can( get_post_type_object( 'docs' )->cap->publish_posts ),
			'canImport'     => Importer::can_import(),
		];
	}

	/**
	 * The bar's stylesheet, on the category screens only
	 * (Admin::render_bar() draws the bar itself; the articles list redirects
	 * to the Docs page).
	 */
	private function enqueue_chrome() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

		if ( ! $screen || 'docs_category' !== $screen->taxonomy ) {
			return;
		}

		$file = BRIDLE_KB_PATH . 'build/chrome.css';

		if ( ! file_exists( $file ) ) {
			return;
		}

		// A stylesheet-only entry: its .asset.php version hashes an empty
		// script, so version by the file itself.
		wp_enqueue_style(
			'bridle-kb-chrome',
			BRIDLE_KB_URL . 'build/chrome.css',
			[],
			(string) filemtime( $file )
		);
	}

	/**
	 * Enqueue media scripts for category icon upload.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function enqueue_media( $hook ) {
		if ( 'edit-tags.php' !== $hook && 'term.php' !== $hook ) {
			return;
		}

		// Read-only screen detection (which taxonomy is being edited) to decide whether
		// to enqueue the media uploader — no data is processed, so no nonce applies.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$taxonomy = isset( $_GET['taxonomy'] ) ? sanitize_key( wp_unslash( $_GET['taxonomy'] ) ) : '';
		if ( 'docs_category' !== $taxonomy ) {
			return;
		}

		wp_enqueue_media();
		wp_add_inline_script( 'jquery', $this->get_icon_upload_script() );
	}

	/**
	 * Enqueue frontend scripts and styles.
	 */
	public function enqueue_frontend() {
		$is_docs_page = is_singular( 'docs' ) || is_post_type_archive( 'docs' ) || is_tax( 'docs_category' );

		if ( ! $is_docs_page ) {
			return;
		}

		// Frontend template assets (CSS + JS for templates, TOC, search).
		$this->enqueue_frontend_assets();
	}

	/**
	 * Enqueue frontend template CSS and JS.
	 */
	private function enqueue_frontend_assets() {
		$asset_file = BRIDLE_KB_PATH . 'build/frontend.asset.php';
		$version    = file_exists( $asset_file )
			? ( include $asset_file )['version']
			: BRIDLE_KB_VERSION;

		wp_enqueue_style(
			'bridle-kb-frontend',
			BRIDLE_KB_URL . 'build/style-frontend.css',
			[],
			$version
		);

		wp_enqueue_script(
			'bridle-kb-frontend',
			BRIDLE_KB_URL . 'build/frontend.js',
			[],
			$version,
			true
		);

		wp_localize_script(
			'bridle-kb-frontend',
			'bridleKbFrontend',
			[
				'restUrl'    => rest_url( 'bridle-kb/v1/' ),
				'nonce'      => wp_create_nonce( 'wp_rest' ),
				'archiveUrl' => (string) get_post_type_archive_link( 'docs' ),
				'i18n'       => [
					'searchLabel'   => __( 'Search docs', 'bridle-kb' ),
					'placeholder'   => Templates::search_placeholder(),
					'close'         => __( 'Close', 'bridle-kb' ),
					'hint'          => __( 'Type to search every article.', 'bridle-kb' ),
					'searching'     => __( 'Searching…', 'bridle-kb' ),
					/* translators: %s: the search terms */
					'noResults'     => __( 'No results for “%s”.', 'bridle-kb' ),
					/* translators: %s: the search terms */
					'seeAll'        => __( 'See all results for “%s”', 'bridle-kb' ),
					'error'         => __( 'Search is not available right now.', 'bridle-kb' ),
					'results'       => __( 'Results', 'bridle-kb' ),
					'copyPage'      => __( 'Copy page', 'bridle-kb' ),
					'copied'        => __( 'Copied', 'bridle-kb' ),
					'copyFailed'    => __( 'Could not copy', 'bridle-kb' ),
					'copyCode'      => __( 'Copy code', 'bridle-kb' ),
					'linkToSection' => __( 'Link to this section', 'bridle-kb' ),
				],
			]
		);
	}


	/**
	 * Get the inline JavaScript for the icon uploader.
	 *
	 * @return string
	 */
	private function get_icon_upload_script() {
		$title  = wp_json_encode( __( 'Choose an icon', 'bridle-kb' ) );
		$button = wp_json_encode( __( 'Use this icon', 'bridle-kb' ) );

		return "
		jQuery(document).ready(function($) {
			var iconUploader;

			$('.bridle-kb-upload-icon').on('click', function(e) {
				e.preventDefault();

				if (iconUploader) {
					iconUploader.open();
					return;
				}

				iconUploader = wp.media({
					title: {$title},
					button: { text: {$button} },
					multiple: false,
					library: { type: 'image' }
				});

				iconUploader.on('select', function() {
					var attachment = iconUploader.state().get('selection').first().toJSON();
					$('#category_icon').val(attachment.id);
					$('.bridle-kb-icon-preview img').attr('src', attachment.url);
					$('.bridle-kb-icon-preview').show();
				});

				iconUploader.open();
			});

			$('.bridle-kb-remove-icon').on('click', function(e) {
				e.preventDefault();
				$('#category_icon').val('');
				$('.bridle-kb-icon-preview').hide();
			});
		});
		";
	}
}
