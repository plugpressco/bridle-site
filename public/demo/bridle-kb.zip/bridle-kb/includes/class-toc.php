<?php

/**
 * Table of Contents.
 *
 * Parses headings from post content, injects anchor IDs,
 * and provides data for the sidebar TOC.
 *
 * @package BridleKB
 */

namespace BridleKB;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class TOC
 */
class TOC {


	/**
	 * Cached TOC items for the current post.
	 *
	 * @var array
	 */
	private static $items = [];

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_filter( 'the_content', [ $this, 'add_heading_anchors' ], 5 );
	}

	/**
	 * Add ID attributes to h2–h4 headings and cache the heading list.
	 *
	 * @param string $content Post content.
	 * @return string Modified content.
	 */
	public function add_heading_anchors( $content ) {
		if ( ! is_singular( 'docs' ) ) {
			return $content;
		}

		self::$items = [];

		$content = preg_replace_callback(
			'/<(h[2-4])(\b[^>]*)>(.*?)<\/\1>/is',
			function ( $matches ) {
				$tag   = $matches[1];
				$attrs = $matches[2];
				$text  = trim( wp_strip_all_tags( $matches[3] ) );
				$level = (int) substr( $tag, 1 );

				if ( '' === $text ) {
					return $matches[0];
				}

				// A heading that already has an id keeps it, and the TOC links
				// to that id.
				if ( preg_match( '/(?:^|\s)id\s*=\s*(["\'])(.*?)\1/i', $attrs, $id_match ) && '' !== $id_match[2] ) {
					self::$items[] = [
						'id'    => $id_match[2],
						'text'  => $text,
						'level' => $level,
					];
					return $matches[0];
				}

				$base_id  = sanitize_title( $text );
				$base_id  = '' !== $base_id ? $base_id : 'section';
				$id       = $base_id;
				$counter  = 1;
				$existing = array_column( self::$items, 'id' );
				while ( in_array( $id, $existing, true ) ) {
					$id = $base_id . '-' . $counter;
					++$counter;
				}

				self::$items[] = [
					'id'    => $id,
					'text'  => $text,
					'level' => $level,
				];

				return '<' . $tag . $attrs . ' id="' . esc_attr( $id ) . '">' . $matches[3] . '</' . $tag . '>';
			},
			$content
		);

		return $content;
	}

	/**
	 * Get cached TOC items. Call after the_content() has run.
	 *
	 * @return array
	 */
	public static function get_items() {
		return self::$items;
	}

	/**
	 * Check if the current post has enough headings for a TOC.
	 *
	 * @param int $minimum Minimum headings required.
	 * @return bool
	 */
	public static function has_toc( $minimum = 2 ) {
		return count( self::$items ) >= $minimum;
	}

	/**
	 * Render the TOC sidebar via template part.
	 */
	public static function render() {
		if ( ! self::has_toc() ) {
			return;
		}
		if ( ! bridle_kb_get_option( 'toc_visible', true ) ) {
			return;
		}

		Templates::get_template_part( 'parts/toc', [ 'items' => self::$items ] );
	}
}
