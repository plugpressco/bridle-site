<?php

namespace BridleKB;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
class BlockTemplates {


	const PLUGIN_SLUG = 'bridle-kb';

	public function __construct() {
		add_action( 'init', [ $this, 'register_shortcodes' ] );
		add_action( 'init', [ $this, 'register_templates' ], 20 );
		add_filter( 'render_block_core/shortcode', [ $this, 'ensure_shortcode_renders' ], 10, 2 );
	}

	public function register_shortcodes() {
		add_shortcode( 'bridle_kb_single_doc', [ $this, 'shortcode_single_doc' ] );
		add_shortcode( 'bridle_kb_archive_doc', [ $this, 'shortcode_archive_doc' ] );
		add_shortcode( 'bridle_kb_taxonomy_docs_category', [ $this, 'shortcode_taxonomy_docs_category' ] );
	}

	/**
	 * Shortcode blocks run wpautop over what they hold. A docs template saved
	 * from the Site Editor before the plugin moved to HTML blocks still has
	 * the help center in one, already rendered by the time the block is: hand
	 * that markup back untouched. Anything else gets its shortcodes run.
	 *
	 * @param string $block_content Rendered block.
	 * @param array  $block         Parsed block.
	 * @return string
	 */
	public function ensure_shortcode_renders( $block_content, $block ) {
		$inner = $block['innerHTML'] ?? '';

		if ( false !== strpos( $inner, 'class="bridle-kb bridle-kb-page-' ) ) {
			return $inner;
		}

		return do_shortcode( $block_content );
	}

	public function shortcode_single_doc() {
		if ( ! is_singular( 'docs' ) ) {
			return '';
		}
		return $this->capture( [ Templates::class, 'render_single_docs_content' ] );
	}

	public function shortcode_archive_doc() {
		if ( ! is_post_type_archive( 'docs' ) ) {
			return '';
		}
		return $this->capture( [ Templates::class, 'render_archive_docs_content' ] );
	}

	public function shortcode_taxonomy_docs_category() {
		if ( ! is_tax( 'docs_category' ) ) {
			return '';
		}
		return $this->capture( [ Templates::class, 'render_taxonomy_docs_category_content' ] );
	}

	/**
	 * Run a render callback and return its HTML.
	 *
	 * @param callable $callback Render callback.
	 * @return string
	 */
	private function capture( $callback ) {
		ob_start();
		call_user_func( $callback );
		return (string) ob_get_clean();
	}

	/**
	 * A docs template: the theme's header and footer around the shortcode, in
	 * an HTML block, which prints the help center's markup as it is (a
	 * shortcode block would run wpautop over it).
	 *
	 * @param string $shortcode Shortcode name.
	 * @return string Block markup.
	 */
	private function get_block_template_content( $shortcode ) {
		return '<!-- wp:template-part {"slug":"header"} /-->
<!-- wp:group {"tagName":"main","layout":{"type":"default"}} -->
<main class="wp-block-group">
<!-- wp:html -->
[' . $shortcode . ']
<!-- /wp:html -->
</main>
<!-- /wp:group -->
<!-- wp:template-part {"slug":"footer","tagName":"footer"} /-->';
	}

	public function register_templates() {
		if ( ! function_exists( 'register_block_template' ) ) {
			return;
		}

		$templates = [
			'single-docs'            => [
				'title'       => __( 'Single article', 'bridle-kb' ),
				'description' => __( 'One help article, with the docs navigation and its contents.', 'bridle-kb' ),
				'shortcode'   => 'bridle_kb_single_doc',
			],
			'archive-docs'           => [
				'title'       => __( 'Docs home', 'bridle-kb' ),
				'description' => __( 'The help center home: search and the categories.', 'bridle-kb' ),
				'shortcode'   => 'bridle_kb_archive_doc',
			],
			'taxonomy-docs_category' => [
				'title'       => __( 'Docs category', 'bridle-kb' ),
				'description' => __( 'The articles in one category.', 'bridle-kb' ),
				'shortcode'   => 'bridle_kb_taxonomy_docs_category',
			],
		];

		$register = 'register_block_template';
		foreach ( $templates as $slug => $args ) {
			$register(
				self::PLUGIN_SLUG . '//' . $slug,
				[
					'title'       => $args['title'],
					'description' => $args['description'],
					'content'     => $this->get_block_template_content( $args['shortcode'] ),
				]
			);
		}
	}
}
