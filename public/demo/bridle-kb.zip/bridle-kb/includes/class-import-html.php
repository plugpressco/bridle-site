<?php
/**
 * The importer's text work: Notion blocks to HTML, any help center's HTML to
 * clean block-editor content, its images and its links. Pure: DOM and
 * strings only, no WordPress, so it is unit-tested (tests/unit).
 *
 * @package BridleKB
 */

namespace BridleKB;

defined( 'ABSPATH' ) || exit;

/**
 * Class ImportHtml
 */
class ImportHtml {

	/** Tags kept, with the attributes each may keep. Everything else is unwrapped. */
	const ALLOWED = [
		'p'          => [],
		'h2'         => [],
		'h3'         => [],
		'h4'         => [],
		'ul'         => [],
		'ol'         => [ 'start' ],
		'li'         => [],
		'a'          => [ 'href' ],
		'strong'     => [],
		'em'         => [],
		's'          => [],
		'code'       => [],
		'pre'        => [],
		'blockquote' => [],
		'img'        => [ 'src', 'alt' ],
		'figure'     => [],
		'figcaption' => [],
		'hr'         => [],
		'br'         => [],
		'table'      => [],
		'thead'      => [],
		'tbody'      => [],
		'tr'         => [],
		'th'         => [ 'colspan', 'rowspan' ],
		'td'         => [ 'colspan', 'rowspan' ],
	];

	/** Tags renamed on the way in: one h1 per page is the title. */
	const RENAME = [
		'h1'     => 'h2',
		'h5'     => 'h4',
		'h6'     => 'h4',
		'b'      => 'strong',
		'i'      => 'em',
		'del'    => 's',
		'strike' => 's',
	];

	/** Tags dropped with everything inside them. */
	const DROP = [ 'script', 'style', 'noscript', 'iframe', 'object', 'embed', 'form', 'input', 'button', 'select', 'textarea', 'svg', 'video', 'audio', 'template', 'head' ];

	/** Blocks that hold inline content at the top level. */
	const BLOCK_TAGS = [ 'p', 'h2', 'h3', 'h4', 'ul', 'ol', 'pre', 'blockquote', 'img', 'figure', 'hr', 'table' ];

	/*
	 * ---------------------------------------------------------------------
	 * Notion
	 * ---------------------------------------------------------------------
	 */

	/**
	 * Notion rich text as inline HTML: bold, italic, strikethrough, code and
	 * links. A mention of another page becomes a link to its notion.so
	 * address, which rewrite_links() later points at the imported doc.
	 *
	 * @param array $rich Notion rich_text array.
	 * @return string
	 */
	public static function rich_text( array $rich ): string {
		$out = '';
		foreach ( $rich as $part ) {
			if ( ! is_array( $part ) ) {
				continue;
			}
			$text = self::esc( (string) ( $part['plain_text'] ?? '' ) );
			if ( '' === $text ) {
				continue;
			}
			$text = nl2br( $text, false );
			$a    = (array) ( $part['annotations'] ?? [] );
			if ( ! empty( $a['code'] ) ) {
				$text = '<code>' . $text . '</code>';
			}
			if ( ! empty( $a['bold'] ) ) {
				$text = '<strong>' . $text . '</strong>';
			}
			if ( ! empty( $a['italic'] ) ) {
				$text = '<em>' . $text . '</em>';
			}
			if ( ! empty( $a['strikethrough'] ) ) {
				$text = '<s>' . $text . '</s>';
			}
			$href = (string) ( $part['href'] ?? '' );
			if ( '' === $href && 'page' === ( $part['mention']['type'] ?? '' ) && ! empty( $part['mention']['page']['id'] ) ) {
				$href = 'https://www.notion.so/' . str_replace( '-', '', (string) $part['mention']['page']['id'] );
			}
			if ( '' !== $href && preg_match( '#^(https?://|/)#i', $href ) ) {
				if ( '/' === $href[0] ) {
					$href = 'https://www.notion.so' . $href;
				}
				$text = '<a href="' . self::esc( $href ) . '">' . $text . '</a>';
			}
			$out .= $text;
		}
		return $out;
	}

	/**
	 * Notion blocks as HTML. A block's children, fetched by the caller, sit
	 * in its `children` key. Lists group consecutive items; toggles open up;
	 * callouts become quotes; columns run one after another; child pages
	 * and databases are left out (they are imported as docs of their own).
	 *
	 * @param array $blocks Notion block objects, in order.
	 * @return string
	 */
	public static function notion_blocks( array $blocks ): string {
		$html  = '';
		$list  = '';
		$flush = static function () use ( &$html, &$list ) {
			if ( '' !== $list ) {
				$html .= '</' . $list . '>';
				$list  = '';
			}
		};

		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) || empty( $block['type'] ) ) {
				continue;
			}
			$type     = (string) $block['type'];
			$data     = (array) ( $block[ $type ] ?? [] );
			$text     = self::rich_text( (array) ( $data['rich_text'] ?? [] ) );
			$children = self::notion_blocks( (array) ( $block['children'] ?? [] ) );

			$item = [
				'bulleted_list_item' => 'ul',
				'numbered_list_item' => 'ol',
				'to_do'              => 'ul',
			][ $type ] ?? '';
			if ( $item ) {
				if ( $list !== $item ) {
					$flush();
					$html .= '<' . $item . '>';
					$list  = $item;
				}
				$box   = 'to_do' === $type ? ( ! empty( $data['checked'] ) ? '☑ ' : '☐ ' ) : '';
				$html .= '<li>' . $box . $text . $children . '</li>';
				continue;
			}
			$flush();

			switch ( $type ) {
				case 'paragraph':
					$html .= '' !== $text ? '<p>' . $text . '</p>' : '';
					$html .= $children;
					break;
				case 'heading_1':
				case 'heading_2':
				case 'heading_3':
					$level = min( 4, (int) substr( $type, -1 ) + 1 );
					$html .= '<h' . $level . '>' . $text . '</h' . $level . '>' . $children;
					break;
				case 'quote':
				case 'callout':
					$icon  = 'callout' === $type && 'emoji' === ( $data['icon']['type'] ?? '' ) ? self::esc( (string) $data['icon']['emoji'] ) . ' ' : '';
					$html .= '<blockquote><p>' . $icon . $text . '</p>' . $children . '</blockquote>';
					break;
				case 'toggle':
					$html .= '<p><strong>' . $text . '</strong></p>' . $children;
					break;
				case 'code':
					$code  = self::esc( implode( '', array_map( static fn( $r ) => (string) ( $r['plain_text'] ?? '' ), (array) ( $data['rich_text'] ?? [] ) ) ) );
					$html .= '<pre><code>' . $code . '</code></pre>';
					break;
				case 'divider':
					$html .= '<hr>';
					break;
				case 'image':
					$url = (string) ( $data[ $data['type'] ?? 'external' ]['url'] ?? '' );
					if ( preg_match( '#^https?://#i', $url ) ) {
						$caption = self::rich_text( (array) ( $data['caption'] ?? [] ) );
						$alt     = self::esc( trim( self::plain( $caption ) ) );
						$html   .= '<figure><img src="' . self::esc( $url ) . '" alt="' . $alt . '">' . ( '' !== $caption ? '<figcaption>' . $caption . '</figcaption>' : '' ) . '</figure>';
					}
					break;
				case 'bookmark':
				case 'embed':
				case 'link_preview':
				case 'video':
				case 'file':
				case 'pdf':
					$url = (string) ( $data['url'] ?? ( $data[ $data['type'] ?? 'external' ]['url'] ?? '' ) );
					if ( preg_match( '#^https?://#i', $url ) && 'file' !== ( $data['type'] ?? '' ) ) {
						$label = self::rich_text( (array) ( $data['caption'] ?? [] ) );
						$html .= '<p><a href="' . self::esc( $url ) . '">' . ( '' !== $label ? $label : self::esc( $url ) ) . '</a></p>';
					}
					break;
				case 'table':
					$rows = '';
					foreach ( (array) ( $block['children'] ?? [] ) as $i => $row ) {
						$cells = '';
						$tag   = 0 === $i && ! empty( $data['has_column_header'] ) ? 'th' : 'td';
						foreach ( (array) ( $row['table_row']['cells'] ?? [] ) as $cell ) {
							$cells .= '<' . $tag . '>' . self::rich_text( (array) $cell ) . '</' . $tag . '>';
						}
						$rows .= '<tr>' . $cells . '</tr>';
					}
					$html .= '' !== $rows ? '<table><tbody>' . $rows . '</tbody></table>' : '';
					break;
				case 'column_list':
				case 'column':
				case 'synced_block':
					$html .= $children;
					break;
				default:
					// child_page, child_database, table_of_contents, breadcrumb,
					// equation, unsupported: nothing a reader needs here.
					break;
			}
		}
		$flush();
		return $html;
	}

	/**
	 * A Notion page's or database's title.
	 *
	 * @param array $item A page or database object.
	 * @return string
	 */
	public static function notion_title( array $item ): string {
		if ( isset( $item['title'] ) && is_array( $item['title'] ) ) {
			return trim( implode( '', array_map( static fn( $r ) => (string) ( $r['plain_text'] ?? '' ), $item['title'] ) ) );
		}
		foreach ( (array) ( $item['properties'] ?? [] ) as $property ) {
			if ( 'title' === ( $property['type'] ?? '' ) ) {
				return trim( implode( '', array_map( static fn( $r ) => (string) ( $r['plain_text'] ?? '' ), (array) $property['title'] ) ) );
			}
		}
		return '';
	}

	/*
	 * ---------------------------------------------------------------------
	 * Any HTML
	 * ---------------------------------------------------------------------
	 */

	/**
	 * A help center's HTML with only plain structure left: the allowed tags
	 * and attributes, no classes, styles, scripts or wrappers, links only to
	 * http(s), mailto and in-page anchors, empty paragraphs gone.
	 *
	 * @param string $html Article HTML.
	 * @return string
	 */
	public static function clean( string $html ): string {
		$dom = self::load( $html );
		if ( ! $dom ) {
			return '';
		}
		$root = $dom->getElementsByTagName( 'body' )->item( 0 );
		if ( ! $root ) {
			return '';
		}
		self::clean_node( $root, $dom );
		$out = self::inner( $root );
		$out = (string) preg_replace( '#<p>(\s|&nbsp;|<br>)*</p>#u', '', $out );
		return trim( $out );
	}

	/**
	 * Clean HTML as block-editor content: paragraphs, headings, lists,
	 * quotes, code, images, separators; tables and anything else as an HTML
	 * block. Loose inline text at the top level becomes a paragraph.
	 *
	 * @param string $html From clean().
	 * @param array  $ids  Image URL => attachment id, for wp-image-{id}.
	 * @return string
	 */
	public static function to_blocks( string $html, array $ids = [] ): string {
		$dom = self::load( $html );
		if ( ! $dom ) {
			return '';
		}
		$root   = $dom->getElementsByTagName( 'body' )->item( 0 );
		$blocks = [];
		$loose  = '';
		$flush  = static function () use ( &$blocks, &$loose ) {
			if ( '' !== trim( self::plain( $loose ) ) ) {
				$blocks[] = "<!-- wp:paragraph -->\n<p>" . trim( $loose ) . "</p>\n<!-- /wp:paragraph -->";
			}
			$loose = '';
		};

		foreach ( iterator_to_array( $root ? $root->childNodes : [] ) as $node ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
			$tag = XML_ELEMENT_NODE === $node->nodeType ? strtolower( $node->nodeName ) : ''; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
			if ( '' === $tag || ! in_array( $tag, self::BLOCK_TAGS, true ) ) {
				$loose .= XML_TEXT_NODE === $node->nodeType ? self::esc( (string) $node->textContent ) : $dom->saveHTML( $node ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
				continue;
			}
			$flush();
			$block = self::block( $node, $dom, $ids );
			if ( '' !== $block ) {
				$blocks[] = $block;
			}
		}
		$flush();
		return implode( "\n\n", $blocks );
	}

	/**
	 * Every image address in the HTML, once each.
	 *
	 * @param string $html Clean HTML.
	 * @return string[]
	 */
	public static function images( string $html ): array {
		preg_match_all( '#<img\b[^>]*\ssrc="([^"]+)"#i', $html, $m );
		$urls = array_map( static fn( $u ) => html_entity_decode( $u, ENT_QUOTES | ENT_HTML5, 'UTF-8' ), $m[1] );
		return array_values( array_unique( array_filter( $urls, static fn( $u ) => (bool) preg_match( '#^https?://#i', $u ) ) ) );
	}

	/**
	 * Point images at their copies in the media library; images that
	 * couldn't be copied go.
	 *
	 * @param string $html Clean HTML.
	 * @param array  $map  Original URL => local URL ('' = drop the image).
	 * @return string
	 */
	public static function replace_images( string $html, array $map ): string {
		return (string) preg_replace_callback(
			'#<img\b[^>]*>#i',
			static function ( $m ) use ( $map ) {
				if ( ! preg_match( '#\ssrc="([^"]+)"#i', $m[0], $src ) ) {
					return '';
				}
				$url = html_entity_decode( $src[1], ENT_QUOTES | ENT_HTML5, 'UTF-8' );
				if ( ! array_key_exists( $url, $map ) || '' === $map[ $url ] ) {
					return '';
				}
				return str_replace( $src[0], ' src="' . self::esc( $map[ $url ] ) . '"', $m[0] );
			},
			$html
		);
	}

	/**
	 * The key that names an article in a link from its old help center:
	 * Intercom's article id, Help Scout's article number, Notion's page id
	 * without dashes. '' for any other link.
	 *
	 * @param string $source intercom | helpscout | notion.
	 * @param string $url    A link.
	 * @return string
	 */
	public static function link_key( string $source, string $url ): string {
		$patterns = [
			'intercom'  => '#/articles/(\d+)(?:[-/?\#]|$)#',
			'helpscout' => '#/article/(\d+)(?:[-/?\#]|$)#',
			'notion'    => '#(?:notion\.so|notion\.site)/(?:[^?\#]*?)([0-9a-f]{32})(?:[?\#]|$)#i',
		];
		if ( ! isset( $patterns[ $source ] ) || ! preg_match( $patterns[ $source ], html_entity_decode( $url, ENT_QUOTES | ENT_HTML5, 'UTF-8' ), $m ) ) {
			return '';
		}
		return strtolower( $m[1] );
	}

	/**
	 * Links to imported articles now go to their docs.
	 *
	 * @param string $html   Content.
	 * @param string $source intercom | helpscout | notion.
	 * @param array  $map    Key (from link_key()) => new URL.
	 * @return string
	 */
	public static function rewrite_links( string $html, string $source, array $map ): string {
		if ( ! $map ) {
			return $html;
		}
		return (string) preg_replace_callback(
			'#(<a\b[^>]*\shref=")([^"]+)(")#i',
			static function ( $m ) use ( $source, $map ) {
				$key = self::link_key( $source, $m[2] );
				return '' !== $key && isset( $map[ $key ] ) ? $m[1] . self::esc( $map[ $key ] ) . $m[3] : $m[0];
			},
			$html
		);
	}

	/*
	 * ---------------------------------------------------------------------
	 * Internals
	 * ---------------------------------------------------------------------
	 */

	/**
	 * One top-level element as a block.
	 *
	 * @param \DOMElement  $node The element.
	 * @param \DOMDocument $dom  Its document.
	 * @param array        $ids  Image URL => attachment id.
	 * @return string
	 */
	private static function block( \DOMElement $node, \DOMDocument $dom, array $ids ): string {
		$tag   = strtolower( $node->nodeName ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
		$inner = trim( self::inner( $node ) );

		switch ( $tag ) {
			case 'p':
				return '' === trim( self::plain( $inner ) ) && false === strpos( $inner, '<img' ) ? '' : "<!-- wp:paragraph -->\n<p>{$inner}</p>\n<!-- /wp:paragraph -->";
			case 'h2':
			case 'h3':
			case 'h4':
				$level = (int) substr( $tag, 1 );
				$attrs = 2 === $level ? '' : ' {"level":' . $level . '}';
				return "<!-- wp:heading{$attrs} -->\n<{$tag} class=\"wp-block-heading\">{$inner}</{$tag}>\n<!-- /wp:heading -->";
			case 'ul':
			case 'ol':
				return self::list_block( $node, $dom );
			case 'pre':
				$code = self::esc( (string) $node->textContent ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
				return "<!-- wp:code -->\n<pre class=\"wp-block-code\"><code>{$code}</code></pre>\n<!-- /wp:code -->";
			case 'blockquote':
				$paras = '';
				foreach ( iterator_to_array( $node->childNodes ) as $child ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
					$text = XML_ELEMENT_NODE === $child->nodeType && 'p' === strtolower( $child->nodeName ) ? trim( self::inner( $child ) ) : trim( XML_TEXT_NODE === $child->nodeType ? self::esc( (string) $child->textContent ) : (string) $dom->saveHTML( $child ) ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
					if ( '' !== trim( self::plain( $text ) ) ) {
						$paras .= "<!-- wp:paragraph -->\n<p>{$text}</p>\n<!-- /wp:paragraph -->";
					}
				}
				return '' === $paras ? '' : "<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\">{$paras}</blockquote>\n<!-- /wp:quote -->";
			case 'hr':
				return "<!-- wp:separator -->\n<hr class=\"wp-block-separator has-alpha-channel-opacity\"/>\n<!-- /wp:separator -->";
			case 'img':
			case 'figure':
				$img = 'img' === $tag ? $node : $node->getElementsByTagName( 'img' )->item( 0 );
				if ( ! $img ) {
					return '' === $inner ? '' : "<!-- wp:html -->\n{$inner}\n<!-- /wp:html -->";
				}
				$src     = (string) $img->getAttribute( 'src' );
				$alt     = self::esc( (string) $img->getAttribute( 'alt' ) );
				$caption = '';
				if ( 'figure' === $tag ) {
					$cap     = $node->getElementsByTagName( 'figcaption' )->item( 0 );
					$caption = $cap ? trim( self::inner( $cap ) ) : '';
				}
				$id    = (int) ( $ids[ $src ] ?? 0 );
				$attrs = $id ? '{"id":' . $id . ',"sizeSlug":"full","linkDestination":"none"}' : '{"sizeSlug":"full","linkDestination":"none"}';
				$class = $id ? ' class="wp-image-' . $id . '"' : '';
				$cap   = '' !== $caption ? '<figcaption class="wp-element-caption">' . $caption . '</figcaption>' : '';
				return "<!-- wp:image {$attrs} -->\n<figure class=\"wp-block-image size-full\"><img src=\"" . self::esc( $src ) . "\" alt=\"{$alt}\"{$class}/>{$cap}</figure>\n<!-- /wp:image -->";
			default:
				// Tables and anything else: kept whole, still editable as HTML.
				return "<!-- wp:html -->\n" . (string) $dom->saveHTML( $node ) . "\n<!-- /wp:html -->";
		}
	}

	/**
	 * A list (and its nested lists) as list and list-item blocks.
	 *
	 * @param \DOMElement  $node ul or ol.
	 * @param \DOMDocument $dom  Its document.
	 * @return string
	 */
	private static function list_block( \DOMElement $node, \DOMDocument $dom ): string {
		$ordered = 'ol' === strtolower( $node->nodeName ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
		$tag     = $ordered ? 'ol' : 'ul';
		$items   = '';
		foreach ( iterator_to_array( $node->childNodes ) as $li ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
			if ( XML_ELEMENT_NODE !== $li->nodeType || 'li' !== strtolower( $li->nodeName ) ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
				continue;
			}
			$text   = '';
			$nested = '';
			foreach ( iterator_to_array( $li->childNodes ) as $child ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
				$name = XML_ELEMENT_NODE === $child->nodeType ? strtolower( $child->nodeName ) : ''; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
				if ( 'ul' === $name || 'ol' === $name ) {
					$nested .= self::list_block( $child, $dom );
				} elseif ( 'p' === $name ) {
					$text .= ( '' !== trim( $text ) ? '<br>' : '' ) . trim( self::inner( $child ) );
				} else {
					$text .= XML_TEXT_NODE === $child->nodeType ? self::esc( (string) $child->textContent ) : (string) $dom->saveHTML( $child ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
				}
			}
			$items .= '<!-- wp:list-item -->' . "\n" . '<li>' . trim( $text ) . $nested . '</li>' . "\n" . '<!-- /wp:list-item -->';
		}
		if ( '' === $items ) {
			return '';
		}
		$attrs = $ordered ? ' {"ordered":true}' : '';
		return "<!-- wp:list{$attrs} -->\n<{$tag} class=\"wp-block-list\">{$items}</{$tag}>\n<!-- /wp:list -->";
	}

	/**
	 * Clean one element's subtree in place.
	 *
	 * @param \DOMNode     $node The element.
	 * @param \DOMDocument $dom  Its document.
	 */
	private static function clean_node( \DOMNode $node, \DOMDocument $dom ): void {
		foreach ( iterator_to_array( $node->childNodes ) as $child ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
			if ( XML_COMMENT_NODE === $child->nodeType ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
				$node->removeChild( $child );
				continue;
			}
			if ( XML_ELEMENT_NODE !== $child->nodeType ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
				continue;
			}
			$tag = strtolower( $child->nodeName ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
			if ( in_array( $tag, self::DROP, true ) ) {
				$node->removeChild( $child );
				continue;
			}
			self::clean_node( $child, $dom );

			$tag = self::RENAME[ $tag ] ?? $tag;
			if ( ! isset( self::ALLOWED[ $tag ] ) ) {
				// A wrapper (div, span, section…): keep what's inside. A div
				// holding text becomes a paragraph so lines don't run together.
				$block = in_array( strtolower( $child->nodeName ), [ 'div', 'section', 'article', 'main', 'header', 'footer', 'aside' ], true ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
				if ( $block && ! self::has_block_child( $child ) && '' !== trim( (string) $child->textContent ) ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
					self::replace_tag( $child, 'p', $dom );
				} else {
					while ( $child->firstChild ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
						$node->insertBefore( $child->firstChild, $child ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
					}
					$node->removeChild( $child );
				}
				continue;
			}
			$was = strtolower( $child->nodeName ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
			if ( $was !== $tag ) {
				$child = self::replace_tag( $child, $tag, $dom );
			}
			foreach ( iterator_to_array( $child->attributes ) as $attr ) {
				$name = strtolower( $attr->name );
				if ( ! in_array( $name, self::ALLOWED[ $tag ], true ) ) {
					$child->removeAttribute( $attr->name );
				}
			}
			if ( 'a' === $tag && ! preg_match( '#^(https?:|mailto:|\#)#i', trim( (string) $child->getAttribute( 'href' ) ) ) ) {
				$child->removeAttribute( 'href' );
			}
			if ( 'img' === $tag && ! preg_match( '#^https?://#i', trim( (string) $child->getAttribute( 'src' ) ) ) ) {
				$node->removeChild( $child );
			}
		}
	}

	/**
	 * Whether an element holds block-level children.
	 *
	 * @param \DOMNode $node The element.
	 * @return bool
	 */
	private static function has_block_child( \DOMNode $node ): bool {
		foreach ( $node->childNodes as $child ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
			if ( XML_ELEMENT_NODE === $child->nodeType && in_array( strtolower( $child->nodeName ), array_merge( self::BLOCK_TAGS, [ 'div', 'section', 'li' ] ), true ) ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
				return true;
			}
		}
		return false;
	}

	/**
	 * Swap an element for one with another tag, keeping its children.
	 *
	 * @param \DOMElement  $node The element.
	 * @param string       $tag  The new tag.
	 * @param \DOMDocument $dom  Its document.
	 * @return \DOMElement The new element.
	 */
	private static function replace_tag( \DOMElement $node, string $tag, \DOMDocument $dom ): \DOMElement {
		$new = $dom->createElement( $tag );
		while ( $node->firstChild ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
			$new->appendChild( $node->firstChild ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
		}
		foreach ( iterator_to_array( $node->attributes ) as $attr ) {
			$new->setAttribute( $attr->name, $attr->value );
		}
		$node->parentNode->replaceChild( $new, $node ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
		return $new;
	}

	/**
	 * Parse an HTML fragment as UTF-8.
	 *
	 * @param string $html The fragment.
	 * @return \DOMDocument|null
	 */
	private static function load( string $html ): ?\DOMDocument {
		if ( '' === trim( $html ) || ! class_exists( 'DOMDocument' ) ) {
			return null;
		}
		$dom      = new \DOMDocument();
		$previous = libxml_use_internal_errors( true );
		$dom->loadHTML( '<?xml encoding="utf-8"?><html><body>' . $html . '</body></html>', LIBXML_NONET | LIBXML_NOWARNING | LIBXML_NOERROR );
		libxml_clear_errors();
		libxml_use_internal_errors( $previous );
		return $dom;
	}

	/**
	 * An element's inner HTML.
	 *
	 * @param \DOMNode $node The element.
	 * @return string
	 */
	private static function inner( \DOMNode $node ): string {
		$html = '';
		foreach ( $node->childNodes as $child ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
			$html .= $node->ownerDocument->saveHTML( $child ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM.
		}
		return $html;
	}

	/**
	 * Tags out, entities decoded: plain text, for emptiness checks.
	 *
	 * @param string $html HTML.
	 * @return string
	 */
	private static function plain( string $html ): string {
		return html_entity_decode( (string) preg_replace( '#<[^>]*>#', '', $html ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	}

	/**
	 * HTML-escape text or an attribute value.
	 *
	 * @param string $text The text.
	 * @return string
	 */
	private static function esc( string $text ): string {
		return htmlspecialchars( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	}
}
