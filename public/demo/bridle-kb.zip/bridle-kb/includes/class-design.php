<?php

/**
 * Design Settings — Templates and Brand Colors.
 *
 * @package BridleKB
 */

namespace BridleKB;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Design
 */
class Design {

	/**
	 * The help center's accent when none is chosen: Bridle's blue ink.
	 */
	const DEFAULT_PRIMARY = '#2d6fcd';

	/**
	 * Accents the plugin shipped as its default before; they mean "unset".
	 */
	const OLD_DEFAULT_PRIMARIES = [ '#2563eb', '#1bbb81' ];

	/**
	 * Get available template options per section.
	 *
	 * @return array
	 */
	public static function get_templates() {
		return [
			'archive'  => [
				'default' => [
					'label' => __( 'Default', 'bridle-kb' ),
					'desc'  => __( 'Hero search + category grid', 'bridle-kb' ),
				],
				'minimal' => [
					'label' => __( 'Minimal', 'bridle-kb' ),
					'desc'  => __( 'Compact search, simple list', 'bridle-kb' ),
				],
				'card'    => [
					'label' => __( 'Card', 'bridle-kb' ),
					'desc'  => __( 'Featured cards with more visual emphasis', 'bridle-kb' ),
				],
			],
			'single'   => [
				'default'      => [
					'label' => __( 'Default', 'bridle-kb' ),
					'desc'  => __( 'TOC sidebar right', 'bridle-kb' ),
				],
				'minimal'      => [
					'label' => __( 'Minimal', 'bridle-kb' ),
					'desc'  => __( 'Content-focused, minimal chrome', 'bridle-kb' ),
				],
				'sidebar-left' => [
					'label' => __( 'Sidebar left', 'bridle-kb' ),
					'desc'  => __( 'TOC on the left', 'bridle-kb' ),
				],
			],
			'taxonomy' => [
				'default' => [
					'label' => __( 'Default', 'bridle-kb' ),
					'desc'  => __( 'Full category view', 'bridle-kb' ),
				],
				'minimal' => [
					'label' => __( 'Minimal', 'bridle-kb' ),
					'desc'  => __( 'Compact layout', 'bridle-kb' ),
				],
				'compact' => [
					'label' => __( 'Compact', 'bridle-kb' ),
					'desc'  => __( 'Dense list view', 'bridle-kb' ),
				],
			],
		];
	}

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'wp_head', [ $this, 'output_brand_styles' ], 5 );
		add_filter( 'body_class', [ $this, 'add_body_classes' ] );
	}

	/**
	 * Get design settings.
	 *
	 * @return array
	 */
	public static function get_settings() {
		$d = get_option( 'bridle_kb_design', [] );

		$primary = ( $d['primary_color'] ?? '' ) ?: self::DEFAULT_PRIMARY;
		// Colours the plugin used to ship as the default read as no choice,
		// so those sites take Bridle's blue.
		if ( in_array( strtolower( $primary ), self::OLD_DEFAULT_PRIMARIES, true ) ) {
			$primary = self::DEFAULT_PRIMARY;
		}
		$spacing_top  = max( 0, min( 400, (int) ( $d['spacing_top'] ?? 0 ) ) );
		$container    = $d['container_width'] ?? 'default';
		$container    = in_array( $container, [ 'narrow', 'default', 'wide', 'full' ], true ) ? $container : 'default';
		$toc_position = $d['toc_position'] ?? 'right';
		$toc_position = in_array( $toc_position, [ 'left', 'right' ], true ) ? $toc_position : 'right';

		return [
			'template_archive'   => $d['template_archive'] ?? 'default',
			'template_single'    => $d['template_single'] ?? 'default',
			'template_taxonomy'  => $d['template_taxonomy'] ?? 'default',
			'spacing_top'        => $spacing_top,
			'container_width'    => $container,
			'sidebar_visible'    => (bool) ( $d['sidebar_visible'] ?? true ),
			'sidebar_search'     => (bool) ( $d['sidebar_search'] ?? false ),
			'toc_visible'        => (bool) ( $d['toc_visible'] ?? true ),
			'toc_position'       => $toc_position,
			'breadcrumb_visible' => (bool) ( $d['breadcrumb_visible'] ?? true ),
			'bg_color'           => ( $d['bg_color'] ?? '' ) ?: '',
			'card_bg_color'      => ( $d['card_bg_color'] ?? '' ) ?: '',
			'hero_bg_color'      => ( $d['hero_bg_color'] ?? '' ) ?: '',
			'primary_color'      => $primary,
			'accent_color'       => ( $d['accent_color'] ?? '' ) ?: '',
			'text_color'         => ( $d['text_color'] ?? '' ) ?: '',
			'heading_color'      => ( $d['heading_color'] ?? '' ) ?: '',
			'muted_color'        => ( $d['muted_color'] ?? '' ) ?: '',
			'brand_color'        => $primary,
			'color_mode'         => $d['color_mode'] ?? 'brand',
		];
	}

	/**
	 * Get template slug for current context.
	 *
	 * @return array [ 'archive' => 'default', 'single' => 'default', 'taxonomy' => 'default' ]
	 */
	public static function get_current_templates() {
		$settings = self::get_settings();
		$ctx      = [
			'archive'  => $settings['template_archive'],
			'single'   => $settings['template_single'],
			'taxonomy' => $settings['template_taxonomy'],
		];

		// Per-doc template override (from publish panel).
		if ( is_singular( 'docs' ) ) {
			$post_id      = get_queried_object_id();
			$doc_template = $post_id ? get_post_meta( $post_id, '_bridle_kb_template', true ) : '';
			if ( $doc_template && self::validate_template( 'single', $doc_template ) === $doc_template ) {
				$ctx['single'] = $doc_template;
			}
		}

		if ( is_post_type_archive( 'docs' ) ) {
			return [
				'archive'  => $ctx['archive'],
				'single'   => $ctx['single'],
				'taxonomy' => $ctx['taxonomy'],
			];
		}
		if ( is_singular( 'docs' ) ) {
			return $ctx;
		}
		if ( is_tax( 'docs_category' ) ) {
			return $ctx;
		}

		return $ctx;
	}

	/**
	 * Get data attributes for bridle-kb wrapper.
	 *
	 * @return string
	 */
	public static function get_wrapper_attrs() {
		$t  = self::get_current_templates();
		$s  = self::get_settings();
		$r  = 'data-template-archive="' . esc_attr( $t['archive'] ) . '"';
		$r .= ' data-template-single="' . esc_attr( $t['single'] ) . '"';
		$r .= ' data-template-taxonomy="' . esc_attr( $t['taxonomy'] ) . '"';
		$r .= ' data-color-mode="' . esc_attr( $s['color_mode'] ) . '"';
		$r .= ' data-container-width="' . esc_attr( $s['container_width'] ) . '"';
		$r .= ' data-sidebar-visible="' . ( $s['sidebar_visible'] ? '1' : '0' ) . '"';
		$r .= ' data-sidebar-search="' . ( $s['sidebar_search'] ? '1' : '0' ) . '"';
		$r .= ' data-toc-visible="' . ( $s['toc_visible'] ? '1' : '0' ) . '"';
		$r .= ' data-toc-position="' . esc_attr( $s['toc_position'] ) . '"';
		$r .= ' data-breadcrumb-visible="' . ( $s['breadcrumb_visible'] ? '1' : '0' ) . '"';
		$r .= ' data-spacing-top="' . esc_attr( (string) $s['spacing_top'] ) . '"';
		if ( is_singular( 'docs' ) ) {
			$r .= ' data-current-doc-id="' . esc_attr( (string) get_queried_object_id() ) . '"';
		}
		return $r;
	}

	/**
	 * Add body classes for design.
	 *
	 * @param array $classes Body classes.
	 * @return array
	 */
	public function add_body_classes( $classes ) {
		if ( ! is_post_type_archive( 'docs' ) && ! is_singular( 'docs' ) && ! is_tax( 'docs_category' ) ) {
			return $classes;
		}
		$t = self::get_current_templates();
		if ( is_post_type_archive( 'docs' ) ) {
			$classes[] = 'bridle-kb-archive-' . sanitize_html_class( $t['archive'] );
		}
		if ( is_singular( 'docs' ) ) {
			$classes[] = 'bridle-kb-single-' . sanitize_html_class( $t['single'] );
		}
		if ( is_tax( 'docs_category' ) ) {
			$classes[] = 'bridle-kb-taxonomy-' . sanitize_html_class( $t['taxonomy'] );
		}
		return $classes;
	}

	/**
	 * Output brand color CSS variables in head.
	 */
	public function output_brand_styles() {
		if ( ! is_post_type_archive( 'docs' ) && ! is_singular( 'docs' ) && ! is_tax( 'docs_category' ) ) {
			return;
		}

		$s            = self::get_settings();
		$primary      = sanitize_hex_color( $s['primary_color'] ) ?: self::DEFAULT_PRIMARY;
		$primary_rgb  = self::hex_to_rgb( $primary );
		$primary_dark = self::adjust_brightness( $primary, -15 );

		$accent  = ! empty( $s['accent_color'] ) ? ( sanitize_hex_color( $s['accent_color'] ) ?: '' ) : $primary;
		$text    = ! empty( $s['text_color'] ) ? ( sanitize_hex_color( $s['text_color'] ) ?: '' ) : '';
		$heading = ! empty( $s['heading_color'] ) ? ( sanitize_hex_color( $s['heading_color'] ) ?: '' ) : '';
		$muted   = ! empty( $s['muted_color'] ) ? ( sanitize_hex_color( $s['muted_color'] ) ?: '' ) : '';

		if ( 'neutral' === $s['color_mode'] ) {
			$primary      = '#4b5563';
			$primary_dark = '#374151';
			$accent       = '#4b5563';
		}

		if ( 'theme' === $s['color_mode'] ) {
			$theme_color = apply_filters( 'bridle_kb_theme_primary_color', '' );
			if ( $theme_color ) {
				$primary      = sanitize_hex_color( $theme_color ) ?: $primary;
				$primary_dark = self::adjust_brightness( $primary, -15 );
				$accent       = $primary;
			} else {
				$primary      = '#4b5563';
				$primary_dark = '#374151';
				$accent       = '#4b5563';
			}
		}

		$vars = [
			'--bridle-kb-primary'      => $primary,
			'--bridle-kb-primary-dark' => $primary_dark,
			'--bridle-kb-primary-rgb'  => implode( ', ', $primary_rgb ),
			'--bridle-kb-accent'       => $accent,
		];
		if ( $text ) {
			$vars['--bridle-kb-text'] = $text;
		}
		if ( $heading ) {
			$vars['--bridle-kb-heading'] = $heading;
		}
		if ( $muted ) {
			$vars['--bridle-kb-muted'] = $muted;
		}
		$bg = ! empty( $s['bg_color'] ) ? ( sanitize_hex_color( $s['bg_color'] ) ?: '' ) : '';
		if ( $bg ) {
			$vars['--bridle-kb-bg'] = $bg;
		}
		$card_bg = ! empty( $s['card_bg_color'] ) ? ( sanitize_hex_color( $s['card_bg_color'] ) ?: '' ) : '';
		if ( $card_bg ) {
			$vars['--bridle-kb-card-bg'] = $card_bg;
		}
		$hero_bg = ! empty( $s['hero_bg_color'] ) ? ( sanitize_hex_color( $s['hero_bg_color'] ) ?: '' ) : '';
		if ( $hero_bg ) {
			$vars['--bridle-kb-hero-bg'] = $hero_bg;
		}
		$spacing_top                    = max( 0, min( 400, (int) ( $s['spacing_top'] ?? 0 ) ) );
		$vars['--bridle-kb-spacing-top'] = $spacing_top . 'px';

		// 76rem by default, so the help center sits inside a theme's usual
		// content frame instead of running past it.
		$container_map                           = [
			'narrow'  => '64rem',
			'default' => '76rem',
			'wide'    => '90rem',
			'full'    => '100%',
		];
		$container                               = $s['container_width'] ?? 'default';
		$vars['--bridle-kb-container-max-width'] = $container_map[ $container ] ?? '76rem';

		$decls = array_map(
			function ( $k, $v ) {
				return $k . ': ' . esc_attr( $v );
			},
			array_keys( $vars ),
			$vars
		);
		$css   = ':root { ' . implode( '; ', $decls ) . '; }';
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSS values are esc_attr'd above
		printf( "<style id=\"bridle-kb-brand\">\n%s\n</style>\n", $css );
	}

	/**
	 * Convert hex to RGB array.
	 *
	 * @param string $hex Hex color.
	 * @return array [r, g, b]
	 */
	private static function hex_to_rgb( $hex ) {
		$hex = ltrim( $hex, '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		if ( 6 !== strlen( $hex ) ) {
			return [ 45, 111, 205 ];
		}
		return [
			hexdec( substr( $hex, 0, 2 ) ),
			hexdec( substr( $hex, 2, 2 ) ),
			hexdec( substr( $hex, 4, 2 ) ),
		];
	}

	/**
	 * Adjust brightness of hex color.
	 *
	 * @param string $hex   Hex color.
	 * @param int    $steps Amount to adjust (-255 to 255).
	 * @return string Hex color.
	 */
	private static function adjust_brightness( $hex, $steps ) {
		$rgb = self::hex_to_rgb( $hex );
		foreach ( $rgb as $i => $v ) {
			$rgb[ $i ] = max( 0, min( 255, $v + $steps ) );
		}
		return '#' . sprintf( '%02x%02x%02x', $rgb[0], $rgb[1], $rgb[2] );
	}

	/**
	 * Validate template slug.
	 *
	 * @param string $section archive|single|taxonomy.
	 * @param string $slug    Template slug.
	 * @return string Valid slug.
	 */
	public static function validate_template( $section, $slug ) {
		$templates = self::get_templates();
		$allowed   = array_keys( $templates[ $section ] ?? [] );
		return in_array( $slug, $allowed, true ) ? $slug : 'default';
	}
}
