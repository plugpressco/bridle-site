<?php

/**
 * REST API Endpoints.
 *
 * @package BridleKB
 */

namespace BridleKB;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class REST
 */
class REST {


	/**
	 * REST namespace.
	 *
	 * @var string
	 */
	const NAMESPACE = 'bridle-kb/v1';

	/**
	 * The most articles one bulk request may change.
	 */
	const BULK_MAX = 200;

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	/**
	 * Register REST API routes.
	 */
	public function register_routes() {
		register_rest_route(
			self::NAMESPACE,
			'/stats',
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'get_stats' ],
				'permission_callback' => [ $this, 'check_admin_permissions' ],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/search',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'search_articles' ],
				'permission_callback' => '__return_true',
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/categories',
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'get_categories' ],
				'permission_callback' => '__return_true',
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/articles',
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'get_articles' ],
				'permission_callback' => '__return_true',
			]
		);

		// The Docs page's bulk actions. Anyone who can write posts may call it;
		// each article is then checked on its own (bulk_permission_for()), so
		// an author can only trash, publish or move what they could one by one.
		register_rest_route(
			self::NAMESPACE,
			'/articles/bulk',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'bulk_articles' ],
				'permission_callback' => static function () {
					return current_user_can( 'edit_posts' );
				},
				'args'                => [
					'ids'    => [
						'type'     => 'array',
						'items'    => [ 'type' => 'integer' ],
						'required' => true,
						'minItems' => 1,
						'maxItems' => self::BULK_MAX,
					],
					'action' => [
						'type'     => 'string',
						'enum'     => [ 'trash', 'restore', 'delete', 'publish', 'draft', 'category' ],
						'required' => true,
					],
					'term'   => [
						'type'    => 'integer',
						'minimum' => 0,
					],
					// Restore to the status each article had before the
					// trash (Undo), rather than to draft (core's default).
					'undo'   => [
						'type'    => 'boolean',
						'default' => false,
					],
				],
			]
		);
	}

	/**
	 * Check admin permissions.
	 *
	 * @return bool
	 */
	public function check_admin_permissions() {
		if ( ! is_user_logged_in() || ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		$nonce = isset( $_SERVER['HTTP_X_WP_NONCE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_WP_NONCE'] ) ) : '';

		return wp_verify_nonce( $nonce, 'wp_rest' );
	}

	/**
	 * Get stats.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response
	 */
	public function get_stats( $request ) {
		$post_counts = wp_count_posts( 'docs' );

		return rest_ensure_response(
			[
				'total_articles'   => isset( $post_counts->publish ) ? (int) $post_counts->publish : 0,
				'draft_articles'   => isset( $post_counts->draft ) ? (int) $post_counts->draft : 0,
				'total_categories' => (int) wp_count_terms(
					[
						'taxonomy'   => 'docs_category',
						'hide_empty' => false,
					]
				),
			]
		);
	}

	/**
	 * Search articles.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return array|\WP_Error
	 */
	public function search_articles( $request ) {
		$params = $request->get_json_params();
		$query  = sanitize_text_field( $params['query'] ?? '' );
		$limit  = min( 20, max( 1, (int) ( $params['limit'] ?? 10 ) ) );

		if ( empty( $query ) ) {
			return new \WP_Error( 'empty_query', __( 'Search query is required', 'bridle-kb' ), [ 'status' => 400 ] );
		}

		$posts = get_posts(
			[
				'post_type'      => 'docs',
				'post_status'    => 'publish',
				'posts_per_page' => $limit,
				's'              => $query,
				'meta_query'     => [
					'relation' => 'OR',
					[
						'key'     => '_bridle_kb_searchable',
						'value'   => '1',
						'compare' => '=',
					],
					[
						'key'     => '_bridle_kb_searchable',
						'compare' => 'NOT EXISTS',
					],
				],
			]
		);

		$results = [];

		foreach ( $posts as $post ) {
			$categories = get_the_terms( $post->ID, 'docs_category' );
			$category   = ( $categories && ! is_wp_error( $categories ) ) ? $categories[0]->name : '';

			$results[] = [
				'id'       => $post->ID,
				'title'    => $post->post_title,
				'url'      => get_permalink( $post->ID ),
				'excerpt'  => wp_trim_words( $post->post_content, 20 ),
				'category' => $category,
				'date'     => get_the_date( 'M j, Y', $post->ID ),
			];
		}

		return [
			'success' => true,
			'results' => $results,
			'total'   => count( $results ),
		];
	}

	/**
	 * Get categories.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return array|\WP_Error
	 */
	public function get_categories( $request ) {
		$categories = get_terms(
			[
				'taxonomy'   => 'docs_category',
				'hide_empty' => false,
				'orderby'    => 'name',
				'order'      => 'ASC',
			]
		);

		if ( is_wp_error( $categories ) ) {
			return new \WP_Error( 'categories_error', 'Failed to fetch categories', [ 'status' => 500 ] );
		}

		$results = [];

		foreach ( $categories as $category ) {
			$article_ids = get_posts(
				[
					'post_type'      => 'docs',
					'posts_per_page' => -1,
					'tax_query'      => [
						[
							'taxonomy' => 'docs_category',
							'field'    => 'term_id',
							'terms'    => $category->term_id,
						],
					],
					'fields'         => 'ids',
				]
			);

			$recent = get_posts(
				[
					'post_type'      => 'docs',
					'posts_per_page' => 3,
					'tax_query'      => [
						[
							'taxonomy' => 'docs_category',
							'field'    => 'term_id',
							'terms'    => $category->term_id,
						],
					],
				]
			);

			$articles = [];

			foreach ( $recent as $article ) {
				$articles[] = [
					'id'      => $article->ID,
					'title'   => $article->post_title,
					'url'     => get_permalink( $article->ID ),
					'excerpt' => wp_trim_words( $article->post_content, 15 ),
					'date'    => get_the_date( 'M j, Y', $article->ID ),
				];
			}

			$icon_id = (int) get_term_meta( $category->term_id, 'category_icon', true );

			$results[] = [
				'id'            => $category->term_id,
				'name'          => $category->name,
				'slug'          => $category->slug,
				'description'   => $category->description,
				'url'           => get_term_link( $category ),
				'parent'        => (int) $category->parent,
				'icon_url'      => $icon_id ? (string) wp_get_attachment_url( $icon_id ) : '',
				'color'         => (string) sanitize_hex_color( (string) get_term_meta( $category->term_id, 'category_color', true ) ),
				'article_count' => count( $article_ids ),
				'articles'      => $articles,
				'count'         => $category->count,
			];
		}

		return [
			'success'    => true,
			'categories' => $results,
			'total'      => count( $results ),
		];
	}

	/**
	 * Get articles (supports pagination for sidebar load-more).
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return array
	 */
	public function get_articles( $request ) {
		$params          = $request->get_params();
		$category_id     = isset( $params['category_id'] ) ? (int) $params['category_id'] : null;
		$per_page        = isset( $params['per_page'] ) ? max( 1, min( 50, (int) $params['per_page'] ) ) : 15;
		$offset          = isset( $params['offset'] ) ? max( 0, (int) $params['offset'] ) : 0;
		$order           = isset( $params['order'] ) && 'desc' === strtolower( $params['order'] ) ? 'DESC' : 'ASC';
		$allowed_orderby = [ 'title', 'date', 'menu_order', 'menu_order title', 'modified', 'rand' ];
		$orderby         = ( isset( $params['orderby'] ) && in_array( $params['orderby'], $allowed_orderby, true ) )
			? $params['orderby'] : 'menu_order title';

		$args = [
			'post_type'      => 'docs',
			'posts_per_page' => $per_page,
			'offset'         => $offset,
			'post_status'    => 'publish',
			'orderby'        => $orderby,
			'order'          => $order,
		];

		if ( $category_id ) {
			$args['tax_query'] = [
				[
					'taxonomy' => 'docs_category',
					'field'    => 'term_id',
					'terms'    => $category_id,
				],
			];
		}

		$query   = new \WP_Query( $args );
		$posts   = $query->posts;
		$total   = (int) $query->found_posts;
		$results = [];

		foreach ( $posts as $post ) {
			$categories    = get_the_terms( $post->ID, 'docs_category' );
			$category_name = ( $categories && ! is_wp_error( $categories ) ) ? $categories[0]->name : '';

			$results[] = [
				'id'       => $post->ID,
				'title'    => $post->post_title,
				'url'      => get_permalink( $post->ID ),
				'excerpt'  => wp_trim_words( $post->post_content, 20 ),
				'category' => $category_name,
				'date'     => get_the_date( 'M j, Y', $post->ID ),
			];
		}

		$has_more = ( $offset + count( $results ) ) < $total;

		return [
			'success'     => true,
			'articles'    => $results,
			'total'       => $total,
			'has_more'    => $has_more,
			'next_offset' => $offset + count( $results ),
		];
	}

	/**
	 * Bulk actions from the Docs page: trash, restore, delete for good,
	 * publish, move to draft, or move to one category.
	 *
	 * Restore goes through wp_untrash_post(), which also gives a trashed
	 * article its slug back (a REST status update would leave `__trashed`).
	 * Articles the user may not change, or that are not docs, land in
	 * `failed` and the rest go ahead. `items` are the changed articles as
	 * the page lists them; it counts the tabs from those itself.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function bulk_articles( $request ) {
		$action = $request['action'];
		$ids    = array_values( array_unique( array_map( 'absint', (array) $request['ids'] ) ) );
		$term   = absint( $request['term'] );
		$undo   = 'restore' === $action && ! empty( $request['undo'] );

		if ( $undo ) {
			add_filter( 'wp_untrash_post_status', 'wp_untrash_post_set_previous_status', 10, 3 );
		}

		if ( 'category' === $action ) {
			$found = $term ? get_term( $term, 'docs_category' ) : null;
			if ( ! $found || is_wp_error( $found ) ) {
				return new \WP_Error( 'bridle_kb_bad_category', __( 'That category no longer exists.', 'bridle-kb' ), [ 'status' => 400 ] );
			}
		}

		$done   = [];
		$failed = [];
		$items  = [];

		foreach ( $ids as $id ) {
			$post = get_post( $id );

			if ( ! $post || 'docs' !== $post->post_type ) {
				$failed[] = [
					'id'      => $id,
					'message' => __( 'Not found.', 'bridle-kb' ),
				];
				continue;
			}
			if ( ! $this->bulk_permission_for( $action, $post ) ) {
				$failed[] = [
					'id'      => $id,
					'message' => __( 'You are not allowed to change this article.', 'bridle-kb' ),
				];
				continue;
			}

			$ok = $this->bulk_apply( $action, $post, $term );

			if ( ! $ok ) {
				$failed[] = [
					'id'      => $id,
					'message' => __( 'It could not be changed.', 'bridle-kb' ),
				];
				continue;
			}

			$done[] = $id;
			if ( 'delete' !== $action ) {
				$items[] = self::article_row( get_post( $id ) );
			}
		}

		if ( $undo ) {
			remove_filter( 'wp_untrash_post_status', 'wp_untrash_post_set_previous_status', 10 );
		}

		return rest_ensure_response(
			[
				'done'   => $done,
				'failed' => $failed,
				'items'  => $items,
			]
		);
	}

	/**
	 * Whether the current user may apply a bulk action to one article.
	 *
	 * @param string   $action The bulk action.
	 * @param \WP_Post $post   The article.
	 * @return bool
	 */
	private function bulk_permission_for( $action, $post ) {
		switch ( $action ) {
			case 'trash':
			case 'restore':
			case 'delete':
				return current_user_can( 'delete_post', $post->ID );
			case 'publish':
				return current_user_can( 'edit_post', $post->ID ) && current_user_can( 'publish_post', $post->ID );
			case 'category':
				$taxonomy = get_taxonomy( 'docs_category' );
				return current_user_can( 'edit_post', $post->ID ) && $taxonomy && current_user_can( $taxonomy->cap->assign_terms );
			default:
				return current_user_can( 'edit_post', $post->ID );
		}
	}

	/**
	 * Apply one bulk action to one article.
	 *
	 * @param string   $action The bulk action.
	 * @param \WP_Post $post   The article.
	 * @param int      $term   The category, for `category`.
	 * @return bool Whether it changed.
	 */
	private function bulk_apply( $action, $post, $term ) {
		switch ( $action ) {
			case 'trash':
				return 'trash' === $post->post_status || (bool) wp_trash_post( $post->ID );
			case 'restore':
				return 'trash' !== $post->post_status || (bool) wp_untrash_post( $post->ID );
			case 'delete':
				return (bool) wp_delete_post( $post->ID, true );
			case 'publish':
				if ( 'trash' === $post->post_status ) {
					return false;
				}
				// A future date keeps it scheduled, as the editor's Publish does.
				$status = strtotime( $post->post_date_gmt ) > time() && '0000-00-00 00:00:00' !== $post->post_date_gmt ? 'future' : 'publish';
				$result = wp_update_post(
					[
						'ID'          => $post->ID,
						'post_status' => $status,
					],
					true
				);
				return ! is_wp_error( $result );
			case 'draft':
				if ( 'trash' === $post->post_status ) {
					return false;
				}
				$result = wp_update_post(
					[
						'ID'          => $post->ID,
						'post_status' => 'draft',
					],
					true
				);
				return ! is_wp_error( $result );
			case 'category':
				return ! is_wp_error( wp_set_object_terms( $post->ID, [ $term ], 'docs_category' ) );
		}
		return false;
	}

	/**
	 * One article in the shape the Docs page reads from wp/v2/docs (the
	 * fields it asks for with `_fields`), so a bulk reply can replace rows.
	 *
	 * @param \WP_Post $post The article.
	 * @return array
	 */
	public static function article_row( $post ) {
		$terms = wp_get_object_terms( $post->ID, 'docs_category', [ 'fields' => 'ids' ] );

		return [
			'id'            => $post->ID,
			'title'         => [
				'raw'      => $post->post_title,
				'rendered' => get_the_title( $post ),
			],
			'status'        => $post->post_status,
			'modified_gmt'  => mysql_to_rfc3339( $post->post_modified_gmt ),
			'link'          => get_permalink( $post ),
			'docs_category' => is_wp_error( $terms ) ? [] : array_map( 'intval', $terms ),
			'author'        => (int) $post->post_author,
			'parent'        => (int) $post->post_parent,
			'menu_order'    => (int) $post->menu_order,
		];
	}

	/**
	 * The Docs page's tab counts: all (everything not trashed), published,
	 * drafts (with pending review) and trash.
	 *
	 * @return array
	 */
	public static function tab_counts() {
		$counts = wp_count_posts( 'docs', 'readable' );
		$count  = static function ( $status ) use ( $counts ) {
			return isset( $counts->$status ) ? (int) $counts->$status : 0;
		};

		return [
			'all'     => $count( 'publish' ) + $count( 'future' ) + $count( 'draft' ) + $count( 'pending' ) + $count( 'private' ),
			'publish' => $count( 'publish' ),
			'drafts'  => $count( 'draft' ) + $count( 'pending' ),
			'trash'   => $count( 'trash' ),
		];
	}
}
