<?php

/**
 * Template Loader.
 *
 * WooCommerce-style template override: theme bridle-kb/ folder → plugin templates/ folder.
 *
 * @package BridleKB
 */

namespace BridleKB;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Templates
 *
 * The help center, laid out like a Mintlify docs site: a grouped navigation
 * on the left, the article in the middle, "On this page" on the right, and a
 * home of category cards under one search.
 */
class Templates {

	/**
	 * Cache group for the navigation.
	 */
	const CACHE_GROUP = 'bridle_kb';

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_filter( 'template_include', [ $this, 'template_loader' ] );
		add_action( 'pre_get_posts', [ $this, 'archive_only_categorized_docs' ] );
		add_action( 'pre_get_posts', [ $this, 'apply_articles_per_page' ] );
	}

	/**
	 * Category pages: the articles_per_page setting, and the navigation's
	 * order (menu order, then title) unless the URL asks for another.
	 *
	 * @param \WP_Query $query The query object.
	 */
	public function apply_articles_per_page( $query ) {
		if ( is_admin() || ! $query->is_main_query() || ! $query->is_tax( 'docs_category' ) ) {
			return;
		}
		$per_page = (int) bridle_kb_get_option( 'articles_per_page', 12 );
		if ( $per_page > 0 ) {
			$query->set( 'posts_per_page', $per_page );
		}
		if ( ! $query->get( 'orderby' ) ) {
			$query->set(
				'orderby',
				[
					'menu_order' => 'ASC',
					'title'      => 'ASC',
				]
			);
		}
	}

	/**
	 * On the docs archive, only list articles that have a category. A search
	 * there also skips articles marked as not searchable, the way the live
	 * search does.
	 *
	 * @param \WP_Query $query The query object.
	 */
	public function archive_only_categorized_docs( $query ) {
		if ( is_admin() || ! $query->is_main_query() ) {
			return;
		}
		if ( ! $query->is_post_type_archive( 'docs' ) || $query->is_tax( 'docs_category' ) ) {
			return;
		}
		$query->set(
			'tax_query',
			[
				[
					'taxonomy' => 'docs_category',
					'operator' => 'EXISTS',
				],
			]
		);
		if ( $query->is_search() ) {
			$query->set( 'meta_query', self::searchable_meta_query() );
		}
	}

	/**
	 * The meta query that keeps articles marked as not searchable out of search.
	 *
	 * @return array
	 */
	public static function searchable_meta_query() {
		return [
			'relation' => 'OR',
			[
				'key'     => '_bridle_kb_searchable',
				'value'   => '1',
				'compare' => '=',
			],
			[
				'key'     => '_bridle_kb_searchable',
				'compare' => 'NOT EXISTS',
			],
		];
	}

	/**
	 * Load the appropriate template for docs pages.
	 *
	 * For block themes (FSE) on WordPress 6.7+, uses locate_block_template so
	 * our registered block templates appear in the Site Editor and are used.
	 * For classic themes, uses PHP templates.
	 *
	 * @param string $template Default template path.
	 * @return string
	 */
	public function template_loader( $template ) {
		$is_block_theme = function_exists( 'wp_is_block_theme' ) && wp_is_block_theme();
		$has_block_api  = function_exists( 'locate_block_template' );

		if ( $is_block_theme && $has_block_api ) {
			if ( is_post_type_archive( 'docs' ) ) {
				$templates = [ 'archive-docs.php', 'archive.php', 'index.php' ];
				$template  = locate_template( $templates );
				return locate_block_template( $template, 'archive-docs', $templates );
			}
			if ( is_singular( 'docs' ) ) {
				$templates = [ 'single-docs.php', 'single.php', 'singular.php', 'index.php' ];
				$template  = locate_template( $templates );
				return locate_block_template( $template, 'single-docs', $templates );
			}
			if ( is_tax( 'docs_category' ) ) {
				$templates = [ 'taxonomy-docs_category.php', 'taxonomy.php', 'archive.php', 'index.php' ];
				$template  = locate_template( $templates );
				return locate_block_template( $template, 'taxonomy-docs_category', $templates );
			}
		}

		// Classic theme: use PHP templates.
		if ( is_post_type_archive( 'docs' ) ) {
			$found = self::locate_template( 'archive-docs.php' );
			return $found ? $found : $template;
		}

		if ( is_singular( 'docs' ) ) {
			$found = self::locate_template( 'single-docs.php' );
			return $found ? $found : $template;
		}

		if ( is_tax( 'docs_category' ) ) {
			$found = self::locate_template( 'taxonomy-docs_category.php' );
			return $found ? $found : $template;
		}

		return $template;
	}

	/**
	 * Locate a template file.
	 *
	 * Checks: child theme bridle-kb/ → parent theme bridle-kb/ → plugin templates/.
	 *
	 * @param string $template_name Template file name.
	 * @return string|false Full path or false.
	 */
	public static function locate_template( $template_name ) {
		// Child theme.
		$theme_path = get_stylesheet_directory() . '/bridle-kb/' . $template_name;
		if ( file_exists( $theme_path ) ) {
			return $theme_path;
		}

		// Parent theme.
		$parent_path = get_template_directory() . '/bridle-kb/' . $template_name;
		if ( $parent_path !== $theme_path && file_exists( $parent_path ) ) {
			return $parent_path;
		}

		// Plugin fallback.
		$plugin_path = BRIDLE_KB_PATH . 'templates/' . $template_name;
		if ( file_exists( $plugin_path ) ) {
			return $plugin_path;
		}

		return false;
	}

	/**
	 * Render header for classic or block (FSE) themes.
	 *
	 * In block themes, outputs full document start including doctype, html, head,
	 * body, and block header part. In classic themes, calls get_header().
	 */
	public static function render_header() {
		if ( function_exists( 'wp_is_block_theme' ) && wp_is_block_theme() ) {
			?>
			<!DOCTYPE html>
			<html <?php language_attributes(); ?>>

			<head>
				<meta charset="<?php bloginfo( 'charset' ); ?>" />
				<meta name="viewport" content="width=device-width, initial-scale=1" />
				<?php wp_head(); ?>
			</head>

			<body <?php body_class(); ?>>
				<?php wp_body_open(); ?>
				<?php block_template_part( 'header' ); ?>
			<?php
		} else {
			get_header();
		}
	}

	/**
	 * Render footer for classic or block (FSE) themes.
	 *
	 * In block themes, outputs block footer part, stored styles, wp_footer, and
	 * closes body/html. In classic themes, calls get_footer().
	 */
	public static function render_footer() {
		if ( function_exists( 'wp_is_block_theme' ) && wp_is_block_theme() ) {
			block_template_part( 'footer' );
			if ( function_exists( 'wp_enqueue_stored_styles' ) ) {
				wp_enqueue_stored_styles();
			}
			wp_footer();
			?>
			</body>

			</html>
			<?php
		} else {
			get_footer();
		}
	}

	/**
	 * Render single-docs body content (without header/footer).
	 * Used by both PHP template and block template shortcode.
	 */
	public static function render_single_docs_content() {
		if ( ! have_posts() ) {
			return;
		}
		the_post();

		$post_id   = get_the_ID();
		$category  = self::primary_category( $post_id );
		$templates = Design::get_current_templates();
		$show_nav  = 'minimal' !== $templates['single'] && bridle_kb_get_option( 'sidebar_visible', true );
		$nav       = $show_nav ? self::get_nav_data() : self::empty_nav();

		// The content runs first: the TOC reads its headings from the_content.
		ob_start();
		the_content();
		$content = ob_get_clean();

		$has_toc = 'minimal' !== $templates['single'] && TOC::has_toc() && bridle_kb_get_option( 'toc_visible', true );
		$classes = [ 'bridle-kb-shell' ];
		if ( $show_nav ) {
			$classes[] = 'has-nav';
		}
		if ( $has_toc ) {
			$classes[] = 'has-toc';
		}
		?>
		<div class="bridle-kb bridle-kb-page-single" <?php echo Design::get_wrapper_attrs(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Each attribute value is escaped via esc_attr() inside get_wrapper_attrs(). ?>>
			<div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>">
				<?php
				if ( $show_nav ) {
					self::render_nav( $nav, $post_id, $category ? (int) $category->term_id : 0, $category ? $category->name : '' );
				}
				?>
				<div class="bridle-kb-main">
					<article class="bridle-kb-article">
						<header class="bridle-kb-article-header">
							<?php if ( $category && bridle_kb_get_option( 'breadcrumb_visible', true ) ) : ?>
								<?php $category_link = get_term_link( $category ); ?>
								<p class="bridle-kb-eyebrow">
									<?php if ( is_wp_error( $category_link ) ) : ?>
										<?php echo esc_html( $category->name ); ?>
									<?php else : ?>
										<a href="<?php echo esc_url( $category_link ); ?>"><?php echo esc_html( $category->name ); ?></a>
									<?php endif; ?>
								</p>
							<?php endif; ?>
							<div class="bridle-kb-title-row">
								<h1 class="bridle-kb-title"><?php the_title(); ?></h1>
								<?php
								if ( apply_filters( 'bridle_kb_copy_page', true, $post_id ) ) {
									self::get_template_part( 'parts/copy-page', [ 'page_url' => get_permalink( $post_id ) ] );
								}
								?>
							</div>
							<?php if ( has_excerpt() ) : ?>
								<p class="bridle-kb-lead"><?php echo esc_html( get_the_excerpt() ); ?></p>
							<?php endif; ?>
						</header>

						<div class="bridle-kb-prose"><?php echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the_content() output, filtered by WordPress. ?></div>

						<footer class="bridle-kb-article-footer">
							<?php
							self::get_template_part(
								'parts/pager',
								self::neighbours( $nav['order'], $post_id )
							);
							?>
							<p class="bridle-kb-updated">
								<?php
								printf(
									/* translators: %s: the date the article was last changed */
									esc_html__( 'Last updated %s', 'bridle-kb' ),
									'<time datetime="' . esc_attr( get_the_modified_date( 'c' ) ) . '">' . esc_html( get_the_modified_date() ) . '</time>'
								);
								?>
							</p>
						</footer>
					</article>
				</div>
				<?php if ( $has_toc ) : ?>
					<aside class="bridle-kb-toc-col">
						<?php TOC::render(); ?>
					</aside>
				<?php endif; ?>
			</div>
		</div>
		<?php
		rewind_posts();
	}

	/**
	 * Render archive-docs body content (without header/footer): the help
	 * center's home, or the results of a search made from it.
	 */
	public static function render_archive_docs_content() {
		$title    = apply_filters( 'bridle_kb_archive_title', __( 'Docs', 'bridle-kb' ) );
		$subtitle = apply_filters( 'bridle_kb_archive_subtitle', __( 'Search for answers or browse by topic.', 'bridle-kb' ) );
		?>
		<div class="bridle-kb bridle-kb-page-home" <?php echo Design::get_wrapper_attrs(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Each attribute value is escaped via esc_attr() inside get_wrapper_attrs(). ?>>
			<div class="bridle-kb-home">
				<header class="bridle-kb-hero">
					<h1 class="bridle-kb-hero-title"><?php echo esc_html( $title ); ?></h1>
					<?php if ( $subtitle ) : ?>
						<p class="bridle-kb-hero-subtitle"><?php echo esc_html( $subtitle ); ?></p>
					<?php endif; ?>
					<?php self::get_template_part( 'parts/search-bar', [ 'value' => is_search() ? get_search_query( false ) : '' ] ); ?>
				</header>

				<?php
				if ( is_search() ) {
					self::render_search_results();
				} else {
					self::render_category_grid();
				}
				?>
			</div>
		</div>
		<?php
	}

	/**
	 * The home's category cards: top-level categories that hold articles,
	 * counted with their subcategories. Without categories, the latest
	 * articles instead.
	 */
	private static function render_category_grid() {
		$categories = [];
		$top_level  = get_terms(
			[
				'taxonomy'   => 'docs_category',
				'parent'     => 0,
				'hide_empty' => false,
				'orderby'    => 'name',
				'order'      => 'ASC',
			]
		);

		if ( ! empty( $top_level ) && ! is_wp_error( $top_level ) ) {
			foreach ( $top_level as $category ) {
				$count = self::count_category_articles( $category->term_id );
				if ( $count > 0 ) {
					$category->count = $count;
					$categories[]    = $category;
				}
			}
		}

		if ( $categories ) {
			?>
			<section class="bridle-kb-section" aria-label="<?php esc_attr_e( 'Topics', 'bridle-kb' ); ?>">
				<div class="bridle-kb-card-grid">
					<?php
					foreach ( $categories as $category ) {
						self::get_template_part( 'parts/category-card', [ 'category' => $category ] );
					}
					?>
				</div>
			</section>
			<?php
			return;
		}

		$latest = new \WP_Query(
			[
				'post_type'           => 'docs',
				'post_status'         => 'publish',
				'posts_per_page'      => 20,
				'orderby'             => [
					'menu_order' => 'ASC',
					'title'      => 'ASC',
				],
				'no_found_rows'       => true,
				'ignore_sticky_posts' => true,
			]
		);

		if ( ! $latest->have_posts() ) {
			?>
			<p class="bridle-kb-empty"><?php esc_html_e( 'No articles yet.', 'bridle-kb' ); ?></p>
			<?php
			return;
		}
		?>
		<section class="bridle-kb-section">
			<ul class="bridle-kb-rows">
				<?php
				while ( $latest->have_posts() ) {
					$latest->the_post();
					self::get_template_part( 'parts/article-row' );
				}
				wp_reset_postdata();
				?>
			</ul>
		</section>
		<?php
	}

	/**
	 * The results of a search on the docs archive (Enter in the search field,
	 * or the search with scripts off), from the main query.
	 */
	private static function render_search_results() {
		global $wp_query;

		$total = (int) $wp_query->found_posts;
		?>
		<section class="bridle-kb-section bridle-kb-results">
			<p class="bridle-kb-results-count">
				<?php
				printf(
					/* translators: 1: number of results, 2: the search terms */
					esc_html( _n( '%1$d result for “%2$s”', '%1$d results for “%2$s”', $total, 'bridle-kb' ) ),
					(int) $total,
					esc_html( get_search_query( false ) )
				);
				?>
			</p>
			<?php if ( have_posts() ) : ?>
				<ul class="bridle-kb-rows">
					<?php
					while ( have_posts() ) {
						the_post();
						self::get_template_part( 'parts/article-row', [ 'show_category' => true ] );
					}
					?>
				</ul>
				<?php self::render_pagination(); ?>
			<?php else : ?>
				<p class="bridle-kb-empty"><?php esc_html_e( 'Nothing matches. Try other words, or browse the topics.', 'bridle-kb' ); ?></p>
			<?php endif; ?>
		</section>
		<?php
	}

	/**
	 * Render taxonomy-docs_category body content (without header/footer): the
	 * same shell as an article, with the category's subcategories and articles.
	 */
	public static function render_taxonomy_docs_category_content() {
		global $wp_query;

		$term = get_queried_object();
		if ( ! $term instanceof \WP_Term ) {
			return;
		}

		$templates = Design::get_current_templates();
		$show_nav  = 'default' === $templates['taxonomy'] && bridle_kb_get_option( 'sidebar_visible', true );
		$nav       = $show_nav ? self::get_nav_data() : self::empty_nav();
		$parent    = $term->parent ? get_term( $term->parent, 'docs_category' ) : null;
		$subcats   = get_terms(
			[
				'taxonomy'   => 'docs_category',
				'parent'     => $term->term_id,
				'hide_empty' => false,
				'orderby'    => 'name',
				'order'      => 'ASC',
			]
		);
		$subcats   = is_wp_error( $subcats ) ? [] : $subcats;
		// The main query includes subcategories, so its total matches the
		// count on the home's card.
		$total = (int) $wp_query->found_posts;
		?>
		<div class="bridle-kb bridle-kb-page-category" <?php echo Design::get_wrapper_attrs(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Each attribute value is escaped via esc_attr() inside get_wrapper_attrs(). ?>>
			<div class="bridle-kb-shell<?php echo $show_nav ? ' has-nav' : ''; ?>">
				<?php
				if ( $show_nav ) {
					self::render_nav( $nav, 0, (int) $term->term_id, $term->name );
				}
				?>
				<div class="bridle-kb-main">
					<header class="bridle-kb-article-header">
						<?php if ( bridle_kb_get_option( 'breadcrumb_visible', true ) ) : ?>
							<p class="bridle-kb-eyebrow">
								<?php if ( $parent instanceof \WP_Term ) : ?>
									<a href="<?php echo esc_url( get_term_link( $parent ) ); ?>"><?php echo esc_html( $parent->name ); ?></a>
								<?php else : ?>
									<a href="<?php echo esc_url( get_post_type_archive_link( 'docs' ) ); ?>"><?php echo esc_html( Breadcrumbs::home_label() ); ?></a>
								<?php endif; ?>
							</p>
						<?php endif; ?>
						<h1 class="bridle-kb-title"><?php echo esc_html( $term->name ); ?></h1>
						<?php if ( $term->description ) : ?>
							<p class="bridle-kb-lead"><?php echo esc_html( $term->description ); ?></p>
						<?php endif; ?>
						<p class="bridle-kb-meta">
							<?php
							printf(
								/* translators: %d: number of articles */
								esc_html( _n( '%d article', '%d articles', $total, 'bridle-kb' ) ),
								(int) $total
							);
							?>
						</p>
					</header>

					<?php if ( $subcats ) : ?>
						<section class="bridle-kb-section" aria-label="<?php esc_attr_e( 'Subcategories', 'bridle-kb' ); ?>">
							<div class="bridle-kb-card-grid is-compact">
								<?php
								foreach ( $subcats as $subcat ) {
									$subcat->count = self::count_category_articles( $subcat->term_id );
									self::get_template_part(
										'parts/category-card',
										[
											'category' => $subcat,
											'compact'  => true,
										]
									);
								}
								?>
							</div>
						</section>
					<?php endif; ?>

					<?php if ( have_posts() ) : ?>
						<section class="bridle-kb-section" aria-label="<?php esc_attr_e( 'Articles', 'bridle-kb' ); ?>">
							<ul class="bridle-kb-rows">
								<?php
								while ( have_posts() ) {
									the_post();
									self::get_template_part( 'parts/article-row' );
								}
								?>
							</ul>
							<?php self::render_pagination(); ?>
						</section>
					<?php elseif ( ! $subcats ) : ?>
						<p class="bridle-kb-empty"><?php esc_html_e( 'No articles in this category yet.', 'bridle-kb' ); ?></p>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Previous and next page links for the main query.
	 */
	private static function render_pagination() {
		$pagination = get_the_posts_pagination(
			[
				'prev_text' => __( 'Previous', 'bridle-kb' ),
				'next_text' => __( 'Next', 'bridle-kb' ),
				'class'     => 'bridle-kb-pagination',
			]
		);
		if ( $pagination ) {
			echo wp_kses_post( $pagination );
		}
	}

	/**
	 * Render the navigation (and, for small screens, the bar that opens it).
	 *
	 * @param array  $nav            From get_nav_data().
	 * @param int    $current_id     The article on screen, 0 for none.
	 * @param int    $current_cat_id The category on screen, or the article's.
	 * @param string $place          What the small-screen bar names.
	 */
	public static function render_nav( $nav, $current_id, $current_cat_id, $place ) {
		self::get_template_part( 'parts/mobile-bar', [ 'place' => $place ] );
		self::get_template_part(
			'parts/single-nav-sidebar',
			[
				'groups'         => $nav['groups'],
				'current_id'     => (int) $current_id,
				'current_cat_id' => (int) $current_cat_id,
			]
		);
	}

	/**
	 * The help center's navigation, Mintlify-style: every top-level category
	 * is a group, its articles in their order (menu order, then title), its
	 * subcategories nested and collapsible, child articles under their
	 * parent. Articles without a category close the list as "Other".
	 *
	 * One query for every published article (capped by `bridle_kb_nav_limit`,
	 * 500 by default), cached until a post or term changes.
	 *
	 * @return array{groups: array, order: array} `order` is every article in
	 *                                            reading order, for previous/next.
	 */
	public static function get_nav_data() {
		$limit = max( 1, (int) apply_filters( 'bridle_kb_nav_limit', 500 ) );
		$key   = 'nav-' . md5(
			implode(
				':',
				[
					wp_cache_get_last_changed( 'posts' ),
					wp_cache_get_last_changed( 'terms' ),
					$limit,
					determine_locale(),
				]
			)
		);
		$nav   = wp_cache_get( $key, self::CACHE_GROUP );
		if ( is_array( $nav ) ) {
			return $nav;
		}

		$terms = get_terms(
			[
				'taxonomy'   => 'docs_category',
				'hide_empty' => false,
				'orderby'    => 'name',
				'order'      => 'ASC',
			]
		);
		$terms = is_wp_error( $terms ) ? [] : $terms;

		$query = new \WP_Query(
			[
				'post_type'              => 'docs',
				'post_status'            => 'publish',
				'posts_per_page'         => $limit,
				'orderby'                => [
					'menu_order' => 'ASC',
					'title'      => 'ASC',
				],
				'no_found_rows'          => true,
				'ignore_sticky_posts'    => true,
				'update_post_meta_cache' => false,
			]
		);

		// Each article sits under its first category, the one the eyebrow
		// and breadcrumbs name; 0 for none.
		$docs_by_term = [];
		foreach ( $query->posts as $post ) {
			$category = self::primary_category( $post->ID );

			$docs_by_term[ $category ? (int) $category->term_id : 0 ][] = [
				'id'     => (int) $post->ID,
				'parent' => (int) $post->post_parent,
				'title'  => $post->post_title,
				'url'    => get_permalink( $post ),
			];
		}

		$known    = array_map( 'intval', wp_list_pluck( $terms, 'term_id' ) );
		$children = [];
		foreach ( $terms as $term ) {
			// A term whose parent is gone counts as top level.
			$parent                = in_array( (int) $term->parent, $known, true ) ? (int) $term->parent : 0;
			$children[ $parent ][] = $term;
		}

		$build = static function ( $term ) use ( &$build, $children, $docs_by_term ) {
			$link = get_term_link( $term );
			$node = [
				'id'       => (int) $term->term_id,
				'name'     => $term->name,
				'url'      => is_wp_error( $link ) ? '' : $link,
				'docs'     => self::nest_docs( $docs_by_term[ $term->term_id ] ?? [] ),
				'children' => [],
			];
			foreach ( $children[ $term->term_id ] ?? [] as $child ) {
				$child_node = $build( $child );
				if ( $child_node['docs'] || $child_node['children'] ) {
					$node['children'][] = $child_node;
				}
			}
			return $node;
		};

		$groups = [];
		foreach ( $children[0] ?? [] as $term ) {
			$node = $build( $term );
			if ( $node['docs'] || $node['children'] ) {
				$groups[] = $node;
			}
		}
		if ( ! empty( $docs_by_term[0] ) ) {
			$groups[] = [
				'id'       => 0,
				'name'     => __( 'Other', 'bridle-kb' ),
				'url'      => '',
				'docs'     => self::nest_docs( $docs_by_term[0] ),
				'children' => [],
			];
		}

		$order = [];
		foreach ( $groups as $group ) {
			self::flatten( $group, $order );
		}

		$nav = [
			'groups' => $groups,
			'order'  => $order,
		];
		wp_cache_set( $key, $nav, self::CACHE_GROUP, HOUR_IN_SECONDS );

		return $nav;
	}

	/**
	 * The navigation's shape with nothing in it.
	 *
	 * @return array{groups: array, order: array}
	 */
	private static function empty_nav() {
		return [
			'groups' => [],
			'order'  => [],
		];
	}

	/**
	 * Put child articles under their parent when the parent is in the same
	 * list; keep the order.
	 *
	 * @param array $docs [ id, parent, title, url ] in order.
	 * @return array The same, top-level only, each with `children`.
	 */
	private static function nest_docs( $docs ) {
		$ids = wp_list_pluck( $docs, 'id' );
		$by  = [];
		foreach ( $docs as $doc ) {
			$doc['children']  = [];
			$by[ $doc['id'] ] = $doc;
		}

		$roots = [];
		foreach ( $docs as $doc ) {
			$parent = $doc['parent'];
			if ( $parent && $parent !== $doc['id'] && in_array( $parent, $ids, true ) ) {
				$by[ $parent ]['children'][] = $doc['id'];
			} else {
				$roots[] = $doc['id'];
			}
		}

		$resolve = static function ( $id, $depth ) use ( &$resolve, $by ) {
			$doc             = $by[ $id ];
			$kids            = $doc['children'];
			$doc['children'] = [];
			// Deep enough for any real hierarchy, and safe against loops.
			if ( $depth < 6 ) {
				foreach ( $kids as $kid ) {
					$doc['children'][] = $resolve( $kid, $depth + 1 );
				}
			}
			return $doc;
		};

		return array_map(
			static function ( $id ) use ( $resolve ) {
				return $resolve( $id, 0 );
			},
			$roots
		);
	}

	/**
	 * Every article of a navigation node in reading order.
	 *
	 * @param array $node  A group or subcategory.
	 * @param array $order Collects [ id, title, url ].
	 */
	private static function flatten( $node, &$order ) {
		$walk = static function ( $docs ) use ( &$walk, &$order ) {
			foreach ( $docs as $doc ) {
				$order[] = [
					'id'    => $doc['id'],
					'title' => $doc['title'],
					'url'   => $doc['url'],
				];
				$walk( $doc['children'] );
			}
		};
		$walk( $node['docs'] );
		foreach ( $node['children'] as $child ) {
			self::flatten( $child, $order );
		}
	}

	/**
	 * The articles before and after one, in navigation order.
	 *
	 * @param array $order   From get_nav_data().
	 * @param int   $post_id The article.
	 * @return array{previous: array|null, next: array|null}
	 */
	public static function neighbours( $order, $post_id ) {
		$ids   = array_map( 'intval', wp_list_pluck( $order, 'id' ) );
		$index = array_search( (int) $post_id, $ids, true );

		if ( false === $index ) {
			return [
				'previous' => null,
				'next'     => null,
			];
		}

		return [
			'previous' => $order[ $index - 1 ] ?? null,
			'next'     => $order[ $index + 1 ] ?? null,
		];
	}

	/**
	 * An article's first category, the one its eyebrow and breadcrumbs name.
	 *
	 * @param int $post_id Article ID.
	 * @return \WP_Term|null
	 */
	public static function primary_category( $post_id ) {
		$terms = get_the_terms( $post_id, 'docs_category' );

		return ( $terms && ! is_wp_error( $terms ) ) ? $terms[0] : null;
	}

	/**
	 * A line about an article for lists: its excerpt, or the start of it.
	 *
	 * @param \WP_Post|int $post Article.
	 * @return string Plain text.
	 */
	public static function summary( $post ) {
		$post = get_post( $post );
		if ( ! $post ) {
			return '';
		}
		if ( has_excerpt( $post ) ) {
			return wp_strip_all_tags( get_the_excerpt( $post ) );
		}

		return wp_trim_words( wp_strip_all_tags( strip_shortcodes( excerpt_remove_blocks( $post->post_content ) ) ), 18 );
	}

	/**
	 * The search field's placeholder: the setting, unless it still holds the
	 * placeholder the plugin used to ship ("Search knowledge base...").
	 *
	 * @return string
	 */
	public static function search_placeholder() {
		$placeholder = trim( (string) bridle_kb_get_option( 'search_placeholder', '' ) );

		if ( '' === $placeholder || 'Search knowledge base...' === $placeholder ) {
			return __( 'Search docs...', 'bridle-kb' );
		}

		return $placeholder;
	}

	/**
	 * Count published articles in a category and all its subcategories.
	 *
	 * @param int $term_id Category term ID.
	 * @return int Total article count.
	 */
	public static function count_category_articles( $term_id ) {
		$q = new \WP_Query(
			[
				'post_type'              => 'docs',
				'post_status'            => 'publish',
				'posts_per_page'         => 1,
				'fields'                 => 'ids',
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
				'tax_query'              => [
					[
						'taxonomy'         => 'docs_category',
						'field'            => 'term_id',
						'terms'            => $term_id,
						'include_children' => true,
					],
				],
			]
		);
		return (int) $q->found_posts;
	}

	/**
	 * Print one of the help center's icons (lucide, 24px grid, 2px stroke).
	 *
	 * @param string $name       Icon name.
	 * @param string $class_name Extra class.
	 */
	public static function icon( $name, $class_name = '' ) {
		$paths = [
			'search'        => '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
			'chevron-right' => '<path d="m9 18 6-6-6-6"/>',
			'chevron-down'  => '<path d="m6 9 6 6 6-6"/>',
			'arrow-left'    => '<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
			'arrow-right'   => '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
			'copy'          => '<rect width="14" height="14" x="8" y="8" rx="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
			'check'         => '<path d="M20 6 9 17l-5-5"/>',
			'menu'          => '<path d="M4 6h16"/><path d="M4 12h16"/><path d="M4 18h16"/>',
			'x'             => '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
			'file'          => '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/>',
			'book'          => '<path d="M12 7v14"/><path d="M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z"/>',
			'list'          => '<path d="M15 12H3"/><path d="M17 18H3"/><path d="M21 6H3"/>',
			'message'       => '<path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/>',
			'sparkles'      => '<path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"/><path d="M20 3v4"/><path d="M22 5h-4"/>',
		];

		if ( ! isset( $paths[ $name ] ) ) {
			return;
		}

		printf(
			'<svg class="%1$s" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">%2$s</svg>',
			esc_attr( trim( 'bridle-kb-icon ' . $class_name ) ),
			$paths[ $name ] // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed SVG markup from the list above.
		);
	}

	/**
	 * Load a template part with optional variables.
	 *
	 * @param string $slug Template part slug (without .php).
	 * @param array  $args Variables to extract into scope.
	 */
	public static function get_template_part( $slug, $args = [] ) {
		$template = self::locate_template( $slug . '.php' );

		if ( $template ) {
			if ( ! empty( $args ) ) {
				extract( $args, EXTR_SKIP ); // phpcs:ignore WordPress.PHP.DontExtract.extract_extract
			}
			include $template;
		}
	}
}
