<?php
/**
 * Import docs from Intercom, Help Scout or Notion.
 *
 * @package BridleKB
 */

namespace BridleKB;

defined( 'ABSPATH' ) || exit;

/**
 * One import at a time. The owner pastes a token, sees what will come in,
 * and starts it; the rest runs in the background in short batches (Action
 * Scheduler when present, else WP-Cron, and the open Docs page keeps it
 * going too): list the source, make the categories, then read and save
 * each article (images into the media library), then point links between
 * imported articles at their new docs.
 *
 * The running import is one transient (`bridle_kb_import`), the token in
 * it, deleted from it as soon as the reading is done and gone with Cancel.
 * Each doc remembers where it came from (`_bridle_kb_import_ref`
 * "{source}:{id}"), so importing again updates it instead of adding a copy.
 * Status, author and categories the owner changed since are kept.
 */
class Importer {

	const JOB  = 'bridle_kb_import';
	const LOCK = 'bridle_kb_import_lock';
	const HOOK = 'bridle_kb_import_run';

	/** How long a job lives without progress, and a finished one is shown. */
	const JOB_TTL  = 12 * HOUR_IN_SECONDS;
	const DONE_TTL = DAY_IN_SECONDS;

	/** Seconds of work per background run, and per nudge from the open page. */
	const RUN_SECONDS   = 20;
	const NUDGE_SECONDS = 8;

	/** Images copied per article, and failures listed. */
	const MAX_IMAGES   = 40;
	const MAX_FAILURES = 20;

	/** Articles in one import. */
	const MAX_ARTICLES = 3000;

	/**
	 * Hooks.
	 */
	public function __construct() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
		add_action( self::HOOK, [ self::class, 'run' ] );
	}

	/**
	 * The import routes. Every one needs a person who may write and publish
	 * other people's articles and upload files: an import creates many docs
	 * and media at once. The REST cookie nonce applies as on every route.
	 */
	public function register_routes() {
		register_rest_route(
			REST::NAMESPACE,
			'/import/preview',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'rest_preview' ],
				'permission_callback' => [ self::class, 'can_import' ],
				'args'                => self::token_args(),
			]
		);
		register_rest_route(
			REST::NAMESPACE,
			'/import',
			[
				[
					'methods'             => 'GET',
					'callback'            => [ $this, 'rest_status' ],
					'permission_callback' => [ self::class, 'can_import' ],
				],
				[
					'methods'             => 'POST',
					'callback'            => [ $this, 'rest_start' ],
					'permission_callback' => [ self::class, 'can_import' ],
					'args'                => self::token_args() + [
						'publish' => [
							'type'    => 'boolean',
							'default' => false,
						],
					],
				],
				[
					'methods'             => 'DELETE',
					'callback'            => [ $this, 'rest_cancel' ],
					'permission_callback' => [ self::class, 'can_import' ],
				],
			]
		);
	}

	/**
	 * Who may import.
	 *
	 * @return bool
	 */
	public static function can_import() {
		return current_user_can( 'edit_others_posts' ) && current_user_can( 'upload_files' );
	}

	/**
	 * The source and token arguments.
	 *
	 * @return array
	 */
	private static function token_args() {
		return [
			'source' => [
				'type'     => 'string',
				'required' => true,
				'enum'     => ImportSources::SOURCES,
			],
			'token'  => [
				'type'              => 'string',
				'required'          => true,
				'sanitize_callback' => static fn( $value ) => trim( preg_replace( '/[\s\x00-\x1f]+/', '', (string) $value ) ),
			],
		];
	}

	/**
	 * POST /import/preview: what the token can see.
	 *
	 * @param \WP_REST_Request $request The request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function rest_preview( $request ) {
		$token = (string) $request['token'];
		if ( '' === $token ) {
			return new \WP_Error( 'bridle_kb_import_token', __( 'Paste a token first.', 'bridle-kb' ), [ 'status' => 400 ] );
		}
		$preview = ImportSources::preview( (string) $request['source'], $token );
		if ( is_wp_error( $preview ) ) {
			$preview->add_data( [ 'status' => 400 ] );
			return $preview;
		}
		return new \WP_REST_Response( $preview );
	}

	/**
	 * POST /import: start an import.
	 *
	 * @param \WP_REST_Request $request The request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function rest_start( $request ) {
		$job = self::job();
		if ( $job && self::active( $job ) ) {
			return new \WP_Error( 'bridle_kb_import_running', __( 'An import is already running.', 'bridle-kb' ), [ 'status' => 409 ] );
		}
		$token = (string) $request['token'];
		if ( '' === $token ) {
			return new \WP_Error( 'bridle_kb_import_token', __( 'Paste a token first.', 'bridle-kb' ), [ 'status' => 400 ] );
		}
		$source = (string) $request['source'];
		$job    = [
			'source'     => $source,
			'token'      => $token,
			'status'     => 'listing',
			'publish'    => (bool) $request['publish'] && current_user_can( 'publish_posts' ),
			'user'       => get_current_user_id(),
			'cursor'     => ImportSources::first_cursor( $source ),
			'categories' => [],
			'terms'      => [],
			'items'      => [],
			'next'       => 0,
			'order'      => [],
			'docs'       => [],
			'link_next'  => 0,
			'created'    => 0,
			'updated'    => 0,
			'failed'     => [],
			'failures'   => 0,
			'error'      => '',
			'retry_at'   => 0,
			'started'    => time(),
			'touched'    => 0,
		];
		self::save( $job );
		self::schedule( 0 );
		return new \WP_REST_Response( self::status( $job ), 201 );
	}

	/**
	 * GET /import: where the import is. While it runs and the background
	 * hasn't moved it for a while (WP-Cron needs visits), this request does
	 * a short batch itself, so an open Docs page always gets it done.
	 *
	 * @return \WP_REST_Response
	 */
	public function rest_status() {
		$job = self::job();
		if ( $job && self::active( $job ) && time() - (int) $job['touched'] > 20 && time() >= (int) $job['retry_at'] ) {
			self::run( self::NUDGE_SECONDS );
			$job = self::job();
		}
		return new \WP_REST_Response( $job ? self::status( $job ) : [ 'status' => 'none' ] );
	}

	/**
	 * DELETE /import: stop. What was imported stays.
	 *
	 * @return \WP_REST_Response
	 */
	public function rest_cancel() {
		$job = self::job();
		if ( $job && self::active( $job ) ) {
			$job['status'] = 'cancelled';
			$job['token']  = '';
			self::save( $job, self::DONE_TTL );
		}
		wp_clear_scheduled_hook( self::HOOK );
		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( self::HOOK, [], 'bridle-kb' );
		}
		$job = self::job();
		return new \WP_REST_Response( $job ? self::status( $job ) : [ 'status' => 'none' ] );
	}

	/**
	 * The job as the Docs page sees it: never the token.
	 *
	 * @param array $job The job.
	 * @return array
	 */
	public static function status( array $job ) {
		return [
			'source'   => $job['source'],
			'status'   => $job['status'],
			'total'    => count( $job['items'] ),
			'done'     => (int) $job['next'],
			'created'  => (int) $job['created'],
			'updated'  => (int) $job['updated'],
			'failures' => (int) $job['failures'],
			'failed'   => array_slice( $job['failed'], 0, self::MAX_FAILURES ),
			'error'    => (string) $job['error'],
			'started'  => (int) $job['started'],
		];
	}

	/**
	 * One background run: a few seconds of work, then the next run is
	 * queued if there's more.
	 *
	 * @param int $seconds Work budget.
	 */
	public static function run( $seconds = self::RUN_SECONDS ) {
		$job = self::job();
		if ( ! $job || ! self::active( $job ) || get_transient( self::LOCK ) ) {
			return;
		}
		if ( time() < (int) $job['retry_at'] ) {
			self::schedule( (int) $job['retry_at'] - time() );
			return;
		}
		set_transient( self::LOCK, 1, MINUTE_IN_SECONDS );
		wp_set_current_user( (int) $job['user'] );
		$until = microtime( true ) + max( 1, (int) $seconds );

		while ( self::active( $job ) && microtime( true ) < $until ) {
			$job = self::step( $job );
			if ( (int) $job['retry_at'] > time() ) {
				break;
			}
		}

		$job['touched'] = time();
		self::save( $job, self::active( $job ) ? self::JOB_TTL : self::DONE_TTL );
		delete_transient( self::LOCK );
		if ( self::active( $job ) ) {
			self::schedule( max( 0, (int) $job['retry_at'] - time() ) );
		}
	}

	/**
	 * One unit of work: a page of the listing, one article, or links for a
	 * batch of docs.
	 *
	 * @param array $job The job.
	 * @return array The job, moved on.
	 */
	private static function step( array $job ) {
		switch ( $job['status'] ) {
			case 'listing':
				$page = ImportSources::list_step( $job['source'], $job['token'], (array) $job['cursor'] );
				if ( is_wp_error( $page ) ) {
					return self::trouble( $job, $page, true );
				}
				$job['categories'] = array_merge( $job['categories'], $page['categories'] );
				$seen              = array_flip( array_column( $job['items'], 'id' ) );
				foreach ( $page['items'] as $item ) {
					if ( ! isset( $seen[ $item['id'] ] ) && count( $job['items'] ) < self::MAX_ARTICLES ) {
						$job['items'][]      = $item;
						$seen[ $item['id'] ] = true;
					}
				}
				$job['cursor'] = $page['cursor'];
				if ( null === $page['cursor'] ) {
					if ( 'notion' === $job['source'] ) {
						$grouped           = ImportSources::notion_groups( $job['items'], $job['categories'] );
						$job['items']      = $grouped['items'];
						$job['categories'] = $grouped['categories'];
					}
					$job['terms']  = self::terms( $job['source'], $job['categories'] );
					$job['status'] = $job['items'] ? 'importing' : 'done';
					if ( ! $job['items'] ) {
						$job['error'] = __( 'The token works, but it sees no articles.', 'bridle-kb' );
						$job['token'] = '';
					}
				}
				return $job;

			case 'importing':
				$item    = $job['items'][ $job['next'] ];
				$article = ImportSources::article( $job['source'], $job['token'], $item );
				if ( is_wp_error( $article ) ) {
					if ( self::retry_after( $article ) ) {
						return self::trouble( $job, $article, false );
					}
					if ( 'bridle_kb_import_token' === $article->get_error_code() ) {
						return self::trouble( $job, $article, true );
					}
					$job = self::failure( $job, (string) $item['title'], $article->get_error_message() );
				} else {
					$job = self::save_doc( $job, $item, $article );
				}
				++$job['next'];
				if ( $job['next'] >= count( $job['items'] ) ) {
					$job['status'] = 'linking';
					// Reading is done: the token goes now.
					$job['token'] = '';
				}
				return $job;

			case 'linking':
				$job['link_next'] = self::link( $job, (int) $job['link_next'], 25 );
				if ( $job['link_next'] >= count( $job['docs'] ) ) {
					$job['status'] = 'done';
				}
				return $job;
		}
		return $job;
	}

	/**
	 * Save one article as a doc: create it, or update the one an earlier
	 * import made.
	 *
	 * @param array $job     The job.
	 * @param array $item    Its listing ref.
	 * @param array $article From ImportSources::article().
	 * @return array The job.
	 */
	private static function save_doc( array $job, array $item, array $article ) {
		$ref      = $job['source'] . ':' . $item['id'];
		$existing = get_posts(
			[
				'post_type'        => 'docs',
				'post_status'      => [ 'publish', 'draft', 'pending', 'private', 'future' ],
				'meta_key'         => '_bridle_kb_import_ref', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- one lookup per imported article.
				'meta_value'       => $ref, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- as above.
				'fields'           => 'ids',
				'numberposts'      => 1,
				'suppress_filters' => false,
			]
		);
		$post_id  = $existing ? (int) $existing[0] : 0;
		$title    = sanitize_text_field( (string) $article['title'] );
		$category = (string) ( $item['category'] ?? '' );
		$order    = (int) ( $job['order'][ $category ] ?? 0 );

		$job['order'][ $category ] = $order + 1;

		$post = [
			'post_type'    => 'docs',
			'post_title'   => '' !== $title ? $title : __( 'Untitled', 'bridle-kb' ),
			'post_excerpt' => sanitize_text_field( (string) $article['excerpt'] ),
			'menu_order'   => $order,
		];
		if ( $post_id ) {
			$post['ID'] = $post_id;
			$saved      = wp_update_post( $post, true );
		} else {
			$post['post_status']  = $job['publish'] && $article['published'] ? 'publish' : 'draft';
			$post['post_author']  = (int) $job['user'];
			$post['post_content'] = '';
			$saved                = wp_insert_post( $post, true );
		}
		if ( is_wp_error( $saved ) || ! $saved ) {
			return self::failure( $job, $title, is_wp_error( $saved ) ? $saved->get_error_message() : __( 'Couldn’t be saved.', 'bridle-kb' ) );
		}
		$post_id = (int) $saved;

		// Images into the media library, attached to the doc.
		$html = ImportHtml::clean( (string) $article['html'] );
		$map  = [];
		$ids  = [];
		foreach ( array_slice( ImportHtml::images( $html ), 0, self::MAX_IMAGES ) as $url ) {
			$copy = self::copy_image( $url, $post_id );
			if ( $copy ) {
				$map[ $url ]         = $copy['url'];
				$ids[ $copy['url'] ] = $copy['id'];
			} else {
				// Kept where it was; better than losing it.
				$map[ $url ] = $url;
			}
		}
		$content = ImportHtml::to_blocks( ImportHtml::replace_images( $html, $map ), $ids );

		wp_update_post(
			[
				'ID'           => $post_id,
				'post_content' => wp_slash( $content ),
			]
		);
		update_post_meta( $post_id, '_bridle_kb_import_ref', $ref );
		update_post_meta( $post_id, '_bridle_kb_import_source', $job['source'] );
		update_post_meta( $post_id, '_bridle_kb_import_key', (string) $article['key'] );

		$term = (int) ( $job['terms'][ $category ] ?? 0 );
		if ( $term && ( ! $existing || ! wp_get_object_terms( $post_id, 'docs_category', [ 'fields' => 'ids' ] ) ) ) {
			wp_set_object_terms( $post_id, [ $term ], 'docs_category' );
		}

		$job['docs'][] = $post_id;
		++$job[ $existing ? 'updated' : 'created' ];
		return $job;
	}

	/**
	 * Copy one image into the media library, or reuse the copy an earlier
	 * import made.
	 *
	 * @param string $url     The image's address.
	 * @param int    $post_id The doc it belongs to.
	 * @return array|null { id, url }
	 */
	private static function copy_image( $url, $post_id ) {
		$hash  = md5( $url );
		$found = get_posts(
			[
				'post_type'   => 'attachment',
				'post_status' => 'inherit',
				'meta_key'    => '_bridle_kb_import_src', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- one lookup per image.
				'meta_value'  => $hash, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- as above.
				'fields'      => 'ids',
				'numberposts' => 1,
			]
		);
		if ( $found ) {
			return [
				'id'  => (int) $found[0],
				'url' => (string) wp_get_attachment_url( (int) $found[0] ),
			];
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		// download_url() fetches through wp_safe_remote_get(): public hosts only.
		$tmp = download_url( $url, 30 );
		if ( is_wp_error( $tmp ) ) {
			return null;
		}
		$name = sanitize_file_name( (string) wp_basename( (string) wp_parse_url( $url, PHP_URL_PATH ) ) );
		if ( ! preg_match( '/\.(jpe?g|png|gif|webp|avif|svg)$/i', $name ) ) {
			$mime = function_exists( 'wp_get_image_mime' ) ? (string) wp_get_image_mime( $tmp ) : '';
			$ext  = [
				'image/jpeg' => 'jpg',
				'image/png'  => 'png',
				'image/gif'  => 'gif',
				'image/webp' => 'webp',
				'image/avif' => 'avif',
			][ $mime ] ?? '';
			if ( '' === $ext ) {
				wp_delete_file( $tmp );
				return null;
			}
			$name = ( '' !== $name ? $name : 'image' ) . '.' . $ext;
		}
		$id = media_handle_sideload(
			[
				'name'     => $name,
				'tmp_name' => $tmp,
			],
			$post_id
		);
		if ( is_wp_error( $id ) ) {
			wp_delete_file( $tmp );
			return null;
		}
		update_post_meta( $id, '_bridle_kb_import_src', $hash );
		return [
			'id'  => (int) $id,
			'url' => (string) wp_get_attachment_url( $id ),
		];
	}

	/**
	 * Make (or find) the categories, parents first.
	 *
	 * @param string $source     The source.
	 * @param array  $categories Source id => { name, parent, description }.
	 * @return array Source id => term id.
	 */
	private static function terms( $source, array $categories ) {
		$terms = [];
		$left  = $categories;
		// Parents first: a few passes settle any depth.
		for ( $pass = 0; $left && $pass < 6; $pass++ ) {
			foreach ( $left as $src => $category ) {
				$parent_src = (string) $category['parent'];
				if ( '' !== $parent_src && isset( $categories[ $parent_src ] ) && ! isset( $terms[ $parent_src ] ) && $pass < 5 ) {
					continue;
				}
				$parent = (int) ( $terms[ $parent_src ] ?? 0 );
				$ref    = $source . ':' . $src;
				$found  = get_terms(
					[
						'taxonomy'   => 'docs_category',
						'hide_empty' => false,
						'fields'     => 'ids',
						'number'     => 1,
						'meta_key'   => '_bridle_kb_import_ref', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- once per category.
						'meta_value' => $ref, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- as above.
					]
				);
				$name   = sanitize_text_field( (string) $category['name'] );
				if ( $found && ! is_wp_error( $found ) ) {
					$term_id = (int) $found[0];
				} else {
					$exists  = '' !== $name ? term_exists( $name, 'docs_category', $parent ) : null;
					$term_id = $exists ? (int) ( is_array( $exists ) ? $exists['term_id'] : $exists ) : 0;
					if ( ! $term_id && '' !== $name ) {
						$made    = wp_insert_term(
							$name,
							'docs_category',
							[
								'parent'      => $parent,
								'description' => sanitize_textarea_field( (string) $category['description'] ),
							]
						);
						$term_id = is_wp_error( $made ) ? 0 : (int) $made['term_id'];
					}
					if ( $term_id ) {
						update_term_meta( $term_id, '_bridle_kb_import_ref', $ref );
					}
				}
				if ( $term_id ) {
					$terms[ $src ] = $term_id;
				}
				unset( $left[ $src ] );
			}
		}
		return $terms;
	}

	/**
	 * Point links between imported articles at their docs, for a batch of
	 * this import's docs.
	 *
	 * @param array $job   The job.
	 * @param int   $from  Index into the job's docs.
	 * @param int   $count How many.
	 * @return int The next index.
	 */
	private static function link( array $job, $from, $count ) {
		$map = [];
		$ids = get_posts(
			[
				'post_type'   => 'docs',
				'post_status' => [ 'publish', 'draft', 'pending', 'private', 'future' ],
				'meta_key'    => '_bridle_kb_import_source', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- once per batch of links.
				'meta_value'  => $job['source'], // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- as above.
				'fields'      => 'ids',
				'numberposts' => -1,
			]
		);
		foreach ( $ids as $id ) {
			$key = (string) get_post_meta( $id, '_bridle_kb_import_key', true );
			if ( '' !== $key ) {
				// A draft has no pretty address yet; this one redirects to it once published.
				$map[ $key ] = 'publish' === get_post_status( $id )
					? (string) get_permalink( $id )
					: add_query_arg(
						[
							'post_type' => 'docs',
							'p'         => $id,
						],
						home_url( '/' )
					);
			}
		}
		$batch = array_slice( $job['docs'], $from, $count );
		foreach ( $batch as $id ) {
			$post = get_post( $id );
			if ( ! $post ) {
				continue;
			}
			$content = ImportHtml::rewrite_links( (string) $post->post_content, $job['source'], $map );
			if ( $content !== $post->post_content ) {
				wp_update_post(
					[
						'ID'           => $id,
						'post_content' => wp_slash( $content ),
					]
				);
			}
		}
		return $from + count( $batch );
	}

	/**
	 * A problem the job can't step past now: wait and retry, or stop.
	 *
	 * @param array     $job   The job.
	 * @param \WP_Error $error What went wrong.
	 * @param bool      $fatal Stop unless the service asked to wait.
	 * @return array
	 */
	private static function trouble( array $job, \WP_Error $error, $fatal ) {
		$wait = self::retry_after( $error );
		if ( $wait ) {
			$job['retry_at'] = time() + $wait;
			return $job;
		}
		if ( $fatal ) {
			$job['status'] = 'failed';
			$job['error']  = $error->get_error_message();
			$job['token']  = '';
		}
		return $job;
	}

	/**
	 * Seconds the service asked to wait, or 0.
	 *
	 * @param \WP_Error $error An error from ImportSources.
	 * @return int
	 */
	private static function retry_after( \WP_Error $error ) {
		$data = $error->get_error_data();
		return is_array( $data ) ? (int) ( $data['retry'] ?? 0 ) : 0;
	}

	/**
	 * Count an article that couldn't come in, keeping the first few.
	 *
	 * @param array  $job     The job.
	 * @param string $title   Its title.
	 * @param string $message Why.
	 * @return array
	 */
	private static function failure( array $job, $title, $message ) {
		++$job['failures'];
		if ( count( $job['failed'] ) < self::MAX_FAILURES ) {
			$job['failed'][] = [
				'title'   => $title,
				'message' => $message,
			];
		}
		return $job;
	}

	/**
	 * Whether a job still has work.
	 *
	 * @param array $job The job.
	 * @return bool
	 */
	private static function active( array $job ) {
		return in_array( $job['status'], [ 'listing', 'importing', 'linking' ], true );
	}

	/**
	 * The job, or null.
	 *
	 * @return array|null
	 */
	private static function job() {
		$job = get_transient( self::JOB );
		return is_array( $job ) && isset( $job['status'], $job['source'] ) ? $job : null;
	}

	/**
	 * Keep the job.
	 *
	 * @param array $job The job.
	 * @param int   $ttl How long.
	 */
	private static function save( array $job, $ttl = self::JOB_TTL ) {
		set_transient( self::JOB, $job, $ttl );
	}

	/**
	 * Queue the next background run.
	 *
	 * @param int $delay Seconds from now.
	 */
	private static function schedule( $delay ) {
		if ( function_exists( 'as_schedule_single_action' ) ) {
			if ( ! as_has_scheduled_action( self::HOOK, [], 'bridle-kb' ) ) {
				as_schedule_single_action( time() + $delay, self::HOOK, [], 'bridle-kb' );
			}
			return;
		}
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_single_event( time() + $delay, self::HOOK );
		}
		if ( 0 === $delay && function_exists( 'spawn_cron' ) ) {
			spawn_cron();
		}
	}
}
