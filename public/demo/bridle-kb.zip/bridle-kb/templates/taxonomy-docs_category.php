<?php
/**
 * Template: a category, in the same shell as an article: its subcategories
 * as cards, then its articles.
 *
 * @package BridleKB
 */

use BridleKB\Templates;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

Templates::render_header();
Templates::render_taxonomy_docs_category_content();
Templates::render_footer();
