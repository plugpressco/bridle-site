<?php
/**
 * Template Part: one article as a card. Kept for theme overrides that
 * include it; the plugin's own lists use parts/article-row.php.
 *
 * @package BridleKB
 */

use BridleKB\Templates;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bridle_kb_summary = Templates::summary( get_post() );
?>
<a href="<?php the_permalink(); ?>" class="bridle-kb-card is-compact">
	<span class="bridle-kb-card-body">
		<span class="bridle-kb-card-title"><?php the_title(); ?><?php Templates::icon( 'arrow-right', 'bridle-kb-card-arrow' ); ?></span>
		<?php if ( $bridle_kb_summary ) : ?>
			<span class="bridle-kb-card-desc"><?php echo esc_html( $bridle_kb_summary ); ?></span>
		<?php endif; ?>
	</span>
</a>
