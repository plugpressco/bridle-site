<?php
/**
 * Template Part: Copy page, Mintlify's split button beside the title. The
 * button copies the article as Markdown; the menu also opens it in an AI
 * chat. Shown once the script is ready (it does the copying).
 *
 * @var string $page_url The article's address.
 *
 * @package BridleKB
 */

use BridleKB\Templates;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* translators: %s: the article's address */
$bridle_kb_prompt  = sprintf( __( 'Read %s so I can ask questions about it.', 'bridle-kb' ), $page_url );
$bridle_kb_chatgpt = 'https://chatgpt.com/?hints=search&q=' . rawurlencode( $bridle_kb_prompt );
$bridle_kb_claude  = 'https://claude.ai/new?q=' . rawurlencode( $bridle_kb_prompt );
?>
<div class="bridle-kb-copy" data-bridle-kb-copy hidden>
	<button type="button" class="bridle-kb-copy-main" data-bridle-kb-copy-page>
		<?php Templates::icon( 'copy', 'is-idle' ); ?>
		<?php Templates::icon( 'check', 'is-done' ); ?>
		<span data-bridle-kb-copy-label><?php esc_html_e( 'Copy page', 'bridle-kb' ); ?></span>
	</button>
	<button type="button" class="bridle-kb-copy-toggle" aria-haspopup="menu" aria-expanded="false" aria-controls="bridle-kb-copy-menu" aria-label="<?php esc_attr_e( 'More ways to use this page', 'bridle-kb' ); ?>">
		<?php Templates::icon( 'chevron-down' ); ?>
	</button>
	<div class="bridle-kb-menu" id="bridle-kb-copy-menu" role="menu" hidden>
		<button type="button" role="menuitem" class="bridle-kb-menu-item" data-bridle-kb-copy-page>
			<?php Templates::icon( 'copy' ); ?>
			<span><strong><?php esc_html_e( 'Copy page', 'bridle-kb' ); ?></strong><small><?php esc_html_e( 'As Markdown, for AI tools', 'bridle-kb' ); ?></small></span>
		</button>
		<a role="menuitem" class="bridle-kb-menu-item" href="<?php echo esc_url( $bridle_kb_chatgpt ); ?>" target="_blank" rel="noopener noreferrer">
			<?php Templates::icon( 'message' ); ?>
			<span><strong><?php esc_html_e( 'Open in ChatGPT', 'bridle-kb' ); ?></strong><small><?php esc_html_e( 'Ask questions about this page', 'bridle-kb' ); ?></small></span>
		</a>
		<a role="menuitem" class="bridle-kb-menu-item" href="<?php echo esc_url( $bridle_kb_claude ); ?>" target="_blank" rel="noopener noreferrer">
			<?php Templates::icon( 'sparkles' ); ?>
			<span><strong><?php esc_html_e( 'Open in Claude', 'bridle-kb' ); ?></strong><small><?php esc_html_e( 'Ask questions about this page', 'bridle-kb' ); ?></small></span>
		</a>
	</div>
</div>
