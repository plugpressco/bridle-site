<?php
/**
 * Template Part: a category card, Mintlify-style: a tinted panel in the
 * category's colour with its icon, then its name, description and count.
 *
 * @var WP_Term $category Category term object; `count` holds the articles in
 *                        it and its subcategories.
 * @var bool    $compact  A smaller card without the panel (subcategories).
 *
 * @package BridleKB
 */

use BridleKB\Templates;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bridle_kb_link = get_term_link( $category );
if ( is_wp_error( $bridle_kb_link ) ) {
	return;
}

$bridle_kb_icon_id  = (int) get_term_meta( $category->term_id, 'category_icon', true );
$bridle_kb_icon_url = $bridle_kb_icon_id ? wp_get_attachment_image_url( $bridle_kb_icon_id, 'thumbnail' ) : '';
$bridle_kb_color    = sanitize_hex_color( (string) get_term_meta( $category->term_id, 'category_color', true ) );
$bridle_kb_style    = $bridle_kb_color ? '--bridle-kb-card-color:' . $bridle_kb_color : '';
$bridle_kb_compact  = ! empty( $compact );
$bridle_kb_count    = (int) $category->count;
?>
<a href="<?php echo esc_url( $bridle_kb_link ); ?>" class="bridle-kb-card<?php echo $bridle_kb_compact ? ' is-compact' : ''; ?>"<?php echo $bridle_kb_style ? ' style="' . esc_attr( $bridle_kb_style ) . '"' : ''; ?>>
	<?php if ( ! $bridle_kb_compact ) : ?>
		<span class="bridle-kb-card-panel" aria-hidden="true">
			<span class="bridle-kb-card-icon">
				<?php if ( $bridle_kb_icon_url ) : ?>
					<img src="<?php echo esc_url( $bridle_kb_icon_url ); ?>" alt="" loading="lazy" />
				<?php else : ?>
					<?php Templates::icon( 'book' ); ?>
				<?php endif; ?>
			</span>
		</span>
	<?php endif; ?>
	<span class="bridle-kb-card-body">
		<span class="bridle-kb-card-title"><?php echo esc_html( $category->name ); ?><?php Templates::icon( 'arrow-right', 'bridle-kb-card-arrow' ); ?></span>
		<?php if ( $category->description ) : ?>
			<span class="bridle-kb-card-desc"><?php echo esc_html( wp_trim_words( $category->description, 24 ) ); ?></span>
		<?php endif; ?>
		<span class="bridle-kb-card-meta">
			<?php
			printf(
				/* translators: %d: number of articles */
				esc_html( _n( '%d article', '%d articles', $bridle_kb_count, 'bridle-kb' ) ),
				(int) $bridle_kb_count
			);
			?>
		</span>
	</span>
</a>
