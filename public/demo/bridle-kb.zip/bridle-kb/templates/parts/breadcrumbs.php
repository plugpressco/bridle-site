<?php
/**
 * Template Part: Breadcrumbs. The help center's own pages show an eyebrow
 * instead; this part stays for themes and code that call
 * Breadcrumbs::render().
 *
 * @var array $items Breadcrumb items: [ label, url|null ].
 *
 * @package BridleKB
 */

use BridleKB\Templates;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( empty( $items ) ) {
	return;
}
?>
<nav class="bridle-kb-breadcrumbs" aria-label="<?php esc_attr_e( 'Breadcrumb', 'bridle-kb' ); ?>">
	<ol class="bridle-kb-breadcrumbs-list">
		<?php foreach ( $items as $bridle_kb_index => $bridle_kb_crumb ) : ?>
			<li class="bridle-kb-breadcrumbs-item">
				<?php
				if ( $bridle_kb_index > 0 ) {
					Templates::icon( 'chevron-right', 'bridle-kb-breadcrumbs-sep' );
				}
				?>
				<?php if ( $bridle_kb_crumb['url'] ) : ?>
					<a href="<?php echo esc_url( $bridle_kb_crumb['url'] ); ?>" class="bridle-kb-breadcrumbs-link"><?php echo esc_html( $bridle_kb_crumb['label'] ); ?></a>
				<?php else : ?>
					<span class="bridle-kb-breadcrumbs-current" aria-current="page"><?php echo esc_html( $bridle_kb_crumb['label'] ); ?></span>
				<?php endif; ?>
			</li>
		<?php endforeach; ?>
	</ol>
</nav>
