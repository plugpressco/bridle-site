<?php
/**
 * Template Part: "On this page", the article's headings on the right. The
 * script marks the section in view.
 *
 * @var array $items TOC heading items: [ id, text, level ].
 *
 * @package BridleKB
 */

use BridleKB\Templates;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( empty( $items ) ) {
	return;
}
?>
<nav class="bridle-kb-toc" aria-labelledby="bridle-kb-toc-title">
	<p class="bridle-kb-toc-title" id="bridle-kb-toc-title"><?php Templates::icon( 'list' ); ?><?php esc_html_e( 'On this page', 'bridle-kb' ); ?></p>
	<ul class="bridle-kb-toc-list">
		<?php foreach ( $items as $bridle_kb_item ) : ?>
			<li class="bridle-kb-toc-item" data-level="<?php echo esc_attr( (string) $bridle_kb_item['level'] ); ?>"><a href="#<?php echo esc_attr( $bridle_kb_item['id'] ); ?>"><?php echo esc_html( $bridle_kb_item['text'] ); ?></a></li>
		<?php endforeach; ?>
	</ul>
</nav>
