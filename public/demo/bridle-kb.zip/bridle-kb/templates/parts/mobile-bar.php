<?php
/**
 * Template Part: the bar above the page on small screens. Its button opens
 * the navigation as a sheet; search sits on the right.
 *
 * @var string $place The category (or article's category) on screen.
 *
 * @package BridleKB
 */

use BridleKB\Templates;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="bridle-kb-mobilebar">
	<button type="button" class="bridle-kb-menu-button" aria-controls="bridle-kb-nav" aria-expanded="false" data-bridle-kb-nav-open>
		<?php Templates::icon( 'menu' ); ?>
		<span><?php echo esc_html( ! empty( $place ) ? $place : __( 'Menu', 'bridle-kb' ) ); ?></span>
	</button>
	<button type="button" class="bridle-kb-icon-button" data-bridle-kb-search aria-label="<?php esc_attr_e( 'Search docs', 'bridle-kb' ); ?>">
		<?php Templates::icon( 'search' ); ?>
	</button>
</div>
