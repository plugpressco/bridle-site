<?php
/**
 * Template Part: the search field on the help center's home. It is a real
 * form, so a search works without scripts; with them, it opens the search
 * dialog with live results.
 *
 * @var string $value What was searched, on a results page.
 *
 * @package BridleKB
 */

use BridleKB\Templates;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<form class="bridle-kb-search-form" role="search" action="<?php echo esc_url( get_post_type_archive_link( 'docs' ) ); ?>">
	<label class="bridle-kb-sr-only" for="bridle-kb-search-input"><?php esc_html_e( 'Search docs', 'bridle-kb' ); ?></label>
	<?php Templates::icon( 'search', 'bridle-kb-search-icon' ); ?>
	<input type="search" id="bridle-kb-search-input" name="s" class="bridle-kb-search-input" value="<?php echo esc_attr( $value ?? '' ); ?>" placeholder="<?php echo esc_attr( Templates::search_placeholder() ); ?>" autocomplete="off" data-bridle-kb-search />
	<kbd class="bridle-kb-search-kbd" aria-hidden="true">/</kbd>
	<input type="hidden" name="post_type" value="docs" />
</form>
