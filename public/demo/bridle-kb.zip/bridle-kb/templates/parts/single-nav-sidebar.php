<?php
/**
 * Template Part: the help center's navigation, Mintlify-style.
 *
 * Every top-level category is a group under a small label; its articles
 * follow in order, child articles indented under their parent, and its
 * subcategories fold open. On small screens the same list slides in as a
 * sheet from the bar above the article (parts/mobile-bar.php).
 *
 * @var array $groups         From Templates::get_nav_data().
 * @var int   $current_id     The article on screen, 0 for none.
 * @var int   $current_cat_id The category on screen, or the article's.
 *
 * @package BridleKB
 */

use BridleKB\Templates;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bridle_kb_groups     = $groups ?? [];
$bridle_kb_current    = (int) ( $current_id ?? 0 );
$bridle_kb_current_ct = (int) ( $current_cat_id ?? 0 );

// Whether a subcategory holds what is on screen, so it starts open.
$bridle_kb_holds = static function ( $node ) use ( &$bridle_kb_holds, $bridle_kb_current, $bridle_kb_current_ct ) {
	if ( $bridle_kb_current_ct && (int) $node['id'] === $bridle_kb_current_ct ) {
		return true;
	}
	$in_docs = static function ( $docs ) use ( &$in_docs, $bridle_kb_current ) {
		foreach ( $docs as $doc ) {
			if ( (int) $doc['id'] === $bridle_kb_current || $in_docs( $doc['children'] ) ) {
				return true;
			}
		}
		return false;
	};
	if ( $bridle_kb_current && $in_docs( $node['docs'] ) ) {
		return true;
	}
	foreach ( $node['children'] as $child ) {
		if ( $bridle_kb_holds( $child ) ) {
			return true;
		}
	}
	return false;
};

$bridle_kb_docs = static function ( $docs ) use ( &$bridle_kb_docs, $bridle_kb_current ) {
	foreach ( $docs as $doc ) {
		$is_current = (int) $doc['id'] === $bridle_kb_current;
		?>
		<li>
			<a href="<?php echo esc_url( $doc['url'] ); ?>" class="bridle-kb-nav-link<?php echo $is_current ? ' is-active' : ''; ?>"<?php echo $is_current ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $doc['title'] ); ?></a>
			<?php if ( $doc['children'] ) : ?>
				<ul class="bridle-kb-nav-list is-nested"><?php $bridle_kb_docs( $doc['children'] ); ?></ul>
			<?php endif; ?>
		</li>
		<?php
	}
};

$bridle_kb_subcategory = static function ( $node ) use ( &$bridle_kb_subcategory, $bridle_kb_docs, $bridle_kb_holds ) {
	?>
	<li>
		<details class="bridle-kb-nav-sub"<?php echo $bridle_kb_holds( $node ) ? ' open' : ''; ?>>
			<summary class="bridle-kb-nav-link"><span><?php echo esc_html( $node['name'] ); ?></span><?php Templates::icon( 'chevron-right', 'bridle-kb-nav-chevron' ); ?></summary>
			<ul class="bridle-kb-nav-list is-nested">
				<?php
				$bridle_kb_docs( $node['docs'] );
				foreach ( $node['children'] as $child ) {
					$bridle_kb_subcategory( $child );
				}
				?>
			</ul>
		</details>
	</li>
	<?php
};
?>
<div class="bridle-kb-nav-overlay" data-bridle-kb-nav-close hidden></div>
<nav class="bridle-kb-nav" id="bridle-kb-nav" aria-label="<?php esc_attr_e( 'Docs', 'bridle-kb' ); ?>">
	<div class="bridle-kb-nav-inner">
		<div class="bridle-kb-nav-head">
			<button type="button" class="bridle-kb-search-trigger is-compact" data-bridle-kb-search>
				<?php Templates::icon( 'search' ); ?>
				<span><?php esc_html_e( 'Search', 'bridle-kb' ); ?></span>
				<kbd aria-hidden="true">/</kbd>
			</button>
			<button type="button" class="bridle-kb-icon-button bridle-kb-nav-dismiss" data-bridle-kb-nav-close aria-label="<?php esc_attr_e( 'Close menu', 'bridle-kb' ); ?>">
				<?php Templates::icon( 'x' ); ?>
			</button>
		</div>

		<?php if ( has_nav_menu( 'bridle_kb_sidebar_top' ) ) : ?>
			<div class="bridle-kb-nav-menu">
				<?php
				wp_nav_menu(
					[
						'theme_location' => 'bridle_kb_sidebar_top',
						'menu_class'     => 'bridle-kb-nav-list',
						'container'      => false,
						'depth'          => 2,
					]
				);
				?>
			</div>
		<?php endif; ?>

		<?php foreach ( $bridle_kb_groups as $bridle_kb_group ) : ?>
			<div class="bridle-kb-nav-group">
				<p class="bridle-kb-nav-label">
					<?php if ( $bridle_kb_group['url'] ) : ?>
						<a href="<?php echo esc_url( $bridle_kb_group['url'] ); ?>"<?php echo (int) $bridle_kb_group['id'] === $bridle_kb_current_ct && ! $bridle_kb_current ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $bridle_kb_group['name'] ); ?></a>
					<?php else : ?>
						<?php echo esc_html( $bridle_kb_group['name'] ); ?>
					<?php endif; ?>
				</p>
				<ul class="bridle-kb-nav-list">
					<?php
					$bridle_kb_docs( $bridle_kb_group['docs'] );
					foreach ( $bridle_kb_group['children'] as $bridle_kb_child ) {
						$bridle_kb_subcategory( $bridle_kb_child );
					}
					?>
				</ul>
			</div>
		<?php endforeach; ?>

		<?php if ( ! $bridle_kb_groups ) : ?>
			<p class="bridle-kb-nav-empty"><a href="<?php echo esc_url( get_post_type_archive_link( 'docs' ) ); ?>"><?php esc_html_e( 'Browse all articles', 'bridle-kb' ); ?></a></p>
		<?php endif; ?>

		<?php if ( has_nav_menu( 'bridle_kb_sidebar_bottom' ) ) : ?>
			<div class="bridle-kb-nav-menu">
				<?php
				wp_nav_menu(
					[
						'theme_location' => 'bridle_kb_sidebar_bottom',
						'menu_class'     => 'bridle-kb-nav-list',
						'container'      => false,
						'depth'          => 2,
					]
				);
				?>
			</div>
		<?php endif; ?>
	</div>
</nav>
