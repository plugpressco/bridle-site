<?php
/**
 * Template Part: one article in a list (a category, search results, the
 * home without categories): title, a line about it, an arrow.
 *
 * @var bool $show_category Name the article's category above the title.
 *
 * @package BridleKB
 */

use BridleKB\Templates;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bridle_kb_summary  = Templates::summary( get_post() );
$bridle_kb_category = ! empty( $show_category ) ? Templates::primary_category( get_the_ID() ) : null;
?>
<li class="bridle-kb-row">
	<a href="<?php the_permalink(); ?>" class="bridle-kb-row-link">
		<span class="bridle-kb-row-body">
			<?php if ( $bridle_kb_category ) : ?>
				<span class="bridle-kb-row-eyebrow"><?php echo esc_html( $bridle_kb_category->name ); ?></span>
			<?php endif; ?>
			<span class="bridle-kb-row-title"><?php the_title(); ?></span>
			<?php if ( $bridle_kb_summary ) : ?>
				<span class="bridle-kb-row-summary"><?php echo esc_html( $bridle_kb_summary ); ?></span>
			<?php endif; ?>
		</span>
		<?php Templates::icon( 'chevron-right', 'bridle-kb-row-arrow' ); ?>
	</a>
</li>
