<?php
/**
 * Template Part: the previous and next articles, in navigation order.
 *
 * @var array|null $previous [ id, title, url ] or null.
 * @var array|null $next     [ id, title, url ] or null.
 *
 * @package BridleKB
 */

use BridleKB\Templates;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( empty( $previous ) && empty( $next ) ) {
	return;
}
?>
<nav class="bridle-kb-pager" aria-label="<?php esc_attr_e( 'More articles', 'bridle-kb' ); ?>">
	<?php if ( ! empty( $previous ) ) : ?>
		<a class="bridle-kb-pager-link is-previous" href="<?php echo esc_url( $previous['url'] ); ?>" rel="prev">
			<span class="bridle-kb-pager-label"><?php Templates::icon( 'arrow-left' ); ?><?php esc_html_e( 'Previous', 'bridle-kb' ); ?></span>
			<span class="bridle-kb-pager-title"><?php echo esc_html( $previous['title'] ); ?></span>
		</a>
	<?php else : ?>
		<span></span>
	<?php endif; ?>
	<?php if ( ! empty( $next ) ) : ?>
		<a class="bridle-kb-pager-link is-next" href="<?php echo esc_url( $next['url'] ); ?>" rel="next">
			<span class="bridle-kb-pager-label"><?php esc_html_e( 'Next', 'bridle-kb' ); ?><?php Templates::icon( 'arrow-right' ); ?></span>
			<span class="bridle-kb-pager-title"><?php echo esc_html( $next['title'] ); ?></span>
		</a>
	<?php endif; ?>
</nav>
