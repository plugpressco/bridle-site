<?php
/**
 * Template: the help center's home (and its search results): a centred
 * title over one search, then a card for each topic.
 *
 * @package BridleKB
 */

use BridleKB\Templates;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

Templates::render_header();
Templates::render_archive_docs_content();
Templates::render_footer();
