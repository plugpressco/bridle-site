<?php
/**
 * Template: one article, Mintlify-style: the navigation on the left, the
 * article in the middle, "On this page" on the right.
 *
 * @package BridleKB
 */

use BridleKB\Templates;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

Templates::render_header();
Templates::render_single_docs_content();
Templates::render_footer();
